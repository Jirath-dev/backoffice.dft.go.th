<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class rpt3_ReEdi_A 
    Inherits DataDynamics.ActiveReports.ActiveReport3 

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
        End If
        MyBase.Dispose(disposing)
    End Sub
    
    'NOTE: The following procedure is required by the ActiveReports Designer
    'It can be modified using the ActiveReports Designer.
    'Do not modify it using the code editor.
    Private WithEvents PageHeader1 As DataDynamics.ActiveReports.PageHeader
    Private WithEvents Detail1 As DataDynamics.ActiveReports.Detail
    Private WithEvents PageFooter1 As DataDynamics.ActiveReports.PageFooter
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(rpt3_ReEdi_A))
        Me.TextBox23 = New DataDynamics.ActiveReports.TextBox
        Me.txtForm_Name_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtForm_Name = New DataDynamics.ActiveReports.TextBox
        Me.TextBox1 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox2 = New DataDynamics.ActiveReports.TextBox
        Me.txtrequest_person = New DataDynamics.ActiveReports.TextBox
        Me.Barcode1_invh_run_auto = New DataDynamics.ActiveReports.Barcode
        Me.txtinvh_run_auto = New DataDynamics.ActiveReports.TextBox
        Me.TextBox3 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox4 = New DataDynamics.ActiveReports.TextBox
        Me.txtREFERENCE_CODE2_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtREFERENCE_CODE2 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox5 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox6 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox7 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox8 = New DataDynamics.ActiveReports.TextBox
        Me.txtcard_id_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtcard_id = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_name = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_taxno_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_taxno = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_address_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_address = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_phone_fax_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_phone = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_fax = New DataDynamics.ActiveReports.TextBox
        Me.TextBox9 = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_company = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_address_province_dest_receive_country = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_address = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_province = New DataDynamics.ActiveReports.TextBox
        Me.txtdest_receive_country = New DataDynamics.ActiveReports.TextBox
        Me.txtimport_country_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtimport_country = New DataDynamics.ActiveReports.TextBox
        Me.TextBox10 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox11 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox12 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox13 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox14 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox15 = New DataDynamics.ActiveReports.TextBox
        Me.txtship_by0 = New DataDynamics.ActiveReports.TextBox
        Me.txtship_by1 = New DataDynamics.ActiveReports.TextBox
        Me.txtship_by2 = New DataDynamics.ActiveReports.TextBox
        Me.txtship_by3 = New DataDynamics.ActiveReports.TextBox
        Me.txtship_by4 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox21 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox22 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox24 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox25 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox26 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox27 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox28 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox29 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox30 = New DataDynamics.ActiveReports.TextBox
        Me.txtship_by = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_phone = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_fax = New DataDynamics.ActiveReports.TextBox
        Me.txtTARIFF_CODE_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtNET_WEIGHT_unit_code2 = New DataDynamics.ActiveReports.TextBox
        Me.txtFOB_AMT_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtPRODUCT_NAME = New DataDynamics.ActiveReports.TextBox
        Me.txtNum_Product = New DataDynamics.ActiveReports.TextBox
        Me.txtTARIFF_CODE = New DataDynamics.ActiveReports.TextBox
        Me.txtNET_WEIGHT = New DataDynamics.ActiveReports.TextBox
        Me.txtFOB_AMT = New DataDynamics.ActiveReports.TextBox
        Me.txtunit_code2 = New DataDynamics.ActiveReports.TextBox
        Me.C_TotalRowDe = New DataDynamics.ActiveReports.TextBox
        Me.TextBox33 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox31 = New DataDynamics.ActiveReports.TextBox
        Me.txtTotal = New DataDynamics.ActiveReports.TextBox
        Me.txtSum_Net_Weight = New DataDynamics.ActiveReports.TextBox
        Me.txtSum_Fob_Amt = New DataDynamics.ActiveReports.TextBox
        Me.txtSum_Gross_Weight = New DataDynamics.ActiveReports.TextBox
        Me.TextBox32 = New DataDynamics.ActiveReports.TextBox
        Me.txtbill_type0 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox34 = New DataDynamics.ActiveReports.TextBox
        Me.txtbill_type1 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox36 = New DataDynamics.ActiveReports.TextBox
        Me.txtbill_type2 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox38 = New DataDynamics.ActiveReports.TextBox
        Me.txtbill_type3 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox40 = New DataDynamics.ActiveReports.TextBox
        Me.txtbill_type_other = New DataDynamics.ActiveReports.TextBox
        Me.TextBox41 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox42 = New DataDynamics.ActiveReports.TextBox
        Me.txtbl_no = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_sailing_date = New DataDynamics.ActiveReports.TextBox
        Me.TextBox44 = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_edi_date = New DataDynamics.ActiveReports.TextBox
        Me.TextBox45 = New DataDynamics.ActiveReports.TextBox
        Me.txtbill_type = New DataDynamics.ActiveReports.TextBox
        Me.TextBox16 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox17 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox18 = New DataDynamics.ActiveReports.TextBox
        Me.txtattach_file = New DataDynamics.ActiveReports.TextBox
        Me.TextBox19 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox20 = New DataDynamics.ActiveReports.TextBox
        Me.txtfactory = New DataDynamics.ActiveReports.TextBox
        Me.txtfactory_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtfactory_address = New DataDynamics.ActiveReports.TextBox
        Me.TextBox35 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox37 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox39 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox43 = New DataDynamics.ActiveReports.TextBox
        Me.txtrequest_person_2 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox46 = New DataDynamics.ActiveReports.TextBox
        Me.txtauthorize2 = New DataDynamics.ActiveReports.TextBox
        Me.txtedi_date = New DataDynamics.ActiveReports.TextBox
        Me.txtsailing_date = New DataDynamics.ActiveReports.TextBox
        Me.PageHeader1 = New DataDynamics.ActiveReports.PageHeader
        Me.Shape1 = New DataDynamics.ActiveReports.Shape
        Me.Line1 = New DataDynamics.ActiveReports.Line
        Me.Line2 = New DataDynamics.ActiveReports.Line
        Me.Line3 = New DataDynamics.ActiveReports.Line
        Me.Line4 = New DataDynamics.ActiveReports.Line
        Me.Detail1 = New DataDynamics.ActiveReports.Detail
        Me.Line5 = New DataDynamics.ActiveReports.Line
        Me.Line7 = New DataDynamics.ActiveReports.Line
        Me.Line10 = New DataDynamics.ActiveReports.Line
        Me.Line8 = New DataDynamics.ActiveReports.Line
        Me.Line12 = New DataDynamics.ActiveReports.Line
        Me.Line13 = New DataDynamics.ActiveReports.Line
        Me.PageFooter1 = New DataDynamics.ActiveReports.PageFooter
        Me.Shape4 = New DataDynamics.ActiveReports.Shape
        Me.Shape3 = New DataDynamics.ActiveReports.Shape
        Me.Shape5 = New DataDynamics.ActiveReports.Shape
        Me.Line6 = New DataDynamics.ActiveReports.Line
        Me.GroupHeader1 = New DataDynamics.ActiveReports.GroupHeader
        Me.GroupFooter1 = New DataDynamics.ActiveReports.GroupFooter
        Me.Line9 = New DataDynamics.ActiveReports.Line
        Me.Line11 = New DataDynamics.ActiveReports.Line
        Me.Line14 = New DataDynamics.ActiveReports.Line
        Me.Line15 = New DataDynamics.ActiveReports.Line
        Me.Line16 = New DataDynamics.ActiveReports.Line
        CType(Me.TextBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtForm_Name_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtForm_Name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtrequest_person, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtREFERENCE_CODE2_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtREFERENCE_CODE2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcard_id_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcard_id, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_taxno_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_address_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_phone_fax_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_address_province_dest_receive_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_receive_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtimport_country_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtimport_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtship_by0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtship_by1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtship_by2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtship_by3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtship_by4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtship_by, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTARIFF_CODE_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNET_WEIGHT_unit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOB_AMT_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPRODUCT_NAME, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNum_Product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTARIFF_CODE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNET_WEIGHT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOB_AMT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSum_Net_Weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSum_Fob_Amt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSum_Gross_Weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbill_type0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbill_type1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbill_type2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbill_type3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbill_type_other, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbl_no, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_sailing_date, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_edi_date, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbill_type, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtattach_file, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtfactory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtfactory_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtfactory_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtrequest_person_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtauthorize2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtedi_date, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtsailing_date, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'TextBox23
        '
        Me.TextBox23.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox23.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox23.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox23.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox23.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox23.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox23.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox23.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox23, "TextBox23")
        Me.TextBox23.DistinctField = Nothing
        Me.TextBox23.Height = 0.3937008!
        Me.TextBox23.Left = 2.485236!
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.OutputFormat = resources.GetString("TextBox23.OutputFormat")
        Me.TextBox23.SummaryGroup = Nothing
        Me.TextBox23.Top = 4.429134!
        Me.TextBox23.Width = 0.4183071!
        '
        'txtForm_Name_Temp
        '
        Me.txtForm_Name_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtForm_Name_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtForm_Name_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtForm_Name_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtForm_Name_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtForm_Name_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtForm_Name_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtForm_Name_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtForm_Name_Temp, "txtForm_Name_Temp")
        Me.txtForm_Name_Temp.DistinctField = Nothing
        Me.txtForm_Name_Temp.Height = 0.3937008!
        Me.txtForm_Name_Temp.Left = 0.0!
        Me.txtForm_Name_Temp.Name = "txtForm_Name_Temp"
        Me.txtForm_Name_Temp.OutputFormat = resources.GetString("txtForm_Name_Temp.OutputFormat")
        Me.txtForm_Name_Temp.SummaryGroup = Nothing
        Me.txtForm_Name_Temp.Text = Nothing
        Me.txtForm_Name_Temp.Top = 0.9350393!
        Me.txtForm_Name_Temp.Width = 8.267716!
        '
        'txtForm_Name
        '
        Me.txtForm_Name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtForm_Name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtForm_Name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtForm_Name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtForm_Name.Border.RightColor = System.Drawing.Color.Black
        Me.txtForm_Name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtForm_Name.Border.TopColor = System.Drawing.Color.Black
        Me.txtForm_Name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtForm_Name, "txtForm_Name")
        Me.txtForm_Name.DataField = "Form_Name"
        Me.txtForm_Name.DistinctField = Nothing
        Me.txtForm_Name.Height = 0.2706693!
        Me.txtForm_Name.Left = 0.1476378!
        Me.txtForm_Name.Name = "txtForm_Name"
        Me.txtForm_Name.OutputFormat = resources.GetString("txtForm_Name.OutputFormat")
        Me.txtForm_Name.SummaryGroup = Nothing
        Me.txtForm_Name.Top = 0.1722441!
        Me.txtForm_Name.Visible = False
        Me.txtForm_Name.Width = 0.8366142!
        '
        'TextBox1
        '
        Me.TextBox1.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox1, "TextBox1")
        Me.TextBox1.DistinctField = Nothing
        Me.TextBox1.Height = 0.3937008!
        Me.TextBox1.Left = 0.2214567!
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.OutputFormat = resources.GetString("TextBox1.OutputFormat")
        Me.TextBox1.SummaryGroup = Nothing
        Me.TextBox1.Top = 1.402559!
        Me.TextBox1.Width = 0.4675197!
        '
        'TextBox2
        '
        Me.TextBox2.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox2, "TextBox2")
        Me.TextBox2.DistinctField = Nothing
        Me.TextBox2.Height = 0.3937008!
        Me.TextBox2.Left = 0.6889763!
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.OutputFormat = resources.GetString("TextBox2.OutputFormat")
        Me.TextBox2.SummaryGroup = Nothing
        Me.TextBox2.Top = 1.402559!
        Me.TextBox2.Width = 0.4675197!
        '
        'txtrequest_person
        '
        Me.txtrequest_person.Border.BottomColor = System.Drawing.Color.Black
        Me.txtrequest_person.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person.Border.LeftColor = System.Drawing.Color.Black
        Me.txtrequest_person.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person.Border.RightColor = System.Drawing.Color.Black
        Me.txtrequest_person.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person.Border.TopColor = System.Drawing.Color.Black
        Me.txtrequest_person.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtrequest_person, "txtrequest_person")
        Me.txtrequest_person.DataField = "request_person"
        Me.txtrequest_person.DistinctField = Nothing
        Me.txtrequest_person.Height = 0.3937007!
        Me.txtrequest_person.Left = 1.107283!
        Me.txtrequest_person.Name = "txtrequest_person"
        Me.txtrequest_person.OutputFormat = resources.GetString("txtrequest_person.OutputFormat")
        Me.txtrequest_person.SummaryGroup = Nothing
        Me.txtrequest_person.Top = 1.402559!
        Me.txtrequest_person.Width = 2.091535!
        '
        'Barcode1_invh_run_auto
        '
        Me.Barcode1_invh_run_auto.Border.BottomColor = System.Drawing.Color.Black
        Me.Barcode1_invh_run_auto.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Barcode1_invh_run_auto.Border.LeftColor = System.Drawing.Color.Black
        Me.Barcode1_invh_run_auto.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Barcode1_invh_run_auto.Border.RightColor = System.Drawing.Color.Black
        Me.Barcode1_invh_run_auto.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Barcode1_invh_run_auto.Border.TopColor = System.Drawing.Color.Black
        Me.Barcode1_invh_run_auto.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Barcode1_invh_run_auto.DataField = "invh_run_auto"
        Me.Barcode1_invh_run_auto.Font = New System.Drawing.Font("BrowalliaUPC", 13.0!)
        Me.Barcode1_invh_run_auto.Height = 0.492126!
        Me.Barcode1_invh_run_auto.Left = 5.167323!
        Me.Barcode1_invh_run_auto.Name = "Barcode1_invh_run_auto"
        resources.ApplyResources(Me.Barcode1_invh_run_auto, "Barcode1_invh_run_auto")
        Me.Barcode1_invh_run_auto.Top = 0.1476378!
        Me.Barcode1_invh_run_auto.Width = 2.805118!
        '
        'txtinvh_run_auto
        '
        Me.txtinvh_run_auto.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtinvh_run_auto, "txtinvh_run_auto")
        Me.txtinvh_run_auto.DataField = "invh_run_auto"
        Me.txtinvh_run_auto.DistinctField = Nothing
        Me.txtinvh_run_auto.Height = 0.3937007!
        Me.txtinvh_run_auto.Left = 5.167323!
        Me.txtinvh_run_auto.Name = "txtinvh_run_auto"
        Me.txtinvh_run_auto.OutputFormat = resources.GetString("txtinvh_run_auto.OutputFormat")
        Me.txtinvh_run_auto.SummaryGroup = Nothing
        Me.txtinvh_run_auto.Top = 0.7135827!
        Me.txtinvh_run_auto.Width = 2.780512!
        '
        'TextBox3
        '
        Me.TextBox3.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox3.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox3.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox3.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox3, "TextBox3")
        Me.TextBox3.DistinctField = Nothing
        Me.TextBox3.Height = 0.3937007!
        Me.TextBox3.Left = 3.248032!
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.OutputFormat = resources.GetString("TextBox3.OutputFormat")
        Me.TextBox3.SummaryGroup = Nothing
        Me.TextBox3.Top = 1.402559!
        Me.TextBox3.Width = 2.386811!
        '
        'TextBox4
        '
        Me.TextBox4.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox4.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox4.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox4.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox4, "TextBox4")
        Me.TextBox4.DistinctField = Nothing
        Me.TextBox4.Height = 0.3937007!
        Me.TextBox4.Left = 0.2214567!
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.OutputFormat = resources.GetString("TextBox4.OutputFormat")
        Me.TextBox4.SummaryGroup = Nothing
        Me.TextBox4.Top = 1.673228!
        Me.TextBox4.Width = 5.413386!
        '
        'txtREFERENCE_CODE2_Temp
        '
        Me.txtREFERENCE_CODE2_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtREFERENCE_CODE2_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtREFERENCE_CODE2_Temp, "txtREFERENCE_CODE2_Temp")
        Me.txtREFERENCE_CODE2_Temp.DistinctField = Nothing
        Me.txtREFERENCE_CODE2_Temp.Height = 0.3937007!
        Me.txtREFERENCE_CODE2_Temp.Left = 5.634842!
        Me.txtREFERENCE_CODE2_Temp.Name = "txtREFERENCE_CODE2_Temp"
        Me.txtREFERENCE_CODE2_Temp.OutputFormat = resources.GetString("txtREFERENCE_CODE2_Temp.OutputFormat")
        Me.txtREFERENCE_CODE2_Temp.SummaryGroup = Nothing
        Me.txtREFERENCE_CODE2_Temp.Text = Nothing
        Me.txtREFERENCE_CODE2_Temp.Top = 1.402559!
        Me.txtREFERENCE_CODE2_Temp.Width = 2.401575!
        '
        'txtREFERENCE_CODE2
        '
        Me.txtREFERENCE_CODE2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2.Border.RightColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2.Border.TopColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtREFERENCE_CODE2, "txtREFERENCE_CODE2")
        Me.txtREFERENCE_CODE2.DataField = "REFERENCE_CODE2"
        Me.txtREFERENCE_CODE2.DistinctField = Nothing
        Me.txtREFERENCE_CODE2.Height = 0.2706693!
        Me.txtREFERENCE_CODE2.Left = 0.1476378!
        Me.txtREFERENCE_CODE2.Name = "txtREFERENCE_CODE2"
        Me.txtREFERENCE_CODE2.OutputFormat = resources.GetString("txtREFERENCE_CODE2.OutputFormat")
        Me.txtREFERENCE_CODE2.SummaryGroup = Nothing
        Me.txtREFERENCE_CODE2.Top = 0.5054134!
        Me.txtREFERENCE_CODE2.Visible = False
        Me.txtREFERENCE_CODE2.Width = 0.8366142!
        '
        'TextBox5
        '
        Me.TextBox5.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox5, "TextBox5")
        Me.TextBox5.DistinctField = Nothing
        Me.TextBox5.Height = 0.3937007!
        Me.TextBox5.Left = 5.634842!
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.OutputFormat = resources.GetString("TextBox5.OutputFormat")
        Me.TextBox5.SummaryGroup = Nothing
        Me.TextBox5.Top = 1.845472!
        Me.TextBox5.Width = 2.401575!
        '
        'TextBox6
        '
        Me.TextBox6.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox6.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox6.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox6.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox6, "TextBox6")
        Me.TextBox6.DistinctField = Nothing
        Me.TextBox6.Height = 0.3937007!
        Me.TextBox6.Left = 5.733268!
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.OutputFormat = resources.GetString("TextBox6.OutputFormat")
        Me.TextBox6.SummaryGroup = Nothing
        Me.TextBox6.Top = 2.091536!
        Me.TextBox6.Width = 2.189961!
        '
        'TextBox7
        '
        Me.TextBox7.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox7.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox7.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox7.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox7, "TextBox7")
        Me.TextBox7.DistinctField = Nothing
        Me.TextBox7.Height = 0.3937008!
        Me.TextBox7.Left = 5.733268!
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.OutputFormat = resources.GetString("TextBox7.OutputFormat")
        Me.TextBox7.SummaryGroup = Nothing
        Me.TextBox7.Top = 2.337599!
        Me.TextBox7.Width = 2.189961!
        '
        'TextBox8
        '
        Me.TextBox8.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox8.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox8.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox8.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox8, "TextBox8")
        Me.TextBox8.DistinctField = Nothing
        Me.TextBox8.Height = 0.3937009!
        Me.TextBox8.Left = 5.733268!
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.OutputFormat = resources.GetString("TextBox8.OutputFormat")
        Me.TextBox8.SummaryGroup = Nothing
        Me.TextBox8.Top = 2.583662!
        Me.TextBox8.Width = 2.189961!
        '
        'txtcard_id_Temp
        '
        Me.txtcard_id_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcard_id_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcard_id_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtcard_id_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtcard_id_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcard_id_Temp, "txtcard_id_Temp")
        Me.txtcard_id_Temp.DistinctField = Nothing
        Me.txtcard_id_Temp.Height = 0.3937008!
        Me.txtcard_id_Temp.Left = 0.2214567!
        Me.txtcard_id_Temp.Name = "txtcard_id_Temp"
        Me.txtcard_id_Temp.OutputFormat = resources.GetString("txtcard_id_Temp.OutputFormat")
        Me.txtcard_id_Temp.SummaryGroup = Nothing
        Me.txtcard_id_Temp.Text = Nothing
        Me.txtcard_id_Temp.Top = 1.968504!
        Me.txtcard_id_Temp.Width = 5.38878!
        '
        'txtcard_id
        '
        Me.txtcard_id.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcard_id.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcard_id.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id.Border.RightColor = System.Drawing.Color.Black
        Me.txtcard_id.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id.Border.TopColor = System.Drawing.Color.Black
        Me.txtcard_id.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcard_id, "txtcard_id")
        Me.txtcard_id.DataField = "card_id"
        Me.txtcard_id.DistinctField = Nothing
        Me.txtcard_id.Height = 0.2706693!
        Me.txtcard_id.Left = 0.1476378!
        Me.txtcard_id.Name = "txtcard_id"
        Me.txtcard_id.OutputFormat = resources.GetString("txtcard_id.OutputFormat")
        Me.txtcard_id.SummaryGroup = Nothing
        Me.txtcard_id.Top = 0.8385827!
        Me.txtcard_id.Visible = False
        Me.txtcard_id.Width = 0.8366142!
        '
        'txtcompany_name
        '
        Me.txtcompany_name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcompany_name, "txtcompany_name")
        Me.txtcompany_name.DataField = "company_name"
        Me.txtcompany_name.DistinctField = Nothing
        Me.txtcompany_name.Height = 0.2706693!
        Me.txtcompany_name.Left = 1.008858!
        Me.txtcompany_name.Name = "txtcompany_name"
        Me.txtcompany_name.OutputFormat = resources.GetString("txtcompany_name.OutputFormat")
        Me.txtcompany_name.SummaryGroup = Nothing
        Me.txtcompany_name.Top = 0.1722441!
        Me.txtcompany_name.Visible = False
        Me.txtcompany_name.Width = 0.8366142!
        '
        'txtcompany_taxno_Temp
        '
        Me.txtcompany_taxno_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_taxno_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_taxno_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_taxno_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_taxno_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcompany_taxno_Temp, "txtcompany_taxno_Temp")
        Me.txtcompany_taxno_Temp.DistinctField = Nothing
        Me.txtcompany_taxno_Temp.Height = 0.3937008!
        Me.txtcompany_taxno_Temp.Left = 0.2214567!
        Me.txtcompany_taxno_Temp.Name = "txtcompany_taxno_Temp"
        Me.txtcompany_taxno_Temp.OutputFormat = resources.GetString("txtcompany_taxno_Temp.OutputFormat")
        Me.txtcompany_taxno_Temp.SummaryGroup = Nothing
        Me.txtcompany_taxno_Temp.Text = Nothing
        Me.txtcompany_taxno_Temp.Top = 2.189961!
        Me.txtcompany_taxno_Temp.Width = 5.38878!
        '
        'txtcompany_taxno
        '
        Me.txtcompany_taxno.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcompany_taxno, "txtcompany_taxno")
        Me.txtcompany_taxno.DataField = "company_taxno"
        Me.txtcompany_taxno.DistinctField = Nothing
        Me.txtcompany_taxno.Height = 0.2706693!
        Me.txtcompany_taxno.Left = 1.008858!
        Me.txtcompany_taxno.Name = "txtcompany_taxno"
        Me.txtcompany_taxno.OutputFormat = resources.GetString("txtcompany_taxno.OutputFormat")
        Me.txtcompany_taxno.SummaryGroup = Nothing
        Me.txtcompany_taxno.Top = 0.5054134!
        Me.txtcompany_taxno.Visible = False
        Me.txtcompany_taxno.Width = 0.8366142!
        '
        'txtcompany_address_Temp
        '
        Me.txtcompany_address_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_address_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_address_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_address_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_address_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcompany_address_Temp, "txtcompany_address_Temp")
        Me.txtcompany_address_Temp.DistinctField = Nothing
        Me.txtcompany_address_Temp.Height = 0.3937008!
        Me.txtcompany_address_Temp.Left = 0.2214567!
        Me.txtcompany_address_Temp.Name = "txtcompany_address_Temp"
        Me.txtcompany_address_Temp.OutputFormat = resources.GetString("txtcompany_address_Temp.OutputFormat")
        Me.txtcompany_address_Temp.SummaryGroup = Nothing
        Me.txtcompany_address_Temp.Text = Nothing
        Me.txtcompany_address_Temp.Top = 2.411417!
        Me.txtcompany_address_Temp.Width = 5.38878!
        '
        'txtcompany_address
        '
        Me.txtcompany_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcompany_address, "txtcompany_address")
        Me.txtcompany_address.DataField = "company_address"
        Me.txtcompany_address.DistinctField = Nothing
        Me.txtcompany_address.Height = 0.2706693!
        Me.txtcompany_address.Left = 1.008858!
        Me.txtcompany_address.Name = "txtcompany_address"
        Me.txtcompany_address.OutputFormat = resources.GetString("txtcompany_address.OutputFormat")
        Me.txtcompany_address.SummaryGroup = Nothing
        Me.txtcompany_address.Top = 0.8385827!
        Me.txtcompany_address.Visible = False
        Me.txtcompany_address.Width = 0.8366142!
        '
        'txtcompany_phone_fax_Temp
        '
        Me.txtcompany_phone_fax_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_phone_fax_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone_fax_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_phone_fax_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone_fax_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_phone_fax_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone_fax_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_phone_fax_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcompany_phone_fax_Temp, "txtcompany_phone_fax_Temp")
        Me.txtcompany_phone_fax_Temp.DistinctField = Nothing
        Me.txtcompany_phone_fax_Temp.Height = 0.3937008!
        Me.txtcompany_phone_fax_Temp.Left = 0.2214567!
        Me.txtcompany_phone_fax_Temp.Name = "txtcompany_phone_fax_Temp"
        Me.txtcompany_phone_fax_Temp.OutputFormat = resources.GetString("txtcompany_phone_fax_Temp.OutputFormat")
        Me.txtcompany_phone_fax_Temp.SummaryGroup = Nothing
        Me.txtcompany_phone_fax_Temp.Text = Nothing
        Me.txtcompany_phone_fax_Temp.Top = 2.632874!
        Me.txtcompany_phone_fax_Temp.Width = 5.38878!
        '
        'txtcompany_phone
        '
        Me.txtcompany_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcompany_phone, "txtcompany_phone")
        Me.txtcompany_phone.DataField = "company_phone"
        Me.txtcompany_phone.DistinctField = Nothing
        Me.txtcompany_phone.Height = 0.2706693!
        Me.txtcompany_phone.Left = 1.870079!
        Me.txtcompany_phone.Name = "txtcompany_phone"
        Me.txtcompany_phone.OutputFormat = resources.GetString("txtcompany_phone.OutputFormat")
        Me.txtcompany_phone.SummaryGroup = Nothing
        Me.txtcompany_phone.Top = 0.1722441!
        Me.txtcompany_phone.Visible = False
        Me.txtcompany_phone.Width = 0.8366142!
        '
        'txtcompany_fax
        '
        Me.txtcompany_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtcompany_fax, "txtcompany_fax")
        Me.txtcompany_fax.DataField = "company_fax"
        Me.txtcompany_fax.DistinctField = Nothing
        Me.txtcompany_fax.Height = 0.2706693!
        Me.txtcompany_fax.Left = 1.870079!
        Me.txtcompany_fax.Name = "txtcompany_fax"
        Me.txtcompany_fax.OutputFormat = resources.GetString("txtcompany_fax.OutputFormat")
        Me.txtcompany_fax.SummaryGroup = Nothing
        Me.txtcompany_fax.Top = 0.5054134!
        Me.txtcompany_fax.Visible = False
        Me.txtcompany_fax.Width = 0.8366142!
        '
        'TextBox9
        '
        Me.TextBox9.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox9.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox9.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox9.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox9, "TextBox9")
        Me.TextBox9.DistinctField = Nothing
        Me.TextBox9.Height = 0.3937008!
        Me.TextBox9.Left = 0.2214567!
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.OutputFormat = resources.GetString("TextBox9.OutputFormat")
        Me.TextBox9.SummaryGroup = Nothing
        Me.TextBox9.Top = 2.977362!
        Me.TextBox9.Width = 5.364173!
        '
        'txtdestination_company
        '
        Me.txtdestination_company.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtdestination_company, "txtdestination_company")
        Me.txtdestination_company.DataField = "destination_company"
        Me.txtdestination_company.DistinctField = Nothing
        Me.txtdestination_company.Height = 0.3937007!
        Me.txtdestination_company.Left = 0.2214567!
        Me.txtdestination_company.Name = "txtdestination_company"
        Me.txtdestination_company.OutputFormat = resources.GetString("txtdestination_company.OutputFormat")
        Me.txtdestination_company.SummaryGroup = Nothing
        Me.txtdestination_company.Top = 3.248032!
        Me.txtdestination_company.Width = 5.413386!
        '
        'txtdestination_address_province_dest_receive_country
        '
        Me.txtdestination_address_province_dest_receive_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_address_province_dest_receive_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address_province_dest_receive_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_address_province_dest_receive_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address_province_dest_receive_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_address_province_dest_receive_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address_province_dest_receive_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_address_province_dest_receive_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtdestination_address_province_dest_receive_country, "txtdestination_address_province_dest_receive_country")
        Me.txtdestination_address_province_dest_receive_country.DistinctField = Nothing
        Me.txtdestination_address_province_dest_receive_country.Height = 0.3937007!
        Me.txtdestination_address_province_dest_receive_country.Left = 0.2214567!
        Me.txtdestination_address_province_dest_receive_country.Name = "txtdestination_address_province_dest_receive_country"
        Me.txtdestination_address_province_dest_receive_country.OutputFormat = resources.GetString("txtdestination_address_province_dest_receive_country.OutputFormat")
        Me.txtdestination_address_province_dest_receive_country.SummaryGroup = Nothing
        Me.txtdestination_address_province_dest_receive_country.Text = Nothing
        Me.txtdestination_address_province_dest_receive_country.Top = 3.494095!
        Me.txtdestination_address_province_dest_receive_country.Width = 5.413386!
        '
        'txtdestination_address
        '
        Me.txtdestination_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtdestination_address, "txtdestination_address")
        Me.txtdestination_address.DataField = "destination_address"
        Me.txtdestination_address.DistinctField = Nothing
        Me.txtdestination_address.Height = 0.2706693!
        Me.txtdestination_address.Left = 1.870079!
        Me.txtdestination_address.Name = "txtdestination_address"
        Me.txtdestination_address.OutputFormat = resources.GetString("txtdestination_address.OutputFormat")
        Me.txtdestination_address.SummaryGroup = Nothing
        Me.txtdestination_address.Top = 0.8385828!
        Me.txtdestination_address.Visible = False
        Me.txtdestination_address.Width = 0.8366142!
        '
        'txtdestination_province
        '
        Me.txtdestination_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtdestination_province, "txtdestination_province")
        Me.txtdestination_province.DataField = "destination_province"
        Me.txtdestination_province.DistinctField = Nothing
        Me.txtdestination_province.Height = 0.2706693!
        Me.txtdestination_province.Left = 2.731299!
        Me.txtdestination_province.Name = "txtdestination_province"
        Me.txtdestination_province.OutputFormat = resources.GetString("txtdestination_province.OutputFormat")
        Me.txtdestination_province.SummaryGroup = Nothing
        Me.txtdestination_province.Top = 0.1722441!
        Me.txtdestination_province.Visible = False
        Me.txtdestination_province.Width = 0.8366142!
        '
        'txtdest_receive_country
        '
        Me.txtdest_receive_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_receive_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_receive_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_receive_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_receive_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_receive_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_receive_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_receive_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtdest_receive_country, "txtdest_receive_country")
        Me.txtdest_receive_country.DataField = "dest_receive_country"
        Me.txtdest_receive_country.DistinctField = Nothing
        Me.txtdest_receive_country.Height = 0.2706693!
        Me.txtdest_receive_country.Left = 2.731299!
        Me.txtdest_receive_country.Name = "txtdest_receive_country"
        Me.txtdest_receive_country.OutputFormat = resources.GetString("txtdest_receive_country.OutputFormat")
        Me.txtdest_receive_country.SummaryGroup = Nothing
        Me.txtdest_receive_country.Top = 0.5054134!
        Me.txtdest_receive_country.Visible = False
        Me.txtdest_receive_country.Width = 0.8366142!
        '
        'txtimport_country_Temp
        '
        Me.txtimport_country_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtimport_country_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtimport_country_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtimport_country_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtimport_country_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtimport_country_Temp, "txtimport_country_Temp")
        Me.txtimport_country_Temp.DistinctField = Nothing
        Me.txtimport_country_Temp.Height = 0.3937007!
        Me.txtimport_country_Temp.Left = 0.2214567!
        Me.txtimport_country_Temp.Name = "txtimport_country_Temp"
        Me.txtimport_country_Temp.OutputFormat = resources.GetString("txtimport_country_Temp.OutputFormat")
        Me.txtimport_country_Temp.SummaryGroup = Nothing
        Me.txtimport_country_Temp.Text = Nothing
        Me.txtimport_country_Temp.Top = 3.715551!
        Me.txtimport_country_Temp.Width = 5.413386!
        '
        'txtimport_country
        '
        Me.txtimport_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtimport_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtimport_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtimport_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtimport_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtimport_country, "txtimport_country")
        Me.txtimport_country.DataField = "import_country"
        Me.txtimport_country.DistinctField = Nothing
        Me.txtimport_country.Height = 0.2706693!
        Me.txtimport_country.Left = 2.731299!
        Me.txtimport_country.Name = "txtimport_country"
        Me.txtimport_country.OutputFormat = resources.GetString("txtimport_country.OutputFormat")
        Me.txtimport_country.SummaryGroup = Nothing
        Me.txtimport_country.Top = 0.8385828!
        Me.txtimport_country.Visible = False
        Me.txtimport_country.Width = 0.8366142!
        '
        'TextBox10
        '
        Me.TextBox10.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox10.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox10.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox10.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox10, "TextBox10")
        Me.TextBox10.DistinctField = Nothing
        Me.TextBox10.Height = 0.3937007!
        Me.TextBox10.Left = 5.634842!
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.OutputFormat = resources.GetString("TextBox10.OutputFormat")
        Me.TextBox10.SummaryGroup = Nothing
        Me.TextBox10.Top = 3.026575!
        Me.TextBox10.Width = 2.401575!
        '
        'TextBox11
        '
        Me.TextBox11.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox11.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox11.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox11.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.TextBox11, "TextBox11")
        Me.TextBox11.DistinctField = Nothing
        Me.TextBox11.Height = 0.2460631!
        Me.TextBox11.Left = 5.659449!
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.OutputFormat = resources.GetString("TextBox11.OutputFormat")
        Me.TextBox11.SummaryGroup = Nothing
        Me.TextBox11.Text = Nothing
        Me.TextBox11.Top = 3.420276!
        Me.TextBox11.Width = 0.2460631!
        '
        'TextBox12
        '
        Me.TextBox12.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox12.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox12.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox12.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.TextBox12, "TextBox12")
        Me.TextBox12.DistinctField = Nothing
        Me.TextBox12.Height = 0.2460631!
        Me.TextBox12.Left = 5.659449!
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.OutputFormat = resources.GetString("TextBox12.OutputFormat")
        Me.TextBox12.SummaryGroup = Nothing
        Me.TextBox12.Text = Nothing
        Me.TextBox12.Top = 3.740157!
        Me.TextBox12.Width = 0.2460631!
        '
        'TextBox13
        '
        Me.TextBox13.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox13.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox13.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox13.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox13, "TextBox13")
        Me.TextBox13.DistinctField = Nothing
        Me.TextBox13.Height = 0.3937009!
        Me.TextBox13.Left = 5.954725!
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.OutputFormat = resources.GetString("TextBox13.OutputFormat")
        Me.TextBox13.SummaryGroup = Nothing
        Me.TextBox13.Top = 3.420276!
        Me.TextBox13.Width = 2.066929!
        '
        'TextBox14
        '
        Me.TextBox14.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox14.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox14.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox14.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox14, "TextBox14")
        Me.TextBox14.DistinctField = Nothing
        Me.TextBox14.Height = 0.3937009!
        Me.TextBox14.Left = 5.954725!
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.OutputFormat = resources.GetString("TextBox14.OutputFormat")
        Me.TextBox14.SummaryGroup = Nothing
        Me.TextBox14.Top = 3.740157!
        Me.TextBox14.Width = 2.066929!
        '
        'TextBox15
        '
        Me.TextBox15.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox15.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox15.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox15.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox15.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox15.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox15.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox15.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox15, "TextBox15")
        Me.TextBox15.DistinctField = Nothing
        Me.TextBox15.Height = 0.3937008!
        Me.TextBox15.Left = 0.2214567!
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.OutputFormat = resources.GetString("TextBox15.OutputFormat")
        Me.TextBox15.SummaryGroup = Nothing
        Me.TextBox15.Top = 4.183071!
        Me.TextBox15.Width = 5.364173!
        '
        'txtship_by0
        '
        Me.txtship_by0.Border.BottomColor = System.Drawing.Color.Black
        Me.txtship_by0.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by0.Border.LeftColor = System.Drawing.Color.Black
        Me.txtship_by0.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by0.Border.RightColor = System.Drawing.Color.Black
        Me.txtship_by0.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by0.Border.TopColor = System.Drawing.Color.Black
        Me.txtship_by0.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtship_by0, "txtship_by0")
        Me.txtship_by0.DistinctField = Nothing
        Me.txtship_by0.Height = 0.2460631!
        Me.txtship_by0.Left = 0.3690945!
        Me.txtship_by0.Name = "txtship_by0"
        Me.txtship_by0.OutputFormat = resources.GetString("txtship_by0.OutputFormat")
        Me.txtship_by0.SummaryGroup = Nothing
        Me.txtship_by0.Text = Nothing
        Me.txtship_by0.Top = 4.502953!
        Me.txtship_by0.Width = 0.2460631!
        '
        'txtship_by1
        '
        Me.txtship_by1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtship_by1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtship_by1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by1.Border.RightColor = System.Drawing.Color.Black
        Me.txtship_by1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by1.Border.TopColor = System.Drawing.Color.Black
        Me.txtship_by1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtship_by1, "txtship_by1")
        Me.txtship_by1.DistinctField = Nothing
        Me.txtship_by1.Height = 0.2460631!
        Me.txtship_by1.Left = 1.181102!
        Me.txtship_by1.Name = "txtship_by1"
        Me.txtship_by1.OutputFormat = resources.GetString("txtship_by1.OutputFormat")
        Me.txtship_by1.SummaryGroup = Nothing
        Me.txtship_by1.Text = Nothing
        Me.txtship_by1.Top = 4.502953!
        Me.txtship_by1.Width = 0.2460631!
        '
        'txtship_by2
        '
        Me.txtship_by2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtship_by2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtship_by2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by2.Border.RightColor = System.Drawing.Color.Black
        Me.txtship_by2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by2.Border.TopColor = System.Drawing.Color.Black
        Me.txtship_by2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtship_by2, "txtship_by2")
        Me.txtship_by2.DistinctField = Nothing
        Me.txtship_by2.Height = 0.2460631!
        Me.txtship_by2.Left = 2.189961!
        Me.txtship_by2.Name = "txtship_by2"
        Me.txtship_by2.OutputFormat = resources.GetString("txtship_by2.OutputFormat")
        Me.txtship_by2.SummaryGroup = Nothing
        Me.txtship_by2.Text = Nothing
        Me.txtship_by2.Top = 4.502953!
        Me.txtship_by2.Width = 0.2460631!
        '
        'txtship_by3
        '
        Me.txtship_by3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtship_by3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtship_by3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by3.Border.RightColor = System.Drawing.Color.Black
        Me.txtship_by3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by3.Border.TopColor = System.Drawing.Color.Black
        Me.txtship_by3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtship_by3, "txtship_by3")
        Me.txtship_by3.DistinctField = Nothing
        Me.txtship_by3.Height = 0.2460631!
        Me.txtship_by3.Left = 2.952756!
        Me.txtship_by3.Name = "txtship_by3"
        Me.txtship_by3.OutputFormat = resources.GetString("txtship_by3.OutputFormat")
        Me.txtship_by3.SummaryGroup = Nothing
        Me.txtship_by3.Text = Nothing
        Me.txtship_by3.Top = 4.502953!
        Me.txtship_by3.Width = 0.2460631!
        '
        'txtship_by4
        '
        Me.txtship_by4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtship_by4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtship_by4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by4.Border.RightColor = System.Drawing.Color.Black
        Me.txtship_by4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtship_by4.Border.TopColor = System.Drawing.Color.Black
        Me.txtship_by4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtship_by4, "txtship_by4")
        Me.txtship_by4.DistinctField = Nothing
        Me.txtship_by4.Height = 0.2460631!
        Me.txtship_by4.Left = 3.986221!
        Me.txtship_by4.Name = "txtship_by4"
        Me.txtship_by4.OutputFormat = resources.GetString("txtship_by4.OutputFormat")
        Me.txtship_by4.SummaryGroup = Nothing
        Me.txtship_by4.Text = Nothing
        Me.txtship_by4.Top = 4.502953!
        Me.txtship_by4.Width = 0.2460631!
        '
        'TextBox21
        '
        Me.TextBox21.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox21.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox21.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox21.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox21.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox21.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox21.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox21.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox21, "TextBox21")
        Me.TextBox21.DistinctField = Nothing
        Me.TextBox21.Height = 0.3937008!
        Me.TextBox21.Left = 0.6643701!
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.OutputFormat = resources.GetString("TextBox21.OutputFormat")
        Me.TextBox21.SummaryGroup = Nothing
        Me.TextBox21.Top = 4.429134!
        Me.TextBox21.Width = 0.5167323!
        '
        'TextBox22
        '
        Me.TextBox22.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox22.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox22.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox22.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox22.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox22.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox22.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox22.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox22, "TextBox22")
        Me.TextBox22.DistinctField = Nothing
        Me.TextBox22.Height = 0.3937007!
        Me.TextBox22.Left = 1.476378!
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.OutputFormat = resources.GetString("TextBox22.OutputFormat")
        Me.TextBox22.SummaryGroup = Nothing
        Me.TextBox22.Top = 4.429134!
        Me.TextBox22.Width = 0.7135827!
        '
        'TextBox24
        '
        Me.TextBox24.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox24.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox24.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox24.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox24.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox24.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox24.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox24.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox24, "TextBox24")
        Me.TextBox24.DistinctField = Nothing
        Me.TextBox24.Height = 0.3937007!
        Me.TextBox24.Left = 3.248032!
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.OutputFormat = resources.GetString("TextBox24.OutputFormat")
        Me.TextBox24.SummaryGroup = Nothing
        Me.TextBox24.Top = 4.429134!
        Me.TextBox24.Width = 0.7135827!
        '
        'TextBox25
        '
        Me.TextBox25.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox25.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox25.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox25.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox25.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox25.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox25.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox25.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox25, "TextBox25")
        Me.TextBox25.DistinctField = Nothing
        Me.TextBox25.Height = 0.3937007!
        Me.TextBox25.Left = 4.281496!
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.OutputFormat = resources.GetString("TextBox25.OutputFormat")
        Me.TextBox25.SummaryGroup = Nothing
        Me.TextBox25.Top = 4.429134!
        Me.TextBox25.Width = 0.7135827!
        '
        'TextBox26
        '
        Me.TextBox26.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox26.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox26.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox26.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox26.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox26.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox26.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox26.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox26, "TextBox26")
        Me.TextBox26.DistinctField = Nothing
        Me.TextBox26.Height = 0.3937007!
        Me.TextBox26.Left = 0.2214567!
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.OutputFormat = resources.GetString("TextBox26.OutputFormat")
        Me.TextBox26.SummaryGroup = Nothing
        Me.TextBox26.Top = 4.822834!
        Me.TextBox26.Width = 0.3444882!
        '
        'TextBox27
        '
        Me.TextBox27.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox27.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox27.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox27.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox27.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox27.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox27.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox27.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox27, "TextBox27")
        Me.TextBox27.DistinctField = Nothing
        Me.TextBox27.Height = 0.3937007!
        Me.TextBox27.Left = 0.5659449!
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.OutputFormat = resources.GetString("TextBox27.OutputFormat")
        Me.TextBox27.SummaryGroup = Nothing
        Me.TextBox27.Top = 4.822834!
        Me.TextBox27.Width = 4.109252!
        '
        'TextBox28
        '
        Me.TextBox28.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox28.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox28.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox28.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox28.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox28.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox28.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox28.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox28, "TextBox28")
        Me.TextBox28.DistinctField = Nothing
        Me.TextBox28.Height = 0.3937007!
        Me.TextBox28.Left = 4.675197!
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.OutputFormat = resources.GetString("TextBox28.OutputFormat")
        Me.TextBox28.SummaryGroup = Nothing
        Me.TextBox28.Top = 4.822834!
        Me.TextBox28.Width = 1.033465!
        '
        'TextBox29
        '
        Me.TextBox29.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox29.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox29.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox29.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox29.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox29.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox29.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox29.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox29, "TextBox29")
        Me.TextBox29.DistinctField = Nothing
        Me.TextBox29.Height = 0.3937006!
        Me.TextBox29.Left = 5.708662!
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.OutputFormat = resources.GetString("TextBox29.OutputFormat")
        Me.TextBox29.SummaryGroup = Nothing
        Me.TextBox29.Top = 4.822834!
        Me.TextBox29.Width = 1.377953!
        '
        'TextBox30
        '
        Me.TextBox30.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox30.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox30.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox30.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox30.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox30.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox30.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox30.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox30, "TextBox30")
        Me.TextBox30.DistinctField = Nothing
        Me.TextBox30.Height = 0.3937006!
        Me.TextBox30.Left = 7.086615!
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.OutputFormat = resources.GetString("TextBox30.OutputFormat")
        Me.TextBox30.SummaryGroup = Nothing
        Me.TextBox30.Top = 4.822834!
        Me.TextBox30.Width = 0.9596457!
        '
        'txtship_by
        '
        Me.txtship_by.Border.BottomColor = System.Drawing.Color.Black
        Me.txtship_by.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtship_by.Border.LeftColor = System.Drawing.Color.Black
        Me.txtship_by.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtship_by.Border.RightColor = System.Drawing.Color.Black
        Me.txtship_by.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtship_by.Border.TopColor = System.Drawing.Color.Black
        Me.txtship_by.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtship_by, "txtship_by")
        Me.txtship_by.DataField = "ship_by"
        Me.txtship_by.DistinctField = Nothing
        Me.txtship_by.Height = 0.2706693!
        Me.txtship_by.Left = 3.567913!
        Me.txtship_by.Name = "txtship_by"
        Me.txtship_by.OutputFormat = resources.GetString("txtship_by.OutputFormat")
        Me.txtship_by.SummaryGroup = Nothing
        Me.txtship_by.Top = 0.1722441!
        Me.txtship_by.Visible = False
        Me.txtship_by.Width = 0.8366142!
        '
        'txtdestination_phone
        '
        Me.txtdestination_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtdestination_phone, "txtdestination_phone")
        Me.txtdestination_phone.DataField = "destination_phone"
        Me.txtdestination_phone.DistinctField = Nothing
        Me.txtdestination_phone.Height = 0.2706693!
        Me.txtdestination_phone.Left = 3.567913!
        Me.txtdestination_phone.Name = "txtdestination_phone"
        Me.txtdestination_phone.OutputFormat = resources.GetString("txtdestination_phone.OutputFormat")
        Me.txtdestination_phone.SummaryGroup = Nothing
        Me.txtdestination_phone.Top = 0.5054134!
        Me.txtdestination_phone.Visible = False
        Me.txtdestination_phone.Width = 0.8366142!
        '
        'txtdestination_fax
        '
        Me.txtdestination_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtdestination_fax, "txtdestination_fax")
        Me.txtdestination_fax.DataField = "destination_fax"
        Me.txtdestination_fax.DistinctField = Nothing
        Me.txtdestination_fax.Height = 0.2706693!
        Me.txtdestination_fax.Left = 3.567913!
        Me.txtdestination_fax.Name = "txtdestination_fax"
        Me.txtdestination_fax.OutputFormat = resources.GetString("txtdestination_fax.OutputFormat")
        Me.txtdestination_fax.SummaryGroup = Nothing
        Me.txtdestination_fax.Top = 0.8385828!
        Me.txtdestination_fax.Visible = False
        Me.txtdestination_fax.Width = 0.8366142!
        '
        'txtTARIFF_CODE_Temp
        '
        Me.txtTARIFF_CODE_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTARIFF_CODE_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTARIFF_CODE_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTARIFF_CODE_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTARIFF_CODE_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtTARIFF_CODE_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTARIFF_CODE_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtTARIFF_CODE_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtTARIFF_CODE_Temp, "txtTARIFF_CODE_Temp")
        Me.txtTARIFF_CODE_Temp.DistinctField = Nothing
        Me.txtTARIFF_CODE_Temp.Height = 0.2362205!
        Me.txtTARIFF_CODE_Temp.Left = 4.677166!
        Me.txtTARIFF_CODE_Temp.Name = "txtTARIFF_CODE_Temp"
        Me.txtTARIFF_CODE_Temp.OutputFormat = resources.GetString("txtTARIFF_CODE_Temp.OutputFormat")
        Me.txtTARIFF_CODE_Temp.SummaryGroup = Nothing
        Me.txtTARIFF_CODE_Temp.Text = Nothing
        Me.txtTARIFF_CODE_Temp.Top = 0.0!
        Me.txtTARIFF_CODE_Temp.Width = 1.033465!
        '
        'txtNET_WEIGHT_unit_code2
        '
        Me.txtNET_WEIGHT_unit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNET_WEIGHT_unit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNET_WEIGHT_unit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNET_WEIGHT_unit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNET_WEIGHT_unit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtNET_WEIGHT_unit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNET_WEIGHT_unit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtNET_WEIGHT_unit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtNET_WEIGHT_unit_code2, "txtNET_WEIGHT_unit_code2")
        Me.txtNET_WEIGHT_unit_code2.DistinctField = Nothing
        Me.txtNET_WEIGHT_unit_code2.Height = 0.2362205!
        Me.txtNET_WEIGHT_unit_code2.Left = 5.708662!
        Me.txtNET_WEIGHT_unit_code2.Name = "txtNET_WEIGHT_unit_code2"
        Me.txtNET_WEIGHT_unit_code2.OutputFormat = resources.GetString("txtNET_WEIGHT_unit_code2.OutputFormat")
        Me.txtNET_WEIGHT_unit_code2.SummaryGroup = Nothing
        Me.txtNET_WEIGHT_unit_code2.Text = Nothing
        Me.txtNET_WEIGHT_unit_code2.Top = 0.0!
        Me.txtNET_WEIGHT_unit_code2.Width = 1.377953!
        '
        'txtFOB_AMT_Temp
        '
        Me.txtFOB_AMT_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOB_AMT_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOB_AMT_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOB_AMT_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOB_AMT_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtFOB_AMT_Temp, "txtFOB_AMT_Temp")
        Me.txtFOB_AMT_Temp.DistinctField = Nothing
        Me.txtFOB_AMT_Temp.Height = 0.2362205!
        Me.txtFOB_AMT_Temp.Left = 7.086614!
        Me.txtFOB_AMT_Temp.Name = "txtFOB_AMT_Temp"
        Me.txtFOB_AMT_Temp.OutputFormat = resources.GetString("txtFOB_AMT_Temp.OutputFormat")
        Me.txtFOB_AMT_Temp.SummaryGroup = Nothing
        Me.txtFOB_AMT_Temp.Text = Nothing
        Me.txtFOB_AMT_Temp.Top = 0.0!
        Me.txtFOB_AMT_Temp.Width = 0.9596457!
        '
        'txtPRODUCT_NAME
        '
        Me.txtPRODUCT_NAME.Border.BottomColor = System.Drawing.Color.Black
        Me.txtPRODUCT_NAME.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPRODUCT_NAME.Border.LeftColor = System.Drawing.Color.Black
        Me.txtPRODUCT_NAME.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPRODUCT_NAME.Border.RightColor = System.Drawing.Color.Black
        Me.txtPRODUCT_NAME.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPRODUCT_NAME.Border.TopColor = System.Drawing.Color.Black
        Me.txtPRODUCT_NAME.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtPRODUCT_NAME, "txtPRODUCT_NAME")
        Me.txtPRODUCT_NAME.DataField = "PRODUCT_NAME"
        Me.txtPRODUCT_NAME.DistinctField = Nothing
        Me.txtPRODUCT_NAME.Height = 0.2362205!
        Me.txtPRODUCT_NAME.Left = 0.5659449!
        Me.txtPRODUCT_NAME.Name = "txtPRODUCT_NAME"
        Me.txtPRODUCT_NAME.OutputFormat = resources.GetString("txtPRODUCT_NAME.OutputFormat")
        Me.txtPRODUCT_NAME.SummaryGroup = Nothing
        Me.txtPRODUCT_NAME.Top = 0.0!
        Me.txtPRODUCT_NAME.Width = 4.084646!
        '
        'txtNum_Product
        '
        Me.txtNum_Product.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNum_Product.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNum_Product.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNum_Product.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNum_Product.Border.RightColor = System.Drawing.Color.Black
        Me.txtNum_Product.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNum_Product.Border.TopColor = System.Drawing.Color.Black
        Me.txtNum_Product.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtNum_Product, "txtNum_Product")
        Me.txtNum_Product.DistinctField = Nothing
        Me.txtNum_Product.Height = 0.2362205!
        Me.txtNum_Product.Left = 0.2214567!
        Me.txtNum_Product.Name = "txtNum_Product"
        Me.txtNum_Product.OutputFormat = resources.GetString("txtNum_Product.OutputFormat")
        Me.txtNum_Product.SummaryGroup = Nothing
        Me.txtNum_Product.Text = Nothing
        Me.txtNum_Product.Top = 0.0!
        Me.txtNum_Product.Width = 0.3444882!
        '
        'txtTARIFF_CODE
        '
        Me.txtTARIFF_CODE.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTARIFF_CODE.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTARIFF_CODE.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTARIFF_CODE.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTARIFF_CODE.Border.RightColor = System.Drawing.Color.Black
        Me.txtTARIFF_CODE.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTARIFF_CODE.Border.TopColor = System.Drawing.Color.Black
        Me.txtTARIFF_CODE.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtTARIFF_CODE, "txtTARIFF_CODE")
        Me.txtTARIFF_CODE.DataField = "TARIFF_CODE"
        Me.txtTARIFF_CODE.DistinctField = Nothing
        Me.txtTARIFF_CODE.Height = 0.3937007!
        Me.txtTARIFF_CODE.Left = 4.677166!
        Me.txtTARIFF_CODE.Name = "txtTARIFF_CODE"
        Me.txtTARIFF_CODE.OutputFormat = resources.GetString("txtTARIFF_CODE.OutputFormat")
        Me.txtTARIFF_CODE.SummaryGroup = Nothing
        Me.txtTARIFF_CODE.Top = 0.4562007!
        Me.txtTARIFF_CODE.Visible = False
        Me.txtTARIFF_CODE.Width = 1.033465!
        '
        'txtNET_WEIGHT
        '
        Me.txtNET_WEIGHT.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNET_WEIGHT.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNET_WEIGHT.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNET_WEIGHT.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNET_WEIGHT.Border.RightColor = System.Drawing.Color.Black
        Me.txtNET_WEIGHT.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNET_WEIGHT.Border.TopColor = System.Drawing.Color.Black
        Me.txtNET_WEIGHT.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtNET_WEIGHT, "txtNET_WEIGHT")
        Me.txtNET_WEIGHT.DataField = "NET_WEIGHT"
        Me.txtNET_WEIGHT.DistinctField = Nothing
        Me.txtNET_WEIGHT.Height = 0.3937006!
        Me.txtNET_WEIGHT.Left = 5.708662!
        Me.txtNET_WEIGHT.Name = "txtNET_WEIGHT"
        Me.txtNET_WEIGHT.OutputFormat = resources.GetString("txtNET_WEIGHT.OutputFormat")
        Me.txtNET_WEIGHT.SummaryGroup = Nothing
        Me.txtNET_WEIGHT.Top = 0.4562006!
        Me.txtNET_WEIGHT.Visible = False
        Me.txtNET_WEIGHT.Width = 1.377953!
        '
        'txtFOB_AMT
        '
        Me.txtFOB_AMT.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtFOB_AMT, "txtFOB_AMT")
        Me.txtFOB_AMT.DataField = "FOB_AMT"
        Me.txtFOB_AMT.DistinctField = Nothing
        Me.txtFOB_AMT.Height = 0.3937006!
        Me.txtFOB_AMT.Left = 7.086614!
        Me.txtFOB_AMT.Name = "txtFOB_AMT"
        Me.txtFOB_AMT.OutputFormat = resources.GetString("txtFOB_AMT.OutputFormat")
        Me.txtFOB_AMT.SummaryGroup = Nothing
        Me.txtFOB_AMT.Top = 0.4562006!
        Me.txtFOB_AMT.Visible = False
        Me.txtFOB_AMT.Width = 0.9596457!
        '
        'txtunit_code2
        '
        Me.txtunit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtunit_code2, "txtunit_code2")
        Me.txtunit_code2.DataField = "unit_code2"
        Me.txtunit_code2.DistinctField = Nothing
        Me.txtunit_code2.Height = 0.3937006!
        Me.txtunit_code2.Left = 5.708662!
        Me.txtunit_code2.Name = "txtunit_code2"
        Me.txtunit_code2.OutputFormat = resources.GetString("txtunit_code2.OutputFormat")
        Me.txtunit_code2.SummaryGroup = Nothing
        Me.txtunit_code2.Top = 0.9124011!
        Me.txtunit_code2.Visible = False
        Me.txtunit_code2.Width = 1.377953!
        '
        'C_TotalRowDe
        '
        Me.C_TotalRowDe.Border.BottomColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.LeftColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.RightColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.TopColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.C_TotalRowDe, "C_TotalRowDe")
        Me.C_TotalRowDe.DistinctField = Nothing
        Me.C_TotalRowDe.Height = 0.3198819!
        Me.C_TotalRowDe.Left = 0.2214567!
        Me.C_TotalRowDe.Name = "C_TotalRowDe"
        Me.C_TotalRowDe.OutputFormat = resources.GetString("C_TotalRowDe.OutputFormat")
        Me.C_TotalRowDe.SummaryGroup = Nothing
        Me.C_TotalRowDe.Top = 0.3690945!
        Me.C_TotalRowDe.Visible = False
        Me.C_TotalRowDe.Width = 0.9104331!
        '
        'TextBox33
        '
        Me.TextBox33.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox33.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox33.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox33.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox33.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox33.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox33.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox33.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox33, "TextBox33")
        Me.TextBox33.DistinctField = Nothing
        Me.TextBox33.Height = 0.66437!
        Me.TextBox33.Left = 0.3444882!
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.OutputFormat = resources.GetString("TextBox33.OutputFormat")
        Me.TextBox33.SummaryGroup = Nothing
        Me.TextBox33.Top = 3.001969!
        Me.TextBox33.Width = 7.529528!
        '
        'TextBox31
        '
        Me.TextBox31.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox31.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox31.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox31.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox31.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox31.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox31.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox31.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox31, "TextBox31")
        Me.TextBox31.DistinctField = Nothing
        Me.TextBox31.Height = 0.3937008!
        Me.TextBox31.Left = 0.2214567!
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.OutputFormat = resources.GetString("TextBox31.OutputFormat")
        Me.TextBox31.SummaryGroup = Nothing
        Me.TextBox31.Top = 0.2952756!
        Me.TextBox31.Width = 5.364173!
        '
        'txtTotal
        '
        Me.txtTotal.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTotal.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTotal.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal.Border.RightColor = System.Drawing.Color.Black
        Me.txtTotal.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal.Border.TopColor = System.Drawing.Color.Black
        Me.txtTotal.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtTotal, "txtTotal")
        Me.txtTotal.DistinctField = Nothing
        Me.txtTotal.Height = 0.3149606!
        Me.txtTotal.Left = 0.3937008!
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.OutputFormat = resources.GetString("txtTotal.OutputFormat")
        Me.txtTotal.SummaryGroup = Nothing
        Me.txtTotal.Text = Nothing
        Me.txtTotal.Top = 0.0!
        Me.txtTotal.Width = 5.191929!
        '
        'txtSum_Net_Weight
        '
        Me.txtSum_Net_Weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtSum_Net_Weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Net_Weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtSum_Net_Weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtSum_Net_Weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtSum_Net_Weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Net_Weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtSum_Net_Weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtSum_Net_Weight, "txtSum_Net_Weight")
        Me.txtSum_Net_Weight.DataField = "NET_WEIGHT"
        Me.txtSum_Net_Weight.DistinctField = Nothing
        Me.txtSum_Net_Weight.Height = 0.3149606!
        Me.txtSum_Net_Weight.Left = 5.708662!
        Me.txtSum_Net_Weight.Name = "txtSum_Net_Weight"
        Me.txtSum_Net_Weight.OutputFormat = resources.GetString("txtSum_Net_Weight.OutputFormat")
        Me.txtSum_Net_Weight.SummaryGroup = Nothing
        Me.txtSum_Net_Weight.Text = Nothing
        Me.txtSum_Net_Weight.Top = 0.0!
        Me.txtSum_Net_Weight.Width = 1.377953!
        '
        'txtSum_Fob_Amt
        '
        Me.txtSum_Fob_Amt.Border.BottomColor = System.Drawing.Color.Black
        Me.txtSum_Fob_Amt.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Fob_Amt.Border.LeftColor = System.Drawing.Color.Black
        Me.txtSum_Fob_Amt.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtSum_Fob_Amt.Border.RightColor = System.Drawing.Color.Black
        Me.txtSum_Fob_Amt.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Fob_Amt.Border.TopColor = System.Drawing.Color.Black
        Me.txtSum_Fob_Amt.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtSum_Fob_Amt, "txtSum_Fob_Amt")
        Me.txtSum_Fob_Amt.DataField = "FOB_AMT"
        Me.txtSum_Fob_Amt.DistinctField = Nothing
        Me.txtSum_Fob_Amt.Height = 0.3149606!
        Me.txtSum_Fob_Amt.Left = 7.086615!
        Me.txtSum_Fob_Amt.Name = "txtSum_Fob_Amt"
        Me.txtSum_Fob_Amt.OutputFormat = resources.GetString("txtSum_Fob_Amt.OutputFormat")
        Me.txtSum_Fob_Amt.SummaryGroup = Nothing
        Me.txtSum_Fob_Amt.Text = Nothing
        Me.txtSum_Fob_Amt.Top = 0.0!
        Me.txtSum_Fob_Amt.Width = 0.9596457!
        '
        'txtSum_Gross_Weight
        '
        Me.txtSum_Gross_Weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtSum_Gross_Weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Gross_Weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtSum_Gross_Weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Gross_Weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtSum_Gross_Weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Gross_Weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtSum_Gross_Weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtSum_Gross_Weight, "txtSum_Gross_Weight")
        Me.txtSum_Gross_Weight.DistinctField = Nothing
        Me.txtSum_Gross_Weight.Height = 0.3937007!
        Me.txtSum_Gross_Weight.Left = 3.346457!
        Me.txtSum_Gross_Weight.Name = "txtSum_Gross_Weight"
        Me.txtSum_Gross_Weight.OutputFormat = resources.GetString("txtSum_Gross_Weight.OutputFormat")
        Me.txtSum_Gross_Weight.SummaryGroup = Nothing
        Me.txtSum_Gross_Weight.Text = Nothing
        Me.txtSum_Gross_Weight.Top = 0.3444882!
        Me.txtSum_Gross_Weight.Visible = False
        Me.txtSum_Gross_Weight.Width = 1.033465!
        '
        'TextBox32
        '
        Me.TextBox32.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox32.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox32.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox32.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox32.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox32.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox32.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox32.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox32, "TextBox32")
        Me.TextBox32.DistinctField = Nothing
        Me.TextBox32.Height = 0.3937008!
        Me.TextBox32.Left = 0.2214567!
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.OutputFormat = resources.GetString("TextBox32.OutputFormat")
        Me.TextBox32.SummaryGroup = Nothing
        Me.TextBox32.Top = 0.5659449!
        Me.TextBox32.Width = 1.033465!
        '
        'txtbill_type0
        '
        Me.txtbill_type0.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbill_type0.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type0.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbill_type0.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type0.Border.RightColor = System.Drawing.Color.Black
        Me.txtbill_type0.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type0.Border.TopColor = System.Drawing.Color.Black
        Me.txtbill_type0.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtbill_type0, "txtbill_type0")
        Me.txtbill_type0.DistinctField = Nothing
        Me.txtbill_type0.Height = 0.2460631!
        Me.txtbill_type0.Left = 1.254921!
        Me.txtbill_type0.Name = "txtbill_type0"
        Me.txtbill_type0.OutputFormat = resources.GetString("txtbill_type0.OutputFormat")
        Me.txtbill_type0.SummaryGroup = Nothing
        Me.txtbill_type0.Text = Nothing
        Me.txtbill_type0.Top = 0.9104331!
        Me.txtbill_type0.Width = 0.2460631!
        '
        'TextBox34
        '
        Me.TextBox34.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox34.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox34.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox34.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox34.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox34.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox34.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox34.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox34, "TextBox34")
        Me.TextBox34.DistinctField = Nothing
        Me.TextBox34.Height = 0.3937008!
        Me.TextBox34.Left = 1.550197!
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.OutputFormat = resources.GetString("TextBox34.OutputFormat")
        Me.TextBox34.SummaryGroup = Nothing
        Me.TextBox34.Top = 0.8366142!
        Me.TextBox34.Width = 0.3198818!
        '
        'txtbill_type1
        '
        Me.txtbill_type1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbill_type1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbill_type1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type1.Border.RightColor = System.Drawing.Color.Black
        Me.txtbill_type1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type1.Border.TopColor = System.Drawing.Color.Black
        Me.txtbill_type1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtbill_type1, "txtbill_type1")
        Me.txtbill_type1.DistinctField = Nothing
        Me.txtbill_type1.Height = 0.2460631!
        Me.txtbill_type1.Left = 1.99311!
        Me.txtbill_type1.Name = "txtbill_type1"
        Me.txtbill_type1.OutputFormat = resources.GetString("txtbill_type1.OutputFormat")
        Me.txtbill_type1.SummaryGroup = Nothing
        Me.txtbill_type1.Text = Nothing
        Me.txtbill_type1.Top = 0.9104331!
        Me.txtbill_type1.Width = 0.2460631!
        '
        'TextBox36
        '
        Me.TextBox36.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox36.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox36.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox36.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox36.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox36.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox36.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox36.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox36, "TextBox36")
        Me.TextBox36.DistinctField = Nothing
        Me.TextBox36.Height = 0.3937008!
        Me.TextBox36.Left = 2.288386!
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.OutputFormat = resources.GetString("TextBox36.OutputFormat")
        Me.TextBox36.SummaryGroup = Nothing
        Me.TextBox36.Top = 0.8366142!
        Me.TextBox36.Width = 0.3937008!
        '
        'txtbill_type2
        '
        Me.txtbill_type2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbill_type2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbill_type2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type2.Border.RightColor = System.Drawing.Color.Black
        Me.txtbill_type2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type2.Border.TopColor = System.Drawing.Color.Black
        Me.txtbill_type2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtbill_type2, "txtbill_type2")
        Me.txtbill_type2.DistinctField = Nothing
        Me.txtbill_type2.Height = 0.2460631!
        Me.txtbill_type2.Left = 2.829725!
        Me.txtbill_type2.Name = "txtbill_type2"
        Me.txtbill_type2.OutputFormat = resources.GetString("txtbill_type2.OutputFormat")
        Me.txtbill_type2.SummaryGroup = Nothing
        Me.txtbill_type2.Text = Nothing
        Me.txtbill_type2.Top = 0.9104331!
        Me.txtbill_type2.Width = 0.2460631!
        '
        'TextBox38
        '
        Me.TextBox38.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox38.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox38.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox38.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox38.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox38.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox38.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox38.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox38, "TextBox38")
        Me.TextBox38.DistinctField = Nothing
        Me.TextBox38.Height = 0.3937008!
        Me.TextBox38.Left = 3.125!
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.OutputFormat = resources.GetString("TextBox38.OutputFormat")
        Me.TextBox38.SummaryGroup = Nothing
        Me.TextBox38.Top = 0.8366142!
        Me.TextBox38.Width = 0.9104331!
        '
        'txtbill_type3
        '
        Me.txtbill_type3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbill_type3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbill_type3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type3.Border.RightColor = System.Drawing.Color.Black
        Me.txtbill_type3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.txtbill_type3.Border.TopColor = System.Drawing.Color.Black
        Me.txtbill_type3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        resources.ApplyResources(Me.txtbill_type3, "txtbill_type3")
        Me.txtbill_type3.DistinctField = Nothing
        Me.txtbill_type3.Height = 0.2460631!
        Me.txtbill_type3.Left = 4.084646!
        Me.txtbill_type3.Name = "txtbill_type3"
        Me.txtbill_type3.OutputFormat = resources.GetString("txtbill_type3.OutputFormat")
        Me.txtbill_type3.SummaryGroup = Nothing
        Me.txtbill_type3.Text = Nothing
        Me.txtbill_type3.Top = 0.9104331!
        Me.txtbill_type3.Width = 0.2460631!
        '
        'TextBox40
        '
        Me.TextBox40.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox40.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox40.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox40.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox40.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox40.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox40.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox40.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox40, "TextBox40")
        Me.TextBox40.DistinctField = Nothing
        Me.TextBox40.Height = 0.3937008!
        Me.TextBox40.Left = 4.379921!
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.OutputFormat = resources.GetString("TextBox40.OutputFormat")
        Me.TextBox40.SummaryGroup = Nothing
        Me.TextBox40.Top = 0.8366142!
        Me.TextBox40.Width = 0.4183072!
        '
        'txtbill_type_other
        '
        Me.txtbill_type_other.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbill_type_other.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbill_type_other.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbill_type_other.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbill_type_other.Border.RightColor = System.Drawing.Color.Black
        Me.txtbill_type_other.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbill_type_other.Border.TopColor = System.Drawing.Color.Black
        Me.txtbill_type_other.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtbill_type_other, "txtbill_type_other")
        Me.txtbill_type_other.DataField = "bill_type_other"
        Me.txtbill_type_other.DistinctField = Nothing
        Me.txtbill_type_other.Height = 0.3937008!
        Me.txtbill_type_other.Left = 4.872047!
        Me.txtbill_type_other.Name = "txtbill_type_other"
        Me.txtbill_type_other.OutputFormat = resources.GetString("txtbill_type_other.OutputFormat")
        Me.txtbill_type_other.SummaryGroup = Nothing
        Me.txtbill_type_other.Top = 0.8366142!
        Me.txtbill_type_other.Width = 3.100394!
        '
        'TextBox41
        '
        Me.TextBox41.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox41.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox41.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox41.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox41.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox41.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox41.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox41.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox41, "TextBox41")
        Me.TextBox41.DistinctField = Nothing
        Me.TextBox41.Height = 0.3937008!
        Me.TextBox41.Left = 0.2214567!
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.OutputFormat = resources.GetString("TextBox41.OutputFormat")
        Me.TextBox41.SummaryGroup = Nothing
        Me.TextBox41.Top = 0.8366142!
        Me.TextBox41.Width = 1.033465!
        '
        'TextBox42
        '
        Me.TextBox42.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox42.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox42.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox42.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox42.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox42.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox42.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox42.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox42, "TextBox42")
        Me.TextBox42.DistinctField = Nothing
        Me.TextBox42.Height = 0.3937008!
        Me.TextBox42.Left = 0.3444882!
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.OutputFormat = resources.GetString("TextBox42.OutputFormat")
        Me.TextBox42.SummaryGroup = Nothing
        Me.TextBox42.Top = 1.13189!
        Me.TextBox42.Width = 0.3690945!
        '
        'txtbl_no
        '
        Me.txtbl_no.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbl_no.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbl_no.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbl_no.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbl_no.Border.RightColor = System.Drawing.Color.Black
        Me.txtbl_no.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbl_no.Border.TopColor = System.Drawing.Color.Black
        Me.txtbl_no.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtbl_no, "txtbl_no")
        Me.txtbl_no.DataField = "bl_no"
        Me.txtbl_no.DistinctField = Nothing
        Me.txtbl_no.Height = 0.3937008!
        Me.txtbl_no.Left = 0.8366142!
        Me.txtbl_no.Name = "txtbl_no"
        Me.txtbl_no.OutputFormat = resources.GetString("txtbl_no.OutputFormat")
        Me.txtbl_no.SummaryGroup = Nothing
        Me.txtbl_no.Top = 1.13189!
        Me.txtbl_no.Width = 1.550197!
        '
        'txtTemp_sailing_date
        '
        Me.txtTemp_sailing_date.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_sailing_date.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_sailing_date.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_sailing_date.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_sailing_date.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_sailing_date.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_sailing_date.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_sailing_date.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtTemp_sailing_date, "txtTemp_sailing_date")
        Me.txtTemp_sailing_date.DistinctField = Nothing
        Me.txtTemp_sailing_date.Height = 0.3937008!
        Me.txtTemp_sailing_date.Left = 2.952756!
        Me.txtTemp_sailing_date.Name = "txtTemp_sailing_date"
        Me.txtTemp_sailing_date.SummaryGroup = Nothing
        Me.txtTemp_sailing_date.Top = 1.13189!
        Me.txtTemp_sailing_date.Width = 1.550197!
        '
        'TextBox44
        '
        Me.TextBox44.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox44.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox44.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox44.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox44.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox44.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox44.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox44.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox44, "TextBox44")
        Me.TextBox44.DistinctField = Nothing
        Me.TextBox44.Height = 0.3937008!
        Me.TextBox44.Left = 2.534449!
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.OutputFormat = resources.GetString("TextBox44.OutputFormat")
        Me.TextBox44.SummaryGroup = Nothing
        Me.TextBox44.Top = 1.13189!
        Me.TextBox44.Width = 0.3690945!
        '
        'txtTemp_edi_date
        '
        Me.txtTemp_edi_date.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_edi_date.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_edi_date.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_edi_date.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_edi_date.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_edi_date.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_edi_date.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_edi_date.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtTemp_edi_date, "txtTemp_edi_date")
        Me.txtTemp_edi_date.DataField = "edi_date"
        Me.txtTemp_edi_date.DistinctField = Nothing
        Me.txtTemp_edi_date.Height = 0.3937008!
        Me.txtTemp_edi_date.Left = 5.536417!
        Me.txtTemp_edi_date.Name = "txtTemp_edi_date"
        Me.txtTemp_edi_date.SummaryGroup = Nothing
        Me.txtTemp_edi_date.Top = 1.13189!
        Me.txtTemp_edi_date.Width = 1.550197!
        '
        'TextBox45
        '
        Me.TextBox45.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox45.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox45.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox45.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox45.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox45.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox45.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox45.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox45, "TextBox45")
        Me.TextBox45.DistinctField = Nothing
        Me.TextBox45.Height = 0.3937008!
        Me.TextBox45.Left = 4.625985!
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.OutputFormat = resources.GetString("TextBox45.OutputFormat")
        Me.TextBox45.SummaryGroup = Nothing
        Me.TextBox45.Top = 1.13189!
        Me.TextBox45.Width = 0.9596456!
        '
        'txtbill_type
        '
        Me.txtbill_type.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbill_type.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbill_type.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbill_type.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbill_type.Border.RightColor = System.Drawing.Color.Black
        Me.txtbill_type.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbill_type.Border.TopColor = System.Drawing.Color.Black
        Me.txtbill_type.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtbill_type, "txtbill_type")
        Me.txtbill_type.DataField = "bill_type"
        Me.txtbill_type.DistinctField = Nothing
        Me.txtbill_type.Height = 0.246063!
        Me.txtbill_type.Left = 5.634842!
        Me.txtbill_type.Name = "txtbill_type"
        Me.txtbill_type.OutputFormat = resources.GetString("txtbill_type.OutputFormat")
        Me.txtbill_type.SummaryGroup = Nothing
        Me.txtbill_type.Top = 0.3444882!
        Me.txtbill_type.Visible = False
        Me.txtbill_type.Width = 0.6151576!
        '
        'TextBox16
        '
        Me.TextBox16.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox16.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox16.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox16.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox16, "TextBox16")
        Me.TextBox16.DistinctField = Nothing
        Me.TextBox16.Height = 0.3937007!
        Me.TextBox16.Left = 0.2214567!
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.OutputFormat = resources.GetString("TextBox16.OutputFormat")
        Me.TextBox16.SummaryGroup = Nothing
        Me.TextBox16.Top = 1.377953!
        Me.TextBox16.Width = 7.750984!
        '
        'TextBox17
        '
        Me.TextBox17.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox17.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox17.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox17.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox17.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox17.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox17.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox17.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox17, "TextBox17")
        Me.TextBox17.DistinctField = Nothing
        Me.TextBox17.Height = 0.3937008!
        Me.TextBox17.Left = 0.2214567!
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.OutputFormat = resources.GetString("TextBox17.OutputFormat")
        Me.TextBox17.SummaryGroup = Nothing
        Me.TextBox17.Top = 1.624016!
        Me.TextBox17.Width = 4.084646!
        '
        'TextBox18
        '
        Me.TextBox18.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox18.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox18.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox18.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox18.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox18.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox18.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox18.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox18, "TextBox18")
        Me.TextBox18.DistinctField = Nothing
        Me.TextBox18.Height = 0.3937007!
        Me.TextBox18.Left = 4.379921!
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.OutputFormat = resources.GetString("TextBox18.OutputFormat")
        Me.TextBox18.SummaryGroup = Nothing
        Me.TextBox18.Top = 1.624016!
        Me.TextBox18.Width = 1.205709!
        '
        'txtattach_file
        '
        Me.txtattach_file.Border.BottomColor = System.Drawing.Color.Black
        Me.txtattach_file.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtattach_file.Border.LeftColor = System.Drawing.Color.Black
        Me.txtattach_file.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtattach_file.Border.RightColor = System.Drawing.Color.Black
        Me.txtattach_file.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtattach_file.Border.TopColor = System.Drawing.Color.Black
        Me.txtattach_file.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtattach_file, "txtattach_file")
        Me.txtattach_file.DataField = "attach_file"
        Me.txtattach_file.DistinctField = Nothing
        Me.txtattach_file.Height = 0.3937008!
        Me.txtattach_file.Left = 5.610237!
        Me.txtattach_file.Name = "txtattach_file"
        Me.txtattach_file.OutputFormat = resources.GetString("txtattach_file.OutputFormat")
        Me.txtattach_file.SummaryGroup = Nothing
        Me.txtattach_file.Top = 1.624016!
        Me.txtattach_file.Width = 2.362205!
        '
        'TextBox19
        '
        Me.TextBox19.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox19.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox19.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox19.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox19.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox19.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox19.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox19.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox19, "TextBox19")
        Me.TextBox19.DistinctField = Nothing
        Me.TextBox19.Height = 0.3937008!
        Me.TextBox19.Left = 0.2214567!
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.OutputFormat = resources.GetString("TextBox19.OutputFormat")
        Me.TextBox19.SummaryGroup = Nothing
        Me.TextBox19.Top = 1.99311!
        Me.TextBox19.Width = 4.084646!
        '
        'TextBox20
        '
        Me.TextBox20.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox20.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox20.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox20.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox20.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox20.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox20.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox20.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox20, "TextBox20")
        Me.TextBox20.DistinctField = Nothing
        Me.TextBox20.Height = 0.9350393!
        Me.TextBox20.Left = 0.3444882!
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.OutputFormat = resources.GetString("TextBox20.OutputFormat")
        Me.TextBox20.SummaryGroup = Nothing
        Me.TextBox20.Top = 2.116142!
        Me.TextBox20.Width = 7.529528!
        '
        'txtfactory
        '
        Me.txtfactory.Border.BottomColor = System.Drawing.Color.Black
        Me.txtfactory.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory.Border.LeftColor = System.Drawing.Color.Black
        Me.txtfactory.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory.Border.RightColor = System.Drawing.Color.Black
        Me.txtfactory.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory.Border.TopColor = System.Drawing.Color.Black
        Me.txtfactory.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtfactory, "txtfactory")
        Me.txtfactory.DataField = "factory"
        Me.txtfactory.DistinctField = Nothing
        Me.txtfactory.Height = 0.3937007!
        Me.txtfactory.Left = 2.214567!
        Me.txtfactory.Name = "txtfactory"
        Me.txtfactory.OutputFormat = resources.GetString("txtfactory.OutputFormat")
        Me.txtfactory.SummaryGroup = Nothing
        Me.txtfactory.Top = 3.001969!
        Me.txtfactory.Visible = False
        Me.txtfactory.Width = 1.254921!
        '
        'txtfactory_Temp
        '
        Me.txtfactory_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtfactory_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtfactory_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtfactory_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtfactory_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtfactory_Temp, "txtfactory_Temp")
        Me.txtfactory_Temp.DistinctField = Nothing
        Me.txtfactory_Temp.Height = 0.3937008!
        Me.txtfactory_Temp.Left = 0.3444882!
        Me.txtfactory_Temp.Name = "txtfactory_Temp"
        Me.txtfactory_Temp.OutputFormat = resources.GetString("txtfactory_Temp.OutputFormat")
        Me.txtfactory_Temp.SummaryGroup = Nothing
        Me.txtfactory_Temp.Text = Nothing
        Me.txtfactory_Temp.Top = 2.829725!
        Me.txtfactory_Temp.Width = 7.529528!
        '
        'txtfactory_address
        '
        Me.txtfactory_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtfactory_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtfactory_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtfactory_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfactory_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtfactory_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtfactory_address, "txtfactory_address")
        Me.txtfactory_address.DataField = "factory_address"
        Me.txtfactory_address.DistinctField = Nothing
        Me.txtfactory_address.Height = 0.3937007!
        Me.txtfactory_address.Left = 3.494095!
        Me.txtfactory_address.Name = "txtfactory_address"
        Me.txtfactory_address.OutputFormat = resources.GetString("txtfactory_address.OutputFormat")
        Me.txtfactory_address.SummaryGroup = Nothing
        Me.txtfactory_address.Top = 3.001969!
        Me.txtfactory_address.Visible = False
        Me.txtfactory_address.Width = 1.254921!
        '
        'TextBox35
        '
        Me.TextBox35.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox35.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox35.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox35.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox35.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox35.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox35.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox35.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox35, "TextBox35")
        Me.TextBox35.DistinctField = Nothing
        Me.TextBox35.Height = 0.66437!
        Me.TextBox35.Left = 0.3444882!
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.OutputFormat = resources.GetString("TextBox35.OutputFormat")
        Me.TextBox35.SummaryGroup = Nothing
        Me.TextBox35.Top = 3.420276!
        Me.TextBox35.Width = 7.529528!
        '
        'TextBox37
        '
        Me.TextBox37.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox37.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox37.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox37.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox37.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox37.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox37.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox37.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox37, "TextBox37")
        Me.TextBox37.DistinctField = Nothing
        Me.TextBox37.Height = 0.66437!
        Me.TextBox37.Left = 0.5167323!
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.OutputFormat = resources.GetString("TextBox37.OutputFormat")
        Me.TextBox37.SummaryGroup = Nothing
        Me.TextBox37.Top = 3.912402!
        Me.TextBox37.Width = 3.543307!
        '
        'TextBox39
        '
        Me.TextBox39.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox39.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox39.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox39.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox39.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox39.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox39.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox39.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox39, "TextBox39")
        Me.TextBox39.DistinctField = Nothing
        Me.TextBox39.Height = 0.66437!
        Me.TextBox39.Left = 4.158465!
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.OutputFormat = resources.GetString("TextBox39.OutputFormat")
        Me.TextBox39.SummaryGroup = Nothing
        Me.TextBox39.Top = 3.912402!
        Me.TextBox39.Width = 3.543307!
        '
        'TextBox43
        '
        Me.TextBox43.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox43.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox43.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox43.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox43.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox43.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox43.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox43.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox43, "TextBox43")
        Me.TextBox43.DistinctField = Nothing
        Me.TextBox43.Height = 0.3937008!
        Me.TextBox43.Left = 0.2214567!
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.OutputFormat = resources.GetString("TextBox43.OutputFormat")
        Me.TextBox43.SummaryGroup = Nothing
        Me.TextBox43.Top = 4.355315!
        Me.TextBox43.Width = 1.033465!
        '
        'txtrequest_person_2
        '
        Me.txtrequest_person_2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtrequest_person_2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person_2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtrequest_person_2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person_2.Border.RightColor = System.Drawing.Color.Black
        Me.txtrequest_person_2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person_2.Border.TopColor = System.Drawing.Color.Black
        Me.txtrequest_person_2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtrequest_person_2, "txtrequest_person_2")
        Me.txtrequest_person_2.DistinctField = Nothing
        Me.txtrequest_person_2.Height = 0.3937008!
        Me.txtrequest_person_2.Left = 1.230315!
        Me.txtrequest_person_2.Name = "txtrequest_person_2"
        Me.txtrequest_person_2.OutputFormat = resources.GetString("txtrequest_person_2.OutputFormat")
        Me.txtrequest_person_2.SummaryGroup = Nothing
        Me.txtrequest_person_2.Top = 4.355315!
        Me.txtrequest_person_2.Width = 2.829725!
        '
        'TextBox46
        '
        Me.TextBox46.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox46.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox46.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox46.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox46.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox46.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox46.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox46.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.TextBox46, "TextBox46")
        Me.TextBox46.DistinctField = Nothing
        Me.TextBox46.Height = 0.3937008!
        Me.TextBox46.Left = 4.158465!
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.OutputFormat = resources.GetString("TextBox46.OutputFormat")
        Me.TextBox46.SummaryGroup = Nothing
        Me.TextBox46.Top = 4.355315!
        Me.TextBox46.Width = 3.543307!
        '
        'txtauthorize2
        '
        Me.txtauthorize2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtauthorize2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtauthorize2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtauthorize2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtauthorize2.Border.RightColor = System.Drawing.Color.Black
        Me.txtauthorize2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtauthorize2.Border.TopColor = System.Drawing.Color.Black
        Me.txtauthorize2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtauthorize2, "txtauthorize2")
        Me.txtauthorize2.DataField = "authorize2"
        Me.txtauthorize2.DistinctField = Nothing
        Me.txtauthorize2.Height = 0.246063!
        Me.txtauthorize2.Left = 6.274607!
        Me.txtauthorize2.Name = "txtauthorize2"
        Me.txtauthorize2.OutputFormat = resources.GetString("txtauthorize2.OutputFormat")
        Me.txtauthorize2.SummaryGroup = Nothing
        Me.txtauthorize2.Top = 0.3444882!
        Me.txtauthorize2.Visible = False
        Me.txtauthorize2.Width = 0.6151576!
        '
        'txtedi_date
        '
        Me.txtedi_date.Border.BottomColor = System.Drawing.Color.Black
        Me.txtedi_date.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtedi_date.Border.LeftColor = System.Drawing.Color.Black
        Me.txtedi_date.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtedi_date.Border.RightColor = System.Drawing.Color.Black
        Me.txtedi_date.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtedi_date.Border.TopColor = System.Drawing.Color.Black
        Me.txtedi_date.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtedi_date, "txtedi_date")
        Me.txtedi_date.DataField = "edi_date"
        Me.txtedi_date.DistinctField = Nothing
        Me.txtedi_date.Height = 0.246063!
        Me.txtedi_date.Left = 6.274607!
        Me.txtedi_date.Name = "txtedi_date"
        Me.txtedi_date.OutputFormat = resources.GetString("txtedi_date.OutputFormat")
        Me.txtedi_date.SummaryGroup = Nothing
        Me.txtedi_date.Top = 0.6530512!
        Me.txtedi_date.Visible = False
        Me.txtedi_date.Width = 0.6151576!
        '
        'txtsailing_date
        '
        Me.txtsailing_date.Border.BottomColor = System.Drawing.Color.Black
        Me.txtsailing_date.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtsailing_date.Border.LeftColor = System.Drawing.Color.Black
        Me.txtsailing_date.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtsailing_date.Border.RightColor = System.Drawing.Color.Black
        Me.txtsailing_date.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtsailing_date.Border.TopColor = System.Drawing.Color.Black
        Me.txtsailing_date.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        resources.ApplyResources(Me.txtsailing_date, "txtsailing_date")
        Me.txtsailing_date.DataField = "sailing_date"
        Me.txtsailing_date.DistinctField = Nothing
        Me.txtsailing_date.Height = 0.246063!
        Me.txtsailing_date.Left = 5.634842!
        Me.txtsailing_date.Name = "txtsailing_date"
        Me.txtsailing_date.OutputFormat = resources.GetString("txtsailing_date.OutputFormat")
        Me.txtsailing_date.SummaryGroup = Nothing
        Me.txtsailing_date.Top = 0.6530512!
        Me.txtsailing_date.Visible = False
        Me.txtsailing_date.Width = 0.6151576!
        '
        'PageHeader1
        '
        Me.PageHeader1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.Shape1, Me.TextBox23, Me.txtForm_Name_Temp, Me.txtForm_Name, Me.TextBox1, Me.TextBox2, Me.txtrequest_person, Me.Barcode1_invh_run_auto, Me.txtinvh_run_auto, Me.TextBox3, Me.TextBox4, Me.Line1, Me.Line2, Me.txtREFERENCE_CODE2_Temp, Me.txtREFERENCE_CODE2, Me.TextBox5, Me.TextBox6, Me.TextBox7, Me.TextBox8, Me.txtcard_id_Temp, Me.txtcard_id, Me.txtcompany_name, Me.txtcompany_taxno_Temp, Me.txtcompany_taxno, Me.txtcompany_address_Temp, Me.txtcompany_address, Me.txtcompany_phone_fax_Temp, Me.txtcompany_phone, Me.txtcompany_fax, Me.TextBox9, Me.txtdestination_company, Me.txtdestination_address_province_dest_receive_country, Me.txtdestination_address, Me.txtdestination_province, Me.txtdest_receive_country, Me.txtimport_country_Temp, Me.txtimport_country, Me.Line3, Me.TextBox10, Me.TextBox11, Me.TextBox12, Me.TextBox13, Me.TextBox14, Me.TextBox15, Me.txtship_by0, Me.txtship_by1, Me.txtship_by2, Me.txtship_by3, Me.txtship_by4, Me.TextBox21, Me.TextBox22, Me.TextBox24, Me.TextBox25, Me.Line4, Me.TextBox26, Me.TextBox27, Me.TextBox28, Me.TextBox29, Me.TextBox30, Me.txtship_by, Me.txtdestination_phone, Me.txtdestination_fax})
        Me.PageHeader1.Height = 5.21875!
        Me.PageHeader1.Name = "PageHeader1"
        '
        'Shape1
        '
        Me.Shape1.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.RightColor = System.Drawing.Color.Black
        Me.Shape1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.TopColor = System.Drawing.Color.Black
        Me.Shape1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Height = 3.838583!
        Me.Shape1.Left = 0.1476378!
        Me.Shape1.Name = "Shape1"
        Me.Shape1.RoundingRadius = 9.999999!
        Me.Shape1.Top = 1.377953!
        Me.Shape1.Width = 7.898623!
        '
        'Line1
        '
        Me.Line1.Border.BottomColor = System.Drawing.Color.Black
        Me.Line1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.LeftColor = System.Drawing.Color.Black
        Me.Line1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.RightColor = System.Drawing.Color.Black
        Me.Line1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.TopColor = System.Drawing.Color.Black
        Me.Line1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Height = 0.0!
        Me.Line1.Left = 0.1476378!
        Me.Line1.LineWeight = 1.0!
        Me.Line1.Name = "Line1"
        Me.Line1.Top = 3.001969!
        Me.Line1.Width = 7.883858!
        Me.Line1.X1 = 0.1476378!
        Me.Line1.X2 = 8.031496!
        Me.Line1.Y1 = 3.001969!
        Me.Line1.Y2 = 3.001969!
        '
        'Line2
        '
        Me.Line2.Border.BottomColor = System.Drawing.Color.Black
        Me.Line2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.LeftColor = System.Drawing.Color.Black
        Me.Line2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.RightColor = System.Drawing.Color.Black
        Me.Line2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.TopColor = System.Drawing.Color.Black
        Me.Line2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Height = 3.444881!
        Me.Line2.Left = 5.634842!
        Me.Line2.LineWeight = 1.0!
        Me.Line2.Name = "Line2"
        Me.Line2.Top = 1.377953!
        Me.Line2.Width = 0.0!
        Me.Line2.X1 = 5.634842!
        Me.Line2.X2 = 5.634842!
        Me.Line2.Y1 = 1.377953!
        Me.Line2.Y2 = 4.822834!
        '
        'Line3
        '
        Me.Line3.Border.BottomColor = System.Drawing.Color.Black
        Me.Line3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.LeftColor = System.Drawing.Color.Black
        Me.Line3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.RightColor = System.Drawing.Color.Black
        Me.Line3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.TopColor = System.Drawing.Color.Black
        Me.Line3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Height = 0.0!
        Me.Line3.Left = 0.1476378!
        Me.Line3.LineWeight = 1.0!
        Me.Line3.Name = "Line3"
        Me.Line3.Top = 4.183071!
        Me.Line3.Width = 7.883858!
        Me.Line3.X1 = 0.1476378!
        Me.Line3.X2 = 8.031496!
        Me.Line3.Y1 = 4.183071!
        Me.Line3.Y2 = 4.183071!
        '
        'Line4
        '
        Me.Line4.Border.BottomColor = System.Drawing.Color.Black
        Me.Line4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.LeftColor = System.Drawing.Color.Black
        Me.Line4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.RightColor = System.Drawing.Color.Black
        Me.Line4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.TopColor = System.Drawing.Color.Black
        Me.Line4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Height = 0.0!
        Me.Line4.Left = 0.1476378!
        Me.Line4.LineWeight = 1.0!
        Me.Line4.Name = "Line4"
        Me.Line4.Top = 4.822834!
        Me.Line4.Width = 7.874015!
        Me.Line4.X1 = 0.1476378!
        Me.Line4.X2 = 8.021653!
        Me.Line4.Y1 = 4.822834!
        Me.Line4.Y2 = 4.822834!
        '
        'Detail1
        '
        Me.Detail1.ColumnSpacing = 0.0!
        Me.Detail1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtTARIFF_CODE_Temp, Me.txtNET_WEIGHT_unit_code2, Me.txtFOB_AMT_Temp, Me.txtPRODUCT_NAME, Me.txtNum_Product, Me.txtTARIFF_CODE, Me.txtNET_WEIGHT, Me.txtFOB_AMT, Me.txtunit_code2, Me.C_TotalRowDe, Me.Line5, Me.Line7, Me.Line10, Me.Line8, Me.Line12, Me.Line13})
        Me.Detail1.Height = 0.2362205!
        Me.Detail1.Name = "Detail1"
        '
        'Line5
        '
        Me.Line5.Border.BottomColor = System.Drawing.Color.Black
        Me.Line5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.LeftColor = System.Drawing.Color.Black
        Me.Line5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.RightColor = System.Drawing.Color.Black
        Me.Line5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.TopColor = System.Drawing.Color.Black
        Me.Line5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Height = 0.0!
        Me.Line5.Left = 0.1476378!
        Me.Line5.LineWeight = 1.0!
        Me.Line5.Name = "Line5"
        Me.Line5.Top = 0.2362205!
        Me.Line5.Width = 7.895669!
        Me.Line5.X1 = 0.1476378!
        Me.Line5.X2 = 8.043307!
        Me.Line5.Y1 = 0.2362205!
        Me.Line5.Y2 = 0.2362205!
        '
        'Line7
        '
        Me.Line7.AnchorBottom = True
        Me.Line7.Border.BottomColor = System.Drawing.Color.Black
        Me.Line7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.LeftColor = System.Drawing.Color.Black
        Me.Line7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.RightColor = System.Drawing.Color.Black
        Me.Line7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.TopColor = System.Drawing.Color.Black
        Me.Line7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Height = 0.2362205!
        Me.Line7.Left = 0.1476378!
        Me.Line7.LineWeight = 1.0!
        Me.Line7.Name = "Line7"
        Me.Line7.Top = 0.0!
        Me.Line7.Width = 0.0!
        Me.Line7.X1 = 0.1476378!
        Me.Line7.X2 = 0.1476378!
        Me.Line7.Y1 = 0.0!
        Me.Line7.Y2 = 0.2362205!
        '
        'Line10
        '
        Me.Line10.AnchorBottom = True
        Me.Line10.Border.BottomColor = System.Drawing.Color.Black
        Me.Line10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.LeftColor = System.Drawing.Color.Black
        Me.Line10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.RightColor = System.Drawing.Color.Black
        Me.Line10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.TopColor = System.Drawing.Color.Black
        Me.Line10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Height = 0.2362205!
        Me.Line10.Left = 8.043307!
        Me.Line10.LineWeight = 1.0!
        Me.Line10.Name = "Line10"
        Me.Line10.Top = 0.0!
        Me.Line10.Width = 0.0!
        Me.Line10.X1 = 8.043307!
        Me.Line10.X2 = 8.043307!
        Me.Line10.Y1 = 0.0!
        Me.Line10.Y2 = 0.2362205!
        '
        'Line8
        '
        Me.Line8.AnchorBottom = True
        Me.Line8.Border.BottomColor = System.Drawing.Color.Black
        Me.Line8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.LeftColor = System.Drawing.Color.Black
        Me.Line8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.RightColor = System.Drawing.Color.Black
        Me.Line8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.TopColor = System.Drawing.Color.Black
        Me.Line8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Height = 0.2362205!
        Me.Line8.Left = 4.677166!
        Me.Line8.LineWeight = 1.0!
        Me.Line8.Name = "Line8"
        Me.Line8.Top = 0.0!
        Me.Line8.Width = 0.0!
        Me.Line8.X1 = 4.677166!
        Me.Line8.X2 = 4.677166!
        Me.Line8.Y1 = 0.0!
        Me.Line8.Y2 = 0.2362205!
        '
        'Line12
        '
        Me.Line12.AnchorBottom = True
        Me.Line12.Border.BottomColor = System.Drawing.Color.Black
        Me.Line12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.LeftColor = System.Drawing.Color.Black
        Me.Line12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.RightColor = System.Drawing.Color.Black
        Me.Line12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.TopColor = System.Drawing.Color.Black
        Me.Line12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Height = 0.2362205!
        Me.Line12.Left = 5.708662!
        Me.Line12.LineWeight = 1.0!
        Me.Line12.Name = "Line12"
        Me.Line12.Top = 0.0!
        Me.Line12.Width = 0.0!
        Me.Line12.X1 = 5.708662!
        Me.Line12.X2 = 5.708662!
        Me.Line12.Y1 = 0.0!
        Me.Line12.Y2 = 0.2362205!
        '
        'Line13
        '
        Me.Line13.AnchorBottom = True
        Me.Line13.Border.BottomColor = System.Drawing.Color.Black
        Me.Line13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.LeftColor = System.Drawing.Color.Black
        Me.Line13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.RightColor = System.Drawing.Color.Black
        Me.Line13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.TopColor = System.Drawing.Color.Black
        Me.Line13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Height = 0.2362205!
        Me.Line13.Left = 7.086614!
        Me.Line13.LineWeight = 1.0!
        Me.Line13.Name = "Line13"
        Me.Line13.Top = 0.0!
        Me.Line13.Width = 0.0!
        Me.Line13.X1 = 7.086614!
        Me.Line13.X2 = 7.086614!
        Me.Line13.Y1 = 0.0!
        Me.Line13.Y2 = 0.2362205!
        '
        'PageFooter1
        '
        Me.PageFooter1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.TextBox33, Me.Shape4, Me.TextBox31, Me.Shape3, Me.txtTotal, Me.txtSum_Net_Weight, Me.txtSum_Fob_Amt, Me.txtSum_Gross_Weight, Me.TextBox32, Me.txtbill_type0, Me.TextBox34, Me.txtbill_type1, Me.TextBox36, Me.txtbill_type2, Me.TextBox38, Me.txtbill_type3, Me.TextBox40, Me.txtbill_type_other, Me.TextBox41, Me.TextBox42, Me.txtbl_no, Me.txtTemp_sailing_date, Me.TextBox44, Me.txtTemp_edi_date, Me.TextBox45, Me.txtbill_type, Me.TextBox16, Me.TextBox17, Me.TextBox18, Me.txtattach_file, Me.Shape5, Me.TextBox19, Me.TextBox20, Me.txtfactory, Me.txtfactory_Temp, Me.txtfactory_address, Me.TextBox35, Me.TextBox37, Me.TextBox39, Me.TextBox43, Me.txtrequest_person_2, Me.TextBox46, Me.Line6, Me.txtauthorize2, Me.txtedi_date, Me.txtsailing_date})
        Me.PageFooter1.Height = 4.822834!
        Me.PageFooter1.Name = "PageFooter1"
        '
        'Shape4
        '
        Me.Shape4.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape4.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape4.Border.RightColor = System.Drawing.Color.Black
        Me.Shape4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape4.Border.TopColor = System.Drawing.Color.Black
        Me.Shape4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape4.Height = 1.697835!
        Me.Shape4.Left = 0.1476378!
        Me.Shape4.LineStyle = DataDynamics.ActiveReports.LineStyle.Transparent
        Me.Shape4.Name = "Shape4"
        Me.Shape4.RoundingRadius = 9.999999!
        Me.Shape4.Top = 0.3198819!
        Me.Shape4.Width = 7.898623!
        '
        'Shape3
        '
        Me.Shape3.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape3.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape3.Border.RightColor = System.Drawing.Color.Black
        Me.Shape3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape3.Border.TopColor = System.Drawing.Color.Black
        Me.Shape3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Height = 0.3149606!
        Me.Shape3.Left = 0.1476378!
        Me.Shape3.LineStyle = DataDynamics.ActiveReports.LineStyle.Transparent
        Me.Shape3.Name = "Shape3"
        Me.Shape3.RoundingRadius = 9.999999!
        Me.Shape3.Top = 0.0!
        Me.Shape3.Width = 7.897638!
        '
        'Shape5
        '
        Me.Shape5.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape5.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape5.Border.RightColor = System.Drawing.Color.Black
        Me.Shape5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape5.Border.TopColor = System.Drawing.Color.Black
        Me.Shape5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape5.Height = 2.706693!
        Me.Shape5.Left = 0.1476378!
        Me.Shape5.LineStyle = DataDynamics.ActiveReports.LineStyle.Transparent
        Me.Shape5.Name = "Shape5"
        Me.Shape5.RoundingRadius = 9.999999!
        Me.Shape5.Top = 2.017717!
        Me.Shape5.Width = 7.898623!
        '
        'Line6
        '
        Me.Line6.Border.BottomColor = System.Drawing.Color.Black
        Me.Line6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.LeftColor = System.Drawing.Color.Black
        Me.Line6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.RightColor = System.Drawing.Color.Black
        Me.Line6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.TopColor = System.Drawing.Color.Black
        Me.Line6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Height = 0.0!
        Me.Line6.Left = 0.1476378!
        Me.Line6.LineWeight = 1.0!
        Me.Line6.Name = "Line6"
        Me.Line6.Top = 0.0!
        Me.Line6.Width = 7.895669!
        Me.Line6.X1 = 0.1476378!
        Me.Line6.X2 = 8.043307!
        Me.Line6.Y1 = 0.0!
        Me.Line6.Y2 = 0.0!
        '
        'GroupHeader1
        '
        Me.GroupHeader1.Height = 0.0!
        Me.GroupHeader1.Name = "GroupHeader1"
        '
        'GroupFooter1
        '
        Me.GroupFooter1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.Line9, Me.Line11, Me.Line14, Me.Line15, Me.Line16})
        Me.GroupFooter1.Height = 0.0!
        Me.GroupFooter1.Name = "GroupFooter1"
        Me.GroupFooter1.Visible = False
        '
        'Line9
        '
        Me.Line9.AnchorBottom = True
        Me.Line9.Border.BottomColor = System.Drawing.Color.Black
        Me.Line9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.LeftColor = System.Drawing.Color.Black
        Me.Line9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.RightColor = System.Drawing.Color.Black
        Me.Line9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.TopColor = System.Drawing.Color.Black
        Me.Line9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Height = 2.362205!
        Me.Line9.Left = 0.1496063!
        Me.Line9.LineWeight = 1.0!
        Me.Line9.Name = "Line9"
        Me.Line9.Top = 0.0!
        Me.Line9.Width = 0.0!
        Me.Line9.X1 = 0.1496063!
        Me.Line9.X2 = 0.1496063!
        Me.Line9.Y1 = 0.0!
        Me.Line9.Y2 = 2.362205!
        '
        'Line11
        '
        Me.Line11.AnchorBottom = True
        Me.Line11.Border.BottomColor = System.Drawing.Color.Black
        Me.Line11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.LeftColor = System.Drawing.Color.Black
        Me.Line11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.RightColor = System.Drawing.Color.Black
        Me.Line11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.TopColor = System.Drawing.Color.Black
        Me.Line11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Height = 2.362205!
        Me.Line11.Left = 8.051182!
        Me.Line11.LineWeight = 1.0!
        Me.Line11.Name = "Line11"
        Me.Line11.Top = 0.0!
        Me.Line11.Width = 0.0!
        Me.Line11.X1 = 8.051182!
        Me.Line11.X2 = 8.051182!
        Me.Line11.Y1 = 0.0!
        Me.Line11.Y2 = 2.362205!
        '
        'Line14
        '
        Me.Line14.AnchorBottom = True
        Me.Line14.Border.BottomColor = System.Drawing.Color.Black
        Me.Line14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.LeftColor = System.Drawing.Color.Black
        Me.Line14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.RightColor = System.Drawing.Color.Black
        Me.Line14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.TopColor = System.Drawing.Color.Black
        Me.Line14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Height = 2.362205!
        Me.Line14.Left = 7.086614!
        Me.Line14.LineWeight = 1.0!
        Me.Line14.Name = "Line14"
        Me.Line14.Top = 0.0!
        Me.Line14.Width = 0.0!
        Me.Line14.X1 = 7.086614!
        Me.Line14.X2 = 7.086614!
        Me.Line14.Y1 = 0.0!
        Me.Line14.Y2 = 2.362205!
        '
        'Line15
        '
        Me.Line15.AnchorBottom = True
        Me.Line15.Border.BottomColor = System.Drawing.Color.Black
        Me.Line15.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line15.Border.LeftColor = System.Drawing.Color.Black
        Me.Line15.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line15.Border.RightColor = System.Drawing.Color.Black
        Me.Line15.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line15.Border.TopColor = System.Drawing.Color.Black
        Me.Line15.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line15.Height = 2.362205!
        Me.Line15.Left = 5.708662!
        Me.Line15.LineWeight = 1.0!
        Me.Line15.Name = "Line15"
        Me.Line15.Top = 0.0!
        Me.Line15.Width = 0.0!
        Me.Line15.X1 = 5.708662!
        Me.Line15.X2 = 5.708662!
        Me.Line15.Y1 = 0.0!
        Me.Line15.Y2 = 2.362205!
        '
        'Line16
        '
        Me.Line16.AnchorBottom = True
        Me.Line16.Border.BottomColor = System.Drawing.Color.Black
        Me.Line16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.LeftColor = System.Drawing.Color.Black
        Me.Line16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.RightColor = System.Drawing.Color.Black
        Me.Line16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.TopColor = System.Drawing.Color.Black
        Me.Line16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Height = 2.362205!
        Me.Line16.Left = 4.677166!
        Me.Line16.LineWeight = 1.0!
        Me.Line16.Name = "Line16"
        Me.Line16.Top = 0.0!
        Me.Line16.Width = 0.0!
        Me.Line16.X1 = 4.677166!
        Me.Line16.X2 = 4.677166!
        Me.Line16.Y1 = 0.0!
        Me.Line16.Y2 = 2.362205!
        '
        'rpt3_ReEdi_A
        '
        Me.MasterReport = False
        Me.PageSettings.Margins.Bottom = 0.0!
        Me.PageSettings.Margins.Left = 0.0!
        Me.PageSettings.Margins.Right = 0.0!
        Me.PageSettings.Margins.Top = 0.0!
        Me.PageSettings.PaperHeight = 11.69!
        Me.PageSettings.PaperWidth = 8.27!
        Me.PrintWidth = 8.267716!
        Me.Sections.Add(Me.PageHeader1)
        Me.Sections.Add(Me.GroupHeader1)
        Me.Sections.Add(Me.Detail1)
        Me.Sections.Add(Me.GroupFooter1)
        Me.Sections.Add(Me.PageFooter1)
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Arial; font-style: normal; text-decoration: none; font-weight: norma" & _
                    "l; font-size: 10pt; color: Black; ", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 16pt; font-weight: bold; ", "Heading1", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Times New Roman; font-size: 14pt; font-weight: bold; font-style: ita" & _
                    "lic; ", "Heading2", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 13pt; font-weight: bold; ", "Heading3", "Normal"))
        CType(Me.TextBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtForm_Name_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtForm_Name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtrequest_person, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtREFERENCE_CODE2_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtREFERENCE_CODE2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcard_id_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcard_id, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_taxno_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_address_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_phone_fax_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_address_province_dest_receive_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_receive_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtimport_country_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtimport_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtship_by0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtship_by1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtship_by2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtship_by3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtship_by4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtship_by, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTARIFF_CODE_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNET_WEIGHT_unit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOB_AMT_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPRODUCT_NAME, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNum_Product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTARIFF_CODE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNET_WEIGHT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOB_AMT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSum_Net_Weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSum_Fob_Amt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSum_Gross_Weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbill_type0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbill_type1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbill_type2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbill_type3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbill_type_other, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbl_no, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_sailing_date, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_edi_date, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbill_type, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtattach_file, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtfactory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtfactory_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtfactory_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtrequest_person_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtauthorize2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtedi_date, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtsailing_date, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Friend WithEvents Shape1 As DataDynamics.ActiveReports.Shape
    Friend WithEvents txtForm_Name_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtForm_Name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtrequest_person As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Barcode1_invh_run_auto As DataDynamics.ActiveReports.Barcode
    Friend WithEvents txtinvh_run_auto As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line1 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line2 As DataDynamics.ActiveReports.Line
    Friend WithEvents txtREFERENCE_CODE2_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtREFERENCE_CODE2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox6 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox7 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcard_id_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcard_id As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_taxno_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_taxno As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_address_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_phone_fax_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox9 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_company As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_address_province_dest_receive_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_receive_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtimport_country_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtimport_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line3 As DataDynamics.ActiveReports.Line
    Friend WithEvents TextBox10 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox11 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox12 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox13 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox14 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox15 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtship_by0 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtship_by1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtship_by2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtship_by3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtship_by4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox21 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox22 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox23 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox24 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox25 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line4 As DataDynamics.ActiveReports.Line
    Friend WithEvents TextBox26 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox27 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox28 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox29 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox30 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTARIFF_CODE_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNET_WEIGHT_unit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtFOB_AMT_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtPRODUCT_NAME As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNum_Product As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTARIFF_CODE As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNET_WEIGHT As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtFOB_AMT As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtunit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtship_by As DataDynamics.ActiveReports.TextBox
    Friend WithEvents GroupHeader1 As DataDynamics.ActiveReports.GroupHeader
    Friend WithEvents GroupFooter1 As DataDynamics.ActiveReports.GroupFooter
    Public WithEvents C_TotalRowDe As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Shape3 As DataDynamics.ActiveReports.Shape
    Friend WithEvents txtTotal As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtSum_Net_Weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtSum_Fob_Amt As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Shape4 As DataDynamics.ActiveReports.Shape
    Friend WithEvents TextBox31 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox32 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbill_type0 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox34 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbill_type1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox36 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbill_type2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox38 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbill_type3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox40 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbill_type_other As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox41 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox42 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbl_no As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_sailing_date As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox44 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_edi_date As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox45 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbill_type As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox16 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox17 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox18 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtattach_file As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Shape5 As DataDynamics.ActiveReports.Shape
    Friend WithEvents TextBox19 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox20 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtfactory As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtfactory_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtfactory_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox33 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox35 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox37 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox39 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox43 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtrequest_person_2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox46 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line5 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line7 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line10 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line6 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line9 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line11 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line8 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line12 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line13 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line14 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line15 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line16 As DataDynamics.ActiveReports.Line
    Friend WithEvents txtdestination_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_fax As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtSum_Gross_Weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtauthorize2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtedi_date As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtsailing_date As DataDynamics.ActiveReports.TextBox
End Class
