<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class rpt3_ediFORM4_4 
    Inherits DataDynamics.ActiveReports.ActiveReport3 

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
        End If
        MyBase.Dispose(disposing)
    End Sub
    
    'NOTE: The following procedure is required by the ActiveReports Designer
    'It can be modified using the ActiveReports Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(rpt3_ediFORM4_4))
        Me.Detail1 = New DataDynamics.ActiveReports.Detail
        Me.txtNumRowCount = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_marks = New DataDynamics.ActiveReports.TextBox
        Me.txtT_product = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_box8 = New DataDynamics.ActiveReports.TextBox
        Me.txtTolInvoice = New DataDynamics.ActiveReports.TextBox
        Me.txtGrossTxt = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no1 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no2 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no3 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no4 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no5 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_date1 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_date2 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_date3 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_date4 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_date5 = New DataDynamics.ActiveReports.TextBox
        Me.txtGross_Weight = New DataDynamics.ActiveReports.TextBox
        Me.txtmarks1 = New DataDynamics.ActiveReports.TextBox
        Me.txtproduct_n1 = New DataDynamics.ActiveReports.TextBox
        Me.txtproduct_n2 = New DataDynamics.ActiveReports.TextBox
        Me.txtquantity1 = New DataDynamics.ActiveReports.TextBox
        Me.txtq_unit_code1 = New DataDynamics.ActiveReports.TextBox
        Me.txtquantity2 = New DataDynamics.ActiveReports.TextBox
        Me.txtq_unit_code2 = New DataDynamics.ActiveReports.TextBox
        Me.txtquantity3 = New DataDynamics.ActiveReports.TextBox
        Me.txtq_unit_code3 = New DataDynamics.ActiveReports.TextBox
        Me.txtquantity4 = New DataDynamics.ActiveReports.TextBox
        Me.txtq_unit_code4 = New DataDynamics.ActiveReports.TextBox
        Me.txtquantity5 = New DataDynamics.ActiveReports.TextBox
        Me.txtq_unit_code5 = New DataDynamics.ActiveReports.TextBox
        Me.txtg_unit_code = New DataDynamics.ActiveReports.TextBox
        Me.C_TotalRowDe = New DataDynamics.ActiveReports.TextBox
        Me.txttariff_code = New DataDynamics.ActiveReports.TextBox
        Me.txtg_Unit_Desc = New DataDynamics.ActiveReports.TextBox
        Me.txtFOB_AMT = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_board = New DataDynamics.ActiveReports.TextBox
        Me.txtWeightDisplayHeader = New DataDynamics.ActiveReports.TextBox
        Me.txtFOBDisplay = New DataDynamics.ActiveReports.TextBox
        Me.txtunit_code2 = New DataDynamics.ActiveReports.TextBox
        Me.txtnet_weight = New DataDynamics.ActiveReports.TextBox
        Me.txtgross_weightH = New DataDynamics.ActiveReports.TextBox
        Me.txtthird_country = New DataDynamics.ActiveReports.TextBox
        Me.txtplace_exibition = New DataDynamics.ActiveReports.TextBox
        Me.txtWeightDisplayHeaderH = New DataDynamics.ActiveReports.TextBox
        Me.txtmarks = New DataDynamics.ActiveReports.TextBox
        Me.txtNumInvoice = New DataDynamics.ActiveReports.TextBox
        Me.txtUSDInvoice = New DataDynamics.ActiveReports.TextBox
        Me.txtbox8 = New DataDynamics.ActiveReports.TextBox
        Me.PageHeader1 = New DataDynamics.ActiveReports.PageHeader
        Me.txtCompany_Check_1 = New DataDynamics.ActiveReports.TextBox
        Me.txtreference_code2_Temp = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_Check2 = New DataDynamics.ActiveReports.TextBox
        Me.txttransport_by = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_taxno = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_country = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_province = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_address = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_name = New DataDynamics.ActiveReports.TextBox
        Me.txtob_address = New DataDynamics.ActiveReports.TextBox
        Me.txtdest_remark = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_fax = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_phone = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_company = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_fax = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_address = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_phone = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_province = New DataDynamics.ActiveReports.TextBox
        Me.txtdest_Receive_country = New DataDynamics.ActiveReports.TextBox
        Me.txtreference_code2 = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_email = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_email = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_taxid = New DataDynamics.ActiveReports.TextBox
        Me.txtdest_remark1 = New DataDynamics.ActiveReports.TextBox
        Me.txtob_dest_address = New DataDynamics.ActiveReports.TextBox
        Me.txtAustralia_Thailand = New DataDynamics.ActiveReports.TextBox
        Me.ReportInfo1 = New DataDynamics.ActiveReports.ReportInfo
        Me.PageFooter1 = New DataDynamics.ActiveReports.PageFooter
        Me.txtINDIA = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_provincefoot1 = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_provincefoot = New DataDynamics.ActiveReports.TextBox
        Me.txtshow_check = New DataDynamics.ActiveReports.TextBox
        Me.txtback_country = New DataDynamics.ActiveReports.TextBox
        Me.txtinvh_run_auto = New DataDynamics.ActiveReports.TextBox
        CType(Me.txtNumRowCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_marks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtT_product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_box8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTolInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrossTxt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGross_Weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtmarks1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_n1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_n2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtg_unit_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttariff_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtg_Unit_Desc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOB_AMT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_board, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtWeightDisplayHeader, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOBDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtnet_weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgross_weightH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtthird_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtplace_exibition, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtWeightDisplayHeaderH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtmarks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNumInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUSDInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompany_Check_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtreference_code2_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_Check2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttransport_by, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtob_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_remark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_Receive_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtreference_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_email, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_email, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_taxid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_remark1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtob_dest_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAustralia_Thailand, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReportInfo1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtINDIA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_provincefoot1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_provincefoot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtshow_check, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtback_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'Detail1
        '
        Me.Detail1.CanShrink = True
        Me.Detail1.ColumnSpacing = 0.0!
        Me.Detail1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtNumRowCount, Me.txtTemp_marks, Me.txtT_product, Me.txtTemp_box8, Me.txtTolInvoice, Me.txtGrossTxt, Me.txtinvoice_no1, Me.txtinvoice_no2, Me.txtinvoice_no3, Me.txtinvoice_no4, Me.txtinvoice_no5, Me.txtinvoice_date1, Me.txtinvoice_date2, Me.txtinvoice_date3, Me.txtinvoice_date4, Me.txtinvoice_date5, Me.txtGross_Weight, Me.txtmarks1, Me.txtproduct_n1, Me.txtproduct_n2, Me.txtquantity1, Me.txtq_unit_code1, Me.txtquantity2, Me.txtq_unit_code2, Me.txtquantity3, Me.txtq_unit_code3, Me.txtquantity4, Me.txtq_unit_code4, Me.txtquantity5, Me.txtq_unit_code5, Me.txtg_unit_code, Me.C_TotalRowDe, Me.txttariff_code, Me.txtg_Unit_Desc, Me.txtFOB_AMT, Me.txtinvoice_board, Me.txtWeightDisplayHeader, Me.txtFOBDisplay, Me.txtunit_code2, Me.txtnet_weight, Me.txtgross_weightH, Me.txtthird_country, Me.txtplace_exibition, Me.txtWeightDisplayHeaderH, Me.txtmarks, Me.txtNumInvoice, Me.txtUSDInvoice, Me.txtbox8})
        Me.Detail1.Height = 0.22!
        Me.Detail1.Name = "Detail1"
        '
        'txtNumRowCount
        '
        Me.txtNumRowCount.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.RightColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.TopColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Height = 0.2204724!
        Me.txtNumRowCount.Left = 0.3333333!
        Me.txtNumRowCount.Name = "txtNumRowCount"
        Me.txtNumRowCount.Style = "ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: BrowalliaUPC; " & _
            ""
        Me.txtNumRowCount.Text = Nothing
        Me.txtNumRowCount.Top = 0.0!
        Me.txtNumRowCount.Width = 0.7637799!
        '
        'txtTemp_marks
        '
        Me.txtTemp_marks.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Height = 0.2204724!
        Me.txtTemp_marks.Left = 1.15625!
        Me.txtTemp_marks.Name = "txtTemp_marks"
        Me.txtTemp_marks.Style = "ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtTemp_marks.Text = Nothing
        Me.txtTemp_marks.Top = 0.0!
        Me.txtTemp_marks.Visible = False
        Me.txtTemp_marks.Width = 0.8110237!
        '
        'txtT_product
        '
        Me.txtT_product.Border.BottomColor = System.Drawing.Color.Black
        Me.txtT_product.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.LeftColor = System.Drawing.Color.Black
        Me.txtT_product.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.RightColor = System.Drawing.Color.Black
        Me.txtT_product.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.TopColor = System.Drawing.Color.Black
        Me.txtT_product.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Height = 0.22!
        Me.txtT_product.Left = 2.0!
        Me.txtT_product.Name = "txtT_product"
        Me.txtT_product.Style = "ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtT_product.Text = Nothing
        Me.txtT_product.Top = 0.0!
        Me.txtT_product.Width = 3.563!
        '
        'txtTemp_box8
        '
        Me.txtTemp_box8.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Height = 0.22!
        Me.txtTemp_box8.Left = 5.5625!
        Me.txtTemp_box8.Name = "txtTemp_box8"
        Me.txtTemp_box8.Style = "ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: BrowalliaUPC; " & _
            ""
        Me.txtTemp_box8.Text = Nothing
        Me.txtTemp_box8.Top = 0.0!
        Me.txtTemp_box8.Width = 0.875!
        '
        'txtTolInvoice
        '
        Me.txtTolInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Height = 0.2204724!
        Me.txtTolInvoice.Left = 7.21875!
        Me.txtTolInvoice.Name = "txtTolInvoice"
        Me.txtTolInvoice.Style = "ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: BrowalliaUPC; " & _
            ""
        Me.txtTolInvoice.Text = Nothing
        Me.txtTolInvoice.Top = 0.0!
        Me.txtTolInvoice.Visible = False
        Me.txtTolInvoice.Width = 0.8110237!
        '
        'txtGrossTxt
        '
        Me.txtGrossTxt.Border.BottomColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.LeftColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.RightColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.TopColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Height = 0.22!
        Me.txtGrossTxt.Left = 6.416667!
        Me.txtGrossTxt.Name = "txtGrossTxt"
        Me.txtGrossTxt.Style = "ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: BrowalliaUPC; " & _
            ""
        Me.txtGrossTxt.Text = Nothing
        Me.txtGrossTxt.Top = 0.0!
        Me.txtGrossTxt.Visible = False
        Me.txtGrossTxt.Width = 0.82!
        '
        'txtinvoice_no1
        '
        Me.txtinvoice_no1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.DataField = "invoice_no1"
        Me.txtinvoice_no1.Height = 0.1979167!
        Me.txtinvoice_no1.Left = 0.1230315!
        Me.txtinvoice_no1.Name = "txtinvoice_no1"
        Me.txtinvoice_no1.Style = "color: Red; "
        Me.txtinvoice_no1.Text = "invoice_no1"
        Me.txtinvoice_no1.Top = 0.5413386!
        Me.txtinvoice_no1.Visible = False
        Me.txtinvoice_no1.Width = 1.0!
        '
        'txtinvoice_no2
        '
        Me.txtinvoice_no2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.DataField = "invoice_no2"
        Me.txtinvoice_no2.Height = 0.1979167!
        Me.txtinvoice_no2.Left = 1.13189!
        Me.txtinvoice_no2.Name = "txtinvoice_no2"
        Me.txtinvoice_no2.Style = "color: Red; "
        Me.txtinvoice_no2.Text = "invoice_no2"
        Me.txtinvoice_no2.Top = 0.5413386!
        Me.txtinvoice_no2.Visible = False
        Me.txtinvoice_no2.Width = 1.0!
        '
        'txtinvoice_no3
        '
        Me.txtinvoice_no3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.DataField = "invoice_no3"
        Me.txtinvoice_no3.Height = 0.1979167!
        Me.txtinvoice_no3.Left = 2.140748!
        Me.txtinvoice_no3.Name = "txtinvoice_no3"
        Me.txtinvoice_no3.Style = "color: Red; "
        Me.txtinvoice_no3.Text = "invoice_no3"
        Me.txtinvoice_no3.Top = 0.5413386!
        Me.txtinvoice_no3.Visible = False
        Me.txtinvoice_no3.Width = 1.0!
        '
        'txtinvoice_no4
        '
        Me.txtinvoice_no4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.DataField = "invoice_no4"
        Me.txtinvoice_no4.Height = 0.1979167!
        Me.txtinvoice_no4.Left = 3.149606!
        Me.txtinvoice_no4.Name = "txtinvoice_no4"
        Me.txtinvoice_no4.Style = "color: Red; "
        Me.txtinvoice_no4.Text = "invoice_no4"
        Me.txtinvoice_no4.Top = 0.5413386!
        Me.txtinvoice_no4.Visible = False
        Me.txtinvoice_no4.Width = 1.0!
        '
        'txtinvoice_no5
        '
        Me.txtinvoice_no5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.DataField = "invoice_no5"
        Me.txtinvoice_no5.Height = 0.1979167!
        Me.txtinvoice_no5.Left = 4.158464!
        Me.txtinvoice_no5.Name = "txtinvoice_no5"
        Me.txtinvoice_no5.Style = "color: Red; "
        Me.txtinvoice_no5.Text = "invoice_no5"
        Me.txtinvoice_no5.Top = 0.5413386!
        Me.txtinvoice_no5.Visible = False
        Me.txtinvoice_no5.Width = 1.0!
        '
        'txtinvoice_date1
        '
        Me.txtinvoice_date1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.DataField = "invoice_date1"
        Me.txtinvoice_date1.Height = 0.1979167!
        Me.txtinvoice_date1.Left = 0.1230315!
        Me.txtinvoice_date1.Name = "txtinvoice_date1"
        Me.txtinvoice_date1.Style = "color: Red; "
        Me.txtinvoice_date1.Text = "invoice_date1"
        Me.txtinvoice_date1.Top = 0.8120077!
        Me.txtinvoice_date1.Visible = False
        Me.txtinvoice_date1.Width = 1.0!
        '
        'txtinvoice_date2
        '
        Me.txtinvoice_date2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.DataField = "invoice_date2"
        Me.txtinvoice_date2.Height = 0.1979167!
        Me.txtinvoice_date2.Left = 1.13189!
        Me.txtinvoice_date2.Name = "txtinvoice_date2"
        Me.txtinvoice_date2.Style = "color: Red; "
        Me.txtinvoice_date2.Text = "invoice_date2"
        Me.txtinvoice_date2.Top = 0.8120077!
        Me.txtinvoice_date2.Visible = False
        Me.txtinvoice_date2.Width = 1.0!
        '
        'txtinvoice_date3
        '
        Me.txtinvoice_date3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.DataField = "invoice_date3"
        Me.txtinvoice_date3.Height = 0.1979167!
        Me.txtinvoice_date3.Left = 2.140748!
        Me.txtinvoice_date3.Name = "txtinvoice_date3"
        Me.txtinvoice_date3.Style = "color: Red; "
        Me.txtinvoice_date3.Text = "invoice_date3"
        Me.txtinvoice_date3.Top = 0.8120077!
        Me.txtinvoice_date3.Visible = False
        Me.txtinvoice_date3.Width = 1.0!
        '
        'txtinvoice_date4
        '
        Me.txtinvoice_date4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.DataField = "invoice_date4"
        Me.txtinvoice_date4.Height = 0.1979167!
        Me.txtinvoice_date4.Left = 3.149606!
        Me.txtinvoice_date4.Name = "txtinvoice_date4"
        Me.txtinvoice_date4.Style = "color: Red; "
        Me.txtinvoice_date4.Text = "invoice_date4"
        Me.txtinvoice_date4.Top = 0.8120077!
        Me.txtinvoice_date4.Visible = False
        Me.txtinvoice_date4.Width = 1.0!
        '
        'txtinvoice_date5
        '
        Me.txtinvoice_date5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.DataField = "invoice_date5"
        Me.txtinvoice_date5.Height = 0.1979167!
        Me.txtinvoice_date5.Left = 4.158464!
        Me.txtinvoice_date5.Name = "txtinvoice_date5"
        Me.txtinvoice_date5.Style = "color: Red; "
        Me.txtinvoice_date5.Text = "invoice_date5"
        Me.txtinvoice_date5.Top = 0.8120077!
        Me.txtinvoice_date5.Visible = False
        Me.txtinvoice_date5.Width = 1.0!
        '
        'txtGross_Weight
        '
        Me.txtGross_Weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.DataField = "Gross_Weight"
        Me.txtGross_Weight.Height = 0.1979167!
        Me.txtGross_Weight.Left = 3.125!
        Me.txtGross_Weight.Name = "txtGross_Weight"
        Me.txtGross_Weight.Style = "color: Lime; "
        Me.txtGross_Weight.Text = "Gross_Weight"
        Me.txtGross_Weight.Top = 1.845472!
        Me.txtGross_Weight.Visible = False
        Me.txtGross_Weight.Width = 1.0!
        '
        'txtmarks1
        '
        Me.txtmarks1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtmarks1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtmarks1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks1.Border.RightColor = System.Drawing.Color.Black
        Me.txtmarks1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks1.Border.TopColor = System.Drawing.Color.Black
        Me.txtmarks1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks1.DataField = "marks"
        Me.txtmarks1.Height = 0.1979167!
        Me.txtmarks1.Left = 1.13189!
        Me.txtmarks1.Name = "txtmarks1"
        Me.txtmarks1.Style = "color: Red; "
        Me.txtmarks1.Text = "marks"
        Me.txtmarks1.Top = 1.082677!
        Me.txtmarks1.Visible = False
        Me.txtmarks1.Width = 1.0!
        '
        'txtproduct_n1
        '
        Me.txtproduct_n1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.DataField = "product_n1"
        Me.txtproduct_n1.Height = 0.1979167!
        Me.txtproduct_n1.Left = 2.140748!
        Me.txtproduct_n1.Name = "txtproduct_n1"
        Me.txtproduct_n1.Style = "color: Red; text-align: left; "
        Me.txtproduct_n1.Text = "product_n1"
        Me.txtproduct_n1.Top = 1.082677!
        Me.txtproduct_n1.Visible = False
        Me.txtproduct_n1.Width = 1.0!
        '
        'txtproduct_n2
        '
        Me.txtproduct_n2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.DataField = "product_n2"
        Me.txtproduct_n2.Height = 0.1979167!
        Me.txtproduct_n2.Left = 3.149606!
        Me.txtproduct_n2.Name = "txtproduct_n2"
        Me.txtproduct_n2.Style = "color: Red; "
        Me.txtproduct_n2.Text = "product_n2"
        Me.txtproduct_n2.Top = 1.082677!
        Me.txtproduct_n2.Visible = False
        Me.txtproduct_n2.Width = 1.0!
        '
        'txtquantity1
        '
        Me.txtquantity1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.DataField = "quantity1"
        Me.txtquantity1.Height = 0.1979167!
        Me.txtquantity1.Left = 0.1230315!
        Me.txtquantity1.Name = "txtquantity1"
        Me.txtquantity1.Style = "color: Red; text-align: left; "
        Me.txtquantity1.Text = "quantity1"
        Me.txtquantity1.Top = 1.254921!
        Me.txtquantity1.Visible = False
        Me.txtquantity1.Width = 1.0!
        '
        'txtq_unit_code1
        '
        Me.txtq_unit_code1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.DataField = "q_unit_code1"
        Me.txtq_unit_code1.Height = 0.1979167!
        Me.txtq_unit_code1.Left = 1.13189!
        Me.txtq_unit_code1.Name = "txtq_unit_code1"
        Me.txtq_unit_code1.Style = "color: Red; "
        Me.txtq_unit_code1.Text = "q_unit_code1"
        Me.txtq_unit_code1.Top = 1.254921!
        Me.txtq_unit_code1.Visible = False
        Me.txtq_unit_code1.Width = 1.0!
        '
        'txtquantity2
        '
        Me.txtquantity2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.DataField = "quantity2"
        Me.txtquantity2.Height = 0.1979167!
        Me.txtquantity2.Left = 0.1230315!
        Me.txtquantity2.Name = "txtquantity2"
        Me.txtquantity2.Style = "color: Red; text-align: left; "
        Me.txtquantity2.Text = "quantity2"
        Me.txtquantity2.Top = 1.525591!
        Me.txtquantity2.Visible = False
        Me.txtquantity2.Width = 1.0!
        '
        'txtq_unit_code2
        '
        Me.txtq_unit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.DataField = "q_unit_code2"
        Me.txtq_unit_code2.Height = 0.1979167!
        Me.txtq_unit_code2.Left = 1.13189!
        Me.txtq_unit_code2.Name = "txtq_unit_code2"
        Me.txtq_unit_code2.Style = "color: Red; "
        Me.txtq_unit_code2.Text = "q_unit_code2"
        Me.txtq_unit_code2.Top = 1.525591!
        Me.txtq_unit_code2.Visible = False
        Me.txtq_unit_code2.Width = 1.0!
        '
        'txtquantity3
        '
        Me.txtquantity3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.DataField = "quantity3"
        Me.txtquantity3.Height = 0.1979167!
        Me.txtquantity3.Left = 0.1230315!
        Me.txtquantity3.Name = "txtquantity3"
        Me.txtquantity3.Style = "color: Red; text-align: left; "
        Me.txtquantity3.Text = "quantity3"
        Me.txtquantity3.Top = 1.79626!
        Me.txtquantity3.Visible = False
        Me.txtquantity3.Width = 1.0!
        '
        'txtq_unit_code3
        '
        Me.txtq_unit_code3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.DataField = "q_unit_code3"
        Me.txtq_unit_code3.Height = 0.1979167!
        Me.txtq_unit_code3.Left = 1.13189!
        Me.txtq_unit_code3.Name = "txtq_unit_code3"
        Me.txtq_unit_code3.Style = "color: Red; "
        Me.txtq_unit_code3.Text = "q_unit_code3"
        Me.txtq_unit_code3.Top = 1.79626!
        Me.txtq_unit_code3.Visible = False
        Me.txtq_unit_code3.Width = 1.0!
        '
        'txtquantity4
        '
        Me.txtquantity4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.DataField = "quantity4"
        Me.txtquantity4.Height = 0.1979167!
        Me.txtquantity4.Left = 0.1230315!
        Me.txtquantity4.Name = "txtquantity4"
        Me.txtquantity4.Style = "color: Red; text-align: left; "
        Me.txtquantity4.Text = "quantity4"
        Me.txtquantity4.Top = 2.042323!
        Me.txtquantity4.Visible = False
        Me.txtquantity4.Width = 1.0!
        '
        'txtq_unit_code4
        '
        Me.txtq_unit_code4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.DataField = "q_unit_code4"
        Me.txtq_unit_code4.Height = 0.1979167!
        Me.txtq_unit_code4.Left = 1.13189!
        Me.txtq_unit_code4.Name = "txtq_unit_code4"
        Me.txtq_unit_code4.Style = "color: Red; "
        Me.txtq_unit_code4.Text = "q_unit_code4"
        Me.txtq_unit_code4.Top = 2.042323!
        Me.txtq_unit_code4.Visible = False
        Me.txtq_unit_code4.Width = 1.0!
        '
        'txtquantity5
        '
        Me.txtquantity5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.DataField = "quantity5"
        Me.txtquantity5.Height = 0.1979167!
        Me.txtquantity5.Left = 0.1230315!
        Me.txtquantity5.Name = "txtquantity5"
        Me.txtquantity5.Style = "color: Red; text-align: left; "
        Me.txtquantity5.Text = "quantity5"
        Me.txtquantity5.Top = 2.312992!
        Me.txtquantity5.Visible = False
        Me.txtquantity5.Width = 1.0!
        '
        'txtq_unit_code5
        '
        Me.txtq_unit_code5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.DataField = "q_unit_code5"
        Me.txtq_unit_code5.Height = 0.1979167!
        Me.txtq_unit_code5.Left = 1.13189!
        Me.txtq_unit_code5.Name = "txtq_unit_code5"
        Me.txtq_unit_code5.Style = "color: Red; "
        Me.txtq_unit_code5.Text = "q_unit_code5"
        Me.txtq_unit_code5.Top = 2.312992!
        Me.txtq_unit_code5.Visible = False
        Me.txtq_unit_code5.Width = 1.0!
        '
        'txtg_unit_code
        '
        Me.txtg_unit_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.RightColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.TopColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.DataField = "g_unit_code"
        Me.txtg_unit_code.Height = 0.1979167!
        Me.txtg_unit_code.Left = 2.140748!
        Me.txtg_unit_code.Name = "txtg_unit_code"
        Me.txtg_unit_code.Style = "color: Red; "
        Me.txtg_unit_code.Text = "g_unit_code"
        Me.txtg_unit_code.Top = 1.32874!
        Me.txtg_unit_code.Visible = False
        Me.txtg_unit_code.Width = 1.0!
        '
        'C_TotalRowDe
        '
        Me.C_TotalRowDe.Border.BottomColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.LeftColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.RightColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.TopColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Height = 0.1979167!
        Me.C_TotalRowDe.Left = 2.140748!
        Me.C_TotalRowDe.Name = "C_TotalRowDe"
        Me.C_TotalRowDe.Style = "color: Lime; "
        Me.C_TotalRowDe.Text = "C_TotalRowDe"
        Me.C_TotalRowDe.Top = 1.599409!
        Me.C_TotalRowDe.Visible = False
        Me.C_TotalRowDe.Width = 1.0!
        '
        'txttariff_code
        '
        Me.txttariff_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.RightColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.TopColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.DataField = "tariff_code"
        Me.txttariff_code.Height = 0.1979167!
        Me.txttariff_code.Left = 3.149606!
        Me.txttariff_code.Name = "txttariff_code"
        Me.txttariff_code.Style = "color: Red; "
        Me.txttariff_code.Text = "tariff_code"
        Me.txttariff_code.Top = 1.32874!
        Me.txttariff_code.Visible = False
        Me.txttariff_code.Width = 1.0!
        '
        'txtg_Unit_Desc
        '
        Me.txtg_Unit_Desc.Border.BottomColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.LeftColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.RightColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.TopColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.DataField = "g_Unit_Desc"
        Me.txtg_Unit_Desc.Height = 0.1979167!
        Me.txtg_Unit_Desc.Left = 3.149606!
        Me.txtg_Unit_Desc.Name = "txtg_Unit_Desc"
        Me.txtg_Unit_Desc.Style = "color: Lime; "
        Me.txtg_Unit_Desc.Text = "g_Unit_Desc"
        Me.txtg_Unit_Desc.Top = 1.599409!
        Me.txtg_Unit_Desc.Visible = False
        Me.txtg_Unit_Desc.Width = 1.0!
        '
        'txtFOB_AMT
        '
        Me.txtFOB_AMT.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.DataField = "FOB_AMT"
        Me.txtFOB_AMT.Height = 0.1979167!
        Me.txtFOB_AMT.Left = 3.125!
        Me.txtFOB_AMT.Name = "txtFOB_AMT"
        Me.txtFOB_AMT.Style = "color: Lime; "
        Me.txtFOB_AMT.Text = "FOB_AMT"
        Me.txtFOB_AMT.Top = 2.116143!
        Me.txtFOB_AMT.Visible = False
        Me.txtFOB_AMT.Width = 1.0!
        '
        'txtinvoice_board
        '
        Me.txtinvoice_board.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.DataField = "invoice_board"
        Me.txtinvoice_board.Height = 0.1979167!
        Me.txtinvoice_board.Left = 4.158464!
        Me.txtinvoice_board.Name = "txtinvoice_board"
        Me.txtinvoice_board.Style = "color: Red; "
        Me.txtinvoice_board.Text = "invoice_board"
        Me.txtinvoice_board.Top = 1.082677!
        Me.txtinvoice_board.Visible = False
        Me.txtinvoice_board.Width = 1.0!
        '
        'txtWeightDisplayHeader
        '
        Me.txtWeightDisplayHeader.Border.BottomColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.LeftColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.RightColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.TopColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.DataField = "WeightDisplayHeader"
        Me.txtWeightDisplayHeader.Height = 0.1979167!
        Me.txtWeightDisplayHeader.Left = 4.158464!
        Me.txtWeightDisplayHeader.Name = "txtWeightDisplayHeader"
        Me.txtWeightDisplayHeader.Style = "color: Red; "
        Me.txtWeightDisplayHeader.Text = "WeightDisplayHeader"
        Me.txtWeightDisplayHeader.Top = 1.32874!
        Me.txtWeightDisplayHeader.Visible = False
        Me.txtWeightDisplayHeader.Width = 1.0!
        '
        'txtFOBDisplay
        '
        Me.txtFOBDisplay.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.DataField = "FOBDisplay"
        Me.txtFOBDisplay.Height = 0.1979167!
        Me.txtFOBDisplay.Left = 4.158464!
        Me.txtFOBDisplay.Name = "txtFOBDisplay"
        Me.txtFOBDisplay.Style = "color: Red; "
        Me.txtFOBDisplay.Text = "FOBDisplay"
        Me.txtFOBDisplay.Top = 1.599409!
        Me.txtFOBDisplay.Visible = False
        Me.txtFOBDisplay.Width = 1.0!
        '
        'txtunit_code2
        '
        Me.txtunit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.DataField = "unit_code2"
        Me.txtunit_code2.Height = 0.1979167!
        Me.txtunit_code2.Left = 4.158464!
        Me.txtunit_code2.Name = "txtunit_code2"
        Me.txtunit_code2.Style = "color: Red; "
        Me.txtunit_code2.Text = "unit_code2"
        Me.txtunit_code2.Top = 1.845472!
        Me.txtunit_code2.Visible = False
        Me.txtunit_code2.Width = 1.0!
        '
        'txtnet_weight
        '
        Me.txtnet_weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.DataField = "net_weight"
        Me.txtnet_weight.Height = 0.1979167!
        Me.txtnet_weight.Left = 4.158464!
        Me.txtnet_weight.Name = "txtnet_weight"
        Me.txtnet_weight.Style = "color: Red; "
        Me.txtnet_weight.Text = "net_weight"
        Me.txtnet_weight.Top = 2.116143!
        Me.txtnet_weight.Visible = False
        Me.txtnet_weight.Width = 1.0!
        '
        'txtgross_weightH
        '
        Me.txtgross_weightH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.RightColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.TopColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.DataField = "gross_weightH"
        Me.txtgross_weightH.Height = 0.1979167!
        Me.txtgross_weightH.Left = 2.140748!
        Me.txtgross_weightH.Name = "txtgross_weightH"
        Me.txtgross_weightH.Style = "color: Red; "
        Me.txtgross_weightH.Text = "gross_weightH"
        Me.txtgross_weightH.Top = 1.845472!
        Me.txtgross_weightH.Visible = False
        Me.txtgross_weightH.Width = 1.0!
        '
        'txtthird_country
        '
        Me.txtthird_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.DataField = "third_country"
        Me.txtthird_country.Height = 0.1979167!
        Me.txtthird_country.Left = 2.140748!
        Me.txtthird_country.Name = "txtthird_country"
        Me.txtthird_country.Style = "color: Red; "
        Me.txtthird_country.Text = "third_country"
        Me.txtthird_country.Top = 2.116143!
        Me.txtthird_country.Visible = False
        Me.txtthird_country.Width = 1.0!
        '
        'txtplace_exibition
        '
        Me.txtplace_exibition.Border.BottomColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.LeftColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.RightColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.TopColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.DataField = "place_exibition"
        Me.txtplace_exibition.Height = 0.1979167!
        Me.txtplace_exibition.Left = 2.140748!
        Me.txtplace_exibition.Name = "txtplace_exibition"
        Me.txtplace_exibition.Style = "color: Red; "
        Me.txtplace_exibition.Text = "place_exibition"
        Me.txtplace_exibition.Top = 2.386811!
        Me.txtplace_exibition.Visible = False
        Me.txtplace_exibition.Width = 1.0!
        '
        'txtWeightDisplayHeaderH
        '
        Me.txtWeightDisplayHeaderH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.RightColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.TopColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.DataField = "WeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Height = 0.1979167!
        Me.txtWeightDisplayHeaderH.Left = 4.1875!
        Me.txtWeightDisplayHeaderH.Name = "txtWeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Style = "color: Red; "
        Me.txtWeightDisplayHeaderH.Text = "WeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Top = 2.375!
        Me.txtWeightDisplayHeaderH.Visible = False
        Me.txtWeightDisplayHeaderH.Width = 1.0!
        '
        'txtmarks
        '
        Me.txtmarks.Border.BottomColor = System.Drawing.Color.Black
        Me.txtmarks.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.LeftColor = System.Drawing.Color.Black
        Me.txtmarks.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.RightColor = System.Drawing.Color.Black
        Me.txtmarks.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.TopColor = System.Drawing.Color.Black
        Me.txtmarks.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.DataField = "marks"
        Me.txtmarks.Height = 0.1979167!
        Me.txtmarks.Left = 4.1875!
        Me.txtmarks.Name = "txtmarks"
        Me.txtmarks.Style = "color: Red; "
        Me.txtmarks.Text = "marks"
        Me.txtmarks.Top = 2.635417!
        Me.txtmarks.Visible = False
        Me.txtmarks.Width = 1.0!
        '
        'txtNumInvoice
        '
        Me.txtNumInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.DataField = "NumInvoice"
        Me.txtNumInvoice.Height = 0.25!
        Me.txtNumInvoice.Left = 3.125!
        Me.txtNumInvoice.Name = "txtNumInvoice"
        Me.txtNumInvoice.Style = "color: Red; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtNumInvoice.Text = "NumInvoice"
        Me.txtNumInvoice.Top = 2.37656!
        Me.txtNumInvoice.Visible = False
        Me.txtNumInvoice.Width = 0.5!
        '
        'txtUSDInvoice
        '
        Me.txtUSDInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.DataField = "USDInvoice"
        Me.txtUSDInvoice.Height = 0.25!
        Me.txtUSDInvoice.Left = 3.125!
        Me.txtUSDInvoice.Name = "txtUSDInvoice"
        Me.txtUSDInvoice.Style = "color: Red; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtUSDInvoice.Text = "USDInvoice"
        Me.txtUSDInvoice.Top = 2.68906!
        Me.txtUSDInvoice.Visible = False
        Me.txtUSDInvoice.Width = 0.5!
        '
        'txtbox8
        '
        Me.txtbox8.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbox8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbox8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.RightColor = System.Drawing.Color.Black
        Me.txtbox8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.TopColor = System.Drawing.Color.Black
        Me.txtbox8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.DataField = "box8"
        Me.txtbox8.Height = 0.1979167!
        Me.txtbox8.Left = 4.1875!
        Me.txtbox8.Name = "txtbox8"
        Me.txtbox8.Style = "color: Red; "
        Me.txtbox8.Text = "box8"
        Me.txtbox8.Top = 2.895833!
        Me.txtbox8.Visible = False
        Me.txtbox8.Width = 1.0!
        '
        'PageHeader1
        '
        Me.PageHeader1.CanGrow = False
        Me.PageHeader1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtCompany_Check_1, Me.txtreference_code2_Temp, Me.txtdestination_Check2, Me.txttransport_by, Me.txtcompany_taxno, Me.txtcompany_country, Me.txtcompany_province, Me.txtcompany_address, Me.txtcompany_name, Me.txtob_address, Me.txtdest_remark, Me.txtcompany_fax, Me.txtcompany_phone, Me.txtdestination_company, Me.txtdestination_fax, Me.txtdestination_address, Me.txtdestination_phone, Me.txtdestination_province, Me.txtdest_Receive_country, Me.txtreference_code2, Me.txtcompany_email, Me.txtdestination_email, Me.txtdestination_taxid, Me.txtdest_remark1, Me.txtob_dest_address, Me.txtAustralia_Thailand, Me.ReportInfo1})
        Me.PageHeader1.Height = 4.916667!
        Me.PageHeader1.Name = "PageHeader1"
        '
        'txtCompany_Check_1
        '
        Me.txtCompany_Check_1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.RightColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.TopColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.CanGrow = False
        Me.txtCompany_Check_1.Height = 1.25!
        Me.txtCompany_Check_1.Left = 0.35!
        Me.txtCompany_Check_1.Name = "txtCompany_Check_1"
        Me.txtCompany_Check_1.Style = "ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtCompany_Check_1.Text = Nothing
        Me.txtCompany_Check_1.Top = 0.4375!
        Me.txtCompany_Check_1.Width = 3.8125!
        '
        'txtreference_code2_Temp
        '
        Me.txtreference_code2_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.CanGrow = False
        Me.txtreference_code2_Temp.Height = 0.4375!
        Me.txtreference_code2_Temp.Left = 5.3125!
        Me.txtreference_code2_Temp.Name = "txtreference_code2_Temp"
        Me.txtreference_code2_Temp.Style = "ddo-char-set: 1; font-weight: bold; font-size: 16pt; font-family: BrowalliaUPC; "
        Me.txtreference_code2_Temp.Text = Nothing
        Me.txtreference_code2_Temp.Top = 0.3125!
        Me.txtreference_code2_Temp.Width = 1.5625!
        '
        'txtdestination_Check2
        '
        Me.txtdestination_Check2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.CanGrow = False
        Me.txtdestination_Check2.Height = 1.1875!
        Me.txtdestination_Check2.Left = 0.35!
        Me.txtdestination_Check2.Name = "txtdestination_Check2"
        Me.txtdestination_Check2.Style = "ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtdestination_Check2.Text = Nothing
        Me.txtdestination_Check2.Top = 1.9375!
        Me.txtdestination_Check2.Width = 3.8125!
        '
        'txttransport_by
        '
        Me.txttransport_by.Border.BottomColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.LeftColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.RightColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.TopColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.CanGrow = False
        Me.txttransport_by.DataField = "transport_by"
        Me.txttransport_by.Height = 0.9375!
        Me.txttransport_by.Left = 0.375!
        Me.txttransport_by.Name = "txttransport_by"
        Me.txttransport_by.Style = "ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txttransport_by.Text = "transport_by"
        Me.txttransport_by.Top = 3.375!
        Me.txttransport_by.Width = 3.8125!
        '
        'txtcompany_taxno
        '
        Me.txtcompany_taxno.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.DataField = "company_taxno"
        Me.txtcompany_taxno.Height = 0.1979167!
        Me.txtcompany_taxno.Left = 0.2214567!
        Me.txtcompany_taxno.Name = "txtcompany_taxno"
        Me.txtcompany_taxno.Style = "color: Red; "
        Me.txtcompany_taxno.Text = "company_taxno"
        Me.txtcompany_taxno.Top = 0.07381889!
        Me.txtcompany_taxno.Visible = False
        Me.txtcompany_taxno.Width = 1.0!
        '
        'txtcompany_country
        '
        Me.txtcompany_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.DataField = "company_country"
        Me.txtcompany_country.Height = 0.1979167!
        Me.txtcompany_country.Left = 1.254921!
        Me.txtcompany_country.Name = "txtcompany_country"
        Me.txtcompany_country.Style = "color: Red; "
        Me.txtcompany_country.Text = "company_country"
        Me.txtcompany_country.Top = 0.07381889!
        Me.txtcompany_country.Visible = False
        Me.txtcompany_country.Width = 1.0!
        '
        'txtcompany_province
        '
        Me.txtcompany_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.DataField = "company_province"
        Me.txtcompany_province.Height = 0.1979167!
        Me.txtcompany_province.Left = 2.288386!
        Me.txtcompany_province.Name = "txtcompany_province"
        Me.txtcompany_province.Style = "color: Red; "
        Me.txtcompany_province.Text = "company_province"
        Me.txtcompany_province.Top = 0.07381889!
        Me.txtcompany_province.Visible = False
        Me.txtcompany_province.Width = 1.0!
        '
        'txtcompany_address
        '
        Me.txtcompany_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.DataField = "company_address"
        Me.txtcompany_address.Height = 0.1979167!
        Me.txtcompany_address.Left = 2.288386!
        Me.txtcompany_address.Name = "txtcompany_address"
        Me.txtcompany_address.Style = "color: Red; "
        Me.txtcompany_address.Text = "company_address"
        Me.txtcompany_address.Top = 0.2952756!
        Me.txtcompany_address.Visible = False
        Me.txtcompany_address.Width = 1.0!
        '
        'txtcompany_name
        '
        Me.txtcompany_name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.DataField = "company_name"
        Me.txtcompany_name.Height = 0.1979167!
        Me.txtcompany_name.Left = 3.297244!
        Me.txtcompany_name.Name = "txtcompany_name"
        Me.txtcompany_name.Style = "color: Red; "
        Me.txtcompany_name.Text = "company_name"
        Me.txtcompany_name.Top = 0.07381889!
        Me.txtcompany_name.Visible = False
        Me.txtcompany_name.Width = 1.0!
        '
        'txtob_address
        '
        Me.txtob_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtob_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtob_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtob_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtob_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.DataField = "ob_address"
        Me.txtob_address.Height = 0.1979167!
        Me.txtob_address.Left = 3.297244!
        Me.txtob_address.Name = "txtob_address"
        Me.txtob_address.Style = "color: Red; "
        Me.txtob_address.Text = "ob_address"
        Me.txtob_address.Top = 0.2952756!
        Me.txtob_address.Visible = False
        Me.txtob_address.Width = 1.0!
        '
        'txtdest_remark
        '
        Me.txtdest_remark.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.DataField = "dest_remark"
        Me.txtdest_remark.Height = 0.1979167!
        Me.txtdest_remark.Left = 4.330709!
        Me.txtdest_remark.Name = "txtdest_remark"
        Me.txtdest_remark.Style = "color: Red; "
        Me.txtdest_remark.Text = "dest_remark"
        Me.txtdest_remark.Top = 0.07381889!
        Me.txtdest_remark.Visible = False
        Me.txtdest_remark.Width = 1.0!
        '
        'txtcompany_fax
        '
        Me.txtcompany_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.DataField = "company_fax"
        Me.txtcompany_fax.Height = 0.1979167!
        Me.txtcompany_fax.Left = 0.2214567!
        Me.txtcompany_fax.Name = "txtcompany_fax"
        Me.txtcompany_fax.Style = "color: Red; "
        Me.txtcompany_fax.Text = "company_fax"
        Me.txtcompany_fax.Top = 0.2952756!
        Me.txtcompany_fax.Visible = False
        Me.txtcompany_fax.Width = 1.0!
        '
        'txtcompany_phone
        '
        Me.txtcompany_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.DataField = "company_phone"
        Me.txtcompany_phone.Height = 0.1979167!
        Me.txtcompany_phone.Left = 1.254921!
        Me.txtcompany_phone.Name = "txtcompany_phone"
        Me.txtcompany_phone.Style = "color: Red; "
        Me.txtcompany_phone.Text = "company_phone"
        Me.txtcompany_phone.Top = 0.2952756!
        Me.txtcompany_phone.Visible = False
        Me.txtcompany_phone.Width = 1.0!
        '
        'txtdestination_company
        '
        Me.txtdestination_company.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.DataField = "destination_company"
        Me.txtdestination_company.Height = 0.1979167!
        Me.txtdestination_company.Left = 0.1722441!
        Me.txtdestination_company.Name = "txtdestination_company"
        Me.txtdestination_company.Style = "color: Red; "
        Me.txtdestination_company.Text = "destination_company"
        Me.txtdestination_company.Top = 4.330709!
        Me.txtdestination_company.Visible = False
        Me.txtdestination_company.Width = 1.0!
        '
        'txtdestination_fax
        '
        Me.txtdestination_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.DataField = "destination_fax"
        Me.txtdestination_fax.Height = 0.1979167!
        Me.txtdestination_fax.Left = 1.205709!
        Me.txtdestination_fax.Name = "txtdestination_fax"
        Me.txtdestination_fax.Style = "color: Red; "
        Me.txtdestination_fax.Text = "destination_fax"
        Me.txtdestination_fax.Top = 4.330709!
        Me.txtdestination_fax.Visible = False
        Me.txtdestination_fax.Width = 1.0!
        '
        'txtdestination_address
        '
        Me.txtdestination_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.DataField = "destination_address"
        Me.txtdestination_address.Height = 0.1979167!
        Me.txtdestination_address.Left = 1.205709!
        Me.txtdestination_address.Name = "txtdestination_address"
        Me.txtdestination_address.Style = "color: Red; "
        Me.txtdestination_address.Text = "destination_address"
        Me.txtdestination_address.Top = 4.625985!
        Me.txtdestination_address.Visible = False
        Me.txtdestination_address.Width = 1.0!
        '
        'txtdestination_phone
        '
        Me.txtdestination_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.DataField = "destination_phone"
        Me.txtdestination_phone.Height = 0.1979167!
        Me.txtdestination_phone.Left = 0.1722441!
        Me.txtdestination_phone.Name = "txtdestination_phone"
        Me.txtdestination_phone.Style = "color: Red; "
        Me.txtdestination_phone.Text = "destination_phone"
        Me.txtdestination_phone.Top = 4.615732!
        Me.txtdestination_phone.Visible = False
        Me.txtdestination_phone.Width = 1.0!
        '
        'txtdestination_province
        '
        Me.txtdestination_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.DataField = "destination_province"
        Me.txtdestination_province.Height = 0.1979167!
        Me.txtdestination_province.Left = 2.239173!
        Me.txtdestination_province.Name = "txtdestination_province"
        Me.txtdestination_province.Style = "color: Red; "
        Me.txtdestination_province.Text = "destination_province"
        Me.txtdestination_province.Top = 4.330709!
        Me.txtdestination_province.Visible = False
        Me.txtdestination_province.Width = 1.0!
        '
        'txtdest_Receive_country
        '
        Me.txtdest_Receive_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.DataField = "dest_Receive_country"
        Me.txtdest_Receive_country.Height = 0.1979167!
        Me.txtdest_Receive_country.Left = 2.239173!
        Me.txtdest_Receive_country.Name = "txtdest_Receive_country"
        Me.txtdest_Receive_country.Style = "color: Red; "
        Me.txtdest_Receive_country.Text = "dest_Receive_country"
        Me.txtdest_Receive_country.Top = 4.591125!
        Me.txtdest_Receive_country.Visible = False
        Me.txtdest_Receive_country.Width = 1.0!
        '
        'txtreference_code2
        '
        Me.txtreference_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.DataField = "reference_code2"
        Me.txtreference_code2.Height = 0.3937007!
        Me.txtreference_code2.Left = 5.487205!
        Me.txtreference_code2.Name = "txtreference_code2"
        Me.txtreference_code2.Style = "color: Red; ddo-char-set: 222; font-weight: bold; font-size: 13pt; font-family: B" & _
            "rowalliaUPC; "
        Me.txtreference_code2.Text = "reference_code2"
        Me.txtreference_code2.Top = 0.9104334!
        Me.txtreference_code2.Visible = False
        Me.txtreference_code2.Width = 1.648622!
        '
        'txtcompany_email
        '
        Me.txtcompany_email.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.DataField = "company_email"
        Me.txtcompany_email.Height = 0.1979167!
        Me.txtcompany_email.Left = 4.330709!
        Me.txtcompany_email.Name = "txtcompany_email"
        Me.txtcompany_email.Style = "color: Red; "
        Me.txtcompany_email.Text = "company_email"
        Me.txtcompany_email.Top = 0.3342356!
        Me.txtcompany_email.Visible = False
        Me.txtcompany_email.Width = 1.0!
        '
        'txtdestination_email
        '
        Me.txtdestination_email.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.DataField = "destination_email"
        Me.txtdestination_email.Height = 0.1979167!
        Me.txtdestination_email.Left = 4.330709!
        Me.txtdestination_email.Name = "txtdestination_email"
        Me.txtdestination_email.Style = "color: Red; "
        Me.txtdestination_email.Text = "destination_email"
        Me.txtdestination_email.Top = 0.5946523!
        Me.txtdestination_email.Visible = False
        Me.txtdestination_email.Width = 1.0!
        '
        'txtdestination_taxid
        '
        Me.txtdestination_taxid.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.DataField = "destination_taxid"
        Me.txtdestination_taxid.Height = 0.1979167!
        Me.txtdestination_taxid.Left = 4.330709!
        Me.txtdestination_taxid.Name = "txtdestination_taxid"
        Me.txtdestination_taxid.Style = "color: Red; "
        Me.txtdestination_taxid.Text = "destination_taxid"
        Me.txtdestination_taxid.Top = 0.8550687!
        Me.txtdestination_taxid.Visible = False
        Me.txtdestination_taxid.Width = 1.0!
        '
        'txtdest_remark1
        '
        Me.txtdest_remark1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.DataField = "dest_remark1"
        Me.txtdest_remark1.Height = 0.1979167!
        Me.txtdest_remark1.Left = 4.330709!
        Me.txtdest_remark1.Name = "txtdest_remark1"
        Me.txtdest_remark1.Style = "color: Red; "
        Me.txtdest_remark1.Text = "dest_remark1"
        Me.txtdest_remark1.Top = 1.115486!
        Me.txtdest_remark1.Visible = False
        Me.txtdest_remark1.Width = 1.0!
        '
        'txtob_dest_address
        '
        Me.txtob_dest_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.DataField = "ob_dest_address"
        Me.txtob_dest_address.Height = 0.1979167!
        Me.txtob_dest_address.Left = 4.330709!
        Me.txtob_dest_address.Name = "txtob_dest_address"
        Me.txtob_dest_address.Style = "color: Red; "
        Me.txtob_dest_address.Text = "ob_dest_address"
        Me.txtob_dest_address.Top = 1.375903!
        Me.txtob_dest_address.Visible = False
        Me.txtob_dest_address.Width = 1.0!
        '
        'txtAustralia_Thailand
        '
        Me.txtAustralia_Thailand.Border.BottomColor = System.Drawing.Color.Black
        Me.txtAustralia_Thailand.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAustralia_Thailand.Border.LeftColor = System.Drawing.Color.Black
        Me.txtAustralia_Thailand.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAustralia_Thailand.Border.RightColor = System.Drawing.Color.Black
        Me.txtAustralia_Thailand.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAustralia_Thailand.Border.TopColor = System.Drawing.Color.Black
        Me.txtAustralia_Thailand.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAustralia_Thailand.Height = 0.3937007!
        Me.txtAustralia_Thailand.Left = 6.9375!
        Me.txtAustralia_Thailand.Name = "txtAustralia_Thailand"
        Me.txtAustralia_Thailand.Style = "ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtAustralia_Thailand.Text = "Thailand-Australia"
        Me.txtAustralia_Thailand.Top = 0.3229167!
        Me.txtAustralia_Thailand.Width = 0.9104334!
        '
        'ReportInfo1
        '
        Me.ReportInfo1.Border.BottomColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.LeftColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.RightColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.TopColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.FormatString = Nothing
        Me.ReportInfo1.Height = 0.3125!
        Me.ReportInfo1.Left = 3.4375!
        Me.ReportInfo1.Name = "ReportInfo1"
        Me.ReportInfo1.Style = "text-align: center; font-family: BrowalliaUPC; "
        Me.ReportInfo1.Top = 4.6875!
        Me.ReportInfo1.Width = 1.5!
        '
        'PageFooter1
        '
        Me.PageFooter1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtINDIA, Me.txtcompany_provincefoot1, Me.txtcompany_provincefoot, Me.txtshow_check, Me.txtback_country, Me.txtinvh_run_auto})
        Me.PageFooter1.Height = 1.979861!
        Me.PageFooter1.Name = "PageFooter1"
        '
        'txtINDIA
        '
        Me.txtINDIA.Border.BottomColor = System.Drawing.Color.Black
        Me.txtINDIA.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtINDIA.Border.LeftColor = System.Drawing.Color.Black
        Me.txtINDIA.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtINDIA.Border.RightColor = System.Drawing.Color.Black
        Me.txtINDIA.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtINDIA.Border.TopColor = System.Drawing.Color.Black
        Me.txtINDIA.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtINDIA.Height = 0.3937007!
        Me.txtINDIA.Left = 0.3125!
        Me.txtINDIA.Name = "txtINDIA"
        Me.txtINDIA.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" & _
            "; vertical-align: bottom; "
        Me.txtINDIA.Text = "AUSTRALIA"
        Me.txtINDIA.Top = 0.6666667!
        Me.txtINDIA.Width = 3.838583!
        '
        'txtcompany_provincefoot1
        '
        Me.txtcompany_provincefoot1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.DataField = "company_province"
        Me.txtcompany_provincefoot1.Height = 0.1979167!
        Me.txtcompany_provincefoot1.Left = 6.668307!
        Me.txtcompany_provincefoot1.Name = "txtcompany_provincefoot1"
        Me.txtcompany_provincefoot1.Style = "color: Red; "
        Me.txtcompany_provincefoot1.Text = "company_province"
        Me.txtcompany_provincefoot1.Top = 0.0!
        Me.txtcompany_provincefoot1.Visible = False
        Me.txtcompany_provincefoot1.Width = 1.0!
        '
        'txtcompany_provincefoot
        '
        Me.txtcompany_provincefoot.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Height = 0.3937007!
        Me.txtcompany_provincefoot.Left = 0.3125!
        Me.txtcompany_provincefoot.Name = "txtcompany_provincefoot"
        Me.txtcompany_provincefoot.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" & _
            "; vertical-align: bottom; "
        Me.txtcompany_provincefoot.Text = Nothing
        Me.txtcompany_provincefoot.Top = 1.09375!
        Me.txtcompany_provincefoot.Width = 3.838583!
        '
        'txtshow_check
        '
        Me.txtshow_check.Border.BottomColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.LeftColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.RightColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.TopColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.DataField = "show_check"
        Me.txtshow_check.Height = 0.1979167!
        Me.txtshow_check.Left = 6.668307!
        Me.txtshow_check.Name = "txtshow_check"
        Me.txtshow_check.Style = "color: Red; "
        Me.txtshow_check.Text = "show_check"
        Me.txtshow_check.Top = 0.2604167!
        Me.txtshow_check.Visible = False
        Me.txtshow_check.Width = 1.0!
        '
        'txtback_country
        '
        Me.txtback_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtback_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtback_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtback_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtback_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.DataField = "back_country"
        Me.txtback_country.Height = 0.1979167!
        Me.txtback_country.Left = 6.668307!
        Me.txtback_country.Name = "txtback_country"
        Me.txtback_country.Style = "color: Red; "
        Me.txtback_country.Text = "back_country"
        Me.txtback_country.Top = 0.5208334!
        Me.txtback_country.Visible = False
        Me.txtback_country.Width = 1.0!
        '
        'txtinvh_run_auto
        '
        Me.txtinvh_run_auto.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.DataField = "invh_run_auto"
        Me.txtinvh_run_auto.Height = 0.1979167!
        Me.txtinvh_run_auto.Left = 0.0!
        Me.txtinvh_run_auto.Name = "txtinvh_run_auto"
        Me.txtinvh_run_auto.Style = "color: Red; "
        Me.txtinvh_run_auto.Text = "invh_run_auto"
        Me.txtinvh_run_auto.Top = 0.0!
        Me.txtinvh_run_auto.Visible = False
        Me.txtinvh_run_auto.Width = 1.0!
        '
        'rpt3_ediFORM4_4
        '
        Me.MasterReport = False
        Me.PageSettings.DefaultPaperSize = False
        Me.PageSettings.DefaultPaperSource = False
        Me.PageSettings.Margins.Bottom = 0.0!
        Me.PageSettings.Margins.Left = 0.0!
        Me.PageSettings.Margins.Right = 0.0!
        Me.PageSettings.Margins.Top = 0.0!
        Me.PageSettings.PaperHeight = 12.0!
        Me.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Custom
        Me.PageSettings.PaperName = "Fanfold 210 x 305 mm"
        Me.PageSettings.PaperSource = System.Drawing.Printing.PaperSourceKind.FormSource
        Me.PageSettings.PaperWidth = 8.268056!
        Me.PrintWidth = 8.267715!
        Me.Script = "public bool ActiveReport_FetchData(bool eof)" & Global.Microsoft.VisualBasic.ChrW(10) & "{" & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(9) & "return eof;" & Global.Microsoft.VisualBasic.ChrW(10) & "}"
        Me.Sections.Add(Me.PageHeader1)
        Me.Sections.Add(Me.Detail1)
        Me.Sections.Add(Me.PageFooter1)
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Arial; font-style: normal; text-decoration: none; font-weight: norma" & _
                    "l; font-size: 10pt; color: Black; ddo-char-set: 204; ", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 16pt; font-weight: bold; ", "Heading1", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Times New Roman; font-size: 14pt; font-weight: bold; font-style: ita" & _
                    "lic; ", "Heading2", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 13pt; font-weight: bold; ", "Heading3", "Normal"))
        CType(Me.txtNumRowCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_marks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtT_product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_box8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTolInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrossTxt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGross_Weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtmarks1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_n1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_n2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtg_unit_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttariff_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtg_Unit_Desc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOB_AMT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_board, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtWeightDisplayHeader, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOBDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtnet_weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgross_weightH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtthird_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtplace_exibition, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtWeightDisplayHeaderH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtmarks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNumInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUSDInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompany_Check_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtreference_code2_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_Check2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttransport_by, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtob_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_remark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_Receive_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtreference_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_email, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_email, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_taxid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_remark1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtob_dest_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAustralia_Thailand, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReportInfo1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtINDIA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_provincefoot1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_provincefoot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtshow_check, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtback_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Friend WithEvents Detail1 As DataDynamics.ActiveReports.Detail
    Friend WithEvents txtNumRowCount As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_marks As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtT_product As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_box8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTolInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtGrossTxt As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtmarks1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_n1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_n2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtg_unit_code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttariff_code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_board As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtWeightDisplayHeader As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtFOBDisplay As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtunit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtnet_weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtgross_weightH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtthird_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtplace_exibition As DataDynamics.ActiveReports.TextBox
    Friend WithEvents PageHeader1 As DataDynamics.ActiveReports.PageHeader
    Friend WithEvents txtCompany_Check_1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtreference_code2_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_Check2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttransport_by As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_taxno As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtob_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_remark As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_company As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_Receive_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtreference_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_email As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_email As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_taxid As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_remark1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtob_dest_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtAustralia_Thailand As DataDynamics.ActiveReports.TextBox
    Friend WithEvents PageFooter1 As DataDynamics.ActiveReports.PageFooter
    Friend WithEvents txtINDIA As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_provincefoot1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_provincefoot As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtshow_check As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtback_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtWeightDisplayHeaderH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents ReportInfo1 As DataDynamics.ActiveReports.ReportInfo
    Friend WithEvents txtmarks As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtGross_Weight As DataDynamics.ActiveReports.TextBox
    Public WithEvents C_TotalRowDe As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtg_Unit_Desc As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtFOB_AMT As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNumInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtUSDInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbox8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvh_run_auto As DataDynamics.ActiveReports.TextBox
End Class
