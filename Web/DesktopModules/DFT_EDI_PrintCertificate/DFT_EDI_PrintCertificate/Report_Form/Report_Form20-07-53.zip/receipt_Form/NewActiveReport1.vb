Imports DataDynamics.ActiveReports 
Imports DataDynamics.ActiveReports.Document 

Public Class NewActiveReport1 

End Class 
