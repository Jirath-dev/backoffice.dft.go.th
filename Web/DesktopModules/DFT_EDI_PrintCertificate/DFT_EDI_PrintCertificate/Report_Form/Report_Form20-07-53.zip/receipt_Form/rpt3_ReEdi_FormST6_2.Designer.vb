<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class rpt3_ReEdi_FormST6_2 
    Inherits DataDynamics.ActiveReports.ActiveReport3 

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
        End If
        MyBase.Dispose(disposing)
    End Sub
    
    'NOTE: The following procedure is required by the ActiveReports Designer
    'It can be modified using the ActiveReports Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(rpt3_ReEdi_FormST6_2))
        Me.Detail1 = New DataDynamics.ActiveReports.Detail
        Me.PageHeader1 = New DataDynamics.ActiveReports.PageHeader
        Me.txtREFERENCE_CODE2 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox3 = New DataDynamics.ActiveReports.TextBox
        Me.Shape1 = New DataDynamics.ActiveReports.Shape
        Me.Shape2 = New DataDynamics.ActiveReports.Shape
        Me.TextBox4 = New DataDynamics.ActiveReports.TextBox
        Me.Shape3 = New DataDynamics.ActiveReports.Shape
        Me.TextBox5 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox6 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox7 = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_REFERENCE_CODE2 = New DataDynamics.ActiveReports.TextBox
        Me.txtSent_date = New DataDynamics.ActiveReports.TextBox
        Me.TextBox8 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox9 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox10 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox12 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox11 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox13 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox14 = New DataDynamics.ActiveReports.TextBox
        Me.txtcard_id = New DataDynamics.ActiveReports.TextBox
        Me.TextBox1 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox15 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox16 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox17 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox2 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox18 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox19 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox20 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox21 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox22 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox23 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox24 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox25 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox26 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox27 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox28 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox30 = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_address = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_nameth = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_nameeng = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_request_person1 = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_address1 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox62 = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_company_phone = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_company_fax = New DataDynamics.ActiveReports.TextBox
        Me.TextBox65 = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_company_phone1 = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_company_fax1 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox68 = New DataDynamics.ActiveReports.TextBox
        Me.txtimport_country = New DataDynamics.ActiveReports.TextBox
        Me.txtCAT = New DataDynamics.ActiveReports.TextBox
        Me.txtI_Unit_code = New DataDynamics.ActiveReports.TextBox
        Me.txtTotal_Net_weight = New DataDynamics.ActiveReports.TextBox
        Me.txtQuantity5 = New DataDynamics.ActiveReports.TextBox
        Me.txtedi_date = New DataDynamics.ActiveReports.TextBox
        Me.TextBox29 = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_company = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_dest = New DataDynamics.ActiveReports.TextBox
        Me.TextBox31 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox33 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox78 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox79 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox80 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox81 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox82 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox83 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox84 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox85 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox86 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox87 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox88 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox89 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox90 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox91 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox92 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox93 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox94 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox39 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox95 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox96 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox97 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox98 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox99 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox100 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox101 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox102 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox103 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox104 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox105 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox106 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox107 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox108 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox109 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox110 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox111 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox38 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox32 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox45 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox34 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox46 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox47 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox48 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox49 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox50 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox51 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox52 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox53 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox54 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox55 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox57 = New DataDynamics.ActiveReports.TextBox
        Me.Line1 = New DataDynamics.ActiveReports.Line
        Me.Line2 = New DataDynamics.ActiveReports.Line
        Me.Line3 = New DataDynamics.ActiveReports.Line
        Me.Line4 = New DataDynamics.ActiveReports.Line
        Me.Line5 = New DataDynamics.ActiveReports.Line
        Me.Line6 = New DataDynamics.ActiveReports.Line
        Me.Line7 = New DataDynamics.ActiveReports.Line
        Me.Line8 = New DataDynamics.ActiveReports.Line
        Me.Line9 = New DataDynamics.ActiveReports.Line
        Me.Line10 = New DataDynamics.ActiveReports.Line
        Me.Line11 = New DataDynamics.ActiveReports.Line
        Me.Line12 = New DataDynamics.ActiveReports.Line
        Me.txtcompany_Address = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_Province = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_Country = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_phone = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_fax = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_name = New DataDynamics.ActiveReports.TextBox
        Me.txtcompany_Taxno = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no1 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no2 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no3 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no4 = New DataDynamics.ActiveReports.TextBox
        Me.txtinvoice_no5 = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_invoice = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_address = New DataDynamics.ActiveReports.TextBox
        Me.txtdestination_province = New DataDynamics.ActiveReports.TextBox
        Me.txtdest_receive_country = New DataDynamics.ActiveReports.TextBox
        Me.txtrequest_person = New DataDynamics.ActiveReports.TextBox
        Me.txtTemp_request_person2 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox36 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox37 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox40 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox41 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox42 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox43 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox44 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox56 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox58 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox59 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox60 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox61 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox63 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox64 = New DataDynamics.ActiveReports.TextBox
        Me.TextBox66 = New DataDynamics.ActiveReports.TextBox
        Me.PageFooter1 = New DataDynamics.ActiveReports.PageFooter
        Me.TextBox35 = New DataDynamics.ActiveReports.TextBox
        CType(Me.txtREFERENCE_CODE2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_REFERENCE_CODE2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSent_date, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcard_id, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_nameth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_nameeng, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_request_person1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_address1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_company_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_company_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_company_phone1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_company_fax1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtimport_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCAT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtI_Unit_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotal_Net_weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtQuantity5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtedi_date, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_dest, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox79, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox80, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox81, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox89, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox90, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox91, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox98, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox101, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox102, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox103, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox104, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox105, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox106, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox107, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox108, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox109, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox110, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox111, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_Address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_Province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_Country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_Taxno, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_invoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_receive_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtrequest_person, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_request_person2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox60, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox61, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'Detail1
        '
        Me.Detail1.ColumnSpacing = 0.0!
        Me.Detail1.Height = 0.0!
        Me.Detail1.Name = "Detail1"
        '
        'PageHeader1
        '
        Me.PageHeader1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtREFERENCE_CODE2, Me.TextBox3, Me.Shape1, Me.Shape2, Me.TextBox4, Me.Shape3, Me.TextBox5, Me.TextBox6, Me.TextBox7, Me.txtTemp_REFERENCE_CODE2, Me.txtSent_date, Me.TextBox8, Me.TextBox9, Me.TextBox10, Me.TextBox12, Me.TextBox11, Me.TextBox13, Me.TextBox14, Me.txtcard_id, Me.TextBox1, Me.TextBox15, Me.TextBox16, Me.TextBox17, Me.TextBox2, Me.TextBox18, Me.TextBox19, Me.TextBox20, Me.TextBox21, Me.TextBox22, Me.TextBox23, Me.TextBox24, Me.TextBox25, Me.TextBox26, Me.TextBox27, Me.TextBox28, Me.TextBox30, Me.txtTemp_address, Me.txtcompany_nameth, Me.txtcompany_nameeng, Me.txtTemp_request_person1, Me.txtTemp_address1, Me.TextBox62, Me.txtTemp_company_phone, Me.txtTemp_company_fax, Me.TextBox65, Me.txtTemp_company_phone1, Me.txtTemp_company_fax1, Me.TextBox68, Me.txtimport_country, Me.txtCAT, Me.txtI_Unit_code, Me.txtTotal_Net_weight, Me.txtQuantity5, Me.txtedi_date, Me.TextBox29, Me.txtdestination_company, Me.txtTemp_dest, Me.TextBox31, Me.TextBox33, Me.TextBox78, Me.TextBox79, Me.TextBox80, Me.TextBox81, Me.TextBox82, Me.TextBox83, Me.TextBox84, Me.TextBox85, Me.TextBox86, Me.TextBox87, Me.TextBox88, Me.TextBox89, Me.TextBox90, Me.TextBox91, Me.TextBox92, Me.TextBox93, Me.TextBox94, Me.TextBox39, Me.TextBox95, Me.TextBox96, Me.TextBox97, Me.TextBox98, Me.TextBox99, Me.TextBox100, Me.TextBox101, Me.TextBox102, Me.TextBox103, Me.TextBox104, Me.TextBox105, Me.TextBox106, Me.TextBox107, Me.TextBox108, Me.TextBox109, Me.TextBox110, Me.TextBox111, Me.TextBox38, Me.TextBox32, Me.TextBox45, Me.TextBox34, Me.TextBox46, Me.TextBox47, Me.TextBox48, Me.TextBox49, Me.TextBox50, Me.TextBox51, Me.TextBox52, Me.TextBox53, Me.TextBox54, Me.TextBox55, Me.TextBox57, Me.Line1, Me.Line2, Me.Line3, Me.Line4, Me.Line5, Me.Line6, Me.Line7, Me.Line8, Me.Line9, Me.Line10, Me.Line11, Me.Line12, Me.txtcompany_Address, Me.txtcompany_Province, Me.txtcompany_Country, Me.txtcompany_phone, Me.txtcompany_fax, Me.txtcompany_name, Me.txtcompany_Taxno, Me.txtinvoice_no1, Me.txtinvoice_no2, Me.txtinvoice_no3, Me.txtinvoice_no4, Me.txtinvoice_no5, Me.txtTemp_invoice, Me.txtdestination_address, Me.txtdestination_province, Me.txtdest_receive_country, Me.txtrequest_person, Me.txtTemp_request_person2, Me.TextBox36, Me.TextBox37, Me.TextBox40, Me.TextBox41, Me.TextBox42, Me.TextBox43, Me.TextBox44, Me.TextBox56, Me.TextBox58, Me.TextBox59, Me.TextBox60, Me.TextBox61, Me.TextBox63, Me.TextBox64, Me.TextBox66, Me.TextBox35})
        Me.PageHeader1.Height = 11.61389!
        Me.PageHeader1.Name = "PageHeader1"
        '
        'txtREFERENCE_CODE2
        '
        Me.txtREFERENCE_CODE2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2.Border.RightColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2.Border.TopColor = System.Drawing.Color.Black
        Me.txtREFERENCE_CODE2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtREFERENCE_CODE2.DataField = "REFERENCE_CODE2"
        Me.txtREFERENCE_CODE2.Height = 0.1968504!
        Me.txtREFERENCE_CODE2.Left = 0.09842521!
        Me.txtREFERENCE_CODE2.Name = "txtREFERENCE_CODE2"
        Me.txtREFERENCE_CODE2.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtREFERENCE_CODE2.Text = "REFERENCE_CODE2"
        Me.txtREFERENCE_CODE2.Top = 0.0246063!
        Me.txtREFERENCE_CODE2.Visible = False
        Me.txtREFERENCE_CODE2.Width = 1.033465!
        '
        'TextBox3
        '
        Me.TextBox3.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox3.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox3.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox3.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox3.Height = 0.3937007!
        Me.TextBox3.Left = 0.1230315!
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Style = "ddo-char-set: 222; text-decoration: underline; font-weight: bold; font-size: 14pt" & _
            "; font-family: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox3.Text = "����ͧ��˹ѧ����Ѻ�ͧ������͡�Թ�����觷�"
        Me.TextBox3.Top = 0.4429134!
        Me.TextBox3.Width = 3.051181!
        '
        'Shape1
        '
        Me.Shape1.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape1.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape1.Border.RightColor = System.Drawing.Color.Black
        Me.Shape1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.TopColor = System.Drawing.Color.Black
        Me.Shape1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape1.Height = 10.33465!
        Me.Shape1.Left = 0.1230315!
        Me.Shape1.LineStyle = DataDynamics.ActiveReports.LineStyle.Transparent
        Me.Shape1.Name = "Shape1"
        Me.Shape1.RoundingRadius = 9.999999!
        Me.Shape1.Top = 1.181102!
        Me.Shape1.Width = 3.912402!
        '
        'Shape2
        '
        Me.Shape2.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape2.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Border.RightColor = System.Drawing.Color.Black
        Me.Shape2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape2.Border.TopColor = System.Drawing.Color.Black
        Me.Shape2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape2.Height = 10.33465!
        Me.Shape2.Left = 4.035433!
        Me.Shape2.LineStyle = DataDynamics.ActiveReports.LineStyle.Transparent
        Me.Shape2.Name = "Shape2"
        Me.Shape2.RoundingRadius = 9.999999!
        Me.Shape2.Top = 1.181102!
        Me.Shape2.Width = 4.084647!
        '
        'TextBox4
        '
        Me.TextBox4.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox4.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox4.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox4.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox4.Height = 0.3937007!
        Me.TextBox4.Left = 0.1476378!
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox4.Text = "1. ���ͼ�����͡"
        Me.TextBox4.Top = 1.181102!
        Me.TextBox4.Width = 2.928149!
        '
        'Shape3
        '
        Me.Shape3.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape3.Border.RightColor = System.Drawing.Color.Black
        Me.Shape3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape3.Border.TopColor = System.Drawing.Color.Black
        Me.Shape3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.Shape3.Height = 0.6397638!
        Me.Shape3.Left = 4.035433!
        Me.Shape3.LineStyle = DataDynamics.ActiveReports.LineStyle.Transparent
        Me.Shape3.Name = "Shape3"
        Me.Shape3.RoundingRadius = 9.999999!
        Me.Shape3.Top = 0.5413386!
        Me.Shape3.Width = 4.084647!
        '
        'TextBox5
        '
        Me.TextBox5.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Height = 0.3937007!
        Me.TextBox5.Left = 4.084647!
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox5.Text = "�Ţ������ͧ"
        Me.TextBox5.Top = 0.5413386!
        Me.TextBox5.Width = 1.107283!
        '
        'TextBox6
        '
        Me.TextBox6.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox6.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox6.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox6.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox6.Height = 0.3937007!
        Me.TextBox6.Left = 4.084647!
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox6.Text = "�ѹ������ ( �觢����� )"
        Me.TextBox6.Top = 0.7874014!
        Me.TextBox6.Width = 1.107283!
        '
        'TextBox7
        '
        Me.TextBox7.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox7.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox7.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox7.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox7.Height = 0.3937007!
        Me.TextBox7.Left = 5.51181!
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox7.Text = "Ẻ ʷ.6 (EDI) NON QUOTA"
        Me.TextBox7.Top = 0.246063!
        Me.TextBox7.Width = 2.386811!
        '
        'txtTemp_REFERENCE_CODE2
        '
        Me.txtTemp_REFERENCE_CODE2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_REFERENCE_CODE2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_REFERENCE_CODE2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_REFERENCE_CODE2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_REFERENCE_CODE2.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_REFERENCE_CODE2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_REFERENCE_CODE2.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_REFERENCE_CODE2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_REFERENCE_CODE2.Height = 0.3937007!
        Me.txtTemp_REFERENCE_CODE2.Left = 5.314961!
        Me.txtTemp_REFERENCE_CODE2.Name = "txtTemp_REFERENCE_CODE2"
        Me.txtTemp_REFERENCE_CODE2.Style = "ddo-char-set: 222; text-align: left; font-weight: bold; font-size: 12pt; font-fam" & _
            "ily: BrowalliaUPC; vertical-align: middle; "
        Me.txtTemp_REFERENCE_CODE2.Text = Nothing
        Me.txtTemp_REFERENCE_CODE2.Top = 0.5413386!
        Me.txtTemp_REFERENCE_CODE2.Width = 2.805118!
        '
        'txtSent_date
        '
        Me.txtSent_date.Border.BottomColor = System.Drawing.Color.Black
        Me.txtSent_date.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSent_date.Border.LeftColor = System.Drawing.Color.Black
        Me.txtSent_date.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSent_date.Border.RightColor = System.Drawing.Color.Black
        Me.txtSent_date.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSent_date.Border.TopColor = System.Drawing.Color.Black
        Me.txtSent_date.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSent_date.DataField = "Sent_date"
        Me.txtSent_date.Height = 0.3937007!
        Me.txtSent_date.Left = 5.314961!
        Me.txtSent_date.Name = "txtSent_date"
        Me.txtSent_date.OutputFormat = resources.GetString("txtSent_date.OutputFormat")
        Me.txtSent_date.Style = "ddo-char-set: 222; text-align: left; font-weight: bold; font-size: 12pt; font-fam" & _
            "ily: BrowalliaUPC; vertical-align: middle; "
        Me.txtSent_date.Text = "Sent_date"
        Me.txtSent_date.Top = 0.7874014!
        Me.txtSent_date.Width = 2.805118!
        '
        'TextBox8
        '
        Me.TextBox8.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox8.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox8.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox8.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox8.Height = 0.3937007!
        Me.TextBox8.Left = 0.1476378!
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox8.Text = "��"
        Me.TextBox8.Top = 1.451772!
        Me.TextBox8.Width = 0.7874014!
        '
        'TextBox9
        '
        Me.TextBox9.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox9.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox9.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox9.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox9.Height = 0.3937007!
        Me.TextBox9.Left = 0.1476378!
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox9.Text = "�ѧ���"
        Me.TextBox9.Top = 1.747047!
        Me.TextBox9.Width = 0.7874014!
        '
        'TextBox10
        '
        Me.TextBox10.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox10.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox10.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox10.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox10.Height = 0.3937007!
        Me.TextBox10.Left = 0.1476378!
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox10.Text = "�������"
        Me.TextBox10.Top = 2.066929!
        Me.TextBox10.Width = 0.7874014!
        '
        'TextBox12
        '
        Me.TextBox12.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox12.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox12.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox12.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox12.Height = 0.393701!
        Me.TextBox12.Left = 0.1476378!
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox12.Text = "������ɳ���"
        Me.TextBox12.Top = 2.65748!
        Me.TextBox12.Width = 0.7874014!
        '
        'TextBox11
        '
        Me.TextBox11.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox11.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox11.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox11.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox11.Height = 0.3937005!
        Me.TextBox11.Left = 0.1476378!
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox11.Text = "���Ѿ��"
        Me.TextBox11.Top = 2.952756!
        Me.TextBox11.Width = 0.7874014!
        '
        'TextBox13
        '
        Me.TextBox13.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox13.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox13.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox13.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox13.Height = 0.3937009!
        Me.TextBox13.Left = 0.1476378!
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox13.Text = "�����"
        Me.TextBox13.Top = 3.272638!
        Me.TextBox13.Width = 0.7874014!
        '
        'TextBox14
        '
        Me.TextBox14.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox14.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox14.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox14.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox14.Height = 0.3937007!
        Me.TextBox14.Left = 4.06004!
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox14.Text = "2. ���ͼ��ӡ��᷹ (����Ѻ�ͺ�ӹҨ/�������)"
        Me.TextBox14.Top = 1.181102!
        Me.TextBox14.Width = 2.534449!
        '
        'txtcard_id
        '
        Me.txtcard_id.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcard_id.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcard_id.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id.Border.RightColor = System.Drawing.Color.Black
        Me.txtcard_id.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id.Border.TopColor = System.Drawing.Color.Black
        Me.txtcard_id.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcard_id.DataField = "card_id"
        Me.txtcard_id.Height = 0.3937007!
        Me.txtcard_id.Left = 6.569882!
        Me.txtcard_id.Name = "txtcard_id"
        Me.txtcard_id.Style = "ddo-char-set: 222; text-align: left; font-weight: bold; font-size: 12pt; font-fam" & _
            "ily: BrowalliaUPC; vertical-align: middle; "
        Me.txtcard_id.Text = "card_id"
        Me.txtcard_id.Top = 1.181102!
        Me.txtcard_id.Width = 1.550197!
        '
        'TextBox1
        '
        Me.TextBox1.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Height = 0.3937007!
        Me.TextBox1.Left = 4.084647!
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox1.Text = "�������"
        Me.TextBox1.Top = 2.066929!
        Me.TextBox1.Width = 0.7874014!
        '
        'TextBox15
        '
        Me.TextBox15.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox15.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox15.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox15.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox15.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox15.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox15.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox15.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox15.Height = 0.3937007!
        Me.TextBox15.Left = 4.084647!
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox15.Text = "������ɳ���"
        Me.TextBox15.Top = 2.65748!
        Me.TextBox15.Width = 0.7874014!
        '
        'TextBox16
        '
        Me.TextBox16.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox16.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox16.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox16.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox16.Height = 0.3937007!
        Me.TextBox16.Left = 4.084647!
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox16.Text = "���Ѿ��"
        Me.TextBox16.Top = 2.977362!
        Me.TextBox16.Width = 0.7874014!
        '
        'TextBox17
        '
        Me.TextBox17.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox17.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox17.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox17.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox17.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox17.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox17.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox17.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox17.Height = 0.3937007!
        Me.TextBox17.Left = 4.084647!
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox17.Text = "�����"
        Me.TextBox17.Top = 3.272638!
        Me.TextBox17.Width = 0.7874014!
        '
        'TextBox2
        '
        Me.TextBox2.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Height = 0.3937009!
        Me.TextBox2.Left = 0.1476378!
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox2.Text = "3. �Ţ��Шӵ�Ǽ����������"
        Me.TextBox2.Top = 3.641732!
        Me.TextBox2.Width = 1.353346!
        '
        'TextBox18
        '
        Me.TextBox18.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox18.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox18.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox18.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox18.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox18.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox18.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox18.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox18.Height = 0.3937009!
        Me.TextBox18.Left = 4.084647!
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox18.Text = "4. ���������Ţ����Ե"
        Me.TextBox18.Top = 3.641732!
        Me.TextBox18.Width = 1.353346!
        '
        'TextBox19
        '
        Me.TextBox19.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox19.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox19.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox19.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox19.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox19.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox19.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox19.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox19.Height = 0.3937009!
        Me.TextBox19.Left = 0.1476378!
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox19.Text = "5. ��Ҿ��Ң�˹ѧ����Ѻ�ͧ������͡�����¡����л���� �ѧ���"
        Me.TextBox19.Top = 3.937008!
        Me.TextBox19.Width = 3.838583!
        '
        'TextBox20
        '
        Me.TextBox20.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox20.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox20.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox20.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox20.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox20.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox20.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox20.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox20.Height = 0.3937007!
        Me.TextBox20.Left = 0.1476378!
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox20.Text = "˹ѧ����Ѻ�ͧ"
        Me.TextBox20.Top = 4.232284!
        Me.TextBox20.Width = 1.008858!
        '
        'TextBox21
        '
        Me.TextBox21.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox21.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox21.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox21.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox21.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox21.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox21.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox21.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox21.Height = 0.3937007!
        Me.TextBox21.Left = 0.1476378!
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox21.Text = "����Ȼ��·ҧ"
        Me.TextBox21.Top = 4.527559!
        Me.TextBox21.Width = 1.008858!
        '
        'TextBox22
        '
        Me.TextBox22.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox22.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox22.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox22.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox22.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox22.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox22.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox22.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox22.Height = 0.3937009!
        Me.TextBox22.Left = 0.1476378!
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox22.Text = "��¡��"
        Me.TextBox22.Top = 4.847441!
        Me.TextBox22.Width = 1.008858!
        '
        'TextBox23
        '
        Me.TextBox23.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox23.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox23.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox23.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox23.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox23.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox23.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox23.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox23.Height = 0.3937007!
        Me.TextBox23.Left = 0.1476378!
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox23.Text = "˹���"
        Me.TextBox23.Top = 5.142717!
        Me.TextBox23.Width = 1.008858!
        '
        'TextBox24
        '
        Me.TextBox24.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox24.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox24.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox24.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox24.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox24.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox24.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox24.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox24.Height = 0.3937009!
        Me.TextBox24.Left = 4.084647!
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox24.Text = "INVOICE NO."
        Me.TextBox24.Top = 3.937008!
        Me.TextBox24.Width = 0.8366139!
        '
        'TextBox25
        '
        Me.TextBox25.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox25.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox25.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox25.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox25.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox25.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox25.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox25.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox25.Height = 0.3937007!
        Me.TextBox25.Left = 4.084647!
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox25.Text = "����ҳ"
        Me.TextBox25.Top = 4.232284!
        Me.TextBox25.Width = 1.082677!
        '
        'TextBox26
        '
        Me.TextBox26.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox26.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox26.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox26.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox26.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox26.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox26.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox26.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox26.Height = 0.3937007!
        Me.TextBox26.Left = 4.084647!
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox26.Text = "����ҳ���ҧ����"
        Me.TextBox26.Top = 4.527559!
        Me.TextBox26.Width = 1.082677!
        '
        'TextBox27
        '
        Me.TextBox27.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox27.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox27.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox27.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox27.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox27.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox27.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox27.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox27.Height = 0.3937009!
        Me.TextBox27.Left = 4.084647!
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox27.Text = "��Ť�� (FOB $US)"
        Me.TextBox27.Top = 4.847441!
        Me.TextBox27.Width = 1.082677!
        '
        'TextBox28
        '
        Me.TextBox28.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox28.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox28.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox28.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox28.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox28.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox28.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox28.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox28.Height = 0.393701!
        Me.TextBox28.Left = 4.084647!
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox28.Text = "�ѹ������͡"
        Me.TextBox28.Top = 5.167323!
        Me.TextBox28.Width = 1.082677!
        '
        'TextBox30
        '
        Me.TextBox30.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox30.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox30.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox30.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox30.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox30.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox30.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox30.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox30.Height = 0.3937007!
        Me.TextBox30.Left = 0.1230315!
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox30.Text = "�ӴѺ"
        Me.TextBox30.Top = 6.692914!
        Me.TextBox30.Width = 0.7381889!
        '
        'txtTemp_address
        '
        Me.txtTemp_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_address.Height = 0.5167323!
        Me.txtTemp_address.Left = 0.6397638!
        Me.txtTemp_address.Name = "txtTemp_address"
        Me.txtTemp_address.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: top; "
        Me.txtTemp_address.Text = Nothing
        Me.txtTemp_address.Top = 2.140748!
        Me.txtTemp_address.Width = 3.321851!
        '
        'txtcompany_nameth
        '
        Me.txtcompany_nameth.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_nameth.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_nameth.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_nameth.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_nameth.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_nameth.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_nameth.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_nameth.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_nameth.Height = 0.3937007!
        Me.txtcompany_nameth.Left = 0.6397638!
        Me.txtcompany_nameth.Name = "txtcompany_nameth"
        Me.txtcompany_nameth.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtcompany_nameth.Text = Nothing
        Me.txtcompany_nameth.Top = 1.451772!
        Me.txtcompany_nameth.Width = 3.321851!
        '
        'txtcompany_nameeng
        '
        Me.txtcompany_nameeng.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_nameeng.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_nameeng.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_nameeng.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_nameeng.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_nameeng.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_nameeng.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_nameeng.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_nameeng.Height = 0.3937007!
        Me.txtcompany_nameeng.Left = 0.6397638!
        Me.txtcompany_nameeng.Name = "txtcompany_nameeng"
        Me.txtcompany_nameeng.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtcompany_nameeng.Text = Nothing
        Me.txtcompany_nameeng.Top = 1.747047!
        Me.txtcompany_nameeng.Width = 3.321851!
        '
        'txtTemp_request_person1
        '
        Me.txtTemp_request_person1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_request_person1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_request_person1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_request_person1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_request_person1.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_request_person1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_request_person1.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_request_person1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_request_person1.Height = 0.3937007!
        Me.txtTemp_request_person1.Left = 4.06004!
        Me.txtTemp_request_person1.Name = "txtTemp_request_person1"
        Me.txtTemp_request_person1.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtTemp_request_person1.Text = Nothing
        Me.txtTemp_request_person1.Top = 1.451772!
        Me.txtTemp_request_person1.Width = 4.010827!
        '
        'txtTemp_address1
        '
        Me.txtTemp_address1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_address1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_address1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_address1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_address1.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_address1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_address1.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_address1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_address1.Height = 0.5167323!
        Me.txtTemp_address1.Left = 4.552166!
        Me.txtTemp_address1.Name = "txtTemp_address1"
        Me.txtTemp_address1.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: top; "
        Me.txtTemp_address1.Text = Nothing
        Me.txtTemp_address1.Top = 2.140748!
        Me.txtTemp_address1.Width = 3.518702!
        '
        'TextBox62
        '
        Me.TextBox62.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox62.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox62.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox62.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox62.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox62.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox62.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox62.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox62.Height = 0.393701!
        Me.TextBox62.Left = 0.9350396!
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.TextBox62.Text = Nothing
        Me.TextBox62.Top = 2.65748!
        Me.TextBox62.Width = 3.026575!
        '
        'txtTemp_company_phone
        '
        Me.txtTemp_company_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_company_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_company_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_company_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_company_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_phone.Height = 0.393701!
        Me.txtTemp_company_phone.Left = 0.9350396!
        Me.txtTemp_company_phone.Name = "txtTemp_company_phone"
        Me.txtTemp_company_phone.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtTemp_company_phone.Text = Nothing
        Me.txtTemp_company_phone.Top = 2.952756!
        Me.txtTemp_company_phone.Width = 3.026575!
        '
        'txtTemp_company_fax
        '
        Me.txtTemp_company_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_company_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_company_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_company_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_company_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_fax.Height = 0.393701!
        Me.txtTemp_company_fax.Left = 0.9350396!
        Me.txtTemp_company_fax.Name = "txtTemp_company_fax"
        Me.txtTemp_company_fax.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtTemp_company_fax.Text = Nothing
        Me.txtTemp_company_fax.Top = 3.272638!
        Me.txtTemp_company_fax.Width = 3.026575!
        '
        'TextBox65
        '
        Me.TextBox65.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox65.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox65.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox65.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox65.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox65.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox65.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox65.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox65.Height = 0.393701!
        Me.TextBox65.Left = 4.872047!
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.TextBox65.Text = Nothing
        Me.TextBox65.Top = 2.65748!
        Me.TextBox65.Width = 3.026575!
        '
        'txtTemp_company_phone1
        '
        Me.txtTemp_company_phone1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_company_phone1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_phone1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_company_phone1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_phone1.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_company_phone1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_phone1.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_company_phone1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_phone1.Height = 0.393701!
        Me.txtTemp_company_phone1.Left = 4.872047!
        Me.txtTemp_company_phone1.Name = "txtTemp_company_phone1"
        Me.txtTemp_company_phone1.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtTemp_company_phone1.Text = Nothing
        Me.txtTemp_company_phone1.Top = 2.977362!
        Me.txtTemp_company_phone1.Width = 3.026575!
        '
        'txtTemp_company_fax1
        '
        Me.txtTemp_company_fax1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_company_fax1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_fax1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_company_fax1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_fax1.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_company_fax1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_fax1.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_company_fax1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_company_fax1.Height = 0.393701!
        Me.txtTemp_company_fax1.Left = 4.872047!
        Me.txtTemp_company_fax1.Name = "txtTemp_company_fax1"
        Me.txtTemp_company_fax1.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtTemp_company_fax1.Text = Nothing
        Me.txtTemp_company_fax1.Top = 3.272638!
        Me.txtTemp_company_fax1.Width = 3.026575!
        '
        'TextBox68
        '
        Me.TextBox68.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox68.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox68.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox68.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox68.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox68.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox68.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox68.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox68.Height = 0.3937009!
        Me.TextBox68.Left = 1.13189!
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.TextBox68.Text = "Certificate of Origin"
        Me.TextBox68.Top = 4.232284!
        Me.TextBox68.Width = 2.854331!
        '
        'txtimport_country
        '
        Me.txtimport_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtimport_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtimport_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtimport_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtimport_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtimport_country.DataField = "import_country"
        Me.txtimport_country.Height = 0.3937009!
        Me.txtimport_country.Left = 1.13189!
        Me.txtimport_country.Name = "txtimport_country"
        Me.txtimport_country.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtimport_country.Text = "import_country"
        Me.txtimport_country.Top = 4.527559!
        Me.txtimport_country.Width = 2.854331!
        '
        'txtCAT
        '
        Me.txtCAT.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCAT.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCAT.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCAT.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCAT.Border.RightColor = System.Drawing.Color.Black
        Me.txtCAT.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCAT.Border.TopColor = System.Drawing.Color.Black
        Me.txtCAT.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCAT.DataField = "CAT"
        Me.txtCAT.Height = 0.3937009!
        Me.txtCAT.Left = 1.13189!
        Me.txtCAT.Name = "txtCAT"
        Me.txtCAT.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtCAT.Text = "CAT"
        Me.txtCAT.Top = 4.847441!
        Me.txtCAT.Width = 2.854331!
        '
        'txtI_Unit_code
        '
        Me.txtI_Unit_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txtI_Unit_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtI_Unit_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txtI_Unit_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtI_Unit_code.Border.RightColor = System.Drawing.Color.Black
        Me.txtI_Unit_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtI_Unit_code.Border.TopColor = System.Drawing.Color.Black
        Me.txtI_Unit_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtI_Unit_code.DataField = "I_Unit_code"
        Me.txtI_Unit_code.Height = 0.3937009!
        Me.txtI_Unit_code.Left = 1.13189!
        Me.txtI_Unit_code.Name = "txtI_Unit_code"
        Me.txtI_Unit_code.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtI_Unit_code.Text = "I_Unit_code"
        Me.txtI_Unit_code.Top = 5.142717!
        Me.txtI_Unit_code.Width = 2.854331!
        '
        'txtTotal_Net_weight
        '
        Me.txtTotal_Net_weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTotal_Net_weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal_Net_weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTotal_Net_weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal_Net_weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtTotal_Net_weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal_Net_weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtTotal_Net_weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal_Net_weight.DataField = "Total_Net_weight"
        Me.txtTotal_Net_weight.Height = 0.3937009!
        Me.txtTotal_Net_weight.Left = 5.167323!
        Me.txtTotal_Net_weight.Name = "txtTotal_Net_weight"
        Me.txtTotal_Net_weight.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtTotal_Net_weight.Text = "Total_Net_weight"
        Me.txtTotal_Net_weight.Top = 4.232284!
        Me.txtTotal_Net_weight.Width = 2.928149!
        '
        'txtQuantity5
        '
        Me.txtQuantity5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtQuantity5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtQuantity5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtQuantity5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtQuantity5.Border.RightColor = System.Drawing.Color.Black
        Me.txtQuantity5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtQuantity5.Border.TopColor = System.Drawing.Color.Black
        Me.txtQuantity5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtQuantity5.DataField = "Quantity5"
        Me.txtQuantity5.Height = 0.3937009!
        Me.txtQuantity5.Left = 5.167323!
        Me.txtQuantity5.Name = "txtQuantity5"
        Me.txtQuantity5.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtQuantity5.Text = "Quantity5"
        Me.txtQuantity5.Top = 4.847441!
        Me.txtQuantity5.Width = 2.928149!
        '
        'txtedi_date
        '
        Me.txtedi_date.Border.BottomColor = System.Drawing.Color.Black
        Me.txtedi_date.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtedi_date.Border.LeftColor = System.Drawing.Color.Black
        Me.txtedi_date.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtedi_date.Border.RightColor = System.Drawing.Color.Black
        Me.txtedi_date.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtedi_date.Border.TopColor = System.Drawing.Color.Black
        Me.txtedi_date.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtedi_date.DataField = "edi_date"
        Me.txtedi_date.Height = 0.3937009!
        Me.txtedi_date.Left = 5.167323!
        Me.txtedi_date.Name = "txtedi_date"
        Me.txtedi_date.OutputFormat = resources.GetString("txtedi_date.OutputFormat")
        Me.txtedi_date.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtedi_date.Text = "edi_date"
        Me.txtedi_date.Top = 5.167323!
        Me.txtedi_date.Width = 2.928149!
        '
        'TextBox29
        '
        Me.TextBox29.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox29.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox29.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox29.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox29.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox29.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox29.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox29.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox29.Height = 0.3937007!
        Me.TextBox29.Left = 0.1476378!
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox29.Text = "6. ������з�������������Թ���"
        Me.TextBox29.Top = 5.536417!
        Me.TextBox29.Width = 1.574803!
        '
        'txtdestination_company
        '
        Me.txtdestination_company.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.DataField = "destination_company"
        Me.txtdestination_company.Height = 0.3937007!
        Me.txtdestination_company.Left = 1.722441!
        Me.txtdestination_company.Name = "txtdestination_company"
        Me.txtdestination_company.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtdestination_company.Text = "destination_company"
        Me.txtdestination_company.Top = 5.536417!
        Me.txtdestination_company.Width = 6.373032!
        '
        'txtTemp_dest
        '
        Me.txtTemp_dest.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_dest.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_dest.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_dest.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_dest.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_dest.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_dest.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_dest.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_dest.Height = 0.4429132!
        Me.txtTemp_dest.Left = 0.1476378!
        Me.txtTemp_dest.Name = "txtTemp_dest"
        Me.txtTemp_dest.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: top; "
        Me.txtTemp_dest.Text = resources.GetString("txtTemp_dest.Text")
        Me.txtTemp_dest.Top = 5.807087!
        Me.txtTemp_dest.Width = 7.947833!
        '
        'TextBox31
        '
        Me.TextBox31.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox31.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox31.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox31.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox31.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox31.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox31.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox31.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox31.Height = 0.3937009!
        Me.TextBox31.Left = 0.1476378!
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox31.Text = "7. �������ǵ�˹�����¡���Թ���"
        Me.TextBox31.Top = 6.348424!
        Me.TextBox31.Width = 3.838583!
        '
        'TextBox33
        '
        Me.TextBox33.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox33.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox33.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox33.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox33.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox33.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox33.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox33.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox33.Height = 0.3937009!
        Me.TextBox33.Left = 4.084647!
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox33.Text = "8. �������ǵ�˹��µ��ҧ���� (੾������ͼ��������ٻ����Ѱ����ԡ�)"
        Me.TextBox33.Top = 6.348424!
        Me.TextBox33.Width = 3.838583!
        '
        'TextBox78
        '
        Me.TextBox78.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox78.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox78.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox78.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox78.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox78.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox78.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox78.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox78.Height = 0.3937005!
        Me.TextBox78.Left = 0.8612201!
        Me.TextBox78.Name = "TextBox78"
        Me.TextBox78.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox78.Text = "���������ǵ�"
        Me.TextBox78.Top = 6.692914!
        Me.TextBox78.Width = 1.181102!
        '
        'TextBox79
        '
        Me.TextBox79.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox79.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox79.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox79.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox79.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox79.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox79.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox79.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox79.Height = 0.3937005!
        Me.TextBox79.Left = 2.042323!
        Me.TextBox79.Name = "TextBox79"
        Me.TextBox79.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox79.Text = "����ҳ"
        Me.TextBox79.Top = 6.692914!
        Me.TextBox79.Width = 1.99311!
        '
        'TextBox80
        '
        Me.TextBox80.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox80.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox80.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox80.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox80.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox80.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox80.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox80.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox80.Height = 0.3937005!
        Me.TextBox80.Left = 2.042323!
        Me.TextBox80.Name = "TextBox80"
        Me.TextBox80.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox80.Text = Nothing
        Me.TextBox80.Top = 7.037403!
        Me.TextBox80.Width = 1.99311!
        '
        'TextBox81
        '
        Me.TextBox81.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox81.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox81.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox81.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox81.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox81.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox81.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox81.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox81.Height = 0.3937005!
        Me.TextBox81.Left = 0.8612201!
        Me.TextBox81.Name = "TextBox81"
        Me.TextBox81.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox81.Text = Nothing
        Me.TextBox81.Top = 7.037403!
        Me.TextBox81.Width = 1.181102!
        '
        'TextBox82
        '
        Me.TextBox82.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox82.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox82.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox82.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox82.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox82.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox82.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox82.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox82.Height = 0.3937007!
        Me.TextBox82.Left = 0.1230315!
        Me.TextBox82.Name = "TextBox82"
        Me.TextBox82.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox82.Text = Nothing
        Me.TextBox82.Top = 7.037403!
        Me.TextBox82.Width = 0.7381889!
        '
        'TextBox83
        '
        Me.TextBox83.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox83.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox83.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox83.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox83.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox83.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox83.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox83.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox83.Height = 0.3937005!
        Me.TextBox83.Left = 2.042323!
        Me.TextBox83.Name = "TextBox83"
        Me.TextBox83.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox83.Text = Nothing
        Me.TextBox83.Top = 7.381889!
        Me.TextBox83.Width = 1.99311!
        '
        'TextBox84
        '
        Me.TextBox84.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox84.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox84.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox84.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox84.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox84.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox84.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox84.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox84.Height = 0.3937005!
        Me.TextBox84.Left = 0.8612201!
        Me.TextBox84.Name = "TextBox84"
        Me.TextBox84.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox84.Text = Nothing
        Me.TextBox84.Top = 7.381889!
        Me.TextBox84.Width = 1.181102!
        '
        'TextBox85
        '
        Me.TextBox85.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox85.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox85.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox85.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox85.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox85.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox85.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox85.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox85.Height = 0.3937007!
        Me.TextBox85.Left = 0.1230315!
        Me.TextBox85.Name = "TextBox85"
        Me.TextBox85.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox85.Text = Nothing
        Me.TextBox85.Top = 7.381889!
        Me.TextBox85.Width = 0.7381889!
        '
        'TextBox86
        '
        Me.TextBox86.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox86.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox86.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox86.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox86.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox86.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox86.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox86.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox86.Height = 0.3937005!
        Me.TextBox86.Left = 2.042323!
        Me.TextBox86.Name = "TextBox86"
        Me.TextBox86.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox86.Text = Nothing
        Me.TextBox86.Top = 7.726375!
        Me.TextBox86.Width = 1.99311!
        '
        'TextBox87
        '
        Me.TextBox87.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox87.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox87.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox87.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox87.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox87.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox87.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox87.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox87.Height = 0.3937005!
        Me.TextBox87.Left = 0.8612201!
        Me.TextBox87.Name = "TextBox87"
        Me.TextBox87.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox87.Text = Nothing
        Me.TextBox87.Top = 7.726375!
        Me.TextBox87.Width = 1.181102!
        '
        'TextBox88
        '
        Me.TextBox88.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox88.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox88.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox88.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox88.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox88.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox88.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox88.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox88.Height = 0.3937007!
        Me.TextBox88.Left = 0.1230315!
        Me.TextBox88.Name = "TextBox88"
        Me.TextBox88.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox88.Text = Nothing
        Me.TextBox88.Top = 7.726375!
        Me.TextBox88.Width = 0.7381889!
        '
        'TextBox89
        '
        Me.TextBox89.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox89.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox89.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox89.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox89.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox89.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox89.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox89.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox89.Height = 0.3937005!
        Me.TextBox89.Left = 2.042323!
        Me.TextBox89.Name = "TextBox89"
        Me.TextBox89.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox89.Text = Nothing
        Me.TextBox89.Top = 8.070868!
        Me.TextBox89.Width = 1.99311!
        '
        'TextBox90
        '
        Me.TextBox90.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox90.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox90.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox90.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox90.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox90.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox90.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox90.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox90.Height = 0.3937005!
        Me.TextBox90.Left = 0.8612201!
        Me.TextBox90.Name = "TextBox90"
        Me.TextBox90.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox90.Text = Nothing
        Me.TextBox90.Top = 8.070868!
        Me.TextBox90.Width = 1.181102!
        '
        'TextBox91
        '
        Me.TextBox91.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox91.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox91.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox91.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox91.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox91.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox91.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox91.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox91.Height = 0.3937007!
        Me.TextBox91.Left = 0.1230315!
        Me.TextBox91.Name = "TextBox91"
        Me.TextBox91.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox91.Text = Nothing
        Me.TextBox91.Top = 8.070868!
        Me.TextBox91.Width = 0.7381889!
        '
        'TextBox92
        '
        Me.TextBox92.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox92.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox92.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox92.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox92.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox92.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox92.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox92.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox92.Height = 0.3937007!
        Me.TextBox92.Left = 0.1230315!
        Me.TextBox92.Name = "TextBox92"
        Me.TextBox92.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox92.Text = Nothing
        Me.TextBox92.Top = 8.415355!
        Me.TextBox92.Width = 0.7381889!
        '
        'TextBox93
        '
        Me.TextBox93.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox93.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox93.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox93.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox93.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox93.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox93.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox93.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox93.Height = 0.3937005!
        Me.TextBox93.Left = 0.8612201!
        Me.TextBox93.Name = "TextBox93"
        Me.TextBox93.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox93.Text = Nothing
        Me.TextBox93.Top = 8.415355!
        Me.TextBox93.Width = 1.181102!
        '
        'TextBox94
        '
        Me.TextBox94.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox94.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox94.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox94.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox94.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox94.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox94.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox94.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox94.Height = 0.3937005!
        Me.TextBox94.Left = 2.042323!
        Me.TextBox94.Name = "TextBox94"
        Me.TextBox94.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox94.Text = Nothing
        Me.TextBox94.Top = 8.415355!
        Me.TextBox94.Width = 1.99311!
        '
        'TextBox39
        '
        Me.TextBox39.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox39.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox39.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox39.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox39.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox39.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox39.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox39.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox39.Height = 0.3937005!
        Me.TextBox39.Left = 4.035433!
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox39.Text = Nothing
        Me.TextBox39.Top = 6.692914!
        Me.TextBox39.Width = 0.7874014!
        '
        'TextBox95
        '
        Me.TextBox95.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox95.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox95.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox95.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox95.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox95.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox95.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox95.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox95.Height = 0.3937005!
        Me.TextBox95.Left = 4.822834!
        Me.TextBox95.Name = "TextBox95"
        Me.TextBox95.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox95.Text = Nothing
        Me.TextBox95.Top = 6.692914!
        Me.TextBox95.Width = 1.181102!
        '
        'TextBox96
        '
        Me.TextBox96.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox96.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox96.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox96.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox96.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox96.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox96.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox96.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox96.Height = 0.3937005!
        Me.TextBox96.Left = 6.003937!
        Me.TextBox96.Name = "TextBox96"
        Me.TextBox96.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox96.Text = Nothing
        Me.TextBox96.Top = 6.692914!
        Me.TextBox96.Width = 2.116143!
        '
        'TextBox97
        '
        Me.TextBox97.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox97.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox97.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox97.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox97.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox97.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox97.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox97.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox97.Height = 0.3937011!
        Me.TextBox97.Left = 4.035433!
        Me.TextBox97.Name = "TextBox97"
        Me.TextBox97.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox97.Text = Nothing
        Me.TextBox97.Top = 7.037403!
        Me.TextBox97.Width = 0.7874014!
        '
        'TextBox98
        '
        Me.TextBox98.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox98.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox98.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox98.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox98.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox98.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox98.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox98.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox98.Height = 0.3937005!
        Me.TextBox98.Left = 4.822834!
        Me.TextBox98.Name = "TextBox98"
        Me.TextBox98.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox98.Text = Nothing
        Me.TextBox98.Top = 7.037403!
        Me.TextBox98.Width = 1.181102!
        '
        'TextBox99
        '
        Me.TextBox99.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox99.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox99.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox99.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox99.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox99.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox99.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox99.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox99.Height = 0.3937011!
        Me.TextBox99.Left = 6.003937!
        Me.TextBox99.Name = "TextBox99"
        Me.TextBox99.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox99.Text = Nothing
        Me.TextBox99.Top = 7.037403!
        Me.TextBox99.Width = 2.116143!
        '
        'TextBox100
        '
        Me.TextBox100.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox100.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox100.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox100.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox100.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox100.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox100.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox100.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox100.Height = 0.393701!
        Me.TextBox100.Left = 6.003937!
        Me.TextBox100.Name = "TextBox100"
        Me.TextBox100.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox100.Text = Nothing
        Me.TextBox100.Top = 7.381889!
        Me.TextBox100.Width = 2.116143!
        '
        'TextBox101
        '
        Me.TextBox101.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox101.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox101.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox101.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox101.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox101.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox101.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox101.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox101.Height = 0.3937005!
        Me.TextBox101.Left = 4.822834!
        Me.TextBox101.Name = "TextBox101"
        Me.TextBox101.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox101.Text = Nothing
        Me.TextBox101.Top = 7.381889!
        Me.TextBox101.Width = 1.181102!
        '
        'TextBox102
        '
        Me.TextBox102.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox102.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox102.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox102.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox102.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox102.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox102.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox102.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox102.Height = 0.393701!
        Me.TextBox102.Left = 4.035433!
        Me.TextBox102.Name = "TextBox102"
        Me.TextBox102.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox102.Text = Nothing
        Me.TextBox102.Top = 7.381889!
        Me.TextBox102.Width = 0.7874014!
        '
        'TextBox103
        '
        Me.TextBox103.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox103.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox103.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox103.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox103.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox103.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox103.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox103.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox103.Height = 0.3937007!
        Me.TextBox103.Left = 4.035433!
        Me.TextBox103.Name = "TextBox103"
        Me.TextBox103.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox103.Text = Nothing
        Me.TextBox103.Top = 7.726375!
        Me.TextBox103.Width = 0.7874014!
        '
        'TextBox104
        '
        Me.TextBox104.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox104.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox104.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox104.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox104.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox104.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox104.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox104.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox104.Height = 0.3937005!
        Me.TextBox104.Left = 4.822834!
        Me.TextBox104.Name = "TextBox104"
        Me.TextBox104.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox104.Text = Nothing
        Me.TextBox104.Top = 7.726375!
        Me.TextBox104.Width = 1.181102!
        '
        'TextBox105
        '
        Me.TextBox105.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox105.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox105.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox105.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox105.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox105.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox105.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox105.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox105.Height = 0.3937007!
        Me.TextBox105.Left = 6.003937!
        Me.TextBox105.Name = "TextBox105"
        Me.TextBox105.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox105.Text = Nothing
        Me.TextBox105.Top = 7.726375!
        Me.TextBox105.Width = 2.116143!
        '
        'TextBox106
        '
        Me.TextBox106.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox106.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox106.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox106.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox106.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox106.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox106.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox106.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox106.Height = 0.3937007!
        Me.TextBox106.Left = 6.003937!
        Me.TextBox106.Name = "TextBox106"
        Me.TextBox106.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox106.Text = Nothing
        Me.TextBox106.Top = 8.070868!
        Me.TextBox106.Width = 2.116143!
        '
        'TextBox107
        '
        Me.TextBox107.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox107.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox107.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox107.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox107.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox107.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox107.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox107.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox107.Height = 0.3937005!
        Me.TextBox107.Left = 4.822834!
        Me.TextBox107.Name = "TextBox107"
        Me.TextBox107.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox107.Text = Nothing
        Me.TextBox107.Top = 8.070868!
        Me.TextBox107.Width = 1.181102!
        '
        'TextBox108
        '
        Me.TextBox108.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox108.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox108.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox108.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox108.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox108.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox108.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox108.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox108.Height = 0.3937007!
        Me.TextBox108.Left = 4.035433!
        Me.TextBox108.Name = "TextBox108"
        Me.TextBox108.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox108.Text = Nothing
        Me.TextBox108.Top = 8.070868!
        Me.TextBox108.Width = 0.7874014!
        '
        'TextBox109
        '
        Me.TextBox109.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox109.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox109.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox109.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox109.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox109.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox109.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox109.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox109.Height = 0.3937005!
        Me.TextBox109.Left = 4.035433!
        Me.TextBox109.Name = "TextBox109"
        Me.TextBox109.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox109.Text = Nothing
        Me.TextBox109.Top = 8.415355!
        Me.TextBox109.Width = 0.7874014!
        '
        'TextBox110
        '
        Me.TextBox110.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox110.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox110.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox110.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox110.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox110.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox110.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox110.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox110.Height = 0.3937005!
        Me.TextBox110.Left = 4.822834!
        Me.TextBox110.Name = "TextBox110"
        Me.TextBox110.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox110.Text = Nothing
        Me.TextBox110.Top = 8.415355!
        Me.TextBox110.Width = 1.181102!
        '
        'TextBox111
        '
        Me.TextBox111.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox111.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox111.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox111.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox111.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox111.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox111.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox111.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox111.Height = 0.3937005!
        Me.TextBox111.Left = 6.003937!
        Me.TextBox111.Name = "TextBox111"
        Me.TextBox111.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox111.Text = Nothing
        Me.TextBox111.Top = 8.415355!
        Me.TextBox111.Width = 2.116143!
        '
        'TextBox38
        '
        Me.TextBox38.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox38.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox38.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox38.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox38.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox38.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox38.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox38.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox38.Height = 0.3937005!
        Me.TextBox38.Left = 0.1230315!
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox38.Text = "�������ҳ���˹�����¡��"
        Me.TextBox38.Top = 8.75984!
        Me.TextBox38.Width = 1.919291!
        '
        'TextBox32
        '
        Me.TextBox32.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox32.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox32.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox32.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox32.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox32.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox32.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox32.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox32.Height = 0.3937005!
        Me.TextBox32.Left = 2.042323!
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox32.Text = Nothing
        Me.TextBox32.Top = 8.75984!
        Me.TextBox32.Width = 1.99311!
        '
        'TextBox45
        '
        Me.TextBox45.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox45.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox45.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox45.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox45.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox45.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox45.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox45.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox45.Height = 0.3937005!
        Me.TextBox45.Left = 4.035433!
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox45.Text = "�������ҳ���ҧ����"
        Me.TextBox45.Top = 8.75984!
        Me.TextBox45.Width = 1.968504!
        '
        'TextBox34
        '
        Me.TextBox34.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox34.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox34.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox34.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.Solid
        Me.TextBox34.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox34.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox34.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox34.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox34.Height = 0.3937005!
        Me.TextBox34.Left = 6.003937!
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox34.Text = Nothing
        Me.TextBox34.Top = 8.75984!
        Me.TextBox34.Width = 2.116143!
        '
        'TextBox46
        '
        Me.TextBox46.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox46.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox46.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox46.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox46.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox46.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox46.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox46.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox46.Height = 0.3937009!
        Me.TextBox46.Left = 0.1722441!
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox46.Text = "9. ��Ҿ��Ң��Ѻ�ͧ���"
        Me.TextBox46.Top = 9.128938!
        Me.TextBox46.Width = 3.838583!
        '
        'TextBox47
        '
        Me.TextBox47.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox47.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox47.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox47.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox47.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox47.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox47.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox47.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox47.Height = 0.3937007!
        Me.TextBox47.Left = 0.1722441!
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Style = "ddo-char-set: 1; font-weight: normal; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox47.Text = "1. �Թ�����觷͵�������蹢��Ѻ�ͧ������͡��Ѻ��� ���Թ��ҷ���Ե���㹻�����" & _
            "� �١��ͧ�����������Ҵ������觡��Դ�Թ��Ңͧ����ȵ������к�㹢�� 5"
        Me.TextBox47.Top = 9.350396!
        Me.TextBox47.Width = 7.972445!
        '
        'TextBox48
        '
        Me.TextBox48.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox48.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox48.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox48.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox48.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox48.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox48.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox48.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox48.Height = 0.3937012!
        Me.TextBox48.Left = 0.1722441!
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Style = "ddo-char-set: 1; font-weight: normal; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox48.Text = "2. ������͡�����蹢�˹ѧ����Ѻ�ͧ������͡ ��仵������º�����ѡࡳ�����з��" & _
            "��ҳԪ���˹�"
        Me.TextBox48.Top = 9.547243!
        Me.TextBox48.Width = 7.972445!
        '
        'TextBox49
        '
        Me.TextBox49.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox49.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox49.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox49.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox49.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox49.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox49.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox49.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox49.Height = 0.3937005!
        Me.TextBox49.Left = 0.1722441!
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Style = "ddo-char-set: 1; font-weight: normal; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox49.Text = "3. ���ǵ���§������Ѻ�����蹢�˹ѧ����Ѻ�ͧ���駹��"
        Me.TextBox49.Top = 9.768702!
        Me.TextBox49.Width = 7.972445!
        '
        'TextBox50
        '
        Me.TextBox50.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox50.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox50.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox50.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox50.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox50.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox50.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox50.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox50.Height = 0.3937007!
        Me.TextBox50.Left = 0.1722441!
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Style = "ddo-char-set: 1; font-weight: normal; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox50.Text = "4. �����͡�Թ�����觷� ��Шй���һ���Ȼ��·ҧ�������к�����˹ѧ����Ѻ�ͧ��Ѻ" & _
            "���"
        Me.TextBox50.Top = 9.99016!
        Me.TextBox50.Width = 7.972445!
        '
        'TextBox51
        '
        Me.TextBox51.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox51.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox51.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox51.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox51.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox51.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox51.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox51.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox51.Height = 0.3937013!
        Me.TextBox51.Left = 4.232284!
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox51.Text = "ŧ����"
        Me.TextBox51.Top = 10.26083!
        Me.TextBox51.Width = 0.6397638!
        '
        'TextBox52
        '
        Me.TextBox52.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox52.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox52.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox52.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox52.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox52.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox52.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox52.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox52.Height = 0.393701!
        Me.TextBox52.Left = 4.773623!
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox52.Text = "( _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ )"
        Me.TextBox52.Top = 10.58071!
        Me.TextBox52.Width = 3.297244!
        '
        'TextBox53
        '
        Me.TextBox53.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox53.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox53.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox53.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox53.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox53.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox53.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox53.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox53.Height = 0.393701!
        Me.TextBox53.Left = 4.232284!
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox53.Text = "���˹�"
        Me.TextBox53.Top = 10.87598!
        Me.TextBox53.Width = 0.6397638!
        '
        'TextBox54
        '
        Me.TextBox54.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox54.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox54.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox54.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox54.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox54.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox54.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox54.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox54.Height = 0.3937005!
        Me.TextBox54.Left = 4.232284!
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 12pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox54.Text = "��һ�зѺ"
        Me.TextBox54.Top = 11.12205!
        Me.TextBox54.Width = 3.838583!
        '
        'TextBox55
        '
        Me.TextBox55.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox55.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox55.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox55.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox55.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox55.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox55.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox55.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox55.Height = 0.3937013!
        Me.TextBox55.Left = 4.872047!
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox55.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox55.Top = 10.26083!
        Me.TextBox55.Width = 3.198819!
        '
        'TextBox57
        '
        Me.TextBox57.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox57.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox57.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox57.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox57.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox57.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox57.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox57.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox57.Height = 0.3937013!
        Me.TextBox57.Left = 4.872047!
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox57.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox57.Top = 10.87598!
        Me.TextBox57.Width = 3.198819!
        '
        'Line1
        '
        Me.Line1.Border.BottomColor = System.Drawing.Color.Black
        Me.Line1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.LeftColor = System.Drawing.Color.Black
        Me.Line1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.RightColor = System.Drawing.Color.Black
        Me.Line1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.TopColor = System.Drawing.Color.Black
        Me.Line1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Height = 4.354331!
        Me.Line1.Left = 4.035433!
        Me.Line1.LineWeight = 1.0!
        Me.Line1.Name = "Line1"
        Me.Line1.Top = 1.181102!
        Me.Line1.Width = 0.0!
        Me.Line1.X1 = 4.035433!
        Me.Line1.X2 = 4.035433!
        Me.Line1.Y1 = 1.181102!
        Me.Line1.Y2 = 5.535433!
        '
        'Line2
        '
        Me.Line2.Border.BottomColor = System.Drawing.Color.Black
        Me.Line2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.LeftColor = System.Drawing.Color.Black
        Me.Line2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.RightColor = System.Drawing.Color.Black
        Me.Line2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.TopColor = System.Drawing.Color.Black
        Me.Line2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Height = 0.0!
        Me.Line2.Left = 0.1220472!
        Me.Line2.LineWeight = 1.0!
        Me.Line2.Name = "Line2"
        Me.Line2.Top = 3.666339!
        Me.Line2.Width = 8.007876!
        Me.Line2.X1 = 0.1220472!
        Me.Line2.X2 = 8.129924!
        Me.Line2.Y1 = 3.666339!
        Me.Line2.Y2 = 3.666339!
        '
        'Line3
        '
        Me.Line3.Border.BottomColor = System.Drawing.Color.Black
        Me.Line3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.LeftColor = System.Drawing.Color.Black
        Me.Line3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.RightColor = System.Drawing.Color.Black
        Me.Line3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.TopColor = System.Drawing.Color.Black
        Me.Line3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Height = 0.0!
        Me.Line3.Left = 0.1230315!
        Me.Line3.LineWeight = 1.0!
        Me.Line3.Name = "Line3"
        Me.Line3.Top = 3.986221!
        Me.Line3.Width = 7.997045!
        Me.Line3.X1 = 0.1230315!
        Me.Line3.X2 = 8.120076!
        Me.Line3.Y1 = 3.986221!
        Me.Line3.Y2 = 3.986221!
        '
        'Line4
        '
        Me.Line4.Border.BottomColor = System.Drawing.Color.Black
        Me.Line4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.LeftColor = System.Drawing.Color.Black
        Me.Line4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.RightColor = System.Drawing.Color.Black
        Me.Line4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.TopColor = System.Drawing.Color.Black
        Me.Line4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Height = 0.0!
        Me.Line4.Left = 0.1230315!
        Me.Line4.LineWeight = 1.0!
        Me.Line4.Name = "Line4"
        Me.Line4.Top = 4.281496!
        Me.Line4.Width = 7.997045!
        Me.Line4.X1 = 0.1230315!
        Me.Line4.X2 = 8.120076!
        Me.Line4.Y1 = 4.281496!
        Me.Line4.Y2 = 4.281496!
        '
        'Line5
        '
        Me.Line5.Border.BottomColor = System.Drawing.Color.Black
        Me.Line5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.LeftColor = System.Drawing.Color.Black
        Me.Line5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.RightColor = System.Drawing.Color.Black
        Me.Line5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.TopColor = System.Drawing.Color.Black
        Me.Line5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Height = 0.0!
        Me.Line5.Left = 0.1230315!
        Me.Line5.LineWeight = 1.0!
        Me.Line5.Name = "Line5"
        Me.Line5.Top = 4.576772!
        Me.Line5.Width = 7.997045!
        Me.Line5.X1 = 0.1230315!
        Me.Line5.X2 = 8.120076!
        Me.Line5.Y1 = 4.576772!
        Me.Line5.Y2 = 4.576772!
        '
        'Line6
        '
        Me.Line6.Border.BottomColor = System.Drawing.Color.Black
        Me.Line6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.LeftColor = System.Drawing.Color.Black
        Me.Line6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.RightColor = System.Drawing.Color.Black
        Me.Line6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.TopColor = System.Drawing.Color.Black
        Me.Line6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Height = 0.0!
        Me.Line6.Left = 0.1230315!
        Me.Line6.LineWeight = 1.0!
        Me.Line6.Name = "Line6"
        Me.Line6.Top = 4.896654!
        Me.Line6.Width = 7.997045!
        Me.Line6.X1 = 0.1230315!
        Me.Line6.X2 = 8.120076!
        Me.Line6.Y1 = 4.896654!
        Me.Line6.Y2 = 4.896654!
        '
        'Line7
        '
        Me.Line7.Border.BottomColor = System.Drawing.Color.Black
        Me.Line7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.LeftColor = System.Drawing.Color.Black
        Me.Line7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.RightColor = System.Drawing.Color.Black
        Me.Line7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.TopColor = System.Drawing.Color.Black
        Me.Line7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Height = 0.0!
        Me.Line7.Left = 0.1230315!
        Me.Line7.LineWeight = 1.0!
        Me.Line7.Name = "Line7"
        Me.Line7.Top = 5.191928!
        Me.Line7.Width = 7.997045!
        Me.Line7.X1 = 0.1230315!
        Me.Line7.X2 = 8.120076!
        Me.Line7.Y1 = 5.191928!
        Me.Line7.Y2 = 5.191928!
        '
        'Line8
        '
        Me.Line8.Border.BottomColor = System.Drawing.Color.Black
        Me.Line8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.LeftColor = System.Drawing.Color.Black
        Me.Line8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.RightColor = System.Drawing.Color.Black
        Me.Line8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.TopColor = System.Drawing.Color.Black
        Me.Line8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Height = 0.0!
        Me.Line8.Left = 0.1230315!
        Me.Line8.LineWeight = 1.0!
        Me.Line8.Name = "Line8"
        Me.Line8.Top = 5.536417!
        Me.Line8.Width = 7.997045!
        Me.Line8.X1 = 0.1230315!
        Me.Line8.X2 = 8.120076!
        Me.Line8.Y1 = 5.536417!
        Me.Line8.Y2 = 5.536417!
        '
        'Line9
        '
        Me.Line9.Border.BottomColor = System.Drawing.Color.Black
        Me.Line9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.LeftColor = System.Drawing.Color.Black
        Me.Line9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.RightColor = System.Drawing.Color.Black
        Me.Line9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.TopColor = System.Drawing.Color.Black
        Me.Line9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Height = 0.0!
        Me.Line9.Left = 0.1230315!
        Me.Line9.LineWeight = 1.0!
        Me.Line9.Name = "Line9"
        Me.Line9.Top = 6.348424!
        Me.Line9.Width = 7.997045!
        Me.Line9.X1 = 0.1230315!
        Me.Line9.X2 = 8.120076!
        Me.Line9.Y1 = 6.348424!
        Me.Line9.Y2 = 6.348424!
        '
        'Line10
        '
        Me.Line10.Border.BottomColor = System.Drawing.Color.Black
        Me.Line10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.LeftColor = System.Drawing.Color.Black
        Me.Line10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.RightColor = System.Drawing.Color.Black
        Me.Line10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.TopColor = System.Drawing.Color.Black
        Me.Line10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Height = 2.812993!
        Me.Line10.Left = 4.035433!
        Me.Line10.LineWeight = 1.0!
        Me.Line10.Name = "Line10"
        Me.Line10.Top = 6.348424!
        Me.Line10.Width = 0.0!
        Me.Line10.X1 = 4.035433!
        Me.Line10.X2 = 4.035433!
        Me.Line10.Y1 = 6.348424!
        Me.Line10.Y2 = 9.161417!
        '
        'Line11
        '
        Me.Line11.Border.BottomColor = System.Drawing.Color.Black
        Me.Line11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.LeftColor = System.Drawing.Color.Black
        Me.Line11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.RightColor = System.Drawing.Color.Black
        Me.Line11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.TopColor = System.Drawing.Color.Black
        Me.Line11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Height = 1.251969!
        Me.Line11.Left = 1.107283!
        Me.Line11.LineWeight = 1.0!
        Me.Line11.Name = "Line11"
        Me.Line11.Top = 4.283464!
        Me.Line11.Width = 0.0!
        Me.Line11.X1 = 1.107283!
        Me.Line11.X2 = 1.107283!
        Me.Line11.Y1 = 4.283464!
        Me.Line11.Y2 = 5.535433!
        '
        'Line12
        '
        Me.Line12.Border.BottomColor = System.Drawing.Color.Black
        Me.Line12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.LeftColor = System.Drawing.Color.Black
        Me.Line12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.RightColor = System.Drawing.Color.Black
        Me.Line12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.TopColor = System.Drawing.Color.Black
        Me.Line12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Height = 1.254921!
        Me.Line12.Left = 5.142717!
        Me.Line12.LineWeight = 1.0!
        Me.Line12.Name = "Line12"
        Me.Line12.Top = 4.281496!
        Me.Line12.Width = 0.0!
        Me.Line12.X1 = 5.142717!
        Me.Line12.X2 = 5.142717!
        Me.Line12.Y1 = 4.281496!
        Me.Line12.Y2 = 5.536417!
        '
        'txtcompany_Address
        '
        Me.txtcompany_Address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_Address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_Address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Address.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_Address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Address.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_Address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Address.DataField = "company_Address"
        Me.txtcompany_Address.Height = 0.1968504!
        Me.txtcompany_Address.Left = 0.09842521!
        Me.txtcompany_Address.Name = "txtcompany_Address"
        Me.txtcompany_Address.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtcompany_Address.Text = "company_Address"
        Me.txtcompany_Address.Top = 0.2839567!
        Me.txtcompany_Address.Visible = False
        Me.txtcompany_Address.Width = 1.033465!
        '
        'txtcompany_Province
        '
        Me.txtcompany_Province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_Province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_Province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Province.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_Province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Province.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_Province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Province.DataField = "company_Province"
        Me.txtcompany_Province.Height = 0.1968504!
        Me.txtcompany_Province.Left = 1.13189!
        Me.txtcompany_Province.Name = "txtcompany_Province"
        Me.txtcompany_Province.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtcompany_Province.Text = "company_Province"
        Me.txtcompany_Province.Top = 0.0!
        Me.txtcompany_Province.Visible = False
        Me.txtcompany_Province.Width = 1.033465!
        '
        'txtcompany_Country
        '
        Me.txtcompany_Country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_Country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_Country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Country.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_Country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Country.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_Country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Country.DataField = "company_Country"
        Me.txtcompany_Country.Height = 0.1968504!
        Me.txtcompany_Country.Left = 1.13189!
        Me.txtcompany_Country.Name = "txtcompany_Country"
        Me.txtcompany_Country.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtcompany_Country.Text = "company_Country"
        Me.txtcompany_Country.Top = 0.2706693!
        Me.txtcompany_Country.Visible = False
        Me.txtcompany_Country.Width = 1.033465!
        '
        'txtcompany_phone
        '
        Me.txtcompany_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.DataField = "company_phone"
        Me.txtcompany_phone.Height = 0.1968504!
        Me.txtcompany_phone.Left = 2.165354!
        Me.txtcompany_phone.Name = "txtcompany_phone"
        Me.txtcompany_phone.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtcompany_phone.Text = "company_phone"
        Me.txtcompany_phone.Top = 0.0!
        Me.txtcompany_phone.Visible = False
        Me.txtcompany_phone.Width = 1.033465!
        '
        'txtcompany_fax
        '
        Me.txtcompany_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.DataField = "company_fax"
        Me.txtcompany_fax.Height = 0.1968504!
        Me.txtcompany_fax.Left = 2.165354!
        Me.txtcompany_fax.Name = "txtcompany_fax"
        Me.txtcompany_fax.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtcompany_fax.Text = "company_fax"
        Me.txtcompany_fax.Top = 0.2706693!
        Me.txtcompany_fax.Visible = False
        Me.txtcompany_fax.Width = 1.033465!
        '
        'txtcompany_name
        '
        Me.txtcompany_name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.DataField = "company_name"
        Me.txtcompany_name.Height = 0.1968504!
        Me.txtcompany_name.Left = 3.223425!
        Me.txtcompany_name.Name = "txtcompany_name"
        Me.txtcompany_name.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtcompany_name.Text = "company_name"
        Me.txtcompany_name.Top = 0.0246063!
        Me.txtcompany_name.Visible = False
        Me.txtcompany_name.Width = 1.033465!
        '
        'txtcompany_Taxno
        '
        Me.txtcompany_Taxno.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_Taxno.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Taxno.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_Taxno.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Taxno.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_Taxno.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Taxno.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_Taxno.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_Taxno.DataField = "company_Taxno"
        Me.txtcompany_Taxno.Height = 0.3937009!
        Me.txtcompany_Taxno.Left = 1.550197!
        Me.txtcompany_Taxno.Name = "txtcompany_Taxno"
        Me.txtcompany_Taxno.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtcompany_Taxno.Text = "company_Taxno"
        Me.txtcompany_Taxno.Top = 3.641732!
        Me.txtcompany_Taxno.Width = 2.411417!
        '
        'txtinvoice_no1
        '
        Me.txtinvoice_no1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.DataField = "invoice_no1"
        Me.txtinvoice_no1.Height = 0.1968504!
        Me.txtinvoice_no1.Left = 3.223425!
        Me.txtinvoice_no1.Name = "txtinvoice_no1"
        Me.txtinvoice_no1.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtinvoice_no1.Text = "invoice_no1"
        Me.txtinvoice_no1.Top = 0.2839567!
        Me.txtinvoice_no1.Visible = False
        Me.txtinvoice_no1.Width = 1.033465!
        '
        'txtinvoice_no2
        '
        Me.txtinvoice_no2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.DataField = "invoice_no2"
        Me.txtinvoice_no2.Height = 0.1968504!
        Me.txtinvoice_no2.Left = 4.281496!
        Me.txtinvoice_no2.Name = "txtinvoice_no2"
        Me.txtinvoice_no2.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtinvoice_no2.Text = "invoice_no2"
        Me.txtinvoice_no2.Top = 0.0!
        Me.txtinvoice_no2.Visible = False
        Me.txtinvoice_no2.Width = 1.033465!
        '
        'txtinvoice_no3
        '
        Me.txtinvoice_no3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.DataField = "invoice_no3"
        Me.txtinvoice_no3.Height = 0.1968504!
        Me.txtinvoice_no3.Left = 4.281496!
        Me.txtinvoice_no3.Name = "txtinvoice_no3"
        Me.txtinvoice_no3.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtinvoice_no3.Text = "invoice_no3"
        Me.txtinvoice_no3.Top = 0.2706693!
        Me.txtinvoice_no3.Visible = False
        Me.txtinvoice_no3.Width = 1.033465!
        '
        'txtinvoice_no4
        '
        Me.txtinvoice_no4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.DataField = "invoice_no4"
        Me.txtinvoice_no4.Height = 0.1968504!
        Me.txtinvoice_no4.Left = 5.314961!
        Me.txtinvoice_no4.Name = "txtinvoice_no4"
        Me.txtinvoice_no4.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtinvoice_no4.Text = "invoice_no4"
        Me.txtinvoice_no4.Top = 0.0!
        Me.txtinvoice_no4.Visible = False
        Me.txtinvoice_no4.Width = 1.033465!
        '
        'txtinvoice_no5
        '
        Me.txtinvoice_no5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.DataField = "invoice_no5"
        Me.txtinvoice_no5.Height = 0.1968504!
        Me.txtinvoice_no5.Left = 5.314961!
        Me.txtinvoice_no5.Name = "txtinvoice_no5"
        Me.txtinvoice_no5.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtinvoice_no5.Text = "invoice_no5"
        Me.txtinvoice_no5.Top = 0.2706693!
        Me.txtinvoice_no5.Visible = False
        Me.txtinvoice_no5.Width = 1.033465!
        '
        'txtTemp_invoice
        '
        Me.txtTemp_invoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_invoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_invoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_invoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_invoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_invoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_invoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_invoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_invoice.Height = 0.3937009!
        Me.txtTemp_invoice.Left = 4.872047!
        Me.txtTemp_invoice.Name = "txtTemp_invoice"
        Me.txtTemp_invoice.Style = "ddo-char-set: 222; font-weight: normal; font-size: 12pt; font-family: BrowalliaUP" & _
            "C; vertical-align: middle; "
        Me.txtTemp_invoice.Text = Nothing
        Me.txtTemp_invoice.Top = 3.937008!
        Me.txtTemp_invoice.Width = 3.248032!
        '
        'txtdestination_address
        '
        Me.txtdestination_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.DataField = "destination_address"
        Me.txtdestination_address.Height = 0.1968504!
        Me.txtdestination_address.Left = 3.223425!
        Me.txtdestination_address.Name = "txtdestination_address"
        Me.txtdestination_address.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtdestination_address.Text = "destination_address"
        Me.txtdestination_address.Top = 0.5433071!
        Me.txtdestination_address.Visible = False
        Me.txtdestination_address.Width = 1.033465!
        '
        'txtdestination_province
        '
        Me.txtdestination_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.DataField = "destination_province"
        Me.txtdestination_province.Height = 0.1968504!
        Me.txtdestination_province.Left = 3.223425!
        Me.txtdestination_province.Name = "txtdestination_province"
        Me.txtdestination_province.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtdestination_province.Text = "destination_province"
        Me.txtdestination_province.Top = 0.8026577!
        Me.txtdestination_province.Visible = False
        Me.txtdestination_province.Width = 1.033465!
        '
        'txtdest_receive_country
        '
        Me.txtdest_receive_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_receive_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_receive_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_receive_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_receive_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_receive_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_receive_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_receive_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_receive_country.DataField = "dest_receive_country"
        Me.txtdest_receive_country.Height = 0.1968504!
        Me.txtdest_receive_country.Left = 3.223425!
        Me.txtdest_receive_country.Name = "txtdest_receive_country"
        Me.txtdest_receive_country.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtdest_receive_country.Text = "dest_receive_country"
        Me.txtdest_receive_country.Top = 1.062008!
        Me.txtdest_receive_country.Visible = False
        Me.txtdest_receive_country.Width = 1.033465!
        '
        'txtrequest_person
        '
        Me.txtrequest_person.Border.BottomColor = System.Drawing.Color.Black
        Me.txtrequest_person.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person.Border.LeftColor = System.Drawing.Color.Black
        Me.txtrequest_person.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person.Border.RightColor = System.Drawing.Color.Black
        Me.txtrequest_person.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person.Border.TopColor = System.Drawing.Color.Black
        Me.txtrequest_person.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtrequest_person.DataField = "request_person"
        Me.txtrequest_person.Height = 0.1968504!
        Me.txtrequest_person.Left = 6.397638!
        Me.txtrequest_person.Name = "txtrequest_person"
        Me.txtrequest_person.Style = "color: Red; ddo-char-set: 222; text-align: center; font-weight: bold; font-size: " & _
            "12pt; font-family: BrowalliaUPC; vertical-align: top; "
        Me.txtrequest_person.Text = "request_person"
        Me.txtrequest_person.Top = 0.0!
        Me.txtrequest_person.Visible = False
        Me.txtrequest_person.Width = 1.033465!
        '
        'txtTemp_request_person2
        '
        Me.txtTemp_request_person2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_request_person2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_request_person2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_request_person2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_request_person2.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_request_person2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_request_person2.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_request_person2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_request_person2.Height = 0.3937005!
        Me.txtTemp_request_person2.Left = 4.945866!
        Me.txtTemp_request_person2.Name = "txtTemp_request_person2"
        Me.txtTemp_request_person2.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.txtTemp_request_person2.Text = Nothing
        Me.txtTemp_request_person2.Top = 10.5315!
        Me.txtTemp_request_person2.Width = 2.928149!
        '
        'TextBox36
        '
        Me.TextBox36.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox36.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox36.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox36.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox36.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox36.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox36.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox36.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox36.Height = 0.3937007!
        Me.TextBox36.Left = 5.265748!
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox36.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox36.Top = 0.5659449!
        Me.TextBox36.Width = 2.878937!
        '
        'TextBox37
        '
        Me.TextBox37.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox37.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox37.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox37.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox37.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox37.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox37.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox37.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox37.Height = 0.3937007!
        Me.TextBox37.Left = 5.265748!
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox37.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox37.Top = 0.8366139!
        Me.TextBox37.Width = 2.878937!
        '
        'TextBox40
        '
        Me.TextBox40.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox40.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox40.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox40.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox40.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox40.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox40.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox40.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox40.Height = 0.3937008!
        Me.TextBox40.Left = 0.6151575!
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox40.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox40.Top = 1.476378!
        Me.TextBox40.Width = 3.346457!
        '
        'TextBox41
        '
        Me.TextBox41.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox41.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox41.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox41.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox41.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox41.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox41.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox41.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox41.Height = 0.3937007!
        Me.TextBox41.Left = 0.6151575!
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox41.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox41.Top = 1.771653!
        Me.TextBox41.Width = 3.346457!
        '
        'TextBox42
        '
        Me.TextBox42.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox42.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox42.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox42.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox42.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox42.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox42.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox42.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox42.Height = 0.3937007!
        Me.TextBox42.Left = 0.6151575!
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox42.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox42.Top = 2.091535!
        Me.TextBox42.Width = 3.321851!
        '
        'TextBox43
        '
        Me.TextBox43.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox43.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox43.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox43.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox43.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox43.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox43.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox43.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox43.Height = 0.3937008!
        Me.TextBox43.Left = 0.6151575!
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox43.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox43.Top = 2.288386!
        Me.TextBox43.Width = 3.321851!
        '
        'TextBox44
        '
        Me.TextBox44.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox44.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox44.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox44.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox44.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox44.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox44.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox44.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox44.Height = 0.3937008!
        Me.TextBox44.Left = 4.06004!
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox44.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _" & _
            " _ _"
        Me.TextBox44.Top = 1.476378!
        Me.TextBox44.Width = 4.035433!
        '
        'TextBox56
        '
        Me.TextBox56.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox56.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox56.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox56.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox56.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox56.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox56.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox56.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox56.Height = 0.3937007!
        Me.TextBox56.Left = 4.52756!
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox56.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox56.Top = 2.091535!
        Me.TextBox56.Width = 3.567913!
        '
        'TextBox58
        '
        Me.TextBox58.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox58.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox58.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox58.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox58.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox58.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox58.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox58.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox58.Height = 0.3937008!
        Me.TextBox58.Left = 4.52756!
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox58.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox58.Top = 2.288386!
        Me.TextBox58.Width = 3.567913!
        '
        'TextBox59
        '
        Me.TextBox59.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox59.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox59.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox59.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox59.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox59.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox59.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox59.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox59.Height = 0.3937007!
        Me.TextBox59.Left = 0.9104334!
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox59.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox59.Top = 2.706693!
        Me.TextBox59.Width = 3.100394!
        '
        'TextBox60
        '
        Me.TextBox60.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox60.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox60.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox60.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox60.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox60.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox60.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox60.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox60.Height = 0.3937007!
        Me.TextBox60.Left = 0.9104334!
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox60.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox60.Top = 2.977362!
        Me.TextBox60.Width = 3.100394!
        '
        'TextBox61
        '
        Me.TextBox61.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox61.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox61.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox61.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox61.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox61.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox61.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox61.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox61.Height = 0.3937008!
        Me.TextBox61.Left = 0.9104334!
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox61.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox61.Top = 3.321851!
        Me.TextBox61.Width = 3.100394!
        '
        'TextBox63
        '
        Me.TextBox63.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox63.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox63.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox63.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox63.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox63.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox63.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox63.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox63.Height = 0.3937007!
        Me.TextBox63.Left = 4.822834!
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox63.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox63.Top = 2.706693!
        Me.TextBox63.Width = 3.248032!
        '
        'TextBox64
        '
        Me.TextBox64.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox64.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox64.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox64.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox64.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox64.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox64.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox64.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox64.Height = 0.3937009!
        Me.TextBox64.Left = 4.822834!
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox64.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox64.Top = 3.026575!
        Me.TextBox64.Width = 3.248032!
        '
        'TextBox66
        '
        Me.TextBox66.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox66.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox66.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox66.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox66.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox66.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox66.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox66.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox66.Height = 0.3937008!
        Me.TextBox66.Left = 4.822834!
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Style = "ddo-char-set: 222; font-weight: bold; font-size: 12pt; font-family: BrowalliaUPC;" & _
            " vertical-align: middle; "
        Me.TextBox66.Text = "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
        Me.TextBox66.Top = 3.321851!
        Me.TextBox66.Width = 3.248032!
        '
        'PageFooter1
        '
        Me.PageFooter1.Height = 0.0!
        Me.PageFooter1.Name = "PageFooter1"
        '
        'TextBox35
        '
        Me.TextBox35.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox35.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox35.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox35.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox35.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox35.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox35.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox35.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox35.Height = 0.3937007!
        Me.TextBox35.Left = 3.223425!
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 24pt; font-f" & _
            "amily: BrowalliaUPC; vertical-align: middle; "
        Me.TextBox35.Text = "COPY"
        Me.TextBox35.Top = 0.2839567!
        Me.TextBox35.Width = 0.7874014!
        '
        'rpt3_ReEdi_FormST6_2
        '
        Me.MasterReport = False
        Me.PageSettings.Margins.Bottom = 0.0!
        Me.PageSettings.Margins.Left = 0.0!
        Me.PageSettings.Margins.Right = 0.0!
        Me.PageSettings.Margins.Top = 0.0!
        Me.PageSettings.PaperHeight = 11.69!
        Me.PageSettings.PaperWidth = 8.27!
        Me.PrintWidth = 8.267715!
        Me.Sections.Add(Me.PageHeader1)
        Me.Sections.Add(Me.Detail1)
        Me.Sections.Add(Me.PageFooter1)
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Arial; font-style: normal; text-decoration: none; font-weight: norma" & _
                    "l; font-size: 10pt; color: Black; ", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 16pt; font-weight: bold; ", "Heading1", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Times New Roman; font-size: 14pt; font-weight: bold; font-style: ita" & _
                    "lic; ", "Heading2", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 13pt; font-weight: bold; ", "Heading3", "Normal"))
        CType(Me.txtREFERENCE_CODE2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_REFERENCE_CODE2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSent_date, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcard_id, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_nameth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_nameeng, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_request_person1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_address1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_company_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_company_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_company_phone1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_company_fax1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtimport_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCAT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtI_Unit_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotal_Net_weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtQuantity5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtedi_date, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_dest, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox79, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox80, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox81, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox89, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox90, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox91, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox98, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox101, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox102, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox103, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox104, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox105, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox106, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox107, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox108, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox109, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox110, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox111, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_Address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_Province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_Country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_Taxno, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_invoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_receive_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtrequest_person, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_request_person2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox60, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox61, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Friend WithEvents Detail1 As DataDynamics.ActiveReports.Detail
    Friend WithEvents PageHeader1 As DataDynamics.ActiveReports.PageHeader
    Friend WithEvents txtREFERENCE_CODE2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Shape1 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape2 As DataDynamics.ActiveReports.Shape
    Friend WithEvents TextBox4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Shape3 As DataDynamics.ActiveReports.Shape
    Friend WithEvents TextBox5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox6 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox7 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_REFERENCE_CODE2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtSent_date As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox9 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox10 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox12 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox11 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox13 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox14 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcard_id As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox15 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox16 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox17 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox18 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox19 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox20 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox21 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox22 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox23 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox24 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox25 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox26 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox27 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox28 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox30 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_nameth As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_nameeng As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_request_person1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_address1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox62 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_company_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_company_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox65 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_company_phone1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_company_fax1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox68 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtimport_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtCAT As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtI_Unit_code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTotal_Net_weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtQuantity5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtedi_date As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox29 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_company As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_dest As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox31 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox33 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox78 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox79 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox80 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox81 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox82 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox83 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox84 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox85 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox86 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox87 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox88 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox89 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox90 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox91 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox92 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox93 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox94 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox39 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox95 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox96 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox97 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox98 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox99 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox100 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox101 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox102 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox103 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox104 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox105 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox106 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox107 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox108 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox109 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox110 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox111 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox38 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox32 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox45 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox34 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox46 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox47 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox48 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox49 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox50 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox51 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox52 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox53 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox54 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox55 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox57 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line1 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line2 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line3 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line4 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line5 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line6 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line7 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line8 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line9 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line10 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line11 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line12 As DataDynamics.ActiveReports.Line
    Friend WithEvents txtcompany_Address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_Province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_Country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_Taxno As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_invoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_receive_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtrequest_person As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_request_person2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox36 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox37 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox40 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox41 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox42 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox43 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox44 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox56 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox58 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox59 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox60 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox61 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox63 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox64 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox66 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents PageFooter1 As DataDynamics.ActiveReports.PageFooter
    Friend WithEvents TextBox35 As DataDynamics.ActiveReports.TextBox
End Class
