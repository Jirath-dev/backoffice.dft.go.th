Imports DataDynamics.ActiveReports 
Imports DataDynamics.ActiveReports.Document 
Imports Microsoft.ApplicationBlocks.Data
Imports System.Data.SqlClient
Imports System.Data
Imports System.Text
Imports DFT.Dotnetnuke.ClassLibrary
Imports ReportPrintClass
Public Class rpt3_ReEdi_FormST6_1 

    Private Sub PageHeader1_Format(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PageHeader1.Format
        txtTemp_REFERENCE_CODE2.Text = "I" & txtREFERENCE_CODE2.Value

        txtcompany_nameth.Text = txtcompany_name.Value
        txtcompany_nameeng.Text = txtcompany_name.Value

        txtTemp_address.Text = txtcompany_Address.Value & " " & txtcompany_Province.Value & " " & txtcompany_Country.Value
        txtTemp_address1.Text = txtcompany_Address.Value & " " & txtcompany_Province.Value & " " & txtcompany_Country.Value

        txtTemp_company_phone.Text = txtcompany_phone.Value
        txtTemp_company_phone1.Text = txtcompany_phone.Value

        txtTemp_company_fax.Text = txtcompany_fax.Value
        txtTemp_company_fax1.Text = txtcompany_fax.Value

        txtTemp_invoice.Text = IIf(txtinvoice_no1.Value <> "", txtinvoice_no1.Value, "") & _
                IIf(txtinvoice_no2.Value <> "", " " & txtinvoice_no2.Value, "") & _
                IIf(txtinvoice_no3.Value <> "", " " & txtinvoice_no3.Value, "") & _
                IIf(txtinvoice_no4.Value <> "", " " & txtinvoice_no4.Value, "") & _
                IIf(txtinvoice_no5.Value <> "", " " & txtinvoice_no5.Value, "")

        txtTemp_dest.Text = txtdestination_address.Value & " " & txtdestination_province.Value & " " & txtdest_receive_country.Value

        txtTemp_request_person1.Text = txtrequest_person.Value
        txtTemp_request_person2.Text = txtrequest_person.Value

        Q1Q5()
    End Sub

    Sub Q1Q5()
        'check �����ʴ���� Q1(USD) ���� Q5(����� USD)
        Select Case txtcurrency_code.Text
            Case "USD"
                txtTemp_Q1Q5.Text = Format(txtQuantity1.Value, "#,##0.00##")
            Case Else
                txtTemp_Q1Q5.Text = Format(txtQuantity5.Value, "#,##0.00##")
        End Select
    End Sub
    
    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

End Class
