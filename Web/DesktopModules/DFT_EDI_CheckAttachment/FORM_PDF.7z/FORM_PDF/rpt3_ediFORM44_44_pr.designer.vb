<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class rpt3_ediFORM44_44_pr
    Inherits DataDynamics.ActiveReports.ActiveReport3

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
        End If
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the ActiveReports Designer
    'It can be modified using the ActiveReports Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(rpt3_ediFORM44_44_pr))
        Me.Detail1 = New DataDynamics.ActiveReports.Detail()
        Me.txtNumRowCount = New DataDynamics.ActiveReports.TextBox()
        Me.txtTemp_marks = New DataDynamics.ActiveReports.TextBox()
        Me.txtT_product = New DataDynamics.ActiveReports.TextBox()
        Me.txtTemp_box8 = New DataDynamics.ActiveReports.TextBox()
        Me.txtTolInvoice = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtGross_Weight = New DataDynamics.ActiveReports.TextBox()
        Me.txtmarks = New DataDynamics.ActiveReports.TextBox()
        Me.txtproduct_n1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtproduct_n2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtg_unit_code = New DataDynamics.ActiveReports.TextBox()
        Me.C_TotalRowDe = New DataDynamics.ActiveReports.TextBox()
        Me.txttariff_code = New DataDynamics.ActiveReports.TextBox()
        Me.txtGrossTxt = New DataDynamics.ActiveReports.TextBox()
        Me.txtg_Unit_Desc = New DataDynamics.ActiveReports.TextBox()
        Me.txtFOB_AMT = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_board = New DataDynamics.ActiveReports.TextBox()
        Me.txtWeightDisplayHeader = New DataDynamics.ActiveReports.TextBox()
        Me.txtFOBDisplay = New DataDynamics.ActiveReports.TextBox()
        Me.txtunit_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtnet_weight = New DataDynamics.ActiveReports.TextBox()
        Me.txtgross_weightH = New DataDynamics.ActiveReports.TextBox()
        Me.txtGrossTxt_ = New DataDynamics.ActiveReports.TextBox()
        Me.txtthird_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtplace_exibition = New DataDynamics.ActiveReports.TextBox()
        Me.txtNumInvoice = New DataDynamics.ActiveReports.TextBox()
        Me.txtUSDInvoice = New DataDynamics.ActiveReports.TextBox()
        Me.txtbox8 = New DataDynamics.ActiveReports.TextBox()
        Me.txtunit_code3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtUSDInvoiceDetail = New DataDynamics.ActiveReports.TextBox()
        Me.txtWeightDisplayHeaderH = New DataDynamics.ActiveReports.TextBox()
        Me.txtgross_weightD = New DataDynamics.ActiveReports.TextBox()
        Me.txtCheckGrossDetail = New DataDynamics.ActiveReports.TextBox()
        Me.txtInvoiceDetailTH = New DataDynamics.ActiveReports.TextBox()
        Me.txtSINGLE_COUNTRY_CONTENT = New DataDynamics.ActiveReports.TextBox()
        Me.txt_NewEmail_ch02 = New DataDynamics.ActiveReports.TextBox()
        Me.txtproduct_model = New DataDynamics.ActiveReports.TextBox()
        Me.txtvoince = New DataDynamics.ActiveReports.TextBox()
        Me.txtTitleMain = New DataDynamics.ActiveReports.TextBox()
        Me.txtPriceOtherDetail = New DataDynamics.ActiveReports.TextBox()
        Me.txtCurrency_Code = New DataDynamics.ActiveReports.TextBox()
        Me.txtletter = New DataDynamics.ActiveReports.TextBox()
        Me.txtAttUSDTotal = New DataDynamics.ActiveReports.TextBox()
        Me.txtAttThirdUSDTotal = New DataDynamics.ActiveReports.TextBox()
        Me.txtUSDAgent = New DataDynamics.ActiveReports.TextBox()
        Me.PageHeader1 = New DataDynamics.ActiveReports.PageHeader()
        Me.txtCompany_Check_1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtreference_code2_Temp = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_Check2 = New DataDynamics.ActiveReports.TextBox()
        Me.txttransport_by = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_taxno = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_province = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_name = New DataDynamics.ActiveReports.TextBox()
        Me.txtob_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_remark = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_fax = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_phone = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_company = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_fax = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_phone = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_province = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_Receive_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtreference_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_email = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_email = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_taxid = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_remark1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtob_dest_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtdeparture_date = New DataDynamics.ActiveReports.TextBox()
        Me.txtvasel_name = New DataDynamics.ActiveReports.TextBox()
        Me.txtport_discharge = New DataDynamics.ActiveReports.TextBox()
        Me.ReportInfo1 = New DataDynamics.ActiveReports.ReportInfo()
        Me.txtform_type = New DataDynamics.ActiveReports.TextBox()
        Me.txtNewEmail_ch02 = New DataDynamics.ActiveReports.TextBox()
        Me.txtNewEmail_ch01 = New DataDynamics.ActiveReports.TextBox()
        Me.txtTitleHead = New DataDynamics.ActiveReports.TextBox()
        Me.Line9 = New DataDynamics.ActiveReports.Line()
        Me.Line8 = New DataDynamics.ActiveReports.Line()
        Me.Line13 = New DataDynamics.ActiveReports.Line()
        Me.Line14 = New DataDynamics.ActiveReports.Line()
        Me.Line12 = New DataDynamics.ActiveReports.Line()
        Me.Line3 = New DataDynamics.ActiveReports.Line()
        Me.Label42 = New DataDynamics.ActiveReports.Label()
        Me.Label43 = New DataDynamics.ActiveReports.Label()
        Me.Label44 = New DataDynamics.ActiveReports.Label()
        Me.Line11 = New DataDynamics.ActiveReports.Line()
        Me.Label3 = New DataDynamics.ActiveReports.Label()
        Me.Label2 = New DataDynamics.ActiveReports.Label()
        Me.Label5 = New DataDynamics.ActiveReports.Label()
        Me.Label4 = New DataDynamics.ActiveReports.Label()
        Me.Label1 = New DataDynamics.ActiveReports.Label()
        Me.Label8 = New DataDynamics.ActiveReports.Label()
        Me.Label7 = New DataDynamics.ActiveReports.Label()
        Me.Label16 = New DataDynamics.ActiveReports.Label()
        Me.Label21 = New DataDynamics.ActiveReports.Label()
        Me.Label17 = New DataDynamics.ActiveReports.Label()
        Me.Label22 = New DataDynamics.ActiveReports.Label()
        Me.Line19 = New DataDynamics.ActiveReports.Line()
        Me.Label19 = New DataDynamics.ActiveReports.Label()
        Me.Label6 = New DataDynamics.ActiveReports.Label()
        Me.Shape1 = New DataDynamics.ActiveReports.Shape()
        Me.Label29 = New DataDynamics.ActiveReports.Label()
        Me.Label31 = New DataDynamics.ActiveReports.Label()
        Me.Label30 = New DataDynamics.ActiveReports.Label()
        Me.Shape2 = New DataDynamics.ActiveReports.Shape()
        Me.Shape3 = New DataDynamics.ActiveReports.Shape()
        Me.Label33 = New DataDynamics.ActiveReports.Label()
        Me.Label48 = New DataDynamics.ActiveReports.Label()
        Me.Label47 = New DataDynamics.ActiveReports.Label()
        Me.Label46 = New DataDynamics.ActiveReports.Label()
        Me.Line10 = New DataDynamics.ActiveReports.Line()
        Me.PageFooter1 = New DataDynamics.ActiveReports.PageFooter()
        Me.Pic_ch5_exhibi = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch7_Issued = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch6_demin = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch4_par = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch3_back = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch1_third = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch2_accu = New DataDynamics.ActiveReports.Picture()
        Me.txtTemp_back_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtIMPORT_COUNTRY = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_provincefoot1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_provincefoot = New DataDynamics.ActiveReports.TextBox()
        Me.txtshow_check = New DataDynamics.ActiveReports.TextBox()
        Me.txtback_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvh_run_auto = New DataDynamics.ActiveReports.TextBox()
        Me.txtCheckIssued = New DataDynamics.ActiveReports.TextBox()
        Me.txttotalSum_fob_amt = New DataDynamics.ActiveReports.TextBox()
        Me.Line27 = New DataDynamics.ActiveReports.Line()
        Me.Line2 = New DataDynamics.ActiveReports.Line()
        Me.Line20 = New DataDynamics.ActiveReports.Line()
        Me.Label25 = New DataDynamics.ActiveReports.Label()
        Me.Line25 = New DataDynamics.ActiveReports.Line()
        Me.Line1 = New DataDynamics.ActiveReports.Line()
        Me.Line6 = New DataDynamics.ActiveReports.Line()
        Me.Line26 = New DataDynamics.ActiveReports.Line()
        Me.Label23 = New DataDynamics.ActiveReports.Label()
        Me.Label24 = New DataDynamics.ActiveReports.Label()
        Me.Label10 = New DataDynamics.ActiveReports.Label()
        Me.Label11 = New DataDynamics.ActiveReports.Label()
        Me.Label26 = New DataDynamics.ActiveReports.Label()
        Me.Label12 = New DataDynamics.ActiveReports.Label()
        Me.Line16 = New DataDynamics.ActiveReports.Line()
        Me.Label13 = New DataDynamics.ActiveReports.Label()
        Me.Label28 = New DataDynamics.ActiveReports.Label()
        Me.Label14 = New DataDynamics.ActiveReports.Label()
        Me.Line17 = New DataDynamics.ActiveReports.Line()
        Me.Label9 = New DataDynamics.ActiveReports.Label()
        Me.Shape11 = New DataDynamics.ActiveReports.Shape()
        Me.Shape12 = New DataDynamics.ActiveReports.Shape()
        Me.Shape13 = New DataDynamics.ActiveReports.Shape()
        Me.Shape14 = New DataDynamics.ActiveReports.Shape()
        Me.Label52 = New DataDynamics.ActiveReports.Label()
        Me.Label53 = New DataDynamics.ActiveReports.Label()
        Me.Label54 = New DataDynamics.ActiveReports.Label()
        Me.Label55 = New DataDynamics.ActiveReports.Label()
        Me.Shape9 = New DataDynamics.ActiveReports.Shape()
        Me.Shape8 = New DataDynamics.ActiveReports.Shape()
        Me.Shape15 = New DataDynamics.ActiveReports.Shape()
        Me.Label51 = New DataDynamics.ActiveReports.Label()
        Me.Label50 = New DataDynamics.ActiveReports.Label()
        Me.Label49 = New DataDynamics.ActiveReports.Label()
        Me.txtCheck_CaseRVCCount = New DataDynamics.ActiveReports.TextBox()
        Me.txtDisplayUDS7 = New DataDynamics.ActiveReports.TextBox()
        Me.txtInvAgentType = New DataDynamics.ActiveReports.TextBox()
        Me.GroupHeader1 = New DataDynamics.ActiveReports.GroupHeader()
        Me.GroupFooter1 = New DataDynamics.ActiveReports.GroupFooter()
        Me.txtTotalAll = New DataDynamics.ActiveReports.TextBox()
        Me.Label15 = New DataDynamics.ActiveReports.Label()
        CType(Me.txtNumRowCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_marks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtT_product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_box8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTolInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGross_Weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtmarks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_n1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_n2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtg_unit_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttariff_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrossTxt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtg_Unit_Desc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOB_AMT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_board, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtWeightDisplayHeader, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOBDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtnet_weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgross_weightH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrossTxt_, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtthird_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtplace_exibition, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNumInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUSDInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtunit_code3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUSDInvoiceDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtWeightDisplayHeaderH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgross_weightD, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCheckGrossDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInvoiceDetailTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSINGLE_COUNTRY_CONTENT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt_NewEmail_ch02, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_model, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtvoince, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTitleMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOtherDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCurrency_Code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtletter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttUSDTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttThirdUSDTotal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUSDAgent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompany_Check_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtreference_code2_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_Check2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttransport_by, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtob_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_remark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_Receive_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtreference_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_email, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_email, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_taxid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_remark1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtob_dest_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdeparture_date, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtvasel_name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtport_discharge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReportInfo1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtform_type, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNewEmail_ch02, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNewEmail_ch01, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTitleHead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch5_exhibi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch7_Issued, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch6_demin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch4_par, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch3_back, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch1_third, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch2_accu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_back_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtIMPORT_COUNTRY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_provincefoot1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_provincefoot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtshow_check, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtback_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCheckIssued, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttotalSum_fob_amt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCheck_CaseRVCCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDisplayUDS7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInvAgentType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotalAll, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'Detail1
        '
        Me.Detail1.ColumnSpacing = 0!
        Me.Detail1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtNumRowCount, Me.txtTemp_marks, Me.txtT_product, Me.txtTemp_box8, Me.txtTolInvoice, Me.txtinvoice_no1, Me.txtinvoice_no2, Me.txtinvoice_no3, Me.txtinvoice_no4, Me.txtinvoice_no5, Me.txtinvoice_date1, Me.txtinvoice_date2, Me.txtinvoice_date3, Me.txtinvoice_date4, Me.txtinvoice_date5, Me.txtGross_Weight, Me.txtmarks, Me.txtproduct_n1, Me.txtproduct_n2, Me.txtquantity1, Me.txtq_unit_code1, Me.txtquantity2, Me.txtq_unit_code2, Me.txtquantity3, Me.txtq_unit_code3, Me.txtquantity4, Me.txtq_unit_code4, Me.txtquantity5, Me.txtq_unit_code5, Me.txtg_unit_code, Me.C_TotalRowDe, Me.txttariff_code, Me.txtGrossTxt, Me.txtg_Unit_Desc, Me.txtFOB_AMT, Me.txtinvoice_board, Me.txtWeightDisplayHeader, Me.txtFOBDisplay, Me.txtunit_code2, Me.txtnet_weight, Me.txtgross_weightH, Me.txtGrossTxt_, Me.txtthird_country, Me.txtplace_exibition, Me.txtNumInvoice, Me.txtUSDInvoice, Me.txtbox8, Me.txtunit_code3, Me.txtUSDInvoiceDetail, Me.txtWeightDisplayHeaderH, Me.txtgross_weightD, Me.txtCheckGrossDetail, Me.txtInvoiceDetailTH, Me.txtSINGLE_COUNTRY_CONTENT, Me.txt_NewEmail_ch02, Me.txtproduct_model, Me.txtvoince, Me.txtTitleMain, Me.txtPriceOtherDetail, Me.txtCurrency_Code, Me.txtletter, Me.txtAttUSDTotal, Me.txtAttThirdUSDTotal, Me.txtUSDAgent})
        Me.Detail1.Height = 0.311!
        Me.Detail1.Name = "Detail1"
        '
        'txtNumRowCount
        '
        Me.txtNumRowCount.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.RightColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.TopColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Height = 0.2204724!
        Me.txtNumRowCount.Left = 0.25!
        Me.txtNumRowCount.Name = "txtNumRowCount"
        Me.txtNumRowCount.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtNumRowCount.Text = Nothing
        Me.txtNumRowCount.Top = 0!
        Me.txtNumRowCount.Width = 0.3937007!
        '
        'txtTemp_marks
        '
        Me.txtTemp_marks.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Height = 0.2214567!
        Me.txtTemp_marks.Left = 0.8858268!
        Me.txtTemp_marks.Name = "txtTemp_marks"
        Me.txtTemp_marks.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtTemp_marks.Text = Nothing
        Me.txtTemp_marks.Top = 0!
        Me.txtTemp_marks.Visible = False
        Me.txtTemp_marks.Width = 0.9448819!
        '
        'txtT_product
        '
        Me.txtT_product.Border.BottomColor = System.Drawing.Color.Black
        Me.txtT_product.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.LeftColor = System.Drawing.Color.Black
        Me.txtT_product.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.RightColor = System.Drawing.Color.Black
        Me.txtT_product.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.TopColor = System.Drawing.Color.Black
        Me.txtT_product.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Height = 0.3125!
        Me.txtT_product.Left = 1.875!
        Me.txtT_product.Name = "txtT_product"
        Me.txtT_product.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtT_product.Text = Nothing
        Me.txtT_product.Top = 0!
        Me.txtT_product.Width = 3.5!
        '
        'txtTemp_box8
        '
        Me.txtTemp_box8.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Height = 0.2214567!
        Me.txtTemp_box8.Left = 5.38878!
        Me.txtTemp_box8.Name = "txtTemp_box8"
        Me.txtTemp_box8.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtTemp_box8.Text = Nothing
        Me.txtTemp_box8.Top = 0!
        Me.txtTemp_box8.Width = 0.5943241!
        '
        'txtTolInvoice
        '
        Me.txtTolInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Height = 0.2214567!
        Me.txtTolInvoice.Left = 5.0625!
        Me.txtTolInvoice.Name = "txtTolInvoice"
        Me.txtTolInvoice.Style = "ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: BrowalliaUPC; " &
    ""
        Me.txtTolInvoice.Text = Nothing
        Me.txtTolInvoice.Top = 0.625!
        Me.txtTolInvoice.Visible = False
        Me.txtTolInvoice.Width = 0.9448819!
        '
        'txtinvoice_no1
        '
        Me.txtinvoice_no1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.DataField = "invoice_no1"
        Me.txtinvoice_no1.Height = 0.1979167!
        Me.txtinvoice_no1.Left = 0!
        Me.txtinvoice_no1.Name = "txtinvoice_no1"
        Me.txtinvoice_no1.Style = "color: Red; "
        Me.txtinvoice_no1.Text = "invoice_no1"
        Me.txtinvoice_no1.Top = 0.6889763!
        Me.txtinvoice_no1.Visible = False
        Me.txtinvoice_no1.Width = 1.0!
        '
        'txtinvoice_no2
        '
        Me.txtinvoice_no2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.DataField = "invoice_no2"
        Me.txtinvoice_no2.Height = 0.1979167!
        Me.txtinvoice_no2.Left = 1.008858!
        Me.txtinvoice_no2.Name = "txtinvoice_no2"
        Me.txtinvoice_no2.Style = "color: Red; "
        Me.txtinvoice_no2.Text = "invoice_no2"
        Me.txtinvoice_no2.Top = 0.6889763!
        Me.txtinvoice_no2.Visible = False
        Me.txtinvoice_no2.Width = 1.0!
        '
        'txtinvoice_no3
        '
        Me.txtinvoice_no3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.DataField = "invoice_no3"
        Me.txtinvoice_no3.Height = 0.1979167!
        Me.txtinvoice_no3.Left = 2.017717!
        Me.txtinvoice_no3.Name = "txtinvoice_no3"
        Me.txtinvoice_no3.Style = "color: Red; "
        Me.txtinvoice_no3.Text = "invoice_no3"
        Me.txtinvoice_no3.Top = 0.6889763!
        Me.txtinvoice_no3.Visible = False
        Me.txtinvoice_no3.Width = 1.0!
        '
        'txtinvoice_no4
        '
        Me.txtinvoice_no4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.DataField = "invoice_no4"
        Me.txtinvoice_no4.Height = 0.1979167!
        Me.txtinvoice_no4.Left = 3.026575!
        Me.txtinvoice_no4.Name = "txtinvoice_no4"
        Me.txtinvoice_no4.Style = "color: Red; "
        Me.txtinvoice_no4.Text = "invoice_no4"
        Me.txtinvoice_no4.Top = 0.6889763!
        Me.txtinvoice_no4.Visible = False
        Me.txtinvoice_no4.Width = 1.0!
        '
        'txtinvoice_no5
        '
        Me.txtinvoice_no5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.DataField = "invoice_no5"
        Me.txtinvoice_no5.Height = 0.1979167!
        Me.txtinvoice_no5.Left = 4.035433!
        Me.txtinvoice_no5.Name = "txtinvoice_no5"
        Me.txtinvoice_no5.Style = "color: Red; "
        Me.txtinvoice_no5.Text = "invoice_no5"
        Me.txtinvoice_no5.Top = 0.6889763!
        Me.txtinvoice_no5.Visible = False
        Me.txtinvoice_no5.Width = 1.0!
        '
        'txtinvoice_date1
        '
        Me.txtinvoice_date1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.DataField = "invoice_date1"
        Me.txtinvoice_date1.Height = 0.1979167!
        Me.txtinvoice_date1.Left = 0!
        Me.txtinvoice_date1.Name = "txtinvoice_date1"
        Me.txtinvoice_date1.Style = "color: Red; "
        Me.txtinvoice_date1.Text = "invoice_date1"
        Me.txtinvoice_date1.Top = 0.949393!
        Me.txtinvoice_date1.Visible = False
        Me.txtinvoice_date1.Width = 1.0!
        '
        'txtinvoice_date2
        '
        Me.txtinvoice_date2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.DataField = "invoice_date2"
        Me.txtinvoice_date2.Height = 0.1979167!
        Me.txtinvoice_date2.Left = 1.008858!
        Me.txtinvoice_date2.Name = "txtinvoice_date2"
        Me.txtinvoice_date2.Style = "color: Red; "
        Me.txtinvoice_date2.Text = "invoice_date2"
        Me.txtinvoice_date2.Top = 0.949393!
        Me.txtinvoice_date2.Visible = False
        Me.txtinvoice_date2.Width = 1.0!
        '
        'txtinvoice_date3
        '
        Me.txtinvoice_date3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.DataField = "invoice_date3"
        Me.txtinvoice_date3.Height = 0.1979167!
        Me.txtinvoice_date3.Left = 2.017717!
        Me.txtinvoice_date3.Name = "txtinvoice_date3"
        Me.txtinvoice_date3.Style = "color: Red; "
        Me.txtinvoice_date3.Text = "invoice_date3"
        Me.txtinvoice_date3.Top = 0.949393!
        Me.txtinvoice_date3.Visible = False
        Me.txtinvoice_date3.Width = 1.0!
        '
        'txtinvoice_date4
        '
        Me.txtinvoice_date4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.DataField = "invoice_date4"
        Me.txtinvoice_date4.Height = 0.1979167!
        Me.txtinvoice_date4.Left = 3.026575!
        Me.txtinvoice_date4.Name = "txtinvoice_date4"
        Me.txtinvoice_date4.Style = "color: Red; "
        Me.txtinvoice_date4.Text = "invoice_date4"
        Me.txtinvoice_date4.Top = 0.949393!
        Me.txtinvoice_date4.Visible = False
        Me.txtinvoice_date4.Width = 1.0!
        '
        'txtinvoice_date5
        '
        Me.txtinvoice_date5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.DataField = "invoice_date5"
        Me.txtinvoice_date5.Height = 0.1979167!
        Me.txtinvoice_date5.Left = 4.035433!
        Me.txtinvoice_date5.Name = "txtinvoice_date5"
        Me.txtinvoice_date5.Style = "color: Red; "
        Me.txtinvoice_date5.Text = "invoice_date5"
        Me.txtinvoice_date5.Top = 0.949393!
        Me.txtinvoice_date5.Visible = False
        Me.txtinvoice_date5.Width = 1.0!
        '
        'txtGross_Weight
        '
        Me.txtGross_Weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.DataField = "Gross_Weight"
        Me.txtGross_Weight.Height = 0.1979167!
        Me.txtGross_Weight.Left = 3.001969!
        Me.txtGross_Weight.Name = "txtGross_Weight"
        Me.txtGross_Weight.Style = "color: Lime; "
        Me.txtGross_Weight.Text = "Gross_Weight"
        Me.txtGross_Weight.Top = 1.99311!
        Me.txtGross_Weight.Visible = False
        Me.txtGross_Weight.Width = 1.0!
        '
        'txtmarks
        '
        Me.txtmarks.Border.BottomColor = System.Drawing.Color.Black
        Me.txtmarks.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.LeftColor = System.Drawing.Color.Black
        Me.txtmarks.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.RightColor = System.Drawing.Color.Black
        Me.txtmarks.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.TopColor = System.Drawing.Color.Black
        Me.txtmarks.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.DataField = "marks"
        Me.txtmarks.Height = 0.1979167!
        Me.txtmarks.Left = 1.008858!
        Me.txtmarks.Name = "txtmarks"
        Me.txtmarks.Style = "color: Red; "
        Me.txtmarks.Text = "marks"
        Me.txtmarks.Top = 1.20981!
        Me.txtmarks.Visible = False
        Me.txtmarks.Width = 1.0!
        '
        'txtproduct_n1
        '
        Me.txtproduct_n1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.DataField = "product_n1"
        Me.txtproduct_n1.Height = 0.1979167!
        Me.txtproduct_n1.Left = 2.017717!
        Me.txtproduct_n1.Name = "txtproduct_n1"
        Me.txtproduct_n1.Style = "color: Red; text-align: left; "
        Me.txtproduct_n1.Text = "product_n1"
        Me.txtproduct_n1.Top = 1.20981!
        Me.txtproduct_n1.Visible = False
        Me.txtproduct_n1.Width = 1.0!
        '
        'txtproduct_n2
        '
        Me.txtproduct_n2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.DataField = "product_n2"
        Me.txtproduct_n2.Height = 0.1979167!
        Me.txtproduct_n2.Left = 3.026575!
        Me.txtproduct_n2.Name = "txtproduct_n2"
        Me.txtproduct_n2.Style = "color: Red; "
        Me.txtproduct_n2.Text = "product_n2"
        Me.txtproduct_n2.Top = 1.20981!
        Me.txtproduct_n2.Visible = False
        Me.txtproduct_n2.Width = 1.0!
        '
        'txtquantity1
        '
        Me.txtquantity1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.DataField = "quantity1"
        Me.txtquantity1.Height = 0.1979167!
        Me.txtquantity1.Left = 0!
        Me.txtquantity1.Name = "txtquantity1"
        Me.txtquantity1.Style = "color: Red; text-align: left; "
        Me.txtquantity1.Text = "quantity1"
        Me.txtquantity1.Top = 1.402559!
        Me.txtquantity1.Visible = False
        Me.txtquantity1.Width = 1.0!
        '
        'txtq_unit_code1
        '
        Me.txtq_unit_code1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.DataField = "q_unit_code1"
        Me.txtq_unit_code1.Height = 0.1979167!
        Me.txtq_unit_code1.Left = 1.008858!
        Me.txtq_unit_code1.Name = "txtq_unit_code1"
        Me.txtq_unit_code1.Style = "color: Red; "
        Me.txtq_unit_code1.Text = "q_unit_code1"
        Me.txtq_unit_code1.Top = 1.402559!
        Me.txtq_unit_code1.Visible = False
        Me.txtq_unit_code1.Width = 1.0!
        '
        'txtquantity2
        '
        Me.txtquantity2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.DataField = "quantity2"
        Me.txtquantity2.Height = 0.1979167!
        Me.txtquantity2.Left = 0!
        Me.txtquantity2.Name = "txtquantity2"
        Me.txtquantity2.Style = "color: Red; text-align: left; "
        Me.txtquantity2.Text = "quantity2"
        Me.txtquantity2.Top = 1.662976!
        Me.txtquantity2.Visible = False
        Me.txtquantity2.Width = 1.0!
        '
        'txtq_unit_code2
        '
        Me.txtq_unit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.DataField = "q_unit_code2"
        Me.txtq_unit_code2.Height = 0.1979167!
        Me.txtq_unit_code2.Left = 1.008858!
        Me.txtq_unit_code2.Name = "txtq_unit_code2"
        Me.txtq_unit_code2.Style = "color: Red; "
        Me.txtq_unit_code2.Text = "q_unit_code2"
        Me.txtq_unit_code2.Top = 1.662976!
        Me.txtq_unit_code2.Visible = False
        Me.txtq_unit_code2.Width = 1.0!
        '
        'txtquantity3
        '
        Me.txtquantity3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.DataField = "quantity3"
        Me.txtquantity3.Height = 0.1979167!
        Me.txtquantity3.Left = 0!
        Me.txtquantity3.Name = "txtquantity3"
        Me.txtquantity3.Style = "color: Red; text-align: left; "
        Me.txtquantity3.Text = "quantity3"
        Me.txtquantity3.Top = 1.923393!
        Me.txtquantity3.Visible = False
        Me.txtquantity3.Width = 1.0!
        '
        'txtq_unit_code3
        '
        Me.txtq_unit_code3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.DataField = "q_unit_code3"
        Me.txtq_unit_code3.Height = 0.1979167!
        Me.txtq_unit_code3.Left = 1.008858!
        Me.txtq_unit_code3.Name = "txtq_unit_code3"
        Me.txtq_unit_code3.Style = "color: Red; "
        Me.txtq_unit_code3.Text = "q_unit_code3"
        Me.txtq_unit_code3.Top = 1.923393!
        Me.txtq_unit_code3.Visible = False
        Me.txtq_unit_code3.Width = 1.0!
        '
        'txtquantity4
        '
        Me.txtquantity4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.DataField = "quantity4"
        Me.txtquantity4.Height = 0.1979167!
        Me.txtquantity4.Left = 0!
        Me.txtquantity4.Name = "txtquantity4"
        Me.txtquantity4.Style = "color: Red; text-align: left; "
        Me.txtquantity4.Text = "quantity4"
        Me.txtquantity4.Top = 2.183809!
        Me.txtquantity4.Visible = False
        Me.txtquantity4.Width = 1.0!
        '
        'txtq_unit_code4
        '
        Me.txtq_unit_code4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.DataField = "q_unit_code4"
        Me.txtq_unit_code4.Height = 0.1979167!
        Me.txtq_unit_code4.Left = 1.008858!
        Me.txtq_unit_code4.Name = "txtq_unit_code4"
        Me.txtq_unit_code4.Style = "color: Red; "
        Me.txtq_unit_code4.Text = "q_unit_code4"
        Me.txtq_unit_code4.Top = 2.183809!
        Me.txtq_unit_code4.Visible = False
        Me.txtq_unit_code4.Width = 1.0!
        '
        'txtquantity5
        '
        Me.txtquantity5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.DataField = "quantity5"
        Me.txtquantity5.Height = 0.1979167!
        Me.txtquantity5.Left = 0!
        Me.txtquantity5.Name = "txtquantity5"
        Me.txtquantity5.Style = "color: Red; text-align: left; "
        Me.txtquantity5.Text = "quantity5"
        Me.txtquantity5.Top = 2.444227!
        Me.txtquantity5.Visible = False
        Me.txtquantity5.Width = 1.0!
        '
        'txtq_unit_code5
        '
        Me.txtq_unit_code5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.DataField = "q_unit_code5"
        Me.txtq_unit_code5.Height = 0.1979167!
        Me.txtq_unit_code5.Left = 1.008858!
        Me.txtq_unit_code5.Name = "txtq_unit_code5"
        Me.txtq_unit_code5.Style = "color: Red; "
        Me.txtq_unit_code5.Text = "q_unit_code5"
        Me.txtq_unit_code5.Top = 2.444227!
        Me.txtq_unit_code5.Visible = False
        Me.txtq_unit_code5.Width = 1.0!
        '
        'txtg_unit_code
        '
        Me.txtg_unit_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.RightColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.TopColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.DataField = "g_unit_code"
        Me.txtg_unit_code.Height = 0.1979167!
        Me.txtg_unit_code.Left = 2.017717!
        Me.txtg_unit_code.Name = "txtg_unit_code"
        Me.txtg_unit_code.Style = "color: Red; "
        Me.txtg_unit_code.Text = "g_unit_code"
        Me.txtg_unit_code.Top = 1.470227!
        Me.txtg_unit_code.Visible = False
        Me.txtg_unit_code.Width = 1.0!
        '
        'C_TotalRowDe
        '
        Me.C_TotalRowDe.Border.BottomColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.LeftColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.RightColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.TopColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Height = 0.1979167!
        Me.C_TotalRowDe.Left = 2.017717!
        Me.C_TotalRowDe.Name = "C_TotalRowDe"
        Me.C_TotalRowDe.Style = "color: Lime; "
        Me.C_TotalRowDe.Text = "C_TotalRowDe"
        Me.C_TotalRowDe.Top = 1.730644!
        Me.C_TotalRowDe.Visible = False
        Me.C_TotalRowDe.Width = 1.0!
        '
        'txttariff_code
        '
        Me.txttariff_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.RightColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.TopColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.DataField = "tariff_code"
        Me.txttariff_code.Height = 0.1979167!
        Me.txttariff_code.Left = 3.026575!
        Me.txttariff_code.Name = "txttariff_code"
        Me.txttariff_code.Style = "color: Red; "
        Me.txttariff_code.Text = "tariff_code"
        Me.txttariff_code.Top = 1.470227!
        Me.txttariff_code.Visible = False
        Me.txttariff_code.Width = 1.0!
        '
        'txtGrossTxt
        '
        Me.txtGrossTxt.Border.BottomColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.LeftColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.RightColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.TopColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Height = 0.2214567!
        Me.txtGrossTxt.Left = 6.003937!
        Me.txtGrossTxt.Name = "txtGrossTxt"
        Me.txtGrossTxt.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtGrossTxt.Text = Nothing
        Me.txtGrossTxt.Top = 0!
        Me.txtGrossTxt.Width = 0.9448819!
        '
        'txtg_Unit_Desc
        '
        Me.txtg_Unit_Desc.Border.BottomColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.LeftColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.RightColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.TopColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.DataField = "g_Unit_Desc"
        Me.txtg_Unit_Desc.Height = 0.1979167!
        Me.txtg_Unit_Desc.Left = 3.026575!
        Me.txtg_Unit_Desc.Name = "txtg_Unit_Desc"
        Me.txtg_Unit_Desc.Style = "color: Lime; "
        Me.txtg_Unit_Desc.Text = "g_Unit_Desc"
        Me.txtg_Unit_Desc.Top = 1.730644!
        Me.txtg_Unit_Desc.Visible = False
        Me.txtg_Unit_Desc.Width = 1.0!
        '
        'txtFOB_AMT
        '
        Me.txtFOB_AMT.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.DataField = "FOB_AMT"
        Me.txtFOB_AMT.Height = 0.1979167!
        Me.txtFOB_AMT.Left = 3.001969!
        Me.txtFOB_AMT.Name = "txtFOB_AMT"
        Me.txtFOB_AMT.Style = "color: Lime; "
        Me.txtFOB_AMT.Text = "FOB_AMT"
        Me.txtFOB_AMT.Top = 2.253527!
        Me.txtFOB_AMT.Visible = False
        Me.txtFOB_AMT.Width = 1.0!
        '
        'txtinvoice_board
        '
        Me.txtinvoice_board.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.DataField = "invoice_board"
        Me.txtinvoice_board.Height = 0.1979167!
        Me.txtinvoice_board.Left = 4.035433!
        Me.txtinvoice_board.Name = "txtinvoice_board"
        Me.txtinvoice_board.Style = "color: Red; "
        Me.txtinvoice_board.Text = "invoice_board"
        Me.txtinvoice_board.Top = 1.20981!
        Me.txtinvoice_board.Visible = False
        Me.txtinvoice_board.Width = 1.0!
        '
        'txtWeightDisplayHeader
        '
        Me.txtWeightDisplayHeader.Border.BottomColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.LeftColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.RightColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.TopColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.DataField = "WeightDisplayHeader"
        Me.txtWeightDisplayHeader.Height = 0.1979167!
        Me.txtWeightDisplayHeader.Left = 4.035433!
        Me.txtWeightDisplayHeader.Name = "txtWeightDisplayHeader"
        Me.txtWeightDisplayHeader.Style = "color: Red; "
        Me.txtWeightDisplayHeader.Text = "WeightDisplayHeader"
        Me.txtWeightDisplayHeader.Top = 1.470227!
        Me.txtWeightDisplayHeader.Visible = False
        Me.txtWeightDisplayHeader.Width = 1.0!
        '
        'txtFOBDisplay
        '
        Me.txtFOBDisplay.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.DataField = "FOBDisplay"
        Me.txtFOBDisplay.Height = 0.1979167!
        Me.txtFOBDisplay.Left = 4.035433!
        Me.txtFOBDisplay.Name = "txtFOBDisplay"
        Me.txtFOBDisplay.Style = "color: Red; "
        Me.txtFOBDisplay.Text = "FOBDisplay"
        Me.txtFOBDisplay.Top = 1.730644!
        Me.txtFOBDisplay.Visible = False
        Me.txtFOBDisplay.Width = 1.0!
        '
        'txtunit_code2
        '
        Me.txtunit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.DataField = "unit_code2"
        Me.txtunit_code2.Height = 0.1979167!
        Me.txtunit_code2.Left = 4.035433!
        Me.txtunit_code2.Name = "txtunit_code2"
        Me.txtunit_code2.Style = "color: Red; "
        Me.txtunit_code2.Text = "unit_code2"
        Me.txtunit_code2.Top = 1.99106!
        Me.txtunit_code2.Visible = False
        Me.txtunit_code2.Width = 1.0!
        '
        'txtnet_weight
        '
        Me.txtnet_weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.DataField = "net_weight"
        Me.txtnet_weight.Height = 0.1979167!
        Me.txtnet_weight.Left = 4.035433!
        Me.txtnet_weight.Name = "txtnet_weight"
        Me.txtnet_weight.Style = "color: Red; "
        Me.txtnet_weight.Text = "net_weight"
        Me.txtnet_weight.Top = 2.251477!
        Me.txtnet_weight.Visible = False
        Me.txtnet_weight.Width = 1.0!
        '
        'txtgross_weightH
        '
        Me.txtgross_weightH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.RightColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.TopColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.DataField = "gross_weightH"
        Me.txtgross_weightH.Height = 0.1979167!
        Me.txtgross_weightH.Left = 2.017717!
        Me.txtgross_weightH.Name = "txtgross_weightH"
        Me.txtgross_weightH.Style = "color: Red; "
        Me.txtgross_weightH.Text = "gross_weightH"
        Me.txtgross_weightH.Top = 1.991061!
        Me.txtgross_weightH.Visible = False
        Me.txtgross_weightH.Width = 1.0!
        '
        'txtGrossTxt_
        '
        Me.txtGrossTxt_.Border.BottomColor = System.Drawing.Color.Black
        Me.txtGrossTxt_.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt_.Border.LeftColor = System.Drawing.Color.Black
        Me.txtGrossTxt_.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt_.Border.RightColor = System.Drawing.Color.Black
        Me.txtGrossTxt_.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt_.Border.TopColor = System.Drawing.Color.Black
        Me.txtGrossTxt_.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt_.Height = 0.2204724!
        Me.txtGrossTxt_.Left = 3.026575!
        Me.txtGrossTxt_.Name = "txtGrossTxt_"
        Me.txtGrossTxt_.Style = "color: Red; ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: " &
    "BrowalliaUPC; "
        Me.txtGrossTxt_.Text = "txtGrossTxt"
        Me.txtGrossTxt_.Top = 2.46063!
        Me.txtGrossTxt_.Visible = False
        Me.txtGrossTxt_.Width = 0.9055118!
        '
        'txtthird_country
        '
        Me.txtthird_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.DataField = "third_country"
        Me.txtthird_country.Height = 0.1979167!
        Me.txtthird_country.Left = 2.017717!
        Me.txtthird_country.Name = "txtthird_country"
        Me.txtthird_country.Style = "color: Red; "
        Me.txtthird_country.Text = "third_country"
        Me.txtthird_country.Top = 2.251478!
        Me.txtthird_country.Visible = False
        Me.txtthird_country.Width = 1.0!
        '
        'txtplace_exibition
        '
        Me.txtplace_exibition.Border.BottomColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.LeftColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.RightColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.TopColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.DataField = "place_exibition"
        Me.txtplace_exibition.Height = 0.1979167!
        Me.txtplace_exibition.Left = 2.017717!
        Me.txtplace_exibition.Name = "txtplace_exibition"
        Me.txtplace_exibition.Style = "color: Red; "
        Me.txtplace_exibition.Text = "place_exibition"
        Me.txtplace_exibition.Top = 2.511894!
        Me.txtplace_exibition.Visible = False
        Me.txtplace_exibition.Width = 1.0!
        '
        'txtNumInvoice
        '
        Me.txtNumInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.DataField = "NumInvoice"
        Me.txtNumInvoice.Height = 0.25!
        Me.txtNumInvoice.Left = 4.035433!
        Me.txtNumInvoice.Name = "txtNumInvoice"
        Me.txtNumInvoice.Style = "color: Red; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtNumInvoice.Text = "NumInvoice"
        Me.txtNumInvoice.Top = 2.511894!
        Me.txtNumInvoice.Visible = False
        Me.txtNumInvoice.Width = 0.5!
        '
        'txtUSDInvoice
        '
        Me.txtUSDInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.DataField = "USDInvoice"
        Me.txtUSDInvoice.Height = 0.25!
        Me.txtUSDInvoice.Left = 4.035433!
        Me.txtUSDInvoice.Name = "txtUSDInvoice"
        Me.txtUSDInvoice.Style = "color: Red; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtUSDInvoice.Text = "USDInvoice"
        Me.txtUSDInvoice.Top = 2.824394!
        Me.txtUSDInvoice.Visible = False
        Me.txtUSDInvoice.Width = 0.5!
        '
        'txtbox8
        '
        Me.txtbox8.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbox8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbox8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.RightColor = System.Drawing.Color.Black
        Me.txtbox8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.TopColor = System.Drawing.Color.Black
        Me.txtbox8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.DataField = "box8"
        Me.txtbox8.Height = 0.25!
        Me.txtbox8.Left = 4.035433!
        Me.txtbox8.Name = "txtbox8"
        Me.txtbox8.Style = "color: Red; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtbox8.Text = "box8"
        Me.txtbox8.Top = 3.136894!
        Me.txtbox8.Visible = False
        Me.txtbox8.Width = 0.5!
        '
        'txtunit_code3
        '
        Me.txtunit_code3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtunit_code3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtunit_code3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code3.Border.RightColor = System.Drawing.Color.Black
        Me.txtunit_code3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code3.Border.TopColor = System.Drawing.Color.Black
        Me.txtunit_code3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code3.DataField = "unit_code3"
        Me.txtunit_code3.Height = 0.1979167!
        Me.txtunit_code3.Left = 5.0625!
        Me.txtunit_code3.Name = "txtunit_code3"
        Me.txtunit_code3.Style = "color: Red; "
        Me.txtunit_code3.Text = "unit_code3"
        Me.txtunit_code3.Top = 0.9375!
        Me.txtunit_code3.Visible = False
        Me.txtunit_code3.Width = 1.0!
        '
        'txtUSDInvoiceDetail
        '
        Me.txtUSDInvoiceDetail.Border.BottomColor = System.Drawing.Color.Black
        Me.txtUSDInvoiceDetail.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoiceDetail.Border.LeftColor = System.Drawing.Color.Black
        Me.txtUSDInvoiceDetail.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoiceDetail.Border.RightColor = System.Drawing.Color.Black
        Me.txtUSDInvoiceDetail.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoiceDetail.Border.TopColor = System.Drawing.Color.Black
        Me.txtUSDInvoiceDetail.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoiceDetail.DataField = "USDInvoiceDetail"
        Me.txtUSDInvoiceDetail.Height = 0.1979167!
        Me.txtUSDInvoiceDetail.Left = 5.0625!
        Me.txtUSDInvoiceDetail.Name = "txtUSDInvoiceDetail"
        Me.txtUSDInvoiceDetail.Style = "color: Red; "
        Me.txtUSDInvoiceDetail.Text = "USDInvoiceDetail"
        Me.txtUSDInvoiceDetail.Top = 1.25!
        Me.txtUSDInvoiceDetail.Visible = False
        Me.txtUSDInvoiceDetail.Width = 1.0!
        '
        'txtWeightDisplayHeaderH
        '
        Me.txtWeightDisplayHeaderH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.RightColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.TopColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.DataField = "WeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Height = 0.1979167!
        Me.txtWeightDisplayHeaderH.Left = 3.075788!
        Me.txtWeightDisplayHeaderH.Name = "txtWeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Style = "color: Red; "
        Me.txtWeightDisplayHeaderH.Text = Nothing
        Me.txtWeightDisplayHeaderH.Top = 2.772311!
        Me.txtWeightDisplayHeaderH.Visible = False
        Me.txtWeightDisplayHeaderH.Width = 1.0!
        '
        'txtgross_weightD
        '
        Me.txtgross_weightD.Border.BottomColor = System.Drawing.Color.Black
        Me.txtgross_weightD.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightD.Border.LeftColor = System.Drawing.Color.Black
        Me.txtgross_weightD.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightD.Border.RightColor = System.Drawing.Color.Black
        Me.txtgross_weightD.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightD.Border.TopColor = System.Drawing.Color.Black
        Me.txtgross_weightD.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightD.DataField = "gross_weightD"
        Me.txtgross_weightD.Height = 0.1979167!
        Me.txtgross_weightD.Left = 2.017717!
        Me.txtgross_weightD.Name = "txtgross_weightD"
        Me.txtgross_weightD.Style = "color: Red; "
        Me.txtgross_weightD.Text = Nothing
        Me.txtgross_weightD.Top = 2.776414!
        Me.txtgross_weightD.Visible = False
        Me.txtgross_weightD.Width = 1.0!
        '
        'txtCheckGrossDetail
        '
        Me.txtCheckGrossDetail.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCheckGrossDetail.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckGrossDetail.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCheckGrossDetail.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckGrossDetail.Border.RightColor = System.Drawing.Color.Black
        Me.txtCheckGrossDetail.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckGrossDetail.Border.TopColor = System.Drawing.Color.Black
        Me.txtCheckGrossDetail.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckGrossDetail.DataField = "CheckGrossDetail"
        Me.txtCheckGrossDetail.Height = 0.1979167!
        Me.txtCheckGrossDetail.Left = 2.017717!
        Me.txtCheckGrossDetail.Name = "txtCheckGrossDetail"
        Me.txtCheckGrossDetail.Style = "color: Red; "
        Me.txtCheckGrossDetail.Text = Nothing
        Me.txtCheckGrossDetail.Top = 3.03683!
        Me.txtCheckGrossDetail.Visible = False
        Me.txtCheckGrossDetail.Width = 1.0!
        '
        'txtInvoiceDetailTH
        '
        Me.txtInvoiceDetailTH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtInvoiceDetailTH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvoiceDetailTH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtInvoiceDetailTH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvoiceDetailTH.Border.RightColor = System.Drawing.Color.Black
        Me.txtInvoiceDetailTH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvoiceDetailTH.Border.TopColor = System.Drawing.Color.Black
        Me.txtInvoiceDetailTH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvoiceDetailTH.DataField = "InvoiceDetailTH"
        Me.txtInvoiceDetailTH.Height = 0.1979167!
        Me.txtInvoiceDetailTH.Left = 5.0625!
        Me.txtInvoiceDetailTH.Name = "txtInvoiceDetailTH"
        Me.txtInvoiceDetailTH.Style = "color: Red; "
        Me.txtInvoiceDetailTH.Text = "InvoiceDetailTH"
        Me.txtInvoiceDetailTH.Top = 1.770833!
        Me.txtInvoiceDetailTH.Visible = False
        Me.txtInvoiceDetailTH.Width = 1.0!
        '
        'txtSINGLE_COUNTRY_CONTENT
        '
        Me.txtSINGLE_COUNTRY_CONTENT.Border.BottomColor = System.Drawing.Color.Black
        Me.txtSINGLE_COUNTRY_CONTENT.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSINGLE_COUNTRY_CONTENT.Border.LeftColor = System.Drawing.Color.Black
        Me.txtSINGLE_COUNTRY_CONTENT.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSINGLE_COUNTRY_CONTENT.Border.RightColor = System.Drawing.Color.Black
        Me.txtSINGLE_COUNTRY_CONTENT.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSINGLE_COUNTRY_CONTENT.Border.TopColor = System.Drawing.Color.Black
        Me.txtSINGLE_COUNTRY_CONTENT.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSINGLE_COUNTRY_CONTENT.DataField = "SINGLE_COUNTRY_CONTENT"
        Me.txtSINGLE_COUNTRY_CONTENT.Height = 0.1979167!
        Me.txtSINGLE_COUNTRY_CONTENT.Left = 5.0625!
        Me.txtSINGLE_COUNTRY_CONTENT.Name = "txtSINGLE_COUNTRY_CONTENT"
        Me.txtSINGLE_COUNTRY_CONTENT.Style = "color: Red; "
        Me.txtSINGLE_COUNTRY_CONTENT.Text = "SINGLE_COUNTRY_CONTENT"
        Me.txtSINGLE_COUNTRY_CONTENT.Top = 1.510417!
        Me.txtSINGLE_COUNTRY_CONTENT.Visible = False
        Me.txtSINGLE_COUNTRY_CONTENT.Width = 1.0!
        '
        'txt_NewEmail_ch02
        '
        Me.txt_NewEmail_ch02.Border.BottomColor = System.Drawing.Color.Black
        Me.txt_NewEmail_ch02.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txt_NewEmail_ch02.Border.LeftColor = System.Drawing.Color.Black
        Me.txt_NewEmail_ch02.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txt_NewEmail_ch02.Border.RightColor = System.Drawing.Color.Black
        Me.txt_NewEmail_ch02.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txt_NewEmail_ch02.Border.TopColor = System.Drawing.Color.Black
        Me.txt_NewEmail_ch02.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txt_NewEmail_ch02.DataField = "NewEmail_ch02"
        Me.txt_NewEmail_ch02.Height = 0.1979167!
        Me.txt_NewEmail_ch02.Left = 5.0625!
        Me.txt_NewEmail_ch02.Name = "txt_NewEmail_ch02"
        Me.txt_NewEmail_ch02.Style = "color: Fuchsia; "
        Me.txt_NewEmail_ch02.Text = "NewEmail_ch02"
        Me.txt_NewEmail_ch02.Top = 2.03125!
        Me.txt_NewEmail_ch02.Visible = False
        Me.txt_NewEmail_ch02.Width = 1.0!
        '
        'txtproduct_model
        '
        Me.txtproduct_model.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_model.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_model.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_model.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_model.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_model.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_model.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_model.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_model.DataField = "product_model"
        Me.txtproduct_model.Height = 0.1979167!
        Me.txtproduct_model.Left = 5.0625!
        Me.txtproduct_model.Name = "txtproduct_model"
        Me.txtproduct_model.Style = "color: Fuchsia; "
        Me.txtproduct_model.Text = "product_model"
        Me.txtproduct_model.Top = 2.291667!
        Me.txtproduct_model.Visible = False
        Me.txtproduct_model.Width = 1.0!
        '
        'txtvoince
        '
        Me.txtvoince.Border.BottomColor = System.Drawing.Color.Black
        Me.txtvoince.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvoince.Border.LeftColor = System.Drawing.Color.Black
        Me.txtvoince.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvoince.Border.RightColor = System.Drawing.Color.Black
        Me.txtvoince.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvoince.Border.TopColor = System.Drawing.Color.Black
        Me.txtvoince.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvoince.Height = 0.2214567!
        Me.txtvoince.Left = 6.988!
        Me.txtvoince.Name = "txtvoince"
        Me.txtvoince.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtvoince.Text = Nothing
        Me.txtvoince.Top = 0!
        Me.txtvoince.Width = 0.9842519!
        '
        'txtTitleMain
        '
        Me.txtTitleMain.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTitleMain.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleMain.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTitleMain.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleMain.Border.RightColor = System.Drawing.Color.Black
        Me.txtTitleMain.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleMain.Border.TopColor = System.Drawing.Color.Black
        Me.txtTitleMain.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleMain.DataField = "InvoiceDetailTH"
        Me.txtTitleMain.Height = 0.25!
        Me.txtTitleMain.Left = 5.0625!
        Me.txtTitleMain.Name = "txtTitleMain"
        Me.txtTitleMain.Style = "color: Fuchsia; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtTitleMain.Text = "txtTitleMain"
        Me.txtTitleMain.Top = 2.552084!
        Me.txtTitleMain.Visible = False
        Me.txtTitleMain.Width = 1.625!
        '
        'txtPriceOtherDetail
        '
        Me.txtPriceOtherDetail.Border.BottomColor = System.Drawing.Color.Black
        Me.txtPriceOtherDetail.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPriceOtherDetail.Border.LeftColor = System.Drawing.Color.Black
        Me.txtPriceOtherDetail.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPriceOtherDetail.Border.RightColor = System.Drawing.Color.Black
        Me.txtPriceOtherDetail.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPriceOtherDetail.Border.TopColor = System.Drawing.Color.Black
        Me.txtPriceOtherDetail.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPriceOtherDetail.DataField = "PriceOtherDetail"
        Me.txtPriceOtherDetail.Height = 0.25!
        Me.txtPriceOtherDetail.Left = 5.0625!
        Me.txtPriceOtherDetail.Name = "txtPriceOtherDetail"
        Me.txtPriceOtherDetail.Style = "color: Fuchsia; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtPriceOtherDetail.Text = Nothing
        Me.txtPriceOtherDetail.Top = 2.864584!
        Me.txtPriceOtherDetail.Visible = False
        Me.txtPriceOtherDetail.Width = 1.625!
        '
        'txtCurrency_Code
        '
        Me.txtCurrency_Code.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCurrency_Code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCurrency_Code.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCurrency_Code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCurrency_Code.Border.RightColor = System.Drawing.Color.Black
        Me.txtCurrency_Code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCurrency_Code.Border.TopColor = System.Drawing.Color.Black
        Me.txtCurrency_Code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCurrency_Code.DataField = "Currency_Code"
        Me.txtCurrency_Code.Height = 0.25!
        Me.txtCurrency_Code.Left = 5.0625!
        Me.txtCurrency_Code.Name = "txtCurrency_Code"
        Me.txtCurrency_Code.Style = "color: Fuchsia; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtCurrency_Code.Text = Nothing
        Me.txtCurrency_Code.Top = 3.177084!
        Me.txtCurrency_Code.Visible = False
        Me.txtCurrency_Code.Width = 1.625!
        '
        'txtletter
        '
        Me.txtletter.Border.BottomColor = System.Drawing.Color.Black
        Me.txtletter.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtletter.Border.LeftColor = System.Drawing.Color.Black
        Me.txtletter.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtletter.Border.RightColor = System.Drawing.Color.Black
        Me.txtletter.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtletter.Border.TopColor = System.Drawing.Color.Black
        Me.txtletter.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtletter.DataField = "letter"
        Me.txtletter.Height = 0.25!
        Me.txtletter.Left = 5.0625!
        Me.txtletter.Name = "txtletter"
        Me.txtletter.Style = "color: Fuchsia; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtletter.Text = Nothing
        Me.txtletter.Top = 3.489584!
        Me.txtletter.Visible = False
        Me.txtletter.Width = 1.625!
        '
        'txtAttUSDTotal
        '
        Me.txtAttUSDTotal.Border.BottomColor = System.Drawing.Color.Black
        Me.txtAttUSDTotal.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAttUSDTotal.Border.LeftColor = System.Drawing.Color.Black
        Me.txtAttUSDTotal.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAttUSDTotal.Border.RightColor = System.Drawing.Color.Black
        Me.txtAttUSDTotal.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAttUSDTotal.Border.TopColor = System.Drawing.Color.Black
        Me.txtAttUSDTotal.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAttUSDTotal.DataField = "AttUSDTotal"
        Me.txtAttUSDTotal.Height = 0.1979167!
        Me.txtAttUSDTotal.Left = 6.625!
        Me.txtAttUSDTotal.Name = "txtAttUSDTotal"
        Me.txtAttUSDTotal.Style = "color: Red; "
        Me.txtAttUSDTotal.Text = "AttUSDTotal"
        Me.txtAttUSDTotal.Top = 0.8125!
        Me.txtAttUSDTotal.Visible = False
        Me.txtAttUSDTotal.Width = 1.0!
        '
        'txtAttThirdUSDTotal
        '
        Me.txtAttThirdUSDTotal.Border.BottomColor = System.Drawing.Color.Black
        Me.txtAttThirdUSDTotal.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAttThirdUSDTotal.Border.LeftColor = System.Drawing.Color.Black
        Me.txtAttThirdUSDTotal.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAttThirdUSDTotal.Border.RightColor = System.Drawing.Color.Black
        Me.txtAttThirdUSDTotal.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAttThirdUSDTotal.Border.TopColor = System.Drawing.Color.Black
        Me.txtAttThirdUSDTotal.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtAttThirdUSDTotal.DataField = "AttThirdUSDTotal"
        Me.txtAttThirdUSDTotal.Height = 0.1979167!
        Me.txtAttThirdUSDTotal.Left = 6.625!
        Me.txtAttThirdUSDTotal.Name = "txtAttThirdUSDTotal"
        Me.txtAttThirdUSDTotal.Style = "color: Red; "
        Me.txtAttThirdUSDTotal.Text = "AttThirdUSDTotal"
        Me.txtAttThirdUSDTotal.Top = 1.072917!
        Me.txtAttThirdUSDTotal.Visible = False
        Me.txtAttThirdUSDTotal.Width = 1.0!
        '
        'txtUSDAgent
        '
        Me.txtUSDAgent.Border.BottomColor = System.Drawing.Color.Black
        Me.txtUSDAgent.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDAgent.Border.LeftColor = System.Drawing.Color.Black
        Me.txtUSDAgent.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDAgent.Border.RightColor = System.Drawing.Color.Black
        Me.txtUSDAgent.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDAgent.Border.TopColor = System.Drawing.Color.Black
        Me.txtUSDAgent.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDAgent.DataField = "USDAgent"
        Me.txtUSDAgent.Height = 0.1979167!
        Me.txtUSDAgent.Left = 6.1875!
        Me.txtUSDAgent.Name = "txtUSDAgent"
        Me.txtUSDAgent.Style = "color: Red; "
        Me.txtUSDAgent.Text = "USDAgent"
        Me.txtUSDAgent.Top = 1.5625!
        Me.txtUSDAgent.Visible = False
        Me.txtUSDAgent.Width = 1.0!
        '
        'PageHeader1
        '
        Me.PageHeader1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtCompany_Check_1, Me.txtreference_code2_Temp, Me.txtdestination_Check2, Me.txttransport_by, Me.txtcompany_taxno, Me.txtcompany_country, Me.txtcompany_province, Me.txtcompany_address, Me.txtcompany_name, Me.txtob_address, Me.txtdest_remark, Me.txtcompany_fax, Me.txtcompany_phone, Me.txtdestination_company, Me.txtdestination_fax, Me.txtdestination_address, Me.txtdestination_phone, Me.txtdestination_province, Me.txtdest_Receive_country, Me.txtreference_code2, Me.txtcompany_email, Me.txtdestination_email, Me.txtdestination_taxid, Me.txtdest_remark1, Me.txtob_dest_address, Me.txtdeparture_date, Me.txtvasel_name, Me.txtport_discharge, Me.ReportInfo1, Me.txtform_type, Me.txtNewEmail_ch02, Me.txtNewEmail_ch01, Me.txtTitleHead, Me.Line9, Me.Line8, Me.Line13, Me.Line14, Me.Line12, Me.Line3, Me.Label42, Me.Label43, Me.Label44, Me.Line11, Me.Label3, Me.Label2, Me.Label5, Me.Label4, Me.Label1, Me.Label8, Me.Label7, Me.Label16, Me.Label21, Me.Label17, Me.Label22, Me.Line19, Me.Label19, Me.Label6, Me.Shape1, Me.Label29, Me.Label31, Me.Label30, Me.Shape2, Me.Shape3, Me.Label33, Me.Label48, Me.Label47, Me.Label46, Me.Line10, Me.Label15})
        Me.PageHeader1.Height = 4.8677!
        Me.PageHeader1.Name = "PageHeader1"
        '
        'txtCompany_Check_1
        '
        Me.txtCompany_Check_1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.RightColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.TopColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.CanGrow = False
        Me.txtCompany_Check_1.Height = 0.8858271!
        Me.txtCompany_Check_1.Left = 0.4375!
        Me.txtCompany_Check_1.Name = "txtCompany_Check_1"
        Me.txtCompany_Check_1.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtCompany_Check_1.Text = Nothing
        Me.txtCompany_Check_1.Top = 0.5!
        Me.txtCompany_Check_1.Width = 3.779528!
        '
        'txtreference_code2_Temp
        '
        Me.txtreference_code2_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Height = 0.3312007!
        Me.txtreference_code2_Temp.Left = 5.375!
        Me.txtreference_code2_Temp.Name = "txtreference_code2_Temp"
        Me.txtreference_code2_Temp.Style = "color: Blue; ddo-char-set: 1; font-weight: bold; font-size: 16pt; font-family: Br" &
    "owalliaUPC; "
        Me.txtreference_code2_Temp.Text = Nothing
        Me.txtreference_code2_Temp.Top = 0.1875!
        Me.txtreference_code2_Temp.Width = 1.648622!
        '
        'txtdestination_Check2
        '
        Me.txtdestination_Check2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.CanGrow = False
        Me.txtdestination_Check2.Height = 0.8536742!
        Me.txtdestination_Check2.Left = 0.4375!
        Me.txtdestination_Check2.Name = "txtdestination_Check2"
        Me.txtdestination_Check2.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtdestination_Check2.Text = Nothing
        Me.txtdestination_Check2.Top = 1.5625!
        Me.txtdestination_Check2.Width = 3.779528!
        '
        'txttransport_by
        '
        Me.txttransport_by.Border.BottomColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.LeftColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.RightColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.TopColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.DataField = "transport_by"
        Me.txttransport_by.Height = 0.319882!
        Me.txttransport_by.Left = 0.5413386!
        Me.txttransport_by.Name = "txttransport_by"
        Me.txttransport_by.Style = "color: Blue; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txttransport_by.Text = "transport_by"
        Me.txttransport_by.Top = 2.58276!
        Me.txttransport_by.Width = 3.566929!
        '
        'txtcompany_taxno
        '
        Me.txtcompany_taxno.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.DataField = "company_taxno"
        Me.txtcompany_taxno.Height = 0.1979167!
        Me.txtcompany_taxno.Left = 0.2214567!
        Me.txtcompany_taxno.Name = "txtcompany_taxno"
        Me.txtcompany_taxno.Style = "color: Red; "
        Me.txtcompany_taxno.Text = "company_taxno"
        Me.txtcompany_taxno.Top = 0.07381889!
        Me.txtcompany_taxno.Visible = False
        Me.txtcompany_taxno.Width = 1.0!
        '
        'txtcompany_country
        '
        Me.txtcompany_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.DataField = "company_country"
        Me.txtcompany_country.Height = 0.1979167!
        Me.txtcompany_country.Left = 1.254921!
        Me.txtcompany_country.Name = "txtcompany_country"
        Me.txtcompany_country.Style = "color: Red; "
        Me.txtcompany_country.Text = "company_country"
        Me.txtcompany_country.Top = 0.07381889!
        Me.txtcompany_country.Visible = False
        Me.txtcompany_country.Width = 1.0!
        '
        'txtcompany_province
        '
        Me.txtcompany_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.DataField = "company_province"
        Me.txtcompany_province.Height = 0.1979167!
        Me.txtcompany_province.Left = 2.288386!
        Me.txtcompany_province.Name = "txtcompany_province"
        Me.txtcompany_province.Style = "color: Red; "
        Me.txtcompany_province.Text = "company_province"
        Me.txtcompany_province.Top = 0.07381889!
        Me.txtcompany_province.Visible = False
        Me.txtcompany_province.Width = 1.0!
        '
        'txtcompany_address
        '
        Me.txtcompany_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.DataField = "company_address"
        Me.txtcompany_address.Height = 0.1979167!
        Me.txtcompany_address.Left = 2.288386!
        Me.txtcompany_address.Name = "txtcompany_address"
        Me.txtcompany_address.Style = "color: Red; "
        Me.txtcompany_address.Text = "company_address"
        Me.txtcompany_address.Top = 0.2952756!
        Me.txtcompany_address.Visible = False
        Me.txtcompany_address.Width = 1.0!
        '
        'txtcompany_name
        '
        Me.txtcompany_name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.DataField = "company_name"
        Me.txtcompany_name.Height = 0.1979167!
        Me.txtcompany_name.Left = 3.297244!
        Me.txtcompany_name.Name = "txtcompany_name"
        Me.txtcompany_name.Style = "color: Red; "
        Me.txtcompany_name.Text = "company_name"
        Me.txtcompany_name.Top = 0.07381889!
        Me.txtcompany_name.Visible = False
        Me.txtcompany_name.Width = 1.0!
        '
        'txtob_address
        '
        Me.txtob_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtob_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtob_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtob_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtob_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.DataField = "ob_address"
        Me.txtob_address.Height = 0.1979167!
        Me.txtob_address.Left = 3.297244!
        Me.txtob_address.Name = "txtob_address"
        Me.txtob_address.Style = "color: Red; "
        Me.txtob_address.Text = "ob_address"
        Me.txtob_address.Top = 0.2952756!
        Me.txtob_address.Visible = False
        Me.txtob_address.Width = 1.0!
        '
        'txtdest_remark
        '
        Me.txtdest_remark.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.DataField = "dest_remark"
        Me.txtdest_remark.Height = 0.1979167!
        Me.txtdest_remark.Left = 4.330709!
        Me.txtdest_remark.Name = "txtdest_remark"
        Me.txtdest_remark.Style = "color: Red; "
        Me.txtdest_remark.Text = "dest_remark"
        Me.txtdest_remark.Top = 0.07381889!
        Me.txtdest_remark.Visible = False
        Me.txtdest_remark.Width = 1.0!
        '
        'txtcompany_fax
        '
        Me.txtcompany_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.DataField = "company_fax"
        Me.txtcompany_fax.Height = 0.1979167!
        Me.txtcompany_fax.Left = 0.2214567!
        Me.txtcompany_fax.Name = "txtcompany_fax"
        Me.txtcompany_fax.Style = "color: Red; "
        Me.txtcompany_fax.Text = "company_fax"
        Me.txtcompany_fax.Top = 0.2952756!
        Me.txtcompany_fax.Visible = False
        Me.txtcompany_fax.Width = 1.0!
        '
        'txtcompany_phone
        '
        Me.txtcompany_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.DataField = "company_phone"
        Me.txtcompany_phone.Height = 0.1979167!
        Me.txtcompany_phone.Left = 1.254921!
        Me.txtcompany_phone.Name = "txtcompany_phone"
        Me.txtcompany_phone.Style = "color: Red; "
        Me.txtcompany_phone.Text = "company_phone"
        Me.txtcompany_phone.Top = 0.2952756!
        Me.txtcompany_phone.Visible = False
        Me.txtcompany_phone.Width = 1.0!
        '
        'txtdestination_company
        '
        Me.txtdestination_company.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.DataField = "destination_company"
        Me.txtdestination_company.Height = 0.1979167!
        Me.txtdestination_company.Left = 0.1722441!
        Me.txtdestination_company.Name = "txtdestination_company"
        Me.txtdestination_company.Style = "color: Red; "
        Me.txtdestination_company.Text = "destination_company"
        Me.txtdestination_company.Top = 4.330709!
        Me.txtdestination_company.Visible = False
        Me.txtdestination_company.Width = 1.0!
        '
        'txtdestination_fax
        '
        Me.txtdestination_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.DataField = "destination_fax"
        Me.txtdestination_fax.Height = 0.1979167!
        Me.txtdestination_fax.Left = 1.205709!
        Me.txtdestination_fax.Name = "txtdestination_fax"
        Me.txtdestination_fax.Style = "color: Red; "
        Me.txtdestination_fax.Text = "destination_fax"
        Me.txtdestination_fax.Top = 4.330709!
        Me.txtdestination_fax.Visible = False
        Me.txtdestination_fax.Width = 1.0!
        '
        'txtdestination_address
        '
        Me.txtdestination_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.DataField = "destination_address"
        Me.txtdestination_address.Height = 0.1979167!
        Me.txtdestination_address.Left = 1.205709!
        Me.txtdestination_address.Name = "txtdestination_address"
        Me.txtdestination_address.Style = "color: Red; "
        Me.txtdestination_address.Text = "destination_address"
        Me.txtdestination_address.Top = 4.625985!
        Me.txtdestination_address.Visible = False
        Me.txtdestination_address.Width = 1.0!
        '
        'txtdestination_phone
        '
        Me.txtdestination_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.DataField = "destination_phone"
        Me.txtdestination_phone.Height = 0.1979167!
        Me.txtdestination_phone.Left = 0.1722441!
        Me.txtdestination_phone.Name = "txtdestination_phone"
        Me.txtdestination_phone.Style = "color: Red; "
        Me.txtdestination_phone.Text = "destination_phone"
        Me.txtdestination_phone.Top = 4.615732!
        Me.txtdestination_phone.Visible = False
        Me.txtdestination_phone.Width = 1.0!
        '
        'txtdestination_province
        '
        Me.txtdestination_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.DataField = "destination_province"
        Me.txtdestination_province.Height = 0.1979167!
        Me.txtdestination_province.Left = 2.239173!
        Me.txtdestination_province.Name = "txtdestination_province"
        Me.txtdestination_province.Style = "color: Red; "
        Me.txtdestination_province.Text = "destination_province"
        Me.txtdestination_province.Top = 4.330709!
        Me.txtdestination_province.Visible = False
        Me.txtdestination_province.Width = 1.0!
        '
        'txtdest_Receive_country
        '
        Me.txtdest_Receive_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.DataField = "dest_Receive_country"
        Me.txtdest_Receive_country.Height = 0.1979167!
        Me.txtdest_Receive_country.Left = 2.239173!
        Me.txtdest_Receive_country.Name = "txtdest_Receive_country"
        Me.txtdest_Receive_country.Style = "color: Red; "
        Me.txtdest_Receive_country.Text = "dest_Receive_country"
        Me.txtdest_Receive_country.Top = 4.591125!
        Me.txtdest_Receive_country.Visible = False
        Me.txtdest_Receive_country.Width = 1.0!
        '
        'txtreference_code2
        '
        Me.txtreference_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.DataField = "reference_code2"
        Me.txtreference_code2.Height = 0.3937007!
        Me.txtreference_code2.Left = 5.487205!
        Me.txtreference_code2.Name = "txtreference_code2"
        Me.txtreference_code2.Style = "color: Red; ddo-char-set: 222; font-weight: bold; font-size: 13pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtreference_code2.Text = "reference_code2"
        Me.txtreference_code2.Top = 0.9104334!
        Me.txtreference_code2.Visible = False
        Me.txtreference_code2.Width = 1.648622!
        '
        'txtcompany_email
        '
        Me.txtcompany_email.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.DataField = "company_email"
        Me.txtcompany_email.Height = 0.1979167!
        Me.txtcompany_email.Left = 4.330709!
        Me.txtcompany_email.Name = "txtcompany_email"
        Me.txtcompany_email.Style = "color: Red; "
        Me.txtcompany_email.Text = "company_email"
        Me.txtcompany_email.Top = 0.3342356!
        Me.txtcompany_email.Visible = False
        Me.txtcompany_email.Width = 1.0!
        '
        'txtdestination_email
        '
        Me.txtdestination_email.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.DataField = "destination_email"
        Me.txtdestination_email.Height = 0.1979167!
        Me.txtdestination_email.Left = 4.330709!
        Me.txtdestination_email.Name = "txtdestination_email"
        Me.txtdestination_email.Style = "color: Red; "
        Me.txtdestination_email.Text = "destination_email"
        Me.txtdestination_email.Top = 0.5946523!
        Me.txtdestination_email.Visible = False
        Me.txtdestination_email.Width = 1.0!
        '
        'txtdestination_taxid
        '
        Me.txtdestination_taxid.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.DataField = "destination_taxid"
        Me.txtdestination_taxid.Height = 0.1979167!
        Me.txtdestination_taxid.Left = 4.330709!
        Me.txtdestination_taxid.Name = "txtdestination_taxid"
        Me.txtdestination_taxid.Style = "color: Red; "
        Me.txtdestination_taxid.Text = "destination_taxid"
        Me.txtdestination_taxid.Top = 0.8550687!
        Me.txtdestination_taxid.Visible = False
        Me.txtdestination_taxid.Width = 1.0!
        '
        'txtdest_remark1
        '
        Me.txtdest_remark1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.DataField = "dest_remark1"
        Me.txtdest_remark1.Height = 0.1979167!
        Me.txtdest_remark1.Left = 4.330709!
        Me.txtdest_remark1.Name = "txtdest_remark1"
        Me.txtdest_remark1.Style = "color: Red; "
        Me.txtdest_remark1.Text = "dest_remark1"
        Me.txtdest_remark1.Top = 1.115486!
        Me.txtdest_remark1.Visible = False
        Me.txtdest_remark1.Width = 1.0!
        '
        'txtob_dest_address
        '
        Me.txtob_dest_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.DataField = "ob_dest_address"
        Me.txtob_dest_address.Height = 0.1979167!
        Me.txtob_dest_address.Left = 4.330709!
        Me.txtob_dest_address.Name = "txtob_dest_address"
        Me.txtob_dest_address.Style = "color: Red; "
        Me.txtob_dest_address.Text = "ob_dest_address"
        Me.txtob_dest_address.Top = 1.375903!
        Me.txtob_dest_address.Visible = False
        Me.txtob_dest_address.Width = 1.0!
        '
        'txtdeparture_date
        '
        Me.txtdeparture_date.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdeparture_date.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdeparture_date.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdeparture_date.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdeparture_date.Border.RightColor = System.Drawing.Color.Black
        Me.txtdeparture_date.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdeparture_date.Border.TopColor = System.Drawing.Color.Black
        Me.txtdeparture_date.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdeparture_date.DataField = "departure_date"
        Me.txtdeparture_date.Height = 0.319882!
        Me.txtdeparture_date.Left = 0.5413386!
        Me.txtdeparture_date.Name = "txtdeparture_date"
        Me.txtdeparture_date.OutputFormat = resources.GetString("txtdeparture_date.OutputFormat")
        Me.txtdeparture_date.Style = "color: Blue; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtdeparture_date.Text = "departure_date"
        Me.txtdeparture_date.Top = 2.951854!
        Me.txtdeparture_date.Width = 3.567913!
        '
        'txtvasel_name
        '
        Me.txtvasel_name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtvasel_name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvasel_name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtvasel_name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvasel_name.Border.RightColor = System.Drawing.Color.Black
        Me.txtvasel_name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvasel_name.Border.TopColor = System.Drawing.Color.Black
        Me.txtvasel_name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvasel_name.DataField = "vasel_name"
        Me.txtvasel_name.Height = 0.319882!
        Me.txtvasel_name.Left = 0.5413386!
        Me.txtvasel_name.Name = "txtvasel_name"
        Me.txtvasel_name.Style = "color: Blue; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtvasel_name.Text = "vasel_name"
        Me.txtvasel_name.Top = 3.289699!
        Me.txtvasel_name.Width = 3.567913!
        '
        'txtport_discharge
        '
        Me.txtport_discharge.Border.BottomColor = System.Drawing.Color.Black
        Me.txtport_discharge.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtport_discharge.Border.LeftColor = System.Drawing.Color.Black
        Me.txtport_discharge.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtport_discharge.Border.RightColor = System.Drawing.Color.Black
        Me.txtport_discharge.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtport_discharge.Border.TopColor = System.Drawing.Color.Black
        Me.txtport_discharge.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtport_discharge.DataField = "port_discharge"
        Me.txtport_discharge.Height = 0.319882!
        Me.txtport_discharge.Left = 0.5413386!
        Me.txtport_discharge.Name = "txtport_discharge"
        Me.txtport_discharge.Style = "color: Blue; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtport_discharge.Text = "port_discharge"
        Me.txtport_discharge.Top = 3.658792!
        Me.txtport_discharge.Width = 3.567913!
        '
        'ReportInfo1
        '
        Me.ReportInfo1.Border.BottomColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.LeftColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.RightColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.TopColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.FormatString = Nothing
        Me.ReportInfo1.Height = 0.3125!
        Me.ReportInfo1.Left = 3.5625!
        Me.ReportInfo1.Name = "ReportInfo1"
        Me.ReportInfo1.Style = "color: Blue; text-align: center; font-family: BrowalliaUPC; vertical-align: botto" &
    "m; "
        Me.ReportInfo1.Top = 4.1875!
        Me.ReportInfo1.Width = 1.5!
        '
        'txtform_type
        '
        Me.txtform_type.Border.BottomColor = System.Drawing.Color.Black
        Me.txtform_type.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtform_type.Border.LeftColor = System.Drawing.Color.Black
        Me.txtform_type.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtform_type.Border.RightColor = System.Drawing.Color.Black
        Me.txtform_type.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtform_type.Border.TopColor = System.Drawing.Color.Black
        Me.txtform_type.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtform_type.DataField = "form_type"
        Me.txtform_type.Height = 0.1979167!
        Me.txtform_type.Left = 4.330709!
        Me.txtform_type.Name = "txtform_type"
        Me.txtform_type.Style = "color: Red; "
        Me.txtform_type.Text = Nothing
        Me.txtform_type.Top = 1.63632!
        Me.txtform_type.Visible = False
        Me.txtform_type.Width = 1.0!
        '
        'txtNewEmail_ch02
        '
        Me.txtNewEmail_ch02.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.RightColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.TopColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.DataField = "NewEmail_ch02"
        Me.txtNewEmail_ch02.Height = 0.1979167!
        Me.txtNewEmail_ch02.Left = 6.520669!
        Me.txtNewEmail_ch02.Name = "txtNewEmail_ch02"
        Me.txtNewEmail_ch02.Style = "color: Red; "
        Me.txtNewEmail_ch02.Text = "NewEmail_ch02"
        Me.txtNewEmail_ch02.Top = 1.366634!
        Me.txtNewEmail_ch02.Visible = False
        Me.txtNewEmail_ch02.Width = 1.0!
        '
        'txtNewEmail_ch01
        '
        Me.txtNewEmail_ch01.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.RightColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.TopColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.DataField = "NewEmail_ch01"
        Me.txtNewEmail_ch01.Height = 0.1979167!
        Me.txtNewEmail_ch01.Left = 5.487205!
        Me.txtNewEmail_ch01.Name = "txtNewEmail_ch01"
        Me.txtNewEmail_ch01.Style = "color: Red; "
        Me.txtNewEmail_ch01.Text = "NewEmail_ch01"
        Me.txtNewEmail_ch01.Top = 1.366634!
        Me.txtNewEmail_ch01.Visible = False
        Me.txtNewEmail_ch01.Width = 1.0!
        '
        'txtTitleHead
        '
        Me.txtTitleHead.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTitleHead.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleHead.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTitleHead.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleHead.Border.RightColor = System.Drawing.Color.Black
        Me.txtTitleHead.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleHead.Border.TopColor = System.Drawing.Color.Black
        Me.txtTitleHead.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleHead.Height = 0.25!
        Me.txtTitleHead.Left = 1.88!
        Me.txtTitleHead.Name = "txtTitleHead"
        Me.txtTitleHead.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtTitleHead.Text = Nothing
        Me.txtTitleHead.Top = 4.6177!
        Me.txtTitleHead.Visible = False
        Me.txtTitleHead.Width = 3.5!
        '
        'Line9
        '
        Me.Line9.Border.BottomColor = System.Drawing.Color.Black
        Me.Line9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.LeftColor = System.Drawing.Color.Black
        Me.Line9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.RightColor = System.Drawing.Color.Black
        Me.Line9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.TopColor = System.Drawing.Color.Black
        Me.Line9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Height = 0!
        Me.Line9.Left = 0.0625!
        Me.Line9.LineWeight = 1.0!
        Me.Line9.Name = "Line9"
        Me.Line9.Top = 0.0625!
        Me.Line9.Width = 8.125!
        Me.Line9.X1 = 0.0625!
        Me.Line9.X2 = 8.1875!
        Me.Line9.Y1 = 0.0625!
        Me.Line9.Y2 = 0.0625!
        '
        'Line8
        '
        Me.Line8.Border.BottomColor = System.Drawing.Color.Black
        Me.Line8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.LeftColor = System.Drawing.Color.Black
        Me.Line8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.RightColor = System.Drawing.Color.Black
        Me.Line8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.TopColor = System.Drawing.Color.Black
        Me.Line8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Height = 4.5!
        Me.Line8.Left = 0.0625!
        Me.Line8.LineWeight = 1.0!
        Me.Line8.Name = "Line8"
        Me.Line8.Top = 0.0625!
        Me.Line8.Width = 0!
        Me.Line8.X1 = 0.0625!
        Me.Line8.X2 = 0.0625!
        Me.Line8.Y1 = 4.5625!
        Me.Line8.Y2 = 0.0625!
        '
        'Line13
        '
        Me.Line13.Border.BottomColor = System.Drawing.Color.Black
        Me.Line13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.LeftColor = System.Drawing.Color.Black
        Me.Line13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.RightColor = System.Drawing.Color.Black
        Me.Line13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.TopColor = System.Drawing.Color.Black
        Me.Line13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Height = 0!
        Me.Line13.Left = 0.0625!
        Me.Line13.LineWeight = 1.0!
        Me.Line13.Name = "Line13"
        Me.Line13.Top = 1.3125!
        Me.Line13.Width = 4.25!
        Me.Line13.X1 = 0.0625!
        Me.Line13.X2 = 4.3125!
        Me.Line13.Y1 = 1.3125!
        Me.Line13.Y2 = 1.3125!
        '
        'Line14
        '
        Me.Line14.Border.BottomColor = System.Drawing.Color.Black
        Me.Line14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.LeftColor = System.Drawing.Color.Black
        Me.Line14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.RightColor = System.Drawing.Color.Black
        Me.Line14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.TopColor = System.Drawing.Color.Black
        Me.Line14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Height = 0!
        Me.Line14.Left = 0.0625!
        Me.Line14.LineWeight = 1.0!
        Me.Line14.Name = "Line14"
        Me.Line14.Top = 2.3125!
        Me.Line14.Width = 8.125!
        Me.Line14.X1 = 0.0625!
        Me.Line14.X2 = 8.1875!
        Me.Line14.Y1 = 2.3125!
        Me.Line14.Y2 = 2.3125!
        '
        'Line12
        '
        Me.Line12.Border.BottomColor = System.Drawing.Color.Black
        Me.Line12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.LeftColor = System.Drawing.Color.Black
        Me.Line12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.RightColor = System.Drawing.Color.Black
        Me.Line12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.TopColor = System.Drawing.Color.Black
        Me.Line12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Height = 0!
        Me.Line12.Left = 0.0625!
        Me.Line12.LineWeight = 1.0!
        Me.Line12.Name = "Line12"
        Me.Line12.Top = 3.9375!
        Me.Line12.Width = 8.125!
        Me.Line12.X1 = 0.0625!
        Me.Line12.X2 = 8.1875!
        Me.Line12.Y1 = 3.9375!
        Me.Line12.Y2 = 3.9375!
        '
        'Line3
        '
        Me.Line3.Border.BottomColor = System.Drawing.Color.Black
        Me.Line3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.LeftColor = System.Drawing.Color.Black
        Me.Line3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.RightColor = System.Drawing.Color.Black
        Me.Line3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.TopColor = System.Drawing.Color.Black
        Me.Line3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Height = 0!
        Me.Line3.Left = 0.0625!
        Me.Line3.LineWeight = 1.0!
        Me.Line3.Name = "Line3"
        Me.Line3.Top = 4.5625!
        Me.Line3.Width = 8.125!
        Me.Line3.X1 = 0.0625!
        Me.Line3.X2 = 8.1875!
        Me.Line3.Y1 = 4.5625!
        Me.Line3.Y2 = 4.5625!
        '
        'Label42
        '
        Me.Label42.Border.BottomColor = System.Drawing.Color.Black
        Me.Label42.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label42.Border.LeftColor = System.Drawing.Color.Black
        Me.Label42.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label42.Border.RightColor = System.Drawing.Color.Black
        Me.Label42.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label42.Border.TopColor = System.Drawing.Color.Black
        Me.Label42.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label42.Height = 0.3125!
        Me.Label42.HyperLink = Nothing
        Me.Label42.Left = 0.1875!
        Me.Label42.Name = "Label42"
        Me.Label42.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label42.Text = "5. Item number"
        Me.Label42.Top = 4.0!
        Me.Label42.Width = 0.5625!
        '
        'Label43
        '
        Me.Label43.Border.BottomColor = System.Drawing.Color.Black
        Me.Label43.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label43.Border.LeftColor = System.Drawing.Color.Black
        Me.Label43.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label43.Border.RightColor = System.Drawing.Color.Black
        Me.Label43.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label43.Border.TopColor = System.Drawing.Color.Black
        Me.Label43.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label43.Height = 0.4375!
        Me.Label43.HyperLink = Nothing
        Me.Label43.Left = 1.0!
        Me.Label43.Name = "Label43"
        Me.Label43.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label43.Text = "6. Marks and    numbers on packages "
        Me.Label43.Top = 4.0!
        Me.Label43.Width = 0.875!
        '
        'Label44
        '
        Me.Label44.Border.BottomColor = System.Drawing.Color.Black
        Me.Label44.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label44.Border.LeftColor = System.Drawing.Color.Black
        Me.Label44.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label44.Border.RightColor = System.Drawing.Color.Black
        Me.Label44.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label44.Border.TopColor = System.Drawing.Color.Black
        Me.Label44.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label44.Height = 0.4375!
        Me.Label44.HyperLink = Nothing
        Me.Label44.Left = 2.0625!
        Me.Label44.Name = "Label44"
        Me.Label44.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label44.Text = "7. Number and type of packages, description of goods (including quantity where ap" &
    "propriate and HS number of the importing country)"
        Me.Label44.Top = 4.0!
        Me.Label44.Width = 2.8125!
        '
        'Line11
        '
        Me.Line11.Border.BottomColor = System.Drawing.Color.Black
        Me.Line11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.LeftColor = System.Drawing.Color.Black
        Me.Line11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.RightColor = System.Drawing.Color.Black
        Me.Line11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.TopColor = System.Drawing.Color.Black
        Me.Line11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Height = 3.875!
        Me.Line11.Left = 4.3125!
        Me.Line11.LineWeight = 1.0!
        Me.Line11.Name = "Line11"
        Me.Line11.Top = 0.0625!
        Me.Line11.Width = 0!
        Me.Line11.X1 = 4.3125!
        Me.Line11.X2 = 4.3125!
        Me.Line11.Y1 = 3.9375!
        Me.Line11.Y2 = 0.0625!
        '
        'Label3
        '
        Me.Label3.Border.BottomColor = System.Drawing.Color.Black
        Me.Label3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.LeftColor = System.Drawing.Color.Black
        Me.Label3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.RightColor = System.Drawing.Color.Black
        Me.Label3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.TopColor = System.Drawing.Color.Black
        Me.Label3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Height = 0.1875!
        Me.Label3.HyperLink = Nothing
        Me.Label3.Left = 0.3125!
        Me.Label3.Name = "Label3"
        Me.Label3.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label3.Text = "3. Means of transport and route (as far as known)"
        Me.Label3.Top = 2.375!
        Me.Label3.Width = 3.875!
        '
        'Label2
        '
        Me.Label2.Border.BottomColor = System.Drawing.Color.Black
        Me.Label2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.LeftColor = System.Drawing.Color.Black
        Me.Label2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.RightColor = System.Drawing.Color.Black
        Me.Label2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.TopColor = System.Drawing.Color.Black
        Me.Label2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Height = 0.1875!
        Me.Label2.HyperLink = Nothing
        Me.Label2.Left = 0.4375!
        Me.Label2.Name = "Label2"
        Me.Label2.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label2.Text = "Departure date"
        Me.Label2.Top = 2.75!
        Me.Label2.Width = 3.75!
        '
        'Label5
        '
        Me.Label5.Border.BottomColor = System.Drawing.Color.Black
        Me.Label5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.LeftColor = System.Drawing.Color.Black
        Me.Label5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.RightColor = System.Drawing.Color.Black
        Me.Label5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.TopColor = System.Drawing.Color.Black
        Me.Label5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Height = 0.1875!
        Me.Label5.HyperLink = Nothing
        Me.Label5.Left = 0.4375!
        Me.Label5.Name = "Label5"
        Me.Label5.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label5.Text = "Vessel's name / Aircraft etc."
        Me.Label5.Top = 3.125!
        Me.Label5.Width = 3.75!
        '
        'Label4
        '
        Me.Label4.Border.BottomColor = System.Drawing.Color.Black
        Me.Label4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.LeftColor = System.Drawing.Color.Black
        Me.Label4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.RightColor = System.Drawing.Color.Black
        Me.Label4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.TopColor = System.Drawing.Color.Black
        Me.Label4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Height = 0.1875!
        Me.Label4.HyperLink = Nothing
        Me.Label4.Left = 0.4375!
        Me.Label4.Name = "Label4"
        Me.Label4.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label4.Text = "Port of Discharge"
        Me.Label4.Top = 3.5!
        Me.Label4.Width = 3.75!
        '
        'Label1
        '
        Me.Label1.Border.BottomColor = System.Drawing.Color.Black
        Me.Label1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.LeftColor = System.Drawing.Color.Black
        Me.Label1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.RightColor = System.Drawing.Color.Black
        Me.Label1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.TopColor = System.Drawing.Color.Black
        Me.Label1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Height = 0.1875!
        Me.Label1.HyperLink = Nothing
        Me.Label1.Left = 0.3125!
        Me.Label1.Name = "Label1"
        Me.Label1.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label1.Text = "2. Goods consigned to (Consignee's name, address, country)"
        Me.Label1.Top = 1.375!
        Me.Label1.Width = 4.0!
        '
        'Label8
        '
        Me.Label8.Border.BottomColor = System.Drawing.Color.Black
        Me.Label8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.LeftColor = System.Drawing.Color.Black
        Me.Label8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.RightColor = System.Drawing.Color.Black
        Me.Label8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.TopColor = System.Drawing.Color.Black
        Me.Label8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Height = 0.1875!
        Me.Label8.HyperLink = Nothing
        Me.Label8.Left = 0.3125!
        Me.Label8.Name = "Label8"
        Me.Label8.Style = "font-size: 9pt; font-family: Times New Roman; "
        Me.Label8.Text = "1. Goods consigned from (Exporter's business name, address, country)"
        Me.Label8.Top = 0.25!
        Me.Label8.Width = 4.0!
        '
        'Label7
        '
        Me.Label7.Border.BottomColor = System.Drawing.Color.Black
        Me.Label7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.LeftColor = System.Drawing.Color.Black
        Me.Label7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.RightColor = System.Drawing.Color.Black
        Me.Label7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.TopColor = System.Drawing.Color.Black
        Me.Label7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Height = 0.25!
        Me.Label7.HyperLink = Nothing
        Me.Label7.Left = 4.5!
        Me.Label7.Name = "Label7"
        Me.Label7.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label7.Text = "Reference No."
        Me.Label7.Top = 0.25!
        Me.Label7.Width = 0.875!
        '
        'Label16
        '
        Me.Label16.Border.BottomColor = System.Drawing.Color.Black
        Me.Label16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.LeftColor = System.Drawing.Color.Black
        Me.Label16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.RightColor = System.Drawing.Color.Black
        Me.Label16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.TopColor = System.Drawing.Color.Black
        Me.Label16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Height = 0.5625!
        Me.Label16.HyperLink = Nothing
        Me.Label16.Left = 4.75!
        Me.Label16.Name = "Label16"
        Me.Label16.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 9.75pt; font-f" &
    "amily: Times New Roman; "
        Me.Label16.Text = "ASEAN TRADE IN GOODS AGREEMENT / ASEAN INDUSTRIAL COOPERATION SCHEME CERTIFICATE " &
    "OF ORIGIN"
        Me.Label16.Top = 0.625!
        Me.Label16.Width = 3.125!
        '
        'Label21
        '
        Me.Label21.Border.BottomColor = System.Drawing.Color.Black
        Me.Label21.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.LeftColor = System.Drawing.Color.Black
        Me.Label21.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.RightColor = System.Drawing.Color.Black
        Me.Label21.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.TopColor = System.Drawing.Color.Black
        Me.Label21.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Height = 0.25!
        Me.Label21.HyperLink = Nothing
        Me.Label21.Left = 5.6875!
        Me.Label21.Name = "Label21"
        Me.Label21.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 12pt; font-fam" &
    "ily: Times New Roman; "
        Me.Label21.Text = "THAILAND"
        Me.Label21.Top = 1.625!
        Me.Label21.Width = 1.3125!
        '
        'Label17
        '
        Me.Label17.Border.BottomColor = System.Drawing.Color.Black
        Me.Label17.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.LeftColor = System.Drawing.Color.Black
        Me.Label17.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.RightColor = System.Drawing.Color.Black
        Me.Label17.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.TopColor = System.Drawing.Color.Black
        Me.Label17.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Height = 0.1875!
        Me.Label17.HyperLink = Nothing
        Me.Label17.Left = 4.875!
        Me.Label17.Name = "Label17"
        Me.Label17.Style = "text-align: left; font-size: 9pt; font-family: Times New Roman; "
        Me.Label17.Text = "Issued in"
        Me.Label17.Top = 1.6875!
        Me.Label17.Width = 0.5625!
        '
        'Label22
        '
        Me.Label22.Border.BottomColor = System.Drawing.Color.Black
        Me.Label22.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.LeftColor = System.Drawing.Color.Black
        Me.Label22.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.RightColor = System.Drawing.Color.Black
        Me.Label22.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.TopColor = System.Drawing.Color.Black
        Me.Label22.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Height = 0.25!
        Me.Label22.HyperLink = Nothing
        Me.Label22.Left = 5.8125!
        Me.Label22.Name = "Label22"
        Me.Label22.Style = "color: Blue; ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 1" &
    "1.25pt; font-family: Times New Roman; "
        Me.Label22.Text = "FORM D"
        Me.Label22.Top = 1.375!
        Me.Label22.Width = 0.8125!
        '
        'Line19
        '
        Me.Line19.Border.BottomColor = System.Drawing.Color.Black
        Me.Line19.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.LeftColor = System.Drawing.Color.Black
        Me.Line19.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.RightColor = System.Drawing.Color.Black
        Me.Line19.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.TopColor = System.Drawing.Color.Black
        Me.Line19.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Height = 0!
        Me.Line19.Left = 5.375!
        Me.Line19.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line19.LineWeight = 1.0!
        Me.Line19.Name = "Line19"
        Me.Line19.Top = 1.8125!
        Me.Line19.Width = 2.4375!
        Me.Line19.X1 = 5.375!
        Me.Line19.X2 = 7.8125!
        Me.Line19.Y1 = 1.8125!
        Me.Line19.Y2 = 1.8125!
        '
        'Label19
        '
        Me.Label19.Border.BottomColor = System.Drawing.Color.Black
        Me.Label19.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.LeftColor = System.Drawing.Color.Black
        Me.Label19.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.RightColor = System.Drawing.Color.Black
        Me.Label19.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.TopColor = System.Drawing.Color.Black
        Me.Label19.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Height = 0.1875!
        Me.Label19.HyperLink = Nothing
        Me.Label19.Left = 5.4375!
        Me.Label19.Name = "Label19"
        Me.Label19.Style = "text-align: center; font-size: 9pt; font-family: Times New Roman; "
        Me.Label19.Text = "(Country)"
        Me.Label19.Top = 1.8125!
        Me.Label19.Width = 1.8125!
        '
        'Label6
        '
        Me.Label6.Border.BottomColor = System.Drawing.Color.Black
        Me.Label6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.LeftColor = System.Drawing.Color.Black
        Me.Label6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.RightColor = System.Drawing.Color.Black
        Me.Label6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.TopColor = System.Drawing.Color.Black
        Me.Label6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Height = 0.1875!
        Me.Label6.HyperLink = Nothing
        Me.Label6.Left = 4.5!
        Me.Label6.Name = "Label6"
        Me.Label6.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label6.Text = "4. For Official Use"
        Me.Label6.Top = 2.375!
        Me.Label6.Width = 2.5625!
        '
        'Shape1
        '
        Me.Shape1.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.RightColor = System.Drawing.Color.Black
        Me.Shape1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.TopColor = System.Drawing.Color.Black
        Me.Shape1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Height = 0.25!
        Me.Shape1.Left = 4.625!
        Me.Shape1.Name = "Shape1"
        Me.Shape1.RoundingRadius = 9.999999!
        Me.Shape1.Top = 2.625!
        Me.Shape1.Width = 0.25!
        '
        'Label29
        '
        Me.Label29.Border.BottomColor = System.Drawing.Color.Black
        Me.Label29.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.LeftColor = System.Drawing.Color.Black
        Me.Label29.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.RightColor = System.Drawing.Color.Black
        Me.Label29.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.TopColor = System.Drawing.Color.Black
        Me.Label29.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Height = 0.1875!
        Me.Label29.HyperLink = Nothing
        Me.Label29.Left = 4.9375!
        Me.Label29.Name = "Label29"
        Me.Label29.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label29.Text = "Preferential Treatment Given Under ASEAN"
        Me.Label29.Top = 2.625!
        Me.Label29.Width = 3.125!
        '
        'Label31
        '
        Me.Label31.Border.BottomColor = System.Drawing.Color.Black
        Me.Label31.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.LeftColor = System.Drawing.Color.Black
        Me.Label31.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.RightColor = System.Drawing.Color.Black
        Me.Label31.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.TopColor = System.Drawing.Color.Black
        Me.Label31.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Height = 0.1875!
        Me.Label31.HyperLink = Nothing
        Me.Label31.Left = 4.9375!
        Me.Label31.Name = "Label31"
        Me.Label31.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label31.Text = "Preferential Treatment Given Under ASEAN"
        Me.Label31.Top = 2.9375!
        Me.Label31.Width = 3.125!
        '
        'Label30
        '
        Me.Label30.Border.BottomColor = System.Drawing.Color.Black
        Me.Label30.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.LeftColor = System.Drawing.Color.Black
        Me.Label30.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.RightColor = System.Drawing.Color.Black
        Me.Label30.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.TopColor = System.Drawing.Color.Black
        Me.Label30.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Height = 0.1875!
        Me.Label30.HyperLink = Nothing
        Me.Label30.Left = 4.9375!
        Me.Label30.Name = "Label30"
        Me.Label30.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label30.Text = "Common Effective Preferential Tariff Scheme"
        Me.Label30.Top = 2.75!
        Me.Label30.Width = 3.125!
        '
        'Shape2
        '
        Me.Shape2.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Border.RightColor = System.Drawing.Color.Black
        Me.Shape2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Border.TopColor = System.Drawing.Color.Black
        Me.Shape2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Height = 0.25!
        Me.Shape2.Left = 4.625!
        Me.Shape2.Name = "Shape2"
        Me.Shape2.RoundingRadius = 9.999999!
        Me.Shape2.Top = 2.9375!
        Me.Shape2.Width = 0.25!
        '
        'Shape3
        '
        Me.Shape3.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Border.RightColor = System.Drawing.Color.Black
        Me.Shape3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Border.TopColor = System.Drawing.Color.Black
        Me.Shape3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Height = 0.25!
        Me.Shape3.Left = 4.625!
        Me.Shape3.Name = "Shape3"
        Me.Shape3.RoundingRadius = 9.999999!
        Me.Shape3.Top = 3.3125!
        Me.Shape3.Width = 0.25!
        '
        'Label33
        '
        Me.Label33.Border.BottomColor = System.Drawing.Color.Black
        Me.Label33.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.LeftColor = System.Drawing.Color.Black
        Me.Label33.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.RightColor = System.Drawing.Color.Black
        Me.Label33.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.TopColor = System.Drawing.Color.Black
        Me.Label33.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Height = 0.1875!
        Me.Label33.HyperLink = Nothing
        Me.Label33.Left = 4.9375!
        Me.Label33.Name = "Label33"
        Me.Label33.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label33.Text = "Preferential Treatment Not Given (Please state reason/s)"
        Me.Label33.Top = 3.3125!
        Me.Label33.Width = 3.125!
        '
        'Label48
        '
        Me.Label48.Border.BottomColor = System.Drawing.Color.Black
        Me.Label48.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label48.Border.LeftColor = System.Drawing.Color.Black
        Me.Label48.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label48.Border.RightColor = System.Drawing.Color.Black
        Me.Label48.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label48.Border.TopColor = System.Drawing.Color.Black
        Me.Label48.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label48.Height = 0.4375!
        Me.Label48.HyperLink = Nothing
        Me.Label48.Left = 7.1875!
        Me.Label48.Name = "Label48"
        Me.Label48.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label48.Text = "10. Number and date of invoices"
        Me.Label48.Top = 4.0!
        Me.Label48.Width = 0.875!
        '
        'Label47
        '
        Me.Label47.Border.BottomColor = System.Drawing.Color.Black
        Me.Label47.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label47.Border.LeftColor = System.Drawing.Color.Black
        Me.Label47.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label47.Border.RightColor = System.Drawing.Color.Black
        Me.Label47.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label47.Border.TopColor = System.Drawing.Color.Black
        Me.Label47.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label47.Height = 0.4375!
        Me.Label47.HyperLink = Nothing
        Me.Label47.Left = 6.125!
        Me.Label47.Name = "Label47"
        Me.Label47.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label47.Text = "9. Gross weight or other quantity and value (FOB)"
        Me.Label47.Top = 4.0!
        Me.Label47.Width = 0.875!
        '
        'Label46
        '
        Me.Label46.Border.BottomColor = System.Drawing.Color.Black
        Me.Label46.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label46.Border.LeftColor = System.Drawing.Color.Black
        Me.Label46.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label46.Border.RightColor = System.Drawing.Color.Black
        Me.Label46.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label46.Border.TopColor = System.Drawing.Color.Black
        Me.Label46.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label46.Height = 0.3125!
        Me.Label46.HyperLink = Nothing
        Me.Label46.Left = 5.5!
        Me.Label46.Name = "Label46"
        Me.Label46.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label46.Text = "8. Origin criterion"
        Me.Label46.Top = 4.0!
        Me.Label46.Width = 0.5625!
        '
        'Line10
        '
        Me.Line10.Border.BottomColor = System.Drawing.Color.Black
        Me.Line10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.LeftColor = System.Drawing.Color.Black
        Me.Line10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.RightColor = System.Drawing.Color.Black
        Me.Line10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.TopColor = System.Drawing.Color.Black
        Me.Line10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Height = 4.5!
        Me.Line10.Left = 8.1875!
        Me.Line10.LineWeight = 1.0!
        Me.Line10.Name = "Line10"
        Me.Line10.Top = 0.0625!
        Me.Line10.Width = 0!
        Me.Line10.X1 = 8.1875!
        Me.Line10.X2 = 8.1875!
        Me.Line10.Y1 = 0.0625!
        Me.Line10.Y2 = 4.5625!
        '
        'PageFooter1
        '
        Me.PageFooter1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.Pic_ch5_exhibi, Me.Pic_ch7_Issued, Me.Pic_ch6_demin, Me.Pic_ch4_par, Me.Pic_ch3_back, Me.Pic_ch1_third, Me.Pic_ch2_accu, Me.txtTemp_back_country, Me.txtIMPORT_COUNTRY, Me.txtcompany_provincefoot1, Me.txtcompany_provincefoot, Me.txtshow_check, Me.txtback_country, Me.txtinvh_run_auto, Me.txtCheckIssued, Me.txttotalSum_fob_amt, Me.Line27, Me.Line2, Me.Line20, Me.Label25, Me.Line25, Me.Line1, Me.Line6, Me.Line26, Me.Label23, Me.Label24, Me.Label10, Me.Label11, Me.Label26, Me.Label12, Me.Line16, Me.Label13, Me.Label28, Me.Label14, Me.Line17, Me.Label9, Me.Shape11, Me.Shape12, Me.Shape13, Me.Shape14, Me.Label52, Me.Label53, Me.Label54, Me.Label55, Me.Shape9, Me.Shape8, Me.Shape15, Me.Label51, Me.Label50, Me.Label49, Me.txtCheck_CaseRVCCount, Me.txtDisplayUDS7, Me.txtInvAgentType})
        Me.PageFooter1.Height = 4.22!
        Me.PageFooter1.Name = "PageFooter1"
        '
        'Pic_ch5_exhibi
        '
        Me.Pic_ch5_exhibi.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch5_exhibi.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch5_exhibi.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch5_exhibi.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch5_exhibi.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch5_exhibi.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch5_exhibi.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch5_exhibi.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch5_exhibi.Height = 0.3937008!
        Me.Pic_ch5_exhibi.Image = CType(resources.GetObject("Pic_ch5_exhibi.Image"), System.Drawing.Image)
        Me.Pic_ch5_exhibi.ImageData = CType(resources.GetObject("Pic_ch5_exhibi.ImageData"), System.IO.Stream)
        Me.Pic_ch5_exhibi.Left = 2.485236!
        Me.Pic_ch5_exhibi.LineWeight = 0!
        Me.Pic_ch5_exhibi.Name = "Pic_ch5_exhibi"
        Me.Pic_ch5_exhibi.Top = 2.43!
        Me.Pic_ch5_exhibi.Visible = False
        Me.Pic_ch5_exhibi.Width = 0.3937007!
        '
        'Pic_ch7_Issued
        '
        Me.Pic_ch7_Issued.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch7_Issued.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch7_Issued.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch7_Issued.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch7_Issued.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch7_Issued.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch7_Issued.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch7_Issued.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch7_Issued.Height = 0.3937008!
        Me.Pic_ch7_Issued.Image = CType(resources.GetObject("Pic_ch7_Issued.Image"), System.Drawing.Image)
        Me.Pic_ch7_Issued.ImageData = CType(resources.GetObject("Pic_ch7_Issued.ImageData"), System.IO.Stream)
        Me.Pic_ch7_Issued.Left = 2.485236!
        Me.Pic_ch7_Issued.LineWeight = 0!
        Me.Pic_ch7_Issued.Name = "Pic_ch7_Issued"
        Me.Pic_ch7_Issued.Top = 2.9!
        Me.Pic_ch7_Issued.Visible = False
        Me.Pic_ch7_Issued.Width = 0.3937008!
        '
        'Pic_ch6_demin
        '
        Me.Pic_ch6_demin.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch6_demin.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch6_demin.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch6_demin.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch6_demin.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch6_demin.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch6_demin.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch6_demin.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch6_demin.Height = 0.3937008!
        Me.Pic_ch6_demin.Image = CType(resources.GetObject("Pic_ch6_demin.Image"), System.Drawing.Image)
        Me.Pic_ch6_demin.ImageData = CType(resources.GetObject("Pic_ch6_demin.ImageData"), System.IO.Stream)
        Me.Pic_ch6_demin.Left = 2.485236!
        Me.Pic_ch6_demin.LineWeight = 0!
        Me.Pic_ch6_demin.Name = "Pic_ch6_demin"
        Me.Pic_ch6_demin.Top = 2.65!
        Me.Pic_ch6_demin.Visible = False
        Me.Pic_ch6_demin.Width = 0.3937008!
        '
        'Pic_ch4_par
        '
        Me.Pic_ch4_par.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch4_par.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch4_par.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch4_par.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch4_par.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch4_par.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch4_par.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch4_par.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch4_par.Height = 0.3937008!
        Me.Pic_ch4_par.Image = CType(resources.GetObject("Pic_ch4_par.Image"), System.Drawing.Image)
        Me.Pic_ch4_par.ImageData = CType(resources.GetObject("Pic_ch4_par.ImageData"), System.IO.Stream)
        Me.Pic_ch4_par.Left = 0.7940453!
        Me.Pic_ch4_par.LineWeight = 0!
        Me.Pic_ch4_par.Name = "Pic_ch4_par"
        Me.Pic_ch4_par.Top = 3.14!
        Me.Pic_ch4_par.Visible = False
        Me.Pic_ch4_par.Width = 0.3937008!
        '
        'Pic_ch3_back
        '
        Me.Pic_ch3_back.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch3_back.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch3_back.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch3_back.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch3_back.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch3_back.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch3_back.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch3_back.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch3_back.Height = 0.3937008!
        Me.Pic_ch3_back.Image = CType(resources.GetObject("Pic_ch3_back.Image"), System.Drawing.Image)
        Me.Pic_ch3_back.ImageData = CType(resources.GetObject("Pic_ch3_back.ImageData"), System.IO.Stream)
        Me.Pic_ch3_back.Left = 0.7940453!
        Me.Pic_ch3_back.LineWeight = 0!
        Me.Pic_ch3_back.Name = "Pic_ch3_back"
        Me.Pic_ch3_back.Top = 2.9!
        Me.Pic_ch3_back.Visible = False
        Me.Pic_ch3_back.Width = 0.3937008!
        '
        'Pic_ch1_third
        '
        Me.Pic_ch1_third.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch1_third.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch1_third.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch1_third.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch1_third.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch1_third.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch1_third.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch1_third.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch1_third.Height = 0.3937008!
        Me.Pic_ch1_third.Image = CType(resources.GetObject("Pic_ch1_third.Image"), System.Drawing.Image)
        Me.Pic_ch1_third.ImageData = CType(resources.GetObject("Pic_ch1_third.ImageData"), System.IO.Stream)
        Me.Pic_ch1_third.Left = 0.7940453!
        Me.Pic_ch1_third.LineWeight = 0!
        Me.Pic_ch1_third.Name = "Pic_ch1_third"
        Me.Pic_ch1_third.Top = 2.43!
        Me.Pic_ch1_third.Visible = False
        Me.Pic_ch1_third.Width = 0.3937008!
        '
        'Pic_ch2_accu
        '
        Me.Pic_ch2_accu.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch2_accu.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch2_accu.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch2_accu.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch2_accu.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch2_accu.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch2_accu.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch2_accu.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch2_accu.Height = 0.3937008!
        Me.Pic_ch2_accu.Image = CType(resources.GetObject("Pic_ch2_accu.Image"), System.Drawing.Image)
        Me.Pic_ch2_accu.ImageData = CType(resources.GetObject("Pic_ch2_accu.ImageData"), System.IO.Stream)
        Me.Pic_ch2_accu.Left = 0.7902723!
        Me.Pic_ch2_accu.LineWeight = 0!
        Me.Pic_ch2_accu.Name = "Pic_ch2_accu"
        Me.Pic_ch2_accu.Top = 2.65!
        Me.Pic_ch2_accu.Visible = False
        Me.Pic_ch2_accu.Width = 0.3937008!
        '
        'txtTemp_back_country
        '
        Me.txtTemp_back_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_back_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_back_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_back_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_back_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_back_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_back_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_back_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_back_country.Height = 0.3103673!
        Me.txtTemp_back_country.Left = 0.492126!
        Me.txtTemp_back_country.Name = "txtTemp_back_country"
        Me.txtTemp_back_country.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-weight: bold; font-size: 1" &
    "4pt; font-family: BrowalliaUPC; "
        Me.txtTemp_back_country.Text = Nothing
        Me.txtTemp_back_country.Top = 0.71!
        Me.txtTemp_back_country.Width = 3.469488!
        '
        'txtIMPORT_COUNTRY
        '
        Me.txtIMPORT_COUNTRY.Border.BottomColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.LeftColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.RightColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.TopColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.DataField = "IMPORT_COUNTRY"
        Me.txtIMPORT_COUNTRY.Height = 0.3937007!
        Me.txtIMPORT_COUNTRY.Left = 0.492126!
        Me.txtIMPORT_COUNTRY.Name = "txtIMPORT_COUNTRY"
        Me.txtIMPORT_COUNTRY.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-weight: bold; font-size: 1" &
    "4pt; font-family: BrowalliaUPC; vertical-align: bottom; "
        Me.txtIMPORT_COUNTRY.Text = "IMPORT_COUNTRY"
        Me.txtIMPORT_COUNTRY.Top = 1.41!
        Me.txtIMPORT_COUNTRY.Width = 3.469488!
        '
        'txtcompany_provincefoot1
        '
        Me.txtcompany_provincefoot1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.DataField = "company_province"
        Me.txtcompany_provincefoot1.Height = 0.1979167!
        Me.txtcompany_provincefoot1.Left = 6.668307!
        Me.txtcompany_provincefoot1.Name = "txtcompany_provincefoot1"
        Me.txtcompany_provincefoot1.Style = "color: Red; "
        Me.txtcompany_provincefoot1.Text = "company_province"
        Me.txtcompany_provincefoot1.Top = 0!
        Me.txtcompany_provincefoot1.Visible = False
        Me.txtcompany_provincefoot1.Width = 1.0!
        '
        'txtcompany_provincefoot
        '
        Me.txtcompany_provincefoot.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Height = 0.3937007!
        Me.txtcompany_provincefoot.Left = 0.5!
        Me.txtcompany_provincefoot.Name = "txtcompany_provincefoot"
        Me.txtcompany_provincefoot.Style = "color: Blue; ddo-char-set: 222; text-align: center; font-size: 12pt; font-family:" &
    " BrowalliaUPC; vertical-align: bottom; "
        Me.txtcompany_provincefoot.Text = Nothing
        Me.txtcompany_provincefoot.Top = 2.0!
        Me.txtcompany_provincefoot.Width = 3.469488!
        '
        'txtshow_check
        '
        Me.txtshow_check.Border.BottomColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.LeftColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.RightColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.TopColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.DataField = "show_check"
        Me.txtshow_check.Height = 0.1979167!
        Me.txtshow_check.Left = 6.668307!
        Me.txtshow_check.Name = "txtshow_check"
        Me.txtshow_check.Style = "color: Red; "
        Me.txtshow_check.Text = "show_check"
        Me.txtshow_check.Top = 0.2604167!
        Me.txtshow_check.Visible = False
        Me.txtshow_check.Width = 1.0!
        '
        'txtback_country
        '
        Me.txtback_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtback_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtback_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtback_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtback_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.DataField = "back_country"
        Me.txtback_country.Height = 0.1979167!
        Me.txtback_country.Left = 6.668307!
        Me.txtback_country.Name = "txtback_country"
        Me.txtback_country.Style = "color: Red; "
        Me.txtback_country.Text = "back_country"
        Me.txtback_country.Top = 0.5208334!
        Me.txtback_country.Visible = False
        Me.txtback_country.Width = 1.0!
        '
        'txtinvh_run_auto
        '
        Me.txtinvh_run_auto.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.DataField = "invh_run_auto"
        Me.txtinvh_run_auto.Height = 0.1979167!
        Me.txtinvh_run_auto.Left = 0!
        Me.txtinvh_run_auto.Name = "txtinvh_run_auto"
        Me.txtinvh_run_auto.Style = "color: Red; "
        Me.txtinvh_run_auto.Text = "invh_run_auto"
        Me.txtinvh_run_auto.Top = 0!
        Me.txtinvh_run_auto.Visible = False
        Me.txtinvh_run_auto.Width = 1.0!
        '
        'txtCheckIssued
        '
        Me.txtCheckIssued.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCheckIssued.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckIssued.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCheckIssued.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckIssued.Border.RightColor = System.Drawing.Color.Black
        Me.txtCheckIssued.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckIssued.Border.TopColor = System.Drawing.Color.Black
        Me.txtCheckIssued.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckIssued.DataField = "CheckIssued"
        Me.txtCheckIssued.Height = 0.1979167!
        Me.txtCheckIssued.Left = 6.668307!
        Me.txtCheckIssued.Name = "txtCheckIssued"
        Me.txtCheckIssued.Style = "color: Red; "
        Me.txtCheckIssued.Text = "CheckIssued"
        Me.txtCheckIssued.Top = 0.7812501!
        Me.txtCheckIssued.Visible = False
        Me.txtCheckIssued.Width = 1.0!
        '
        'txttotalSum_fob_amt
        '
        Me.txttotalSum_fob_amt.Border.BottomColor = System.Drawing.Color.Black
        Me.txttotalSum_fob_amt.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttotalSum_fob_amt.Border.LeftColor = System.Drawing.Color.Black
        Me.txttotalSum_fob_amt.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttotalSum_fob_amt.Border.RightColor = System.Drawing.Color.Black
        Me.txttotalSum_fob_amt.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttotalSum_fob_amt.Border.TopColor = System.Drawing.Color.Black
        Me.txttotalSum_fob_amt.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttotalSum_fob_amt.DataField = "totalSum_fob_amt"
        Me.txttotalSum_fob_amt.Height = 0.1979167!
        Me.txttotalSum_fob_amt.Left = 6.668307!
        Me.txttotalSum_fob_amt.Name = "txttotalSum_fob_amt"
        Me.txttotalSum_fob_amt.Style = "color: Red; "
        Me.txttotalSum_fob_amt.Text = "totalSum_fob_amt"
        Me.txttotalSum_fob_amt.Top = 1.041667!
        Me.txttotalSum_fob_amt.Visible = False
        Me.txttotalSum_fob_amt.Width = 1.0!
        '
        'Line27
        '
        Me.Line27.Border.BottomColor = System.Drawing.Color.Black
        Me.Line27.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line27.Border.LeftColor = System.Drawing.Color.Black
        Me.Line27.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line27.Border.RightColor = System.Drawing.Color.Black
        Me.Line27.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line27.Border.TopColor = System.Drawing.Color.Black
        Me.Line27.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line27.Height = 4.0!
        Me.Line27.Left = 8.1875!
        Me.Line27.LineWeight = 1.0!
        Me.Line27.Name = "Line27"
        Me.Line27.Top = 0!
        Me.Line27.Width = 0!
        Me.Line27.X1 = 8.1875!
        Me.Line27.X2 = 8.1875!
        Me.Line27.Y1 = 4.0!
        Me.Line27.Y2 = 0!
        '
        'Line2
        '
        Me.Line2.Border.BottomColor = System.Drawing.Color.Black
        Me.Line2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.LeftColor = System.Drawing.Color.Black
        Me.Line2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.RightColor = System.Drawing.Color.Black
        Me.Line2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.TopColor = System.Drawing.Color.Black
        Me.Line2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Height = 0!
        Me.Line2.Left = 0.0625!
        Me.Line2.LineWeight = 1.0!
        Me.Line2.Name = "Line2"
        Me.Line2.Top = 4.0!
        Me.Line2.Width = 8.125!
        Me.Line2.X1 = 0.0625!
        Me.Line2.X2 = 8.1875!
        Me.Line2.Y1 = 4.0!
        Me.Line2.Y2 = 4.0!
        '
        'Line20
        '
        Me.Line20.Border.BottomColor = System.Drawing.Color.Black
        Me.Line20.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.LeftColor = System.Drawing.Color.Black
        Me.Line20.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.RightColor = System.Drawing.Color.Black
        Me.Line20.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.TopColor = System.Drawing.Color.Black
        Me.Line20.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Height = 0!
        Me.Line20.Left = 4.625!
        Me.Line20.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line20.LineWeight = 1.0!
        Me.Line20.Name = "Line20"
        Me.Line20.Top = 3.4375!
        Me.Line20.Width = 3.125!
        Me.Line20.X1 = 4.625!
        Me.Line20.X2 = 7.75!
        Me.Line20.Y1 = 3.4375!
        Me.Line20.Y2 = 3.4375!
        '
        'Label25
        '
        Me.Label25.Border.BottomColor = System.Drawing.Color.Black
        Me.Label25.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label25.Border.LeftColor = System.Drawing.Color.Black
        Me.Label25.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label25.Border.RightColor = System.Drawing.Color.Black
        Me.Label25.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label25.Border.TopColor = System.Drawing.Color.Black
        Me.Label25.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label25.Height = 0.1875!
        Me.Label25.HyperLink = Nothing
        Me.Label25.Left = 4.75!
        Me.Label25.Name = "Label25"
        Me.Label25.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label25.Text = "Place and date, signature and stamp of certifying authority"
        Me.Label25.Top = 3.5!
        Me.Label25.Width = 3.125!
        '
        'Line25
        '
        Me.Line25.Border.BottomColor = System.Drawing.Color.Black
        Me.Line25.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.LeftColor = System.Drawing.Color.Black
        Me.Line25.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.RightColor = System.Drawing.Color.Black
        Me.Line25.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.TopColor = System.Drawing.Color.Black
        Me.Line25.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Height = 4.0!
        Me.Line25.Left = 0.0625!
        Me.Line25.LineWeight = 1.0!
        Me.Line25.Name = "Line25"
        Me.Line25.Top = 0!
        Me.Line25.Width = 0!
        Me.Line25.X1 = 0.0625!
        Me.Line25.X2 = 0.0625!
        Me.Line25.Y1 = 0!
        Me.Line25.Y2 = 4.0!
        '
        'Line1
        '
        Me.Line1.Border.BottomColor = System.Drawing.Color.Black
        Me.Line1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.LeftColor = System.Drawing.Color.Black
        Me.Line1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.RightColor = System.Drawing.Color.Black
        Me.Line1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.TopColor = System.Drawing.Color.Black
        Me.Line1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Height = 3.708333!
        Me.Line1.Left = 4.3125!
        Me.Line1.LineWeight = 1.0!
        Me.Line1.Name = "Line1"
        Me.Line1.Top = 0.2916667!
        Me.Line1.Width = 0!
        Me.Line1.X1 = 4.3125!
        Me.Line1.X2 = 4.3125!
        Me.Line1.Y1 = 0.2916667!
        Me.Line1.Y2 = 4.0!
        '
        'Line6
        '
        Me.Line6.Border.BottomColor = System.Drawing.Color.Black
        Me.Line6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.LeftColor = System.Drawing.Color.Black
        Me.Line6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.RightColor = System.Drawing.Color.Black
        Me.Line6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.TopColor = System.Drawing.Color.Black
        Me.Line6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Height = 0!
        Me.Line6.Left = 0.0625!
        Me.Line6.LineWeight = 1.0!
        Me.Line6.Name = "Line6"
        Me.Line6.Top = 2.4375!
        Me.Line6.Width = 4.25!
        Me.Line6.X1 = 0.0625!
        Me.Line6.X2 = 4.3125!
        Me.Line6.Y1 = 2.4375!
        Me.Line6.Y2 = 2.4375!
        '
        'Line26
        '
        Me.Line26.Border.BottomColor = System.Drawing.Color.Black
        Me.Line26.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.LeftColor = System.Drawing.Color.Black
        Me.Line26.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.RightColor = System.Drawing.Color.Black
        Me.Line26.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.TopColor = System.Drawing.Color.Black
        Me.Line26.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Height = 0!
        Me.Line26.Left = 0.0625!
        Me.Line26.LineWeight = 1.0!
        Me.Line26.Name = "Line26"
        Me.Line26.Top = 0.28125!
        Me.Line26.Width = 8.125!
        Me.Line26.X1 = 8.1875!
        Me.Line26.X2 = 0.0625!
        Me.Line26.Y1 = 0.28125!
        Me.Line26.Y2 = 0.28125!
        '
        'Label23
        '
        Me.Label23.Border.BottomColor = System.Drawing.Color.Black
        Me.Label23.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.LeftColor = System.Drawing.Color.Black
        Me.Label23.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.RightColor = System.Drawing.Color.Black
        Me.Label23.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.TopColor = System.Drawing.Color.Black
        Me.Label23.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Height = 0.1875!
        Me.Label23.HyperLink = Nothing
        Me.Label23.Left = 4.4375!
        Me.Label23.Name = "Label23"
        Me.Label23.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label23.Text = "12. Ceritification"
        Me.Label23.Top = 0.3333333!
        Me.Label23.Width = 2.5625!
        '
        'Label24
        '
        Me.Label24.Border.BottomColor = System.Drawing.Color.Black
        Me.Label24.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.LeftColor = System.Drawing.Color.Black
        Me.Label24.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.RightColor = System.Drawing.Color.Black
        Me.Label24.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.TopColor = System.Drawing.Color.Black
        Me.Label24.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Height = 0.4375!
        Me.Label24.HyperLink = Nothing
        Me.Label24.Left = 4.625!
        Me.Label24.Name = "Label24"
        Me.Label24.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label24.Text = "It is hereby certified, on the basis of control carried out, that the declaration" &
    " by the exporter is correct."
        Me.Label24.Top = 0.5!
        Me.Label24.Width = 2.875!
        '
        'Label10
        '
        Me.Label10.Border.BottomColor = System.Drawing.Color.Black
        Me.Label10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.LeftColor = System.Drawing.Color.Black
        Me.Label10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.RightColor = System.Drawing.Color.Black
        Me.Label10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.TopColor = System.Drawing.Color.Black
        Me.Label10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Height = 0.1875!
        Me.Label10.HyperLink = Nothing
        Me.Label10.Left = 0.25!
        Me.Label10.Name = "Label10"
        Me.Label10.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label10.Text = "11. Declaration by the exporter"
        Me.Label10.Top = 0.3229167!
        Me.Label10.Width = 2.5625!
        '
        'Label11
        '
        Me.Label11.Border.BottomColor = System.Drawing.Color.Black
        Me.Label11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.LeftColor = System.Drawing.Color.Black
        Me.Label11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.RightColor = System.Drawing.Color.Black
        Me.Label11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.TopColor = System.Drawing.Color.Black
        Me.Label11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Height = 0.1875!
        Me.Label11.HyperLink = Nothing
        Me.Label11.Left = 0.4375!
        Me.Label11.Name = "Label11"
        Me.Label11.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label11.Text = "The undersigned hereby declares that the above details and statement"
        Me.Label11.Top = 0.5!
        Me.Label11.Width = 3.5!
        '
        'Label26
        '
        Me.Label26.Border.BottomColor = System.Drawing.Color.Black
        Me.Label26.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.LeftColor = System.Drawing.Color.Black
        Me.Label26.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.RightColor = System.Drawing.Color.Black
        Me.Label26.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.TopColor = System.Drawing.Color.Black
        Me.Label26.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Height = 0.1875!
        Me.Label26.HyperLink = Nothing
        Me.Label26.Left = 0.4375!
        Me.Label26.Name = "Label26"
        Me.Label26.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label26.Text = "are correct; that all the goods were produced in"
        Me.Label26.Top = 0.625!
        Me.Label26.Width = 3.5!
        '
        'Label12
        '
        Me.Label12.Border.BottomColor = System.Drawing.Color.Black
        Me.Label12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.LeftColor = System.Drawing.Color.Black
        Me.Label12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.RightColor = System.Drawing.Color.Black
        Me.Label12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.TopColor = System.Drawing.Color.Black
        Me.Label12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Height = 0.1875!
        Me.Label12.HyperLink = Nothing
        Me.Label12.Left = 0.75!
        Me.Label12.Name = "Label12"
        Me.Label12.Style = "ddo-char-set: 0; text-align: center; font-size: 9pt; font-family: Times New Roman" &
    "; "
        Me.Label12.Text = "(Country)"
        Me.Label12.Top = 1.0!
        Me.Label12.Width = 2.6875!
        '
        'Line16
        '
        Me.Line16.Border.BottomColor = System.Drawing.Color.Black
        Me.Line16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.LeftColor = System.Drawing.Color.Black
        Me.Line16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.RightColor = System.Drawing.Color.Black
        Me.Line16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.TopColor = System.Drawing.Color.Black
        Me.Line16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Height = 0!
        Me.Line16.Left = 0.4375!
        Me.Line16.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line16.LineWeight = 1.0!
        Me.Line16.Name = "Line16"
        Me.Line16.Top = 1.0!
        Me.Line16.Width = 3.375!
        Me.Line16.X1 = 0.4375!
        Me.Line16.X2 = 3.8125!
        Me.Line16.Y1 = 1.0!
        Me.Line16.Y2 = 1.0!
        '
        'Label13
        '
        Me.Label13.Border.BottomColor = System.Drawing.Color.Black
        Me.Label13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.LeftColor = System.Drawing.Color.Black
        Me.Label13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.RightColor = System.Drawing.Color.Black
        Me.Label13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.TopColor = System.Drawing.Color.Black
        Me.Label13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Height = 0.1875!
        Me.Label13.HyperLink = Nothing
        Me.Label13.Left = 0.4375!
        Me.Label13.Name = "Label13"
        Me.Label13.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label13.Text = "and that they comply with the origin requirements specified for these "
        Me.Label13.Top = 1.1875!
        Me.Label13.Width = 3.5!
        '
        'Label28
        '
        Me.Label28.Border.BottomColor = System.Drawing.Color.Black
        Me.Label28.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.LeftColor = System.Drawing.Color.Black
        Me.Label28.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.RightColor = System.Drawing.Color.Black
        Me.Label28.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.TopColor = System.Drawing.Color.Black
        Me.Label28.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Height = 0.1875!
        Me.Label28.HyperLink = Nothing
        Me.Label28.Left = 0.4375!
        Me.Label28.Name = "Label28"
        Me.Label28.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label28.Text = "for the goods exported to"
        Me.Label28.Top = 1.4375!
        Me.Label28.Width = 3.5!
        '
        'Label14
        '
        Me.Label14.Border.BottomColor = System.Drawing.Color.Black
        Me.Label14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.LeftColor = System.Drawing.Color.Black
        Me.Label14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.RightColor = System.Drawing.Color.Black
        Me.Label14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.TopColor = System.Drawing.Color.Black
        Me.Label14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Height = 0.1875!
        Me.Label14.HyperLink = Nothing
        Me.Label14.Left = 0.8125!
        Me.Label14.Name = "Label14"
        Me.Label14.Style = "ddo-char-set: 0; text-align: center; font-size: 9pt; font-family: Times New Roman" &
    "; "
        Me.Label14.Text = "(Importing Country)"
        Me.Label14.Top = 1.8125!
        Me.Label14.Width = 2.6875!
        '
        'Line17
        '
        Me.Line17.Border.BottomColor = System.Drawing.Color.Black
        Me.Line17.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.LeftColor = System.Drawing.Color.Black
        Me.Line17.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.RightColor = System.Drawing.Color.Black
        Me.Line17.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.TopColor = System.Drawing.Color.Black
        Me.Line17.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Height = 0!
        Me.Line17.Left = 0.4375!
        Me.Line17.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line17.LineWeight = 1.0!
        Me.Line17.Name = "Line17"
        Me.Line17.Top = 1.8125!
        Me.Line17.Width = 3.375!
        Me.Line17.X1 = 0.4375!
        Me.Line17.X2 = 3.8125!
        Me.Line17.Y1 = 1.8125!
        Me.Line17.Y2 = 1.8125!
        '
        'Label9
        '
        Me.Label9.Border.BottomColor = System.Drawing.Color.Black
        Me.Label9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.LeftColor = System.Drawing.Color.Black
        Me.Label9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.RightColor = System.Drawing.Color.Black
        Me.Label9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.TopColor = System.Drawing.Color.Black
        Me.Label9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Height = 0.1875!
        Me.Label9.HyperLink = Nothing
        Me.Label9.Left = 0.25!
        Me.Label9.Name = "Label9"
        Me.Label9.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label9.Text = "13."
        Me.Label9.Top = 2.5!
        Me.Label9.Width = 0.4375!
        '
        'Shape11
        '
        Me.Shape11.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape11.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape11.Border.RightColor = System.Drawing.Color.Black
        Me.Shape11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape11.Border.TopColor = System.Drawing.Color.Black
        Me.Shape11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape11.Height = 0.1875!
        Me.Shape11.Left = 0.875!
        Me.Shape11.Name = "Shape11"
        Me.Shape11.RoundingRadius = 9.999999!
        Me.Shape11.Top = 2.5!
        Me.Shape11.Width = 0.1875!
        '
        'Shape12
        '
        Me.Shape12.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape12.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape12.Border.RightColor = System.Drawing.Color.Black
        Me.Shape12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape12.Border.TopColor = System.Drawing.Color.Black
        Me.Shape12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape12.Height = 0.1875!
        Me.Shape12.Left = 0.875!
        Me.Shape12.Name = "Shape12"
        Me.Shape12.RoundingRadius = 9.999999!
        Me.Shape12.Top = 2.75!
        Me.Shape12.Width = 0.1875!
        '
        'Shape13
        '
        Me.Shape13.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape13.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape13.Border.RightColor = System.Drawing.Color.Black
        Me.Shape13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape13.Border.TopColor = System.Drawing.Color.Black
        Me.Shape13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape13.Height = 0.1875!
        Me.Shape13.Left = 0.875!
        Me.Shape13.Name = "Shape13"
        Me.Shape13.RoundingRadius = 9.999999!
        Me.Shape13.Top = 3.0!
        Me.Shape13.Width = 0.1875!
        '
        'Shape14
        '
        Me.Shape14.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape14.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape14.Border.RightColor = System.Drawing.Color.Black
        Me.Shape14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape14.Border.TopColor = System.Drawing.Color.Black
        Me.Shape14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape14.Height = 0.1875!
        Me.Shape14.Left = 0.875!
        Me.Shape14.Name = "Shape14"
        Me.Shape14.RoundingRadius = 9.999999!
        Me.Shape14.Top = 3.25!
        Me.Shape14.Width = 0.1875!
        '
        'Label52
        '
        Me.Label52.Border.BottomColor = System.Drawing.Color.Black
        Me.Label52.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label52.Border.LeftColor = System.Drawing.Color.Black
        Me.Label52.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label52.Border.RightColor = System.Drawing.Color.Black
        Me.Label52.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label52.Border.TopColor = System.Drawing.Color.Black
        Me.Label52.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label52.Height = 0.1875!
        Me.Label52.HyperLink = Nothing
        Me.Label52.Left = 1.25!
        Me.Label52.Name = "Label52"
        Me.Label52.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label52.Text = "Partial Cumulation"
        Me.Label52.Top = 3.3125!
        Me.Label52.Width = 1.3125!
        '
        'Label53
        '
        Me.Label53.Border.BottomColor = System.Drawing.Color.Black
        Me.Label53.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label53.Border.LeftColor = System.Drawing.Color.Black
        Me.Label53.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label53.Border.RightColor = System.Drawing.Color.Black
        Me.Label53.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label53.Border.TopColor = System.Drawing.Color.Black
        Me.Label53.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label53.Height = 0.1875!
        Me.Label53.HyperLink = Nothing
        Me.Label53.Left = 1.25!
        Me.Label53.Name = "Label53"
        Me.Label53.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label53.Text = "Back-to-Back CO"
        Me.Label53.Top = 3.0625!
        Me.Label53.Width = 1.3125!
        '
        'Label54
        '
        Me.Label54.Border.BottomColor = System.Drawing.Color.Black
        Me.Label54.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label54.Border.LeftColor = System.Drawing.Color.Black
        Me.Label54.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label54.Border.RightColor = System.Drawing.Color.Black
        Me.Label54.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label54.Border.TopColor = System.Drawing.Color.Black
        Me.Label54.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label54.Height = 0.1875!
        Me.Label54.HyperLink = Nothing
        Me.Label54.Left = 1.25!
        Me.Label54.Name = "Label54"
        Me.Label54.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label54.Text = "Accumulation"
        Me.Label54.Top = 2.8125!
        Me.Label54.Width = 1.3125!
        '
        'Label55
        '
        Me.Label55.Border.BottomColor = System.Drawing.Color.Black
        Me.Label55.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label55.Border.LeftColor = System.Drawing.Color.Black
        Me.Label55.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label55.Border.RightColor = System.Drawing.Color.Black
        Me.Label55.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label55.Border.TopColor = System.Drawing.Color.Black
        Me.Label55.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label55.Height = 0.1875!
        Me.Label55.HyperLink = Nothing
        Me.Label55.Left = 1.25!
        Me.Label55.Name = "Label55"
        Me.Label55.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label55.Text = "Third-Country Invoicing"
        Me.Label55.Top = 2.5625!
        Me.Label55.Width = 1.3125!
        '
        'Shape9
        '
        Me.Shape9.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape9.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape9.Border.RightColor = System.Drawing.Color.Black
        Me.Shape9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape9.Border.TopColor = System.Drawing.Color.Black
        Me.Shape9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape9.Height = 0.1875!
        Me.Shape9.Left = 2.625!
        Me.Shape9.Name = "Shape9"
        Me.Shape9.RoundingRadius = 9.999999!
        Me.Shape9.Top = 2.5!
        Me.Shape9.Width = 0.1875!
        '
        'Shape8
        '
        Me.Shape8.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape8.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape8.Border.RightColor = System.Drawing.Color.Black
        Me.Shape8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape8.Border.TopColor = System.Drawing.Color.Black
        Me.Shape8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape8.Height = 0.1875!
        Me.Shape8.Left = 2.625!
        Me.Shape8.Name = "Shape8"
        Me.Shape8.RoundingRadius = 9.999999!
        Me.Shape8.Top = 2.75!
        Me.Shape8.Width = 0.1875!
        '
        'Shape15
        '
        Me.Shape15.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape15.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape15.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape15.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape15.Border.RightColor = System.Drawing.Color.Black
        Me.Shape15.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape15.Border.TopColor = System.Drawing.Color.Black
        Me.Shape15.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape15.Height = 0.1875!
        Me.Shape15.Left = 2.625!
        Me.Shape15.Name = "Shape15"
        Me.Shape15.RoundingRadius = 9.999999!
        Me.Shape15.Top = 3.0!
        Me.Shape15.Width = 0.1875!
        '
        'Label51
        '
        Me.Label51.Border.BottomColor = System.Drawing.Color.Black
        Me.Label51.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.LeftColor = System.Drawing.Color.Black
        Me.Label51.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.RightColor = System.Drawing.Color.Black
        Me.Label51.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.TopColor = System.Drawing.Color.Black
        Me.Label51.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Height = 0.1875!
        Me.Label51.HyperLink = Nothing
        Me.Label51.Left = 2.9375!
        Me.Label51.Name = "Label51"
        Me.Label51.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label51.Text = "Issued Retroactively"
        Me.Label51.Top = 3.0625!
        Me.Label51.Width = 1.3125!
        '
        'Label50
        '
        Me.Label50.Border.BottomColor = System.Drawing.Color.Black
        Me.Label50.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label50.Border.LeftColor = System.Drawing.Color.Black
        Me.Label50.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label50.Border.RightColor = System.Drawing.Color.Black
        Me.Label50.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label50.Border.TopColor = System.Drawing.Color.Black
        Me.Label50.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label50.Height = 0.1875!
        Me.Label50.HyperLink = Nothing
        Me.Label50.Left = 2.9375!
        Me.Label50.Name = "Label50"
        Me.Label50.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label50.Text = "De Minimis"
        Me.Label50.Top = 2.8125!
        Me.Label50.Width = 1.3125!
        '
        'Label49
        '
        Me.Label49.Border.BottomColor = System.Drawing.Color.Black
        Me.Label49.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label49.Border.LeftColor = System.Drawing.Color.Black
        Me.Label49.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label49.Border.RightColor = System.Drawing.Color.Black
        Me.Label49.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label49.Border.TopColor = System.Drawing.Color.Black
        Me.Label49.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label49.Height = 0.1875!
        Me.Label49.HyperLink = Nothing
        Me.Label49.Left = 2.9375!
        Me.Label49.Name = "Label49"
        Me.Label49.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label49.Text = "Exhibition"
        Me.Label49.Top = 2.5625!
        Me.Label49.Width = 1.3125!
        '
        'txtCheck_CaseRVCCount
        '
        Me.txtCheck_CaseRVCCount.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCheck_CaseRVCCount.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_CaseRVCCount.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCheck_CaseRVCCount.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_CaseRVCCount.Border.RightColor = System.Drawing.Color.Black
        Me.txtCheck_CaseRVCCount.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_CaseRVCCount.Border.TopColor = System.Drawing.Color.Black
        Me.txtCheck_CaseRVCCount.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_CaseRVCCount.Height = 0.1979167!
        Me.txtCheck_CaseRVCCount.Left = 6.668307!
        Me.txtCheck_CaseRVCCount.Name = "txtCheck_CaseRVCCount"
        Me.txtCheck_CaseRVCCount.Style = "color: Red; "
        Me.txtCheck_CaseRVCCount.Text = Nothing
        Me.txtCheck_CaseRVCCount.Top = 1.302084!
        Me.txtCheck_CaseRVCCount.Visible = False
        Me.txtCheck_CaseRVCCount.Width = 1.0!
        '
        'txtDisplayUDS7
        '
        Me.txtDisplayUDS7.Border.BottomColor = System.Drawing.Color.Black
        Me.txtDisplayUDS7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtDisplayUDS7.Border.LeftColor = System.Drawing.Color.Black
        Me.txtDisplayUDS7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtDisplayUDS7.Border.RightColor = System.Drawing.Color.Black
        Me.txtDisplayUDS7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtDisplayUDS7.Border.TopColor = System.Drawing.Color.Black
        Me.txtDisplayUDS7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtDisplayUDS7.Height = 0.1979167!
        Me.txtDisplayUDS7.Left = 6.668307!
        Me.txtDisplayUDS7.Name = "txtDisplayUDS7"
        Me.txtDisplayUDS7.Style = "color: Red; "
        Me.txtDisplayUDS7.Text = Nothing
        Me.txtDisplayUDS7.Top = 1.562501!
        Me.txtDisplayUDS7.Visible = False
        Me.txtDisplayUDS7.Width = 1.0!
        '
        'txtInvAgentType
        '
        Me.txtInvAgentType.Border.BottomColor = System.Drawing.Color.Black
        Me.txtInvAgentType.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvAgentType.Border.LeftColor = System.Drawing.Color.Black
        Me.txtInvAgentType.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvAgentType.Border.RightColor = System.Drawing.Color.Black
        Me.txtInvAgentType.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvAgentType.Border.TopColor = System.Drawing.Color.Black
        Me.txtInvAgentType.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvAgentType.DataField = "InvAgentType"
        Me.txtInvAgentType.Height = 0.1979167!
        Me.txtInvAgentType.Left = 6.668307!
        Me.txtInvAgentType.Name = "txtInvAgentType"
        Me.txtInvAgentType.Style = "color: Red; "
        Me.txtInvAgentType.Text = "InvAgentType"
        Me.txtInvAgentType.Top = 1.822918!
        Me.txtInvAgentType.Visible = False
        Me.txtInvAgentType.Width = 1.0!
        '
        'GroupHeader1
        '
        Me.GroupHeader1.Height = 0!
        Me.GroupHeader1.Name = "GroupHeader1"
        Me.GroupHeader1.Visible = False
        '
        'GroupFooter1
        '
        Me.GroupFooter1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtTotalAll})
        Me.GroupFooter1.Height = 0.25!
        Me.GroupFooter1.KeepTogether = True
        Me.GroupFooter1.Name = "GroupFooter1"
        Me.GroupFooter1.Visible = False
        '
        'txtTotalAll
        '
        Me.txtTotalAll.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTotalAll.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotalAll.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTotalAll.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotalAll.Border.RightColor = System.Drawing.Color.Black
        Me.txtTotalAll.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotalAll.Border.TopColor = System.Drawing.Color.Black
        Me.txtTotalAll.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotalAll.Height = 0.2214567!
        Me.txtTotalAll.Left = 1.87!
        Me.txtTotalAll.Name = "txtTotalAll"
        Me.txtTotalAll.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtTotalAll.Text = Nothing
        Me.txtTotalAll.Top = 0!
        Me.txtTotalAll.Visible = False
        Me.txtTotalAll.Width = 3.492126!
        '
        'Label15
        '
        Me.Label15.Border.BottomColor = System.Drawing.Color.Black
        Me.Label15.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.LeftColor = System.Drawing.Color.Black
        Me.Label15.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.RightColor = System.Drawing.Color.Black
        Me.Label15.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.TopColor = System.Drawing.Color.Black
        Me.Label15.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Height = 0.1875!
        Me.Label15.HyperLink = Nothing
        Me.Label15.Left = 5.1875!
        Me.Label15.Name = "Label15"
        Me.Label15.Style = "color: Red; ddo-char-set: 0; text-align: right; font-weight: bold; font-size: 13." &
    "8pt; font-family: BrowalliaUPC; "
        Me.Label15.Text = "DUPLICATE"
        Me.Label15.Top = 0.0625!
        Me.Label15.Width = 2.875!
        '
        'rpt3_ediFORM44_44_pr
        '
        Me.MasterReport = False
        Me.PageSettings.DefaultPaperSource = False
        Me.PageSettings.Margins.Bottom = 0!
        Me.PageSettings.Margins.Left = 0!
        Me.PageSettings.Margins.Right = 0!
        Me.PageSettings.Margins.Top = 0!
        Me.PageSettings.PaperHeight = 11.69!
        Me.PageSettings.PaperSource = System.Drawing.Printing.PaperSourceKind.FormSource
        Me.PageSettings.PaperWidth = 8.27!
        Me.PrintWidth = 8.267715!
        Me.Script = "public bool ActiveReport_FetchData(bool eof)" & Global.Microsoft.VisualBasic.ChrW(10) & "{" & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(9) & "return eof;" & Global.Microsoft.VisualBasic.ChrW(10) & "}"
        Me.Sections.Add(Me.PageHeader1)
        Me.Sections.Add(Me.GroupHeader1)
        Me.Sections.Add(Me.Detail1)
        Me.Sections.Add(Me.GroupFooter1)
        Me.Sections.Add(Me.PageFooter1)
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Arial; font-style: normal; text-decoration: none; font-weight: norma" &
            "l; font-size: 10pt; color: Black; ddo-char-set: 204; ", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 16pt; font-weight: bold; ", "Heading1", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Times New Roman; font-size: 14pt; font-weight: bold; font-style: ita" &
            "lic; ", "Heading2", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 13pt; font-weight: bold; ", "Heading3", "Normal"))
        Me.Watermark = CType(resources.GetObject("$this.Watermark"), System.Drawing.Image)
        Me.WatermarkSizeMode = DataDynamics.ActiveReports.SizeModes.Stretch
        CType(Me.txtNumRowCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_marks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtT_product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_box8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTolInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGross_Weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtmarks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_n1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_n2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtg_unit_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttariff_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrossTxt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtg_Unit_Desc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOB_AMT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_board, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtWeightDisplayHeader, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOBDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtnet_weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgross_weightH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrossTxt_, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtthird_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtplace_exibition, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNumInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUSDInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtunit_code3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUSDInvoiceDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtWeightDisplayHeaderH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgross_weightD, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCheckGrossDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInvoiceDetailTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSINGLE_COUNTRY_CONTENT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt_NewEmail_ch02, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_model, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtvoince, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTitleMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOtherDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCurrency_Code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtletter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttUSDTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttThirdUSDTotal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUSDAgent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompany_Check_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtreference_code2_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_Check2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttransport_by, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtob_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_remark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_Receive_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtreference_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_email, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_email, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_taxid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_remark1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtob_dest_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdeparture_date, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtvasel_name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtport_discharge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReportInfo1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtform_type, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNewEmail_ch02, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNewEmail_ch01, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTitleHead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch5_exhibi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch7_Issued, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch6_demin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch4_par, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch3_back, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch1_third, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch2_accu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_back_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtIMPORT_COUNTRY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_provincefoot1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_provincefoot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtshow_check, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtback_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCheckIssued, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttotalSum_fob_amt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCheck_CaseRVCCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDisplayUDS7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInvAgentType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotalAll, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Friend WithEvents Detail1 As DataDynamics.ActiveReports.Detail
    Friend WithEvents txtNumRowCount As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_marks As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtT_product As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_box8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTolInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtGross_Weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtmarks As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_n1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_n2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtg_unit_code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttariff_code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtGrossTxt As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtg_Unit_Desc As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtFOB_AMT As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_board As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtWeightDisplayHeader As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtFOBDisplay As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtunit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtnet_weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtgross_weightH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtGrossTxt_ As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtthird_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtplace_exibition As DataDynamics.ActiveReports.TextBox
    Friend WithEvents PageHeader1 As DataDynamics.ActiveReports.PageHeader
    Friend WithEvents txtCompany_Check_1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtreference_code2_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_Check2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttransport_by As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_taxno As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtob_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_remark As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_company As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_Receive_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtreference_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_email As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_email As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_taxid As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_remark1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtob_dest_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdeparture_date As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtvasel_name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtport_discharge As DataDynamics.ActiveReports.TextBox
    Friend WithEvents PageFooter1 As DataDynamics.ActiveReports.PageFooter
    Friend WithEvents txtTemp_back_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtIMPORT_COUNTRY As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_provincefoot1 As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtcompany_provincefoot As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtshow_check As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtback_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNumInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtUSDInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbox8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents ReportInfo1 As DataDynamics.ActiveReports.ReportInfo
    Public WithEvents C_TotalRowDe As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtunit_code3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtUSDInvoiceDetail As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtWeightDisplayHeaderH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtgross_weightD As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtCheckGrossDetail As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtform_type As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvh_run_auto As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtCheckIssued As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttotalSum_fob_amt As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Pic_ch1_third As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch2_accu As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch3_back As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch4_par As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch5_exhibi As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch7_Issued As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch6_demin As DataDynamics.ActiveReports.Picture
    Friend WithEvents txtNewEmail_ch02 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNewEmail_ch01 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents GroupHeader1 As DataDynamics.ActiveReports.GroupHeader
    Friend WithEvents GroupFooter1 As DataDynamics.ActiveReports.GroupFooter
    Friend WithEvents txtTotalAll As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtInvoiceDetailTH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtSINGLE_COUNTRY_CONTENT As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txt_NewEmail_ch02 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_model As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtvoince As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTitleMain As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTitleHead As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line9 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line8 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line13 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line14 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line12 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line3 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label42 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label43 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label44 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line11 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label3 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label2 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label5 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label4 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label1 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label8 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label7 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label16 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label21 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label17 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label22 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line19 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label19 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label6 As DataDynamics.ActiveReports.Label
    Friend WithEvents Shape1 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Label29 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label31 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label30 As DataDynamics.ActiveReports.Label
    Friend WithEvents Shape2 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape3 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Label33 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label48 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label47 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label46 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line10 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line27 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line2 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line20 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label25 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line25 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line1 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line6 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line26 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label23 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label24 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label10 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label11 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label26 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label12 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line16 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label13 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label28 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label14 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line17 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label9 As DataDynamics.ActiveReports.Label
    Friend WithEvents Shape11 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape12 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape13 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape14 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Label52 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label53 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label54 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label55 As DataDynamics.ActiveReports.Label
    Friend WithEvents Shape9 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape8 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape15 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Label51 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label50 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label49 As DataDynamics.ActiveReports.Label
    Public WithEvents txtCheck_CaseRVCCount As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtPriceOtherDetail As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtCurrency_Code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtletter As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtAttUSDTotal As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtAttThirdUSDTotal As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtDisplayUDS7 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtUSDAgent As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtInvAgentType As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Label15 As DataDynamics.ActiveReports.Label
End Class
