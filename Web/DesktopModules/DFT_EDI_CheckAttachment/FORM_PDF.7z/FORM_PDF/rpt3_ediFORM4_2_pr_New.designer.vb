<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class rpt3_ediFORM4_2_pr_New
    Inherits DataDynamics.ActiveReports.ActiveReport3

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
        End If
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the ActiveReports Designer
    'It can be modified using the ActiveReports Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(rpt3_ediFORM4_2_pr_New))
        Me.Detail1 = New DataDynamics.ActiveReports.Detail()
        Me.txtNumRowCount = New DataDynamics.ActiveReports.TextBox()
        Me.txtTemp_marks = New DataDynamics.ActiveReports.TextBox()
        Me.txtT_product = New DataDynamics.ActiveReports.TextBox()
        Me.txtTemp_box8 = New DataDynamics.ActiveReports.TextBox()
        Me.txtTolInvoice = New DataDynamics.ActiveReports.TextBox()
        Me.txtGrossTxt = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtGross_Weight = New DataDynamics.ActiveReports.TextBox()
        Me.txtmarks1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtproduct_n1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtproduct_n2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtg_unit_code = New DataDynamics.ActiveReports.TextBox()
        Me.C_TotalRowDe = New DataDynamics.ActiveReports.TextBox()
        Me.txttariff_code = New DataDynamics.ActiveReports.TextBox()
        Me.txtg_Unit_Desc = New DataDynamics.ActiveReports.TextBox()
        Me.txtFOB_AMT = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_board = New DataDynamics.ActiveReports.TextBox()
        Me.txtWeightDisplayHeader = New DataDynamics.ActiveReports.TextBox()
        Me.txtFOBDisplay = New DataDynamics.ActiveReports.TextBox()
        Me.txtunit_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtnet_weight = New DataDynamics.ActiveReports.TextBox()
        Me.txtgross_weightH = New DataDynamics.ActiveReports.TextBox()
        Me.txtthird_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtplace_exibition = New DataDynamics.ActiveReports.TextBox()
        Me.txtWeightDisplayHeaderH = New DataDynamics.ActiveReports.TextBox()
        Me.txtbox8 = New DataDynamics.ActiveReports.TextBox()
        Me.txtletter = New DataDynamics.ActiveReports.TextBox()
        Me.txtprofit_per_unit = New DataDynamics.ActiveReports.TextBox()
        Me.txtmarks = New DataDynamics.ActiveReports.TextBox()
        Me.txtSINGLE_COUNTRY_CONTENT = New DataDynamics.ActiveReports.TextBox()
        Me.txtNumInvoice = New DataDynamics.ActiveReports.TextBox()
        Me.txtUSDInvoice = New DataDynamics.ActiveReports.TextBox()
        Me.txtUSDInvoiceDetail = New DataDynamics.ActiveReports.TextBox()
        Me.txtInvoiceDetailTH = New DataDynamics.ActiveReports.TextBox()
        Me.txtTitleMain = New DataDynamics.ActiveReports.TextBox()
        Me.txtCurrency_Code = New DataDynamics.ActiveReports.TextBox()
        Me.txtgross_weightD = New DataDynamics.ActiveReports.TextBox()
        Me.txtDIGIT1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtCheckGrossDetail = New DataDynamics.ActiveReports.TextBox()
        Me.txtPriceOtherDetail = New DataDynamics.ActiveReports.TextBox()
        Me.PageHeader1 = New DataDynamics.ActiveReports.PageHeader()
        Me.txtCompany_Check_1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtreference_code2_Temp = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_Check2 = New DataDynamics.ActiveReports.TextBox()
        Me.txttransport_by = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_taxno = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_province = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_name = New DataDynamics.ActiveReports.TextBox()
        Me.txtob_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_remark = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_fax = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_phone = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_company = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_fax = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_phone = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_province = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_Receive_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtreference_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_email = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_email = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_taxid = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_remark1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtob_dest_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtdeparture_date = New DataDynamics.ActiveReports.TextBox()
        Me.txtvasel_name = New DataDynamics.ActiveReports.TextBox()
        Me.txtport_discharge = New DataDynamics.ActiveReports.TextBox()
        Me.TextBox1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtTax_Status = New DataDynamics.ActiveReports.TextBox()
        Me.ReportInfo1 = New DataDynamics.ActiveReports.ReportInfo()
        Me.txtCheck_StatusWeb = New DataDynamics.ActiveReports.TextBox()
        Me.txtNewEmail_ch02 = New DataDynamics.ActiveReports.TextBox()
        Me.txtNewEmail_ch01 = New DataDynamics.ActiveReports.TextBox()
        Me.txtReserve1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtsupplementary_details = New DataDynamics.ActiveReports.TextBox()
        Me.txtRep_Doc_date2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtTitleHead = New DataDynamics.ActiveReports.TextBox()
        Me.Line14 = New DataDynamics.ActiveReports.Line()
        Me.Label8 = New DataDynamics.ActiveReports.Label()
        Me.Label1 = New DataDynamics.ActiveReports.Label()
        Me.Line13 = New DataDynamics.ActiveReports.Line()
        Me.Label3 = New DataDynamics.ActiveReports.Label()
        Me.Line23 = New DataDynamics.ActiveReports.Line()
        Me.Line25 = New DataDynamics.ActiveReports.Line()
        Me.Line26 = New DataDynamics.ActiveReports.Line()
        Me.Label19 = New DataDynamics.ActiveReports.Label()
        Me.Label9 = New DataDynamics.ActiveReports.Label()
        Me.Label2 = New DataDynamics.ActiveReports.Label()
        Me.Label20 = New DataDynamics.ActiveReports.Label()
        Me.Label22 = New DataDynamics.ActiveReports.Label()
        Me.TextBox2 = New DataDynamics.ActiveReports.TextBox()
        Me.Line19 = New DataDynamics.ActiveReports.Line()
        Me.Label17 = New DataDynamics.ActiveReports.Label()
        Me.Label7 = New DataDynamics.ActiveReports.Label()
        Me.Label31 = New DataDynamics.ActiveReports.Label()
        Me.Shape3 = New DataDynamics.ActiveReports.Shape()
        Me.Label32 = New DataDynamics.ActiveReports.Label()
        Me.Shape2 = New DataDynamics.ActiveReports.Shape()
        Me.Line9 = New DataDynamics.ActiveReports.Line()
        Me.Label10 = New DataDynamics.ActiveReports.Label()
        Me.Line21 = New DataDynamics.ActiveReports.Line()
        Me.Line7 = New DataDynamics.ActiveReports.Line()
        Me.Label4 = New DataDynamics.ActiveReports.Label()
        Me.Line22 = New DataDynamics.ActiveReports.Line()
        Me.Label14 = New DataDynamics.ActiveReports.Label()
        Me.Label13 = New DataDynamics.ActiveReports.Label()
        Me.Label12 = New DataDynamics.ActiveReports.Label()
        Me.Label6 = New DataDynamics.ActiveReports.Label()
        Me.Label5 = New DataDynamics.ActiveReports.Label()
        Me.Label11 = New DataDynamics.ActiveReports.Label()
        Me.Label15 = New DataDynamics.ActiveReports.Label()
        Me.Label16 = New DataDynamics.ActiveReports.Label()
        Me.Line5 = New DataDynamics.ActiveReports.Line()
        Me.PageFooter1 = New DataDynamics.ActiveReports.PageFooter()
        Me.txtTHAILAND = New DataDynamics.ActiveReports.TextBox()
        Me.txtIMPORT_COUNTRY = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_provincefoot1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_provincefoot = New DataDynamics.ActiveReports.TextBox()
        Me.txtshow_check = New DataDynamics.ActiveReports.TextBox()
        Me.txtback_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvh_run_auto = New DataDynamics.ActiveReports.TextBox()
        Me.txttotalSum_fob_amt = New DataDynamics.ActiveReports.TextBox()
        Me.Pic_ch5_exhibi = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch7_Issued = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch3_back = New DataDynamics.ActiveReports.Picture()
        Me.Pic_ch1_third = New DataDynamics.ActiveReports.Picture()
        Me.Line4 = New DataDynamics.ActiveReports.Line()
        Me.Line10 = New DataDynamics.ActiveReports.Line()
        Me.Label28 = New DataDynamics.ActiveReports.Label()
        Me.Label29 = New DataDynamics.ActiveReports.Label()
        Me.Line11 = New DataDynamics.ActiveReports.Line()
        Me.Label23 = New DataDynamics.ActiveReports.Label()
        Me.Label34 = New DataDynamics.ActiveReports.Label()
        Me.Line17 = New DataDynamics.ActiveReports.Line()
        Me.Label26 = New DataDynamics.ActiveReports.Label()
        Me.Line20 = New DataDynamics.ActiveReports.Line()
        Me.Label35 = New DataDynamics.ActiveReports.Label()
        Me.Line16 = New DataDynamics.ActiveReports.Line()
        Me.Line1 = New DataDynamics.ActiveReports.Line()
        Me.Label30 = New DataDynamics.ActiveReports.Label()
        Me.Label21 = New DataDynamics.ActiveReports.Label()
        Me.Line2 = New DataDynamics.ActiveReports.Line()
        Me.Label18 = New DataDynamics.ActiveReports.Label()
        Me.Shape4 = New DataDynamics.ActiveReports.Shape()
        Me.Shape5 = New DataDynamics.ActiveReports.Shape()
        Me.Label24 = New DataDynamics.ActiveReports.Label()
        Me.Shape1 = New DataDynamics.ActiveReports.Shape()
        Me.Shape6 = New DataDynamics.ActiveReports.Shape()
        Me.Label33 = New DataDynamics.ActiveReports.Label()
        Me.Label27 = New DataDynamics.ActiveReports.Label()
        Me.Line3 = New DataDynamics.ActiveReports.Line()
        Me.txtCheck_CaseRVCCount = New DataDynamics.ActiveReports.TextBox()
        Me.GroupHeader1 = New DataDynamics.ActiveReports.GroupHeader()
        Me.GroupFooter1 = New DataDynamics.ActiveReports.GroupFooter()
        Me.txtTotalAll = New DataDynamics.ActiveReports.TextBox()
        Me.Label51 = New DataDynamics.ActiveReports.Label()
        CType(Me.txtNumRowCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_marks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtT_product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_box8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTolInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrossTxt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGross_Weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtmarks1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_n1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_n2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtg_unit_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttariff_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtg_Unit_Desc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOB_AMT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_board, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtWeightDisplayHeader, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOBDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtnet_weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgross_weightH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtthird_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtplace_exibition, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtWeightDisplayHeaderH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtletter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtprofit_per_unit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtmarks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSINGLE_COUNTRY_CONTENT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNumInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUSDInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUSDInvoiceDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInvoiceDetailTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTitleMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCurrency_Code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgross_weightD, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDIGIT1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCheckGrossDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPriceOtherDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompany_Check_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtreference_code2_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_Check2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttransport_by, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtob_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_remark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_Receive_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtreference_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_email, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_email, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_taxid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_remark1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtob_dest_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdeparture_date, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtvasel_name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtport_discharge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTax_Status, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReportInfo1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCheck_StatusWeb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNewEmail_ch02, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNewEmail_ch01, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtReserve1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtsupplementary_details, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtRep_Doc_date2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTitleHead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTHAILAND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtIMPORT_COUNTRY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_provincefoot1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_provincefoot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtshow_check, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtback_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttotalSum_fob_amt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch5_exhibi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch7_Issued, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch3_back, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_ch1_third, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCheck_CaseRVCCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotalAll, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'Detail1
        '
        Me.Detail1.CanShrink = True
        Me.Detail1.ColumnSpacing = 0!
        Me.Detail1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtNumRowCount, Me.txtTemp_marks, Me.txtT_product, Me.txtTemp_box8, Me.txtTolInvoice, Me.txtGrossTxt, Me.txtinvoice_no1, Me.txtinvoice_no2, Me.txtinvoice_no3, Me.txtinvoice_no4, Me.txtinvoice_no5, Me.txtinvoice_date1, Me.txtinvoice_date2, Me.txtinvoice_date3, Me.txtinvoice_date4, Me.txtinvoice_date5, Me.txtGross_Weight, Me.txtmarks1, Me.txtproduct_n1, Me.txtproduct_n2, Me.txtquantity1, Me.txtq_unit_code1, Me.txtquantity2, Me.txtq_unit_code2, Me.txtquantity3, Me.txtq_unit_code3, Me.txtquantity4, Me.txtq_unit_code4, Me.txtquantity5, Me.txtq_unit_code5, Me.txtg_unit_code, Me.C_TotalRowDe, Me.txttariff_code, Me.txtg_Unit_Desc, Me.txtFOB_AMT, Me.txtinvoice_board, Me.txtWeightDisplayHeader, Me.txtFOBDisplay, Me.txtunit_code2, Me.txtnet_weight, Me.txtgross_weightH, Me.txtthird_country, Me.txtplace_exibition, Me.txtWeightDisplayHeaderH, Me.txtbox8, Me.txtletter, Me.txtprofit_per_unit, Me.txtmarks, Me.txtSINGLE_COUNTRY_CONTENT, Me.txtNumInvoice, Me.txtUSDInvoice, Me.txtUSDInvoiceDetail, Me.txtInvoiceDetailTH, Me.txtTitleMain, Me.txtCurrency_Code, Me.txtgross_weightD, Me.txtDIGIT1, Me.txtCheckGrossDetail, Me.txtPriceOtherDetail})
        Me.Detail1.Height = 0.394!
        Me.Detail1.Name = "Detail1"
        '
        'txtNumRowCount
        '
        Me.txtNumRowCount.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.RightColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.TopColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Height = 0.2204724!
        Me.txtNumRowCount.Left = 0.1875!
        Me.txtNumRowCount.Name = "txtNumRowCount"
        Me.txtNumRowCount.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtNumRowCount.Text = Nothing
        Me.txtNumRowCount.Top = 0!
        Me.txtNumRowCount.Width = 0.3937007!
        '
        'txtTemp_marks
        '
        Me.txtTemp_marks.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Height = 0.22!
        Me.txtTemp_marks.Left = 0.875!
        Me.txtTemp_marks.Name = "txtTemp_marks"
        Me.txtTemp_marks.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtTemp_marks.Text = Nothing
        Me.txtTemp_marks.Top = 0!
        Me.txtTemp_marks.Visible = False
        Me.txtTemp_marks.Width = 0.9375!
        '
        'txtT_product
        '
        Me.txtT_product.Border.BottomColor = System.Drawing.Color.Black
        Me.txtT_product.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.LeftColor = System.Drawing.Color.Black
        Me.txtT_product.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.RightColor = System.Drawing.Color.Black
        Me.txtT_product.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.TopColor = System.Drawing.Color.Black
        Me.txtT_product.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Height = 0.22!
        Me.txtT_product.Left = 1.875!
        Me.txtT_product.Name = "txtT_product"
        Me.txtT_product.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtT_product.Text = Nothing
        Me.txtT_product.Top = 0!
        Me.txtT_product.Width = 3.25!
        '
        'txtTemp_box8
        '
        Me.txtTemp_box8.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Height = 0.2214567!
        Me.txtTemp_box8.Left = 5.339567!
        Me.txtTemp_box8.Name = "txtTemp_box8"
        Me.txtTemp_box8.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtTemp_box8.Text = Nothing
        Me.txtTemp_box8.Top = 0!
        Me.txtTemp_box8.Width = 0.5905511!
        '
        'txtTolInvoice
        '
        Me.txtTolInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Height = 0.22!
        Me.txtTolInvoice.Left = 7.0!
        Me.txtTolInvoice.Name = "txtTolInvoice"
        Me.txtTolInvoice.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtTolInvoice.Text = Nothing
        Me.txtTolInvoice.Top = 0!
        Me.txtTolInvoice.Visible = False
        Me.txtTolInvoice.Width = 1.125!
        '
        'txtGrossTxt
        '
        Me.txtGrossTxt.Border.BottomColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.LeftColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.RightColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.TopColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Height = 0.22!
        Me.txtGrossTxt.Left = 5.970833!
        Me.txtGrossTxt.Name = "txtGrossTxt"
        Me.txtGrossTxt.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-size: 10pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtGrossTxt.Text = Nothing
        Me.txtGrossTxt.Top = 0!
        Me.txtGrossTxt.Width = 1.0!
        '
        'txtinvoice_no1
        '
        Me.txtinvoice_no1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.DataField = "invoice_no1"
        Me.txtinvoice_no1.Height = 0.1979167!
        Me.txtinvoice_no1.Left = 0.09842521!
        Me.txtinvoice_no1.Name = "txtinvoice_no1"
        Me.txtinvoice_no1.Style = "color: Red; "
        Me.txtinvoice_no1.Text = "invoice_no1"
        Me.txtinvoice_no1.Top = 0.5413386!
        Me.txtinvoice_no1.Visible = False
        Me.txtinvoice_no1.Width = 1.0!
        '
        'txtinvoice_no2
        '
        Me.txtinvoice_no2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.DataField = "invoice_no2"
        Me.txtinvoice_no2.Height = 0.1979167!
        Me.txtinvoice_no2.Left = 1.107283!
        Me.txtinvoice_no2.Name = "txtinvoice_no2"
        Me.txtinvoice_no2.Style = "color: Red; "
        Me.txtinvoice_no2.Text = "invoice_no2"
        Me.txtinvoice_no2.Top = 0.5413386!
        Me.txtinvoice_no2.Visible = False
        Me.txtinvoice_no2.Width = 1.0!
        '
        'txtinvoice_no3
        '
        Me.txtinvoice_no3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.DataField = "invoice_no3"
        Me.txtinvoice_no3.Height = 0.1979167!
        Me.txtinvoice_no3.Left = 2.116143!
        Me.txtinvoice_no3.Name = "txtinvoice_no3"
        Me.txtinvoice_no3.Style = "color: Red; "
        Me.txtinvoice_no3.Text = "invoice_no3"
        Me.txtinvoice_no3.Top = 0.5413386!
        Me.txtinvoice_no3.Visible = False
        Me.txtinvoice_no3.Width = 1.0!
        '
        'txtinvoice_no4
        '
        Me.txtinvoice_no4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.DataField = "invoice_no4"
        Me.txtinvoice_no4.Height = 0.1979167!
        Me.txtinvoice_no4.Left = 3.125!
        Me.txtinvoice_no4.Name = "txtinvoice_no4"
        Me.txtinvoice_no4.Style = "color: Red; "
        Me.txtinvoice_no4.Text = "invoice_no4"
        Me.txtinvoice_no4.Top = 0.5413386!
        Me.txtinvoice_no4.Visible = False
        Me.txtinvoice_no4.Width = 1.0!
        '
        'txtinvoice_no5
        '
        Me.txtinvoice_no5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.DataField = "invoice_no5"
        Me.txtinvoice_no5.Height = 0.1979167!
        Me.txtinvoice_no5.Left = 4.133858!
        Me.txtinvoice_no5.Name = "txtinvoice_no5"
        Me.txtinvoice_no5.Style = "color: Red; "
        Me.txtinvoice_no5.Text = "invoice_no5"
        Me.txtinvoice_no5.Top = 0.5413386!
        Me.txtinvoice_no5.Visible = False
        Me.txtinvoice_no5.Width = 1.0!
        '
        'txtinvoice_date1
        '
        Me.txtinvoice_date1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.DataField = "invoice_date1"
        Me.txtinvoice_date1.Height = 0.1979167!
        Me.txtinvoice_date1.Left = 0.09842521!
        Me.txtinvoice_date1.Name = "txtinvoice_date1"
        Me.txtinvoice_date1.Style = "color: Red; "
        Me.txtinvoice_date1.Text = "invoice_date1"
        Me.txtinvoice_date1.Top = 0.8120077!
        Me.txtinvoice_date1.Visible = False
        Me.txtinvoice_date1.Width = 1.0!
        '
        'txtinvoice_date2
        '
        Me.txtinvoice_date2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.DataField = "invoice_date2"
        Me.txtinvoice_date2.Height = 0.1979167!
        Me.txtinvoice_date2.Left = 1.107283!
        Me.txtinvoice_date2.Name = "txtinvoice_date2"
        Me.txtinvoice_date2.Style = "color: Red; "
        Me.txtinvoice_date2.Text = "invoice_date2"
        Me.txtinvoice_date2.Top = 0.8120077!
        Me.txtinvoice_date2.Visible = False
        Me.txtinvoice_date2.Width = 1.0!
        '
        'txtinvoice_date3
        '
        Me.txtinvoice_date3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.DataField = "invoice_date3"
        Me.txtinvoice_date3.Height = 0.1979167!
        Me.txtinvoice_date3.Left = 2.116143!
        Me.txtinvoice_date3.Name = "txtinvoice_date3"
        Me.txtinvoice_date3.Style = "color: Red; "
        Me.txtinvoice_date3.Text = "invoice_date3"
        Me.txtinvoice_date3.Top = 0.8120077!
        Me.txtinvoice_date3.Visible = False
        Me.txtinvoice_date3.Width = 1.0!
        '
        'txtinvoice_date4
        '
        Me.txtinvoice_date4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.DataField = "invoice_date4"
        Me.txtinvoice_date4.Height = 0.1979167!
        Me.txtinvoice_date4.Left = 3.125!
        Me.txtinvoice_date4.Name = "txtinvoice_date4"
        Me.txtinvoice_date4.Style = "color: Red; "
        Me.txtinvoice_date4.Text = "invoice_date4"
        Me.txtinvoice_date4.Top = 0.8120077!
        Me.txtinvoice_date4.Visible = False
        Me.txtinvoice_date4.Width = 1.0!
        '
        'txtinvoice_date5
        '
        Me.txtinvoice_date5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.DataField = "invoice_date5"
        Me.txtinvoice_date5.Height = 0.1979167!
        Me.txtinvoice_date5.Left = 4.133858!
        Me.txtinvoice_date5.Name = "txtinvoice_date5"
        Me.txtinvoice_date5.Style = "color: Red; "
        Me.txtinvoice_date5.Text = "invoice_date5"
        Me.txtinvoice_date5.Top = 0.8120077!
        Me.txtinvoice_date5.Visible = False
        Me.txtinvoice_date5.Width = 1.0!
        '
        'txtGross_Weight
        '
        Me.txtGross_Weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtGross_Weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGross_Weight.DataField = "Gross_Weight"
        Me.txtGross_Weight.Height = 0.1979167!
        Me.txtGross_Weight.Left = 3.100394!
        Me.txtGross_Weight.Name = "txtGross_Weight"
        Me.txtGross_Weight.Style = "color: Lime; "
        Me.txtGross_Weight.Text = "Gross_Weight"
        Me.txtGross_Weight.Top = 1.845472!
        Me.txtGross_Weight.Visible = False
        Me.txtGross_Weight.Width = 1.0!
        '
        'txtmarks1
        '
        Me.txtmarks1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtmarks1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtmarks1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks1.Border.RightColor = System.Drawing.Color.Black
        Me.txtmarks1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks1.Border.TopColor = System.Drawing.Color.Black
        Me.txtmarks1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks1.DataField = "marks"
        Me.txtmarks1.Height = 0.1979167!
        Me.txtmarks1.Left = 1.107283!
        Me.txtmarks1.Name = "txtmarks1"
        Me.txtmarks1.Style = "color: Red; "
        Me.txtmarks1.Text = "marks"
        Me.txtmarks1.Top = 1.058071!
        Me.txtmarks1.Visible = False
        Me.txtmarks1.Width = 1.0!
        '
        'txtproduct_n1
        '
        Me.txtproduct_n1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.DataField = "product_n1"
        Me.txtproduct_n1.Height = 0.1979167!
        Me.txtproduct_n1.Left = 2.116143!
        Me.txtproduct_n1.Name = "txtproduct_n1"
        Me.txtproduct_n1.Style = "color: Red; text-align: left; "
        Me.txtproduct_n1.Text = "product_n1"
        Me.txtproduct_n1.Top = 1.058071!
        Me.txtproduct_n1.Visible = False
        Me.txtproduct_n1.Width = 1.0!
        '
        'txtproduct_n2
        '
        Me.txtproduct_n2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.DataField = "product_n2"
        Me.txtproduct_n2.Height = 0.1979167!
        Me.txtproduct_n2.Left = 3.125!
        Me.txtproduct_n2.Name = "txtproduct_n2"
        Me.txtproduct_n2.Style = "color: Red; "
        Me.txtproduct_n2.Text = "product_n2"
        Me.txtproduct_n2.Top = 1.058071!
        Me.txtproduct_n2.Visible = False
        Me.txtproduct_n2.Width = 1.0!
        '
        'txtquantity1
        '
        Me.txtquantity1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.DataField = "quantity1"
        Me.txtquantity1.Height = 0.1979167!
        Me.txtquantity1.Left = 0.09842521!
        Me.txtquantity1.Name = "txtquantity1"
        Me.txtquantity1.Style = "color: Red; text-align: left; "
        Me.txtquantity1.Text = "quantity1"
        Me.txtquantity1.Top = 1.254921!
        Me.txtquantity1.Visible = False
        Me.txtquantity1.Width = 1.0!
        '
        'txtq_unit_code1
        '
        Me.txtq_unit_code1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.DataField = "q_unit_code1"
        Me.txtq_unit_code1.Height = 0.1979167!
        Me.txtq_unit_code1.Left = 1.107283!
        Me.txtq_unit_code1.Name = "txtq_unit_code1"
        Me.txtq_unit_code1.Style = "color: Red; "
        Me.txtq_unit_code1.Text = "q_unit_code1"
        Me.txtq_unit_code1.Top = 1.254921!
        Me.txtq_unit_code1.Visible = False
        Me.txtq_unit_code1.Width = 1.0!
        '
        'txtquantity2
        '
        Me.txtquantity2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.DataField = "quantity2"
        Me.txtquantity2.Height = 0.1979167!
        Me.txtquantity2.Left = 0.09842521!
        Me.txtquantity2.Name = "txtquantity2"
        Me.txtquantity2.Style = "color: Red; text-align: left; "
        Me.txtquantity2.Text = "quantity2"
        Me.txtquantity2.Top = 1.525591!
        Me.txtquantity2.Visible = False
        Me.txtquantity2.Width = 1.0!
        '
        'txtq_unit_code2
        '
        Me.txtq_unit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.DataField = "q_unit_code2"
        Me.txtq_unit_code2.Height = 0.1979167!
        Me.txtq_unit_code2.Left = 1.107283!
        Me.txtq_unit_code2.Name = "txtq_unit_code2"
        Me.txtq_unit_code2.Style = "color: Red; "
        Me.txtq_unit_code2.Text = "q_unit_code2"
        Me.txtq_unit_code2.Top = 1.525591!
        Me.txtq_unit_code2.Visible = False
        Me.txtq_unit_code2.Width = 1.0!
        '
        'txtquantity3
        '
        Me.txtquantity3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.DataField = "quantity3"
        Me.txtquantity3.Height = 0.1979167!
        Me.txtquantity3.Left = 0.09842521!
        Me.txtquantity3.Name = "txtquantity3"
        Me.txtquantity3.Style = "color: Red; text-align: left; "
        Me.txtquantity3.Text = "quantity3"
        Me.txtquantity3.Top = 1.771654!
        Me.txtquantity3.Visible = False
        Me.txtquantity3.Width = 1.0!
        '
        'txtq_unit_code3
        '
        Me.txtq_unit_code3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.DataField = "q_unit_code3"
        Me.txtq_unit_code3.Height = 0.1979167!
        Me.txtq_unit_code3.Left = 1.107283!
        Me.txtq_unit_code3.Name = "txtq_unit_code3"
        Me.txtq_unit_code3.Style = "color: Red; "
        Me.txtq_unit_code3.Text = "q_unit_code3"
        Me.txtq_unit_code3.Top = 1.771654!
        Me.txtq_unit_code3.Visible = False
        Me.txtq_unit_code3.Width = 1.0!
        '
        'txtquantity4
        '
        Me.txtquantity4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.DataField = "quantity4"
        Me.txtquantity4.Height = 0.1979167!
        Me.txtquantity4.Left = 0.09842521!
        Me.txtquantity4.Name = "txtquantity4"
        Me.txtquantity4.Style = "color: Red; text-align: left; "
        Me.txtquantity4.Text = "quantity4"
        Me.txtquantity4.Top = 2.042323!
        Me.txtquantity4.Visible = False
        Me.txtquantity4.Width = 1.0!
        '
        'txtq_unit_code4
        '
        Me.txtq_unit_code4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.DataField = "q_unit_code4"
        Me.txtq_unit_code4.Height = 0.1979167!
        Me.txtq_unit_code4.Left = 1.107283!
        Me.txtq_unit_code4.Name = "txtq_unit_code4"
        Me.txtq_unit_code4.Style = "color: Red; "
        Me.txtq_unit_code4.Text = "q_unit_code4"
        Me.txtq_unit_code4.Top = 2.042323!
        Me.txtq_unit_code4.Visible = False
        Me.txtq_unit_code4.Width = 1.0!
        '
        'txtquantity5
        '
        Me.txtquantity5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.DataField = "quantity5"
        Me.txtquantity5.Height = 0.1979167!
        Me.txtquantity5.Left = 0.09842521!
        Me.txtquantity5.Name = "txtquantity5"
        Me.txtquantity5.Style = "color: Red; text-align: left; "
        Me.txtquantity5.Text = "quantity5"
        Me.txtquantity5.Top = 2.288386!
        Me.txtquantity5.Visible = False
        Me.txtquantity5.Width = 1.0!
        '
        'txtq_unit_code5
        '
        Me.txtq_unit_code5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.DataField = "q_unit_code5"
        Me.txtq_unit_code5.Height = 0.1979167!
        Me.txtq_unit_code5.Left = 1.107283!
        Me.txtq_unit_code5.Name = "txtq_unit_code5"
        Me.txtq_unit_code5.Style = "color: Red; "
        Me.txtq_unit_code5.Text = "q_unit_code5"
        Me.txtq_unit_code5.Top = 2.288386!
        Me.txtq_unit_code5.Visible = False
        Me.txtq_unit_code5.Width = 1.0!
        '
        'txtg_unit_code
        '
        Me.txtg_unit_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.RightColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.TopColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.DataField = "g_unit_code"
        Me.txtg_unit_code.Height = 0.1979167!
        Me.txtg_unit_code.Left = 2.116143!
        Me.txtg_unit_code.Name = "txtg_unit_code"
        Me.txtg_unit_code.Style = "color: Red; "
        Me.txtg_unit_code.Text = "g_unit_code"
        Me.txtg_unit_code.Top = 1.32874!
        Me.txtg_unit_code.Visible = False
        Me.txtg_unit_code.Width = 1.0!
        '
        'C_TotalRowDe
        '
        Me.C_TotalRowDe.Border.BottomColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.LeftColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.RightColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.TopColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Height = 0.1979167!
        Me.C_TotalRowDe.Left = 2.116143!
        Me.C_TotalRowDe.Name = "C_TotalRowDe"
        Me.C_TotalRowDe.Style = "color: Lime; "
        Me.C_TotalRowDe.Text = "C_TotalRowDe"
        Me.C_TotalRowDe.Top = 1.574803!
        Me.C_TotalRowDe.Visible = False
        Me.C_TotalRowDe.Width = 1.0!
        '
        'txttariff_code
        '
        Me.txttariff_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.RightColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.TopColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.DataField = "tariff_code"
        Me.txttariff_code.Height = 0.1979167!
        Me.txttariff_code.Left = 3.125!
        Me.txttariff_code.Name = "txttariff_code"
        Me.txttariff_code.Style = "color: Red; "
        Me.txttariff_code.Text = "tariff_code"
        Me.txttariff_code.Top = 1.32874!
        Me.txttariff_code.Visible = False
        Me.txttariff_code.Width = 1.0!
        '
        'txtg_Unit_Desc
        '
        Me.txtg_Unit_Desc.Border.BottomColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.LeftColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.RightColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.Border.TopColor = System.Drawing.Color.Black
        Me.txtg_Unit_Desc.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_Unit_Desc.DataField = "g_Unit_Desc"
        Me.txtg_Unit_Desc.Height = 0.1979167!
        Me.txtg_Unit_Desc.Left = 3.125!
        Me.txtg_Unit_Desc.Name = "txtg_Unit_Desc"
        Me.txtg_Unit_Desc.Style = "color: Lime; "
        Me.txtg_Unit_Desc.Text = "g_Unit_Desc"
        Me.txtg_Unit_Desc.Top = 1.574803!
        Me.txtg_Unit_Desc.Visible = False
        Me.txtg_Unit_Desc.Width = 1.0!
        '
        'txtFOB_AMT
        '
        Me.txtFOB_AMT.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOB_AMT.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOB_AMT.DataField = "FOB_AMT"
        Me.txtFOB_AMT.Height = 0.1979167!
        Me.txtFOB_AMT.Left = 3.100394!
        Me.txtFOB_AMT.Name = "txtFOB_AMT"
        Me.txtFOB_AMT.Style = "color: Lime; "
        Me.txtFOB_AMT.Text = "FOB_AMT"
        Me.txtFOB_AMT.Top = 2.116143!
        Me.txtFOB_AMT.Visible = False
        Me.txtFOB_AMT.Width = 1.0!
        '
        'txtinvoice_board
        '
        Me.txtinvoice_board.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_board.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_board.DataField = "invoice_board"
        Me.txtinvoice_board.Height = 0.1979167!
        Me.txtinvoice_board.Left = 4.133858!
        Me.txtinvoice_board.Name = "txtinvoice_board"
        Me.txtinvoice_board.Style = "color: Red; "
        Me.txtinvoice_board.Text = "invoice_board"
        Me.txtinvoice_board.Top = 1.058071!
        Me.txtinvoice_board.Visible = False
        Me.txtinvoice_board.Width = 1.0!
        '
        'txtWeightDisplayHeader
        '
        Me.txtWeightDisplayHeader.Border.BottomColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.LeftColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.RightColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.Border.TopColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeader.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeader.DataField = "WeightDisplayHeader"
        Me.txtWeightDisplayHeader.Height = 0.1979167!
        Me.txtWeightDisplayHeader.Left = 4.133858!
        Me.txtWeightDisplayHeader.Name = "txtWeightDisplayHeader"
        Me.txtWeightDisplayHeader.Style = "color: Red; "
        Me.txtWeightDisplayHeader.Text = "WeightDisplayHeader"
        Me.txtWeightDisplayHeader.Top = 1.32874!
        Me.txtWeightDisplayHeader.Visible = False
        Me.txtWeightDisplayHeader.Width = 1.0!
        '
        'txtFOBDisplay
        '
        Me.txtFOBDisplay.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.DataField = "FOBDisplay"
        Me.txtFOBDisplay.Height = 0.1979167!
        Me.txtFOBDisplay.Left = 4.133858!
        Me.txtFOBDisplay.Name = "txtFOBDisplay"
        Me.txtFOBDisplay.Style = "color: Red; "
        Me.txtFOBDisplay.Text = "FOBDisplay"
        Me.txtFOBDisplay.Top = 1.574803!
        Me.txtFOBDisplay.Visible = False
        Me.txtFOBDisplay.Width = 1.0!
        '
        'txtunit_code2
        '
        Me.txtunit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.DataField = "unit_code2"
        Me.txtunit_code2.Height = 0.1979167!
        Me.txtunit_code2.Left = 4.133858!
        Me.txtunit_code2.Name = "txtunit_code2"
        Me.txtunit_code2.Style = "color: Red; "
        Me.txtunit_code2.Text = "unit_code2"
        Me.txtunit_code2.Top = 1.845472!
        Me.txtunit_code2.Visible = False
        Me.txtunit_code2.Width = 1.0!
        '
        'txtnet_weight
        '
        Me.txtnet_weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.DataField = "net_weight"
        Me.txtnet_weight.Height = 0.1979167!
        Me.txtnet_weight.Left = 4.133858!
        Me.txtnet_weight.Name = "txtnet_weight"
        Me.txtnet_weight.Style = "color: Red; "
        Me.txtnet_weight.Text = "net_weight"
        Me.txtnet_weight.Top = 2.116143!
        Me.txtnet_weight.Visible = False
        Me.txtnet_weight.Width = 1.0!
        '
        'txtgross_weightH
        '
        Me.txtgross_weightH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.RightColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.TopColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.DataField = "gross_weightH"
        Me.txtgross_weightH.Height = 0.1979167!
        Me.txtgross_weightH.Left = 2.116143!
        Me.txtgross_weightH.Name = "txtgross_weightH"
        Me.txtgross_weightH.Style = "color: Red; "
        Me.txtgross_weightH.Text = "gross_weightH"
        Me.txtgross_weightH.Top = 1.845472!
        Me.txtgross_weightH.Visible = False
        Me.txtgross_weightH.Width = 1.0!
        '
        'txtthird_country
        '
        Me.txtthird_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.DataField = "third_country"
        Me.txtthird_country.Height = 0.1979167!
        Me.txtthird_country.Left = 2.116143!
        Me.txtthird_country.Name = "txtthird_country"
        Me.txtthird_country.Style = "color: Red; "
        Me.txtthird_country.Text = "third_country"
        Me.txtthird_country.Top = 2.116143!
        Me.txtthird_country.Visible = False
        Me.txtthird_country.Width = 1.0!
        '
        'txtplace_exibition
        '
        Me.txtplace_exibition.Border.BottomColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.LeftColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.RightColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.TopColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.DataField = "place_exibition"
        Me.txtplace_exibition.Height = 0.1979167!
        Me.txtplace_exibition.Left = 2.116143!
        Me.txtplace_exibition.Name = "txtplace_exibition"
        Me.txtplace_exibition.Style = "color: Red; "
        Me.txtplace_exibition.Text = "place_exibition"
        Me.txtplace_exibition.Top = 2.362205!
        Me.txtplace_exibition.Visible = False
        Me.txtplace_exibition.Width = 1.0!
        '
        'txtWeightDisplayHeaderH
        '
        Me.txtWeightDisplayHeaderH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.RightColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.TopColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.DataField = "WeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Height = 0.1979167!
        Me.txtWeightDisplayHeaderH.Left = 4.133858!
        Me.txtWeightDisplayHeaderH.Name = "txtWeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Style = "color: Red; "
        Me.txtWeightDisplayHeaderH.Text = "WeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Top = 2.376559!
        Me.txtWeightDisplayHeaderH.Visible = False
        Me.txtWeightDisplayHeaderH.Width = 1.0!
        '
        'txtbox8
        '
        Me.txtbox8.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbox8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbox8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.RightColor = System.Drawing.Color.Black
        Me.txtbox8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.TopColor = System.Drawing.Color.Black
        Me.txtbox8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.DataField = "box8"
        Me.txtbox8.Height = 0.1968504!
        Me.txtbox8.Left = 5.241142!
        Me.txtbox8.Name = "txtbox8"
        Me.txtbox8.Style = "color: Red; "
        Me.txtbox8.Text = "box8"
        Me.txtbox8.Top = 0.5413386!
        Me.txtbox8.Visible = False
        Me.txtbox8.Width = 0.4183068!
        '
        'txtletter
        '
        Me.txtletter.Border.BottomColor = System.Drawing.Color.Black
        Me.txtletter.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtletter.Border.LeftColor = System.Drawing.Color.Black
        Me.txtletter.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtletter.Border.RightColor = System.Drawing.Color.Black
        Me.txtletter.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtletter.Border.TopColor = System.Drawing.Color.Black
        Me.txtletter.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtletter.DataField = "letter"
        Me.txtletter.Height = 0.1968504!
        Me.txtletter.Left = 5.241142!
        Me.txtletter.Name = "txtletter"
        Me.txtletter.Style = "color: Red; "
        Me.txtletter.Text = "letter"
        Me.txtletter.Top = 0.8006889!
        Me.txtletter.Visible = False
        Me.txtletter.Width = 0.4183068!
        '
        'txtprofit_per_unit
        '
        Me.txtprofit_per_unit.Border.BottomColor = System.Drawing.Color.Black
        Me.txtprofit_per_unit.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtprofit_per_unit.Border.LeftColor = System.Drawing.Color.Black
        Me.txtprofit_per_unit.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtprofit_per_unit.Border.RightColor = System.Drawing.Color.Black
        Me.txtprofit_per_unit.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtprofit_per_unit.Border.TopColor = System.Drawing.Color.Black
        Me.txtprofit_per_unit.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtprofit_per_unit.DataField = "profit_per_unit"
        Me.txtprofit_per_unit.Height = 0.1968504!
        Me.txtprofit_per_unit.Left = 5.241142!
        Me.txtprofit_per_unit.Name = "txtprofit_per_unit"
        Me.txtprofit_per_unit.Style = "color: Red; "
        Me.txtprofit_per_unit.Text = "profit_per_unit"
        Me.txtprofit_per_unit.Top = 1.060039!
        Me.txtprofit_per_unit.Visible = False
        Me.txtprofit_per_unit.Width = 0.4183068!
        '
        'txtmarks
        '
        Me.txtmarks.Border.BottomColor = System.Drawing.Color.Black
        Me.txtmarks.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.LeftColor = System.Drawing.Color.Black
        Me.txtmarks.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.RightColor = System.Drawing.Color.Black
        Me.txtmarks.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.TopColor = System.Drawing.Color.Black
        Me.txtmarks.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.DataField = "marks"
        Me.txtmarks.Height = 0.1968504!
        Me.txtmarks.Left = 5.241142!
        Me.txtmarks.Name = "txtmarks"
        Me.txtmarks.Style = "color: Red; "
        Me.txtmarks.Text = "marks"
        Me.txtmarks.Top = 1.319389!
        Me.txtmarks.Visible = False
        Me.txtmarks.Width = 0.4183068!
        '
        'txtSINGLE_COUNTRY_CONTENT
        '
        Me.txtSINGLE_COUNTRY_CONTENT.Border.BottomColor = System.Drawing.Color.Black
        Me.txtSINGLE_COUNTRY_CONTENT.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSINGLE_COUNTRY_CONTENT.Border.LeftColor = System.Drawing.Color.Black
        Me.txtSINGLE_COUNTRY_CONTENT.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSINGLE_COUNTRY_CONTENT.Border.RightColor = System.Drawing.Color.Black
        Me.txtSINGLE_COUNTRY_CONTENT.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSINGLE_COUNTRY_CONTENT.Border.TopColor = System.Drawing.Color.Black
        Me.txtSINGLE_COUNTRY_CONTENT.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSINGLE_COUNTRY_CONTENT.DataField = "SINGLE_COUNTRY_CONTENT"
        Me.txtSINGLE_COUNTRY_CONTENT.Height = 0.1968504!
        Me.txtSINGLE_COUNTRY_CONTENT.Left = 5.241142!
        Me.txtSINGLE_COUNTRY_CONTENT.Name = "txtSINGLE_COUNTRY_CONTENT"
        Me.txtSINGLE_COUNTRY_CONTENT.Style = "color: Red; "
        Me.txtSINGLE_COUNTRY_CONTENT.Text = "SINGLE_COUNTRY_CONTENT"
        Me.txtSINGLE_COUNTRY_CONTENT.Top = 1.578739!
        Me.txtSINGLE_COUNTRY_CONTENT.Visible = False
        Me.txtSINGLE_COUNTRY_CONTENT.Width = 0.4183068!
        '
        'txtNumInvoice
        '
        Me.txtNumInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.DataField = "NumInvoice"
        Me.txtNumInvoice.Height = 0.25!
        Me.txtNumInvoice.Left = 5.241142!
        Me.txtNumInvoice.Name = "txtNumInvoice"
        Me.txtNumInvoice.Style = "color: Red; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtNumInvoice.Text = "NumInvoice"
        Me.txtNumInvoice.Top = 1.838089!
        Me.txtNumInvoice.Visible = False
        Me.txtNumInvoice.Width = 0.5!
        '
        'txtUSDInvoice
        '
        Me.txtUSDInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtUSDInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoice.DataField = "USDInvoice"
        Me.txtUSDInvoice.Height = 0.25!
        Me.txtUSDInvoice.Left = 5.241142!
        Me.txtUSDInvoice.Name = "txtUSDInvoice"
        Me.txtUSDInvoice.Style = "color: Red; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtUSDInvoice.Text = "USDInvoice"
        Me.txtUSDInvoice.Top = 2.150589!
        Me.txtUSDInvoice.Visible = False
        Me.txtUSDInvoice.Width = 0.5!
        '
        'txtUSDInvoiceDetail
        '
        Me.txtUSDInvoiceDetail.Border.BottomColor = System.Drawing.Color.Black
        Me.txtUSDInvoiceDetail.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoiceDetail.Border.LeftColor = System.Drawing.Color.Black
        Me.txtUSDInvoiceDetail.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoiceDetail.Border.RightColor = System.Drawing.Color.Black
        Me.txtUSDInvoiceDetail.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoiceDetail.Border.TopColor = System.Drawing.Color.Black
        Me.txtUSDInvoiceDetail.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtUSDInvoiceDetail.DataField = "USDInvoiceDetail"
        Me.txtUSDInvoiceDetail.Height = 0.1979167!
        Me.txtUSDInvoiceDetail.Left = 5.241142!
        Me.txtUSDInvoiceDetail.Name = "txtUSDInvoiceDetail"
        Me.txtUSDInvoiceDetail.Style = "color: Red; "
        Me.txtUSDInvoiceDetail.Text = "USDInvoiceDetail"
        Me.txtUSDInvoiceDetail.Top = 2.463089!
        Me.txtUSDInvoiceDetail.Visible = False
        Me.txtUSDInvoiceDetail.Width = 1.0!
        '
        'txtInvoiceDetailTH
        '
        Me.txtInvoiceDetailTH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtInvoiceDetailTH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvoiceDetailTH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtInvoiceDetailTH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvoiceDetailTH.Border.RightColor = System.Drawing.Color.Black
        Me.txtInvoiceDetailTH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvoiceDetailTH.Border.TopColor = System.Drawing.Color.Black
        Me.txtInvoiceDetailTH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtInvoiceDetailTH.DataField = "InvoiceDetailTH"
        Me.txtInvoiceDetailTH.Height = 0.1979167!
        Me.txtInvoiceDetailTH.Left = 5.241142!
        Me.txtInvoiceDetailTH.Name = "txtInvoiceDetailTH"
        Me.txtInvoiceDetailTH.Style = "color: Red; "
        Me.txtInvoiceDetailTH.Text = "InvoiceDetailTH"
        Me.txtInvoiceDetailTH.Top = 2.723505!
        Me.txtInvoiceDetailTH.Visible = False
        Me.txtInvoiceDetailTH.Width = 1.0!
        '
        'txtTitleMain
        '
        Me.txtTitleMain.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTitleMain.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleMain.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTitleMain.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleMain.Border.RightColor = System.Drawing.Color.Black
        Me.txtTitleMain.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleMain.Border.TopColor = System.Drawing.Color.Black
        Me.txtTitleMain.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleMain.DataField = "InvoiceDetailTH"
        Me.txtTitleMain.Height = 0.25!
        Me.txtTitleMain.Left = 5.241142!
        Me.txtTitleMain.Name = "txtTitleMain"
        Me.txtTitleMain.Style = "color: Fuchsia; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtTitleMain.Text = "txtTitleMain"
        Me.txtTitleMain.Top = 2.983922!
        Me.txtTitleMain.Visible = False
        Me.txtTitleMain.Width = 1.625!
        '
        'txtCurrency_Code
        '
        Me.txtCurrency_Code.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCurrency_Code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCurrency_Code.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCurrency_Code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCurrency_Code.Border.RightColor = System.Drawing.Color.Black
        Me.txtCurrency_Code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCurrency_Code.Border.TopColor = System.Drawing.Color.Black
        Me.txtCurrency_Code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCurrency_Code.DataField = "Currency_Code"
        Me.txtCurrency_Code.Height = 0.25!
        Me.txtCurrency_Code.Left = 1.75!
        Me.txtCurrency_Code.Name = "txtCurrency_Code"
        Me.txtCurrency_Code.Style = "color: Fuchsia; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtCurrency_Code.Text = "Currency_Code"
        Me.txtCurrency_Code.Top = 3.0625!
        Me.txtCurrency_Code.Visible = False
        Me.txtCurrency_Code.Width = 1.625!
        '
        'txtgross_weightD
        '
        Me.txtgross_weightD.Border.BottomColor = System.Drawing.Color.Black
        Me.txtgross_weightD.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightD.Border.LeftColor = System.Drawing.Color.Black
        Me.txtgross_weightD.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightD.Border.RightColor = System.Drawing.Color.Black
        Me.txtgross_weightD.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightD.Border.TopColor = System.Drawing.Color.Black
        Me.txtgross_weightD.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightD.DataField = "gross_weightD"
        Me.txtgross_weightD.Height = 0.25!
        Me.txtgross_weightD.Left = 3.375!
        Me.txtgross_weightD.Name = "txtgross_weightD"
        Me.txtgross_weightD.Style = "color: Red; "
        Me.txtgross_weightD.Text = "gross_weightD"
        Me.txtgross_weightD.Top = 3.0625!
        Me.txtgross_weightD.Visible = False
        Me.txtgross_weightD.Width = 1.0!
        '
        'txtDIGIT1
        '
        Me.txtDIGIT1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtDIGIT1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtDIGIT1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtDIGIT1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtDIGIT1.Border.RightColor = System.Drawing.Color.Black
        Me.txtDIGIT1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtDIGIT1.Border.TopColor = System.Drawing.Color.Black
        Me.txtDIGIT1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtDIGIT1.DataField = "DIGIT1"
        Me.txtDIGIT1.Height = 0.1979167!
        Me.txtDIGIT1.Left = 1.8125!
        Me.txtDIGIT1.Name = "txtDIGIT1"
        Me.txtDIGIT1.Style = "color: Red; "
        Me.txtDIGIT1.Text = "DIGIT1"
        Me.txtDIGIT1.Top = 3.375!
        Me.txtDIGIT1.Visible = False
        Me.txtDIGIT1.Width = 1.0!
        '
        'txtCheckGrossDetail
        '
        Me.txtCheckGrossDetail.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCheckGrossDetail.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckGrossDetail.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCheckGrossDetail.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckGrossDetail.Border.RightColor = System.Drawing.Color.Black
        Me.txtCheckGrossDetail.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckGrossDetail.Border.TopColor = System.Drawing.Color.Black
        Me.txtCheckGrossDetail.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheckGrossDetail.DataField = "CheckGrossDetail"
        Me.txtCheckGrossDetail.Height = 0.1875!
        Me.txtCheckGrossDetail.Left = 3.0!
        Me.txtCheckGrossDetail.Name = "txtCheckGrossDetail"
        Me.txtCheckGrossDetail.Style = "color: Red; "
        Me.txtCheckGrossDetail.Text = "CheckGrossDetail"
        Me.txtCheckGrossDetail.Top = 3.375!
        Me.txtCheckGrossDetail.Visible = False
        Me.txtCheckGrossDetail.Width = 1.75!
        '
        'txtPriceOtherDetail
        '
        Me.txtPriceOtherDetail.Border.BottomColor = System.Drawing.Color.Black
        Me.txtPriceOtherDetail.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPriceOtherDetail.Border.LeftColor = System.Drawing.Color.Black
        Me.txtPriceOtherDetail.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPriceOtherDetail.Border.RightColor = System.Drawing.Color.Black
        Me.txtPriceOtherDetail.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPriceOtherDetail.Border.TopColor = System.Drawing.Color.Black
        Me.txtPriceOtherDetail.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtPriceOtherDetail.DataField = "PriceOtherDetail"
        Me.txtPriceOtherDetail.Height = 0.25!
        Me.txtPriceOtherDetail.Left = 6.1875!
        Me.txtPriceOtherDetail.Name = "txtPriceOtherDetail"
        Me.txtPriceOtherDetail.Style = "color: Fuchsia; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtPriceOtherDetail.Text = "PriceOtherDetail"
        Me.txtPriceOtherDetail.Top = 1.1875!
        Me.txtPriceOtherDetail.Visible = False
        Me.txtPriceOtherDetail.Width = 1.625!
        '
        'PageHeader1
        '
        Me.PageHeader1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtCompany_Check_1, Me.txtreference_code2_Temp, Me.txtdestination_Check2, Me.txttransport_by, Me.txtcompany_taxno, Me.txtcompany_country, Me.txtcompany_province, Me.txtcompany_address, Me.txtcompany_name, Me.txtob_address, Me.txtdest_remark, Me.txtcompany_fax, Me.txtcompany_phone, Me.txtdestination_company, Me.txtdestination_fax, Me.txtdestination_address, Me.txtdestination_phone, Me.txtdestination_province, Me.txtdest_Receive_country, Me.txtreference_code2, Me.txtcompany_email, Me.txtdestination_email, Me.txtdestination_taxid, Me.txtdest_remark1, Me.txtob_dest_address, Me.txtdeparture_date, Me.txtvasel_name, Me.txtport_discharge, Me.TextBox1, Me.txtTax_Status, Me.ReportInfo1, Me.txtCheck_StatusWeb, Me.txtNewEmail_ch02, Me.txtNewEmail_ch01, Me.txtReserve1, Me.txtsupplementary_details, Me.txtRep_Doc_date2, Me.txtTitleHead, Me.Line14, Me.Label8, Me.Label1, Me.Line13, Me.Label3, Me.Line23, Me.Line25, Me.Line26, Me.Label19, Me.Label9, Me.Label2, Me.Label20, Me.Label22, Me.TextBox2, Me.Line19, Me.Label17, Me.Label7, Me.Label31, Me.Shape3, Me.Label32, Me.Shape2, Me.Line9, Me.Label10, Me.Line21, Me.Line7, Me.Label4, Me.Line22, Me.Label14, Me.Label13, Me.Label12, Me.Label6, Me.Label5, Me.Label11, Me.Label15, Me.Label16, Me.Line5, Me.Label51})
        Me.PageHeader1.Height = 4.823902!
        Me.PageHeader1.Name = "PageHeader1"
        '
        'txtCompany_Check_1
        '
        Me.txtCompany_Check_1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.RightColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.TopColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.CanGrow = False
        Me.txtCompany_Check_1.Height = 1.0!
        Me.txtCompany_Check_1.Left = 0.4375!
        Me.txtCompany_Check_1.Name = "txtCompany_Check_1"
        Me.txtCompany_Check_1.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtCompany_Check_1.Text = Nothing
        Me.txtCompany_Check_1.Top = 0.375!
        Me.txtCompany_Check_1.Width = 3.6875!
        '
        'txtreference_code2_Temp
        '
        Me.txtreference_code2_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.CanGrow = False
        Me.txtreference_code2_Temp.Height = 0.3937007!
        Me.txtreference_code2_Temp.Left = 5.5!
        Me.txtreference_code2_Temp.Name = "txtreference_code2_Temp"
        Me.txtreference_code2_Temp.Style = "color: Blue; ddo-char-set: 1; font-weight: bold; font-size: 16pt; font-family: Br" &
    "owalliaUPC; "
        Me.txtreference_code2_Temp.Text = Nothing
        Me.txtreference_code2_Temp.Top = 0.25!
        Me.txtreference_code2_Temp.Width = 1.648622!
        '
        'txtdestination_Check2
        '
        Me.txtdestination_Check2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.CanGrow = False
        Me.txtdestination_Check2.Height = 0.8125!
        Me.txtdestination_Check2.Left = 0.4375!
        Me.txtdestination_Check2.Name = "txtdestination_Check2"
        Me.txtdestination_Check2.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtdestination_Check2.Text = Nothing
        Me.txtdestination_Check2.Top = 1.4375!
        Me.txtdestination_Check2.Width = 3.6875!
        '
        'txttransport_by
        '
        Me.txttransport_by.Border.BottomColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.LeftColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.RightColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.TopColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.DataField = "transport_by"
        Me.txttransport_by.Height = 0.375!
        Me.txttransport_by.Left = 0.5!
        Me.txttransport_by.Name = "txttransport_by"
        Me.txttransport_by.Style = "color: Blue; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; verti" &
    "cal-align: middle; "
        Me.txttransport_by.Text = "transport_by"
        Me.txttransport_by.Top = 2.375!
        Me.txttransport_by.Width = 3.5!
        '
        'txtcompany_taxno
        '
        Me.txtcompany_taxno.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.DataField = "company_taxno"
        Me.txtcompany_taxno.Height = 0.1979167!
        Me.txtcompany_taxno.Left = 0.2214567!
        Me.txtcompany_taxno.Name = "txtcompany_taxno"
        Me.txtcompany_taxno.Style = "color: Red; "
        Me.txtcompany_taxno.Text = "company_taxno"
        Me.txtcompany_taxno.Top = 0.07381889!
        Me.txtcompany_taxno.Visible = False
        Me.txtcompany_taxno.Width = 1.0!
        '
        'txtcompany_country
        '
        Me.txtcompany_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.DataField = "company_country"
        Me.txtcompany_country.Height = 0.1979167!
        Me.txtcompany_country.Left = 1.254921!
        Me.txtcompany_country.Name = "txtcompany_country"
        Me.txtcompany_country.Style = "color: Red; "
        Me.txtcompany_country.Text = "company_country"
        Me.txtcompany_country.Top = 0.07381889!
        Me.txtcompany_country.Visible = False
        Me.txtcompany_country.Width = 1.0!
        '
        'txtcompany_province
        '
        Me.txtcompany_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.DataField = "company_province"
        Me.txtcompany_province.Height = 0.1979167!
        Me.txtcompany_province.Left = 2.288386!
        Me.txtcompany_province.Name = "txtcompany_province"
        Me.txtcompany_province.Style = "color: Red; "
        Me.txtcompany_province.Text = "company_province"
        Me.txtcompany_province.Top = 0.07381889!
        Me.txtcompany_province.Visible = False
        Me.txtcompany_province.Width = 1.0!
        '
        'txtcompany_address
        '
        Me.txtcompany_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.DataField = "company_address"
        Me.txtcompany_address.Height = 0.1979167!
        Me.txtcompany_address.Left = 2.288386!
        Me.txtcompany_address.Name = "txtcompany_address"
        Me.txtcompany_address.Style = "color: Red; "
        Me.txtcompany_address.Text = "company_address"
        Me.txtcompany_address.Top = 0.2952756!
        Me.txtcompany_address.Visible = False
        Me.txtcompany_address.Width = 1.0!
        '
        'txtcompany_name
        '
        Me.txtcompany_name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.DataField = "company_name"
        Me.txtcompany_name.Height = 0.1979167!
        Me.txtcompany_name.Left = 3.297244!
        Me.txtcompany_name.Name = "txtcompany_name"
        Me.txtcompany_name.Style = "color: Red; "
        Me.txtcompany_name.Text = "company_name"
        Me.txtcompany_name.Top = 0.07381889!
        Me.txtcompany_name.Visible = False
        Me.txtcompany_name.Width = 1.0!
        '
        'txtob_address
        '
        Me.txtob_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtob_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtob_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtob_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtob_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.DataField = "ob_address"
        Me.txtob_address.Height = 0.1979167!
        Me.txtob_address.Left = 3.297244!
        Me.txtob_address.Name = "txtob_address"
        Me.txtob_address.Style = "color: Red; "
        Me.txtob_address.Text = "ob_address"
        Me.txtob_address.Top = 0.2952756!
        Me.txtob_address.Visible = False
        Me.txtob_address.Width = 1.0!
        '
        'txtdest_remark
        '
        Me.txtdest_remark.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.DataField = "dest_remark"
        Me.txtdest_remark.Height = 0.1979167!
        Me.txtdest_remark.Left = 4.330709!
        Me.txtdest_remark.Name = "txtdest_remark"
        Me.txtdest_remark.Style = "color: Red; "
        Me.txtdest_remark.Text = "dest_remark"
        Me.txtdest_remark.Top = 0.07381889!
        Me.txtdest_remark.Visible = False
        Me.txtdest_remark.Width = 1.0!
        '
        'txtcompany_fax
        '
        Me.txtcompany_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.DataField = "company_fax"
        Me.txtcompany_fax.Height = 0.1979167!
        Me.txtcompany_fax.Left = 0.2214567!
        Me.txtcompany_fax.Name = "txtcompany_fax"
        Me.txtcompany_fax.Style = "color: Red; "
        Me.txtcompany_fax.Text = "company_fax"
        Me.txtcompany_fax.Top = 0.2952756!
        Me.txtcompany_fax.Visible = False
        Me.txtcompany_fax.Width = 1.0!
        '
        'txtcompany_phone
        '
        Me.txtcompany_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.DataField = "company_phone"
        Me.txtcompany_phone.Height = 0.1979167!
        Me.txtcompany_phone.Left = 1.254921!
        Me.txtcompany_phone.Name = "txtcompany_phone"
        Me.txtcompany_phone.Style = "color: Red; "
        Me.txtcompany_phone.Text = "company_phone"
        Me.txtcompany_phone.Top = 0.2952756!
        Me.txtcompany_phone.Visible = False
        Me.txtcompany_phone.Width = 1.0!
        '
        'txtdestination_company
        '
        Me.txtdestination_company.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.DataField = "destination_company"
        Me.txtdestination_company.Height = 0.1979167!
        Me.txtdestination_company.Left = 0.1722441!
        Me.txtdestination_company.Name = "txtdestination_company"
        Me.txtdestination_company.Style = "color: Red; "
        Me.txtdestination_company.Text = "destination_company"
        Me.txtdestination_company.Top = 4.330709!
        Me.txtdestination_company.Visible = False
        Me.txtdestination_company.Width = 1.0!
        '
        'txtdestination_fax
        '
        Me.txtdestination_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.DataField = "destination_fax"
        Me.txtdestination_fax.Height = 0.1979167!
        Me.txtdestination_fax.Left = 1.205709!
        Me.txtdestination_fax.Name = "txtdestination_fax"
        Me.txtdestination_fax.Style = "color: Red; "
        Me.txtdestination_fax.Text = "destination_fax"
        Me.txtdestination_fax.Top = 4.330709!
        Me.txtdestination_fax.Visible = False
        Me.txtdestination_fax.Width = 1.0!
        '
        'txtdestination_address
        '
        Me.txtdestination_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.DataField = "destination_address"
        Me.txtdestination_address.Height = 0.1979167!
        Me.txtdestination_address.Left = 1.205709!
        Me.txtdestination_address.Name = "txtdestination_address"
        Me.txtdestination_address.Style = "color: Red; "
        Me.txtdestination_address.Text = "destination_address"
        Me.txtdestination_address.Top = 4.625985!
        Me.txtdestination_address.Visible = False
        Me.txtdestination_address.Width = 1.0!
        '
        'txtdestination_phone
        '
        Me.txtdestination_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.DataField = "destination_phone"
        Me.txtdestination_phone.Height = 0.1979167!
        Me.txtdestination_phone.Left = 0.1722441!
        Me.txtdestination_phone.Name = "txtdestination_phone"
        Me.txtdestination_phone.Style = "color: Red; "
        Me.txtdestination_phone.Text = "destination_phone"
        Me.txtdestination_phone.Top = 4.615732!
        Me.txtdestination_phone.Visible = False
        Me.txtdestination_phone.Width = 1.0!
        '
        'txtdestination_province
        '
        Me.txtdestination_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.DataField = "destination_province"
        Me.txtdestination_province.Height = 0.1979167!
        Me.txtdestination_province.Left = 2.239173!
        Me.txtdestination_province.Name = "txtdestination_province"
        Me.txtdestination_province.Style = "color: Red; "
        Me.txtdestination_province.Text = "destination_province"
        Me.txtdestination_province.Top = 4.330709!
        Me.txtdestination_province.Visible = False
        Me.txtdestination_province.Width = 1.0!
        '
        'txtdest_Receive_country
        '
        Me.txtdest_Receive_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.DataField = "dest_Receive_country"
        Me.txtdest_Receive_country.Height = 0.1979167!
        Me.txtdest_Receive_country.Left = 2.239173!
        Me.txtdest_Receive_country.Name = "txtdest_Receive_country"
        Me.txtdest_Receive_country.Style = "color: Red; "
        Me.txtdest_Receive_country.Text = "dest_Receive_country"
        Me.txtdest_Receive_country.Top = 4.591125!
        Me.txtdest_Receive_country.Visible = False
        Me.txtdest_Receive_country.Width = 1.0!
        '
        'txtreference_code2
        '
        Me.txtreference_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.DataField = "reference_code2"
        Me.txtreference_code2.Height = 0.3937007!
        Me.txtreference_code2.Left = 5.487205!
        Me.txtreference_code2.Name = "txtreference_code2"
        Me.txtreference_code2.Style = "color: Red; ddo-char-set: 222; font-weight: bold; font-size: 13pt; font-family: B" &
    "rowalliaUPC; "
        Me.txtreference_code2.Text = "reference_code2"
        Me.txtreference_code2.Top = 0.9104334!
        Me.txtreference_code2.Visible = False
        Me.txtreference_code2.Width = 1.648622!
        '
        'txtcompany_email
        '
        Me.txtcompany_email.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.DataField = "company_email"
        Me.txtcompany_email.Height = 0.1979167!
        Me.txtcompany_email.Left = 4.330709!
        Me.txtcompany_email.Name = "txtcompany_email"
        Me.txtcompany_email.Style = "color: Red; "
        Me.txtcompany_email.Text = "company_email"
        Me.txtcompany_email.Top = 0.3342356!
        Me.txtcompany_email.Visible = False
        Me.txtcompany_email.Width = 1.0!
        '
        'txtdestination_email
        '
        Me.txtdestination_email.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.DataField = "destination_email"
        Me.txtdestination_email.Height = 0.1979167!
        Me.txtdestination_email.Left = 4.330709!
        Me.txtdestination_email.Name = "txtdestination_email"
        Me.txtdestination_email.Style = "color: Red; "
        Me.txtdestination_email.Text = "destination_email"
        Me.txtdestination_email.Top = 0.5946523!
        Me.txtdestination_email.Visible = False
        Me.txtdestination_email.Width = 1.0!
        '
        'txtdestination_taxid
        '
        Me.txtdestination_taxid.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.DataField = "destination_taxid"
        Me.txtdestination_taxid.Height = 0.1979167!
        Me.txtdestination_taxid.Left = 4.330709!
        Me.txtdestination_taxid.Name = "txtdestination_taxid"
        Me.txtdestination_taxid.Style = "color: Red; "
        Me.txtdestination_taxid.Text = "destination_taxid"
        Me.txtdestination_taxid.Top = 0.8550687!
        Me.txtdestination_taxid.Visible = False
        Me.txtdestination_taxid.Width = 1.0!
        '
        'txtdest_remark1
        '
        Me.txtdest_remark1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.DataField = "dest_remark1"
        Me.txtdest_remark1.Height = 0.1979167!
        Me.txtdest_remark1.Left = 4.330709!
        Me.txtdest_remark1.Name = "txtdest_remark1"
        Me.txtdest_remark1.Style = "color: Red; "
        Me.txtdest_remark1.Text = "dest_remark1"
        Me.txtdest_remark1.Top = 1.115486!
        Me.txtdest_remark1.Visible = False
        Me.txtdest_remark1.Width = 1.0!
        '
        'txtob_dest_address
        '
        Me.txtob_dest_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.DataField = "ob_dest_address"
        Me.txtob_dest_address.Height = 0.1979167!
        Me.txtob_dest_address.Left = 4.330709!
        Me.txtob_dest_address.Name = "txtob_dest_address"
        Me.txtob_dest_address.Style = "color: Red; "
        Me.txtob_dest_address.Text = "ob_dest_address"
        Me.txtob_dest_address.Top = 1.375903!
        Me.txtob_dest_address.Visible = False
        Me.txtob_dest_address.Width = 1.0!
        '
        'txtdeparture_date
        '
        Me.txtdeparture_date.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdeparture_date.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdeparture_date.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdeparture_date.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdeparture_date.Border.RightColor = System.Drawing.Color.Black
        Me.txtdeparture_date.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdeparture_date.Border.TopColor = System.Drawing.Color.Black
        Me.txtdeparture_date.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdeparture_date.DataField = "departure_date"
        Me.txtdeparture_date.Height = 0.3125!
        Me.txtdeparture_date.Left = 0.5!
        Me.txtdeparture_date.Name = "txtdeparture_date"
        Me.txtdeparture_date.OutputFormat = resources.GetString("txtdeparture_date.OutputFormat")
        Me.txtdeparture_date.Style = "color: Blue; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtdeparture_date.Text = "departure_date"
        Me.txtdeparture_date.Top = 2.854167!
        Me.txtdeparture_date.Width = 3.5!
        '
        'txtvasel_name
        '
        Me.txtvasel_name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtvasel_name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvasel_name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtvasel_name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvasel_name.Border.RightColor = System.Drawing.Color.Black
        Me.txtvasel_name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvasel_name.Border.TopColor = System.Drawing.Color.Black
        Me.txtvasel_name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtvasel_name.DataField = "vasel_name"
        Me.txtvasel_name.Height = 0.3125!
        Me.txtvasel_name.Left = 0.5!
        Me.txtvasel_name.Name = "txtvasel_name"
        Me.txtvasel_name.Style = "color: Blue; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtvasel_name.Text = "vasel_name"
        Me.txtvasel_name.Top = 3.291667!
        Me.txtvasel_name.Width = 3.5!
        '
        'txtport_discharge
        '
        Me.txtport_discharge.Border.BottomColor = System.Drawing.Color.Black
        Me.txtport_discharge.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtport_discharge.Border.LeftColor = System.Drawing.Color.Black
        Me.txtport_discharge.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtport_discharge.Border.RightColor = System.Drawing.Color.Black
        Me.txtport_discharge.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtport_discharge.Border.TopColor = System.Drawing.Color.Black
        Me.txtport_discharge.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtport_discharge.CanGrow = False
        Me.txtport_discharge.DataField = "port_discharge"
        Me.txtport_discharge.Height = 0.4375!
        Me.txtport_discharge.Left = 0.5!
        Me.txtport_discharge.Name = "txtport_discharge"
        Me.txtport_discharge.Style = "color: Blue; ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtport_discharge.Text = "port_discharge"
        Me.txtport_discharge.Top = 3.666667!
        Me.txtport_discharge.Width = 3.5!
        '
        'TextBox1
        '
        Me.TextBox1.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Height = 0.5167325!
        Me.TextBox1.Left = 5.75!
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Style = "ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.TextBox1.Text = Nothing
        Me.TextBox1.Top = 1.645833!
        Me.TextBox1.Visible = False
        Me.TextBox1.Width = 2.140748!
        '
        'txtTax_Status
        '
        Me.txtTax_Status.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTax_Status.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTax_Status.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTax_Status.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTax_Status.Border.RightColor = System.Drawing.Color.Black
        Me.txtTax_Status.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTax_Status.Border.TopColor = System.Drawing.Color.Black
        Me.txtTax_Status.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTax_Status.DataField = "Tax_Status"
        Me.txtTax_Status.Height = 0.1979167!
        Me.txtTax_Status.Left = 4.330709!
        Me.txtTax_Status.Name = "txtTax_Status"
        Me.txtTax_Status.Style = "color: Red; "
        Me.txtTax_Status.Text = "Tax_Status"
        Me.txtTax_Status.Top = 1.63632!
        Me.txtTax_Status.Visible = False
        Me.txtTax_Status.Width = 1.0!
        '
        'ReportInfo1
        '
        Me.ReportInfo1.Border.BottomColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.LeftColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.RightColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.TopColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.CanGrow = False
        Me.ReportInfo1.FormatString = Nothing
        Me.ReportInfo1.Height = 0.3125!
        Me.ReportInfo1.Left = 3.625!
        Me.ReportInfo1.Name = "ReportInfo1"
        Me.ReportInfo1.Style = "color: Blue; text-align: center; font-family: BrowalliaUPC; vertical-align: middl" &
    "e; "
        Me.ReportInfo1.Top = 4.1875!
        Me.ReportInfo1.Width = 1.5!
        '
        'txtCheck_StatusWeb
        '
        Me.txtCheck_StatusWeb.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCheck_StatusWeb.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_StatusWeb.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCheck_StatusWeb.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_StatusWeb.Border.RightColor = System.Drawing.Color.Black
        Me.txtCheck_StatusWeb.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_StatusWeb.Border.TopColor = System.Drawing.Color.Black
        Me.txtCheck_StatusWeb.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_StatusWeb.DataField = "Check_StatusWeb"
        Me.txtCheck_StatusWeb.Height = 0.1979167!
        Me.txtCheck_StatusWeb.Left = 4.330709!
        Me.txtCheck_StatusWeb.Name = "txtCheck_StatusWeb"
        Me.txtCheck_StatusWeb.Style = "color: Red; "
        Me.txtCheck_StatusWeb.Text = "Check_StatusWeb"
        Me.txtCheck_StatusWeb.Top = 1.896737!
        Me.txtCheck_StatusWeb.Visible = False
        Me.txtCheck_StatusWeb.Width = 1.0!
        '
        'txtNewEmail_ch02
        '
        Me.txtNewEmail_ch02.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.RightColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.TopColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.DataField = "NewEmail_ch02"
        Me.txtNewEmail_ch02.Height = 0.1979167!
        Me.txtNewEmail_ch02.Left = 5.364173!
        Me.txtNewEmail_ch02.Name = "txtNewEmail_ch02"
        Me.txtNewEmail_ch02.Style = "color: Red; "
        Me.txtNewEmail_ch02.Text = "NewEmail_ch02"
        Me.txtNewEmail_ch02.Top = 2.157154!
        Me.txtNewEmail_ch02.Visible = False
        Me.txtNewEmail_ch02.Width = 1.0!
        '
        'txtNewEmail_ch01
        '
        Me.txtNewEmail_ch01.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.RightColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.TopColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.DataField = "NewEmail_ch01"
        Me.txtNewEmail_ch01.Height = 0.1979167!
        Me.txtNewEmail_ch01.Left = 4.330709!
        Me.txtNewEmail_ch01.Name = "txtNewEmail_ch01"
        Me.txtNewEmail_ch01.Style = "color: Red; "
        Me.txtNewEmail_ch01.Text = "NewEmail_ch01"
        Me.txtNewEmail_ch01.Top = 2.157154!
        Me.txtNewEmail_ch01.Visible = False
        Me.txtNewEmail_ch01.Width = 1.0!
        '
        'txtReserve1
        '
        Me.txtReserve1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtReserve1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtReserve1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtReserve1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtReserve1.Border.RightColor = System.Drawing.Color.Black
        Me.txtReserve1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtReserve1.Border.TopColor = System.Drawing.Color.Black
        Me.txtReserve1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtReserve1.DataField = "Reserve1"
        Me.txtReserve1.Height = 0.1979167!
        Me.txtReserve1.Left = 4.330709!
        Me.txtReserve1.Name = "txtReserve1"
        Me.txtReserve1.Style = "color: Red; "
        Me.txtReserve1.Text = "Reserve1"
        Me.txtReserve1.Top = 2.417571!
        Me.txtReserve1.Visible = False
        Me.txtReserve1.Width = 1.0!
        '
        'txtsupplementary_details
        '
        Me.txtsupplementary_details.Border.BottomColor = System.Drawing.Color.Black
        Me.txtsupplementary_details.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtsupplementary_details.Border.LeftColor = System.Drawing.Color.Black
        Me.txtsupplementary_details.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtsupplementary_details.Border.RightColor = System.Drawing.Color.Black
        Me.txtsupplementary_details.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtsupplementary_details.Border.TopColor = System.Drawing.Color.Black
        Me.txtsupplementary_details.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtsupplementary_details.DataField = "supplementary_details"
        Me.txtsupplementary_details.Height = 0.1979167!
        Me.txtsupplementary_details.Left = 4.330709!
        Me.txtsupplementary_details.Name = "txtsupplementary_details"
        Me.txtsupplementary_details.Style = "color: Red; "
        Me.txtsupplementary_details.Text = "supplementary_details"
        Me.txtsupplementary_details.Top = 2.677988!
        Me.txtsupplementary_details.Visible = False
        Me.txtsupplementary_details.Width = 1.0!
        '
        'txtRep_Doc_date2
        '
        Me.txtRep_Doc_date2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtRep_Doc_date2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtRep_Doc_date2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtRep_Doc_date2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtRep_Doc_date2.Border.RightColor = System.Drawing.Color.Black
        Me.txtRep_Doc_date2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtRep_Doc_date2.Border.TopColor = System.Drawing.Color.Black
        Me.txtRep_Doc_date2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtRep_Doc_date2.DataField = "Rep_Doc_date2"
        Me.txtRep_Doc_date2.Height = 0.1979167!
        Me.txtRep_Doc_date2.Left = 4.330709!
        Me.txtRep_Doc_date2.Name = "txtRep_Doc_date2"
        Me.txtRep_Doc_date2.Style = "color: Red; "
        Me.txtRep_Doc_date2.Text = "Rep_Doc_date2"
        Me.txtRep_Doc_date2.Top = 2.938404!
        Me.txtRep_Doc_date2.Visible = False
        Me.txtRep_Doc_date2.Width = 1.0!
        '
        'txtTitleHead
        '
        Me.txtTitleHead.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTitleHead.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleHead.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTitleHead.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleHead.Border.RightColor = System.Drawing.Color.Black
        Me.txtTitleHead.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleHead.Border.TopColor = System.Drawing.Color.Black
        Me.txtTitleHead.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTitleHead.Height = 0.22!
        Me.txtTitleHead.Left = 1.875!
        Me.txtTitleHead.Name = "txtTitleHead"
        Me.txtTitleHead.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtTitleHead.Text = Nothing
        Me.txtTitleHead.Top = 4.572917!
        Me.txtTitleHead.Visible = False
        Me.txtTitleHead.Width = 3.25!
        '
        'Line14
        '
        Me.Line14.Border.BottomColor = System.Drawing.Color.Black
        Me.Line14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.LeftColor = System.Drawing.Color.Black
        Me.Line14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.RightColor = System.Drawing.Color.Black
        Me.Line14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.TopColor = System.Drawing.Color.Black
        Me.Line14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Height = 0!
        Me.Line14.Left = 0.0625!
        Me.Line14.LineWeight = 1.0!
        Me.Line14.Name = "Line14"
        Me.Line14.Top = 0.1875!
        Me.Line14.Width = 8.125!
        Me.Line14.X1 = 0.0625!
        Me.Line14.X2 = 8.1875!
        Me.Line14.Y1 = 0.1875!
        Me.Line14.Y2 = 0.1875!
        '
        'Label8
        '
        Me.Label8.Border.BottomColor = System.Drawing.Color.Black
        Me.Label8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.LeftColor = System.Drawing.Color.Black
        Me.Label8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.RightColor = System.Drawing.Color.Black
        Me.Label8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.TopColor = System.Drawing.Color.Black
        Me.Label8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Height = 0.1875!
        Me.Label8.HyperLink = Nothing
        Me.Label8.Left = 0.1875!
        Me.Label8.Name = "Label8"
        Me.Label8.Style = "font-size: 9pt; font-family: Times New Roman; "
        Me.Label8.Text = "1. Goods consigned from (Exporter's business name, address, country)"
        Me.Label8.Top = 0.2083333!
        Me.Label8.Width = 4.0!
        '
        'Label1
        '
        Me.Label1.Border.BottomColor = System.Drawing.Color.Black
        Me.Label1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.LeftColor = System.Drawing.Color.Black
        Me.Label1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.RightColor = System.Drawing.Color.Black
        Me.Label1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.TopColor = System.Drawing.Color.Black
        Me.Label1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Height = 0.1875!
        Me.Label1.HyperLink = Nothing
        Me.Label1.Left = 0.1875!
        Me.Label1.Name = "Label1"
        Me.Label1.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label1.Text = "2. Goods consigned to (Consignee's name, address, country)"
        Me.Label1.Top = 1.270833!
        Me.Label1.Width = 4.0!
        '
        'Line13
        '
        Me.Line13.Border.BottomColor = System.Drawing.Color.Black
        Me.Line13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.LeftColor = System.Drawing.Color.Black
        Me.Line13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.RightColor = System.Drawing.Color.Black
        Me.Line13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.TopColor = System.Drawing.Color.Black
        Me.Line13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Height = 0!
        Me.Line13.Left = 0.0625!
        Me.Line13.LineWeight = 1.0!
        Me.Line13.Name = "Line13"
        Me.Line13.Top = 1.25!
        Me.Line13.Width = 4.25!
        Me.Line13.X1 = 0.0625!
        Me.Line13.X2 = 4.3125!
        Me.Line13.Y1 = 1.25!
        Me.Line13.Y2 = 1.25!
        '
        'Label3
        '
        Me.Label3.Border.BottomColor = System.Drawing.Color.Black
        Me.Label3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.LeftColor = System.Drawing.Color.Black
        Me.Label3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.RightColor = System.Drawing.Color.Black
        Me.Label3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.TopColor = System.Drawing.Color.Black
        Me.Label3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Height = 0.1875!
        Me.Label3.HyperLink = Nothing
        Me.Label3.Left = 0.1875!
        Me.Label3.Name = "Label3"
        Me.Label3.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label3.Text = "3. Means of transport and route (as far as known)"
        Me.Label3.Top = 2.3125!
        Me.Label3.Width = 3.875!
        '
        'Line23
        '
        Me.Line23.Border.BottomColor = System.Drawing.Color.Black
        Me.Line23.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line23.Border.LeftColor = System.Drawing.Color.Black
        Me.Line23.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line23.Border.RightColor = System.Drawing.Color.Black
        Me.Line23.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line23.Border.TopColor = System.Drawing.Color.Black
        Me.Line23.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line23.Height = 0!
        Me.Line23.Left = 0.0625!
        Me.Line23.LineWeight = 1.0!
        Me.Line23.Name = "Line23"
        Me.Line23.Top = 2.25!
        Me.Line23.Width = 8.125!
        Me.Line23.X1 = 0.0625!
        Me.Line23.X2 = 8.1875!
        Me.Line23.Y1 = 2.25!
        Me.Line23.Y2 = 2.25!
        '
        'Line25
        '
        Me.Line25.Border.BottomColor = System.Drawing.Color.Black
        Me.Line25.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.LeftColor = System.Drawing.Color.Black
        Me.Line25.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.RightColor = System.Drawing.Color.Black
        Me.Line25.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.TopColor = System.Drawing.Color.Black
        Me.Line25.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Height = 4.625!
        Me.Line25.Left = 0.0625!
        Me.Line25.LineWeight = 1.0!
        Me.Line25.Name = "Line25"
        Me.Line25.Top = 0.1875!
        Me.Line25.Width = 0!
        Me.Line25.X1 = 0.0625!
        Me.Line25.X2 = 0.0625!
        Me.Line25.Y1 = 4.8125!
        Me.Line25.Y2 = 0.1875!
        '
        'Line26
        '
        Me.Line26.Border.BottomColor = System.Drawing.Color.Black
        Me.Line26.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.LeftColor = System.Drawing.Color.Black
        Me.Line26.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.RightColor = System.Drawing.Color.Black
        Me.Line26.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.TopColor = System.Drawing.Color.Black
        Me.Line26.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Height = 3.75!
        Me.Line26.Left = 4.3125!
        Me.Line26.LineWeight = 1.0!
        Me.Line26.Name = "Line26"
        Me.Line26.Top = 0.1875!
        Me.Line26.Width = 0!
        Me.Line26.X1 = 4.3125!
        Me.Line26.X2 = 4.3125!
        Me.Line26.Y1 = 3.9375!
        Me.Line26.Y2 = 0.1875!
        '
        'Label19
        '
        Me.Label19.Border.BottomColor = System.Drawing.Color.Black
        Me.Label19.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.LeftColor = System.Drawing.Color.Black
        Me.Label19.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.RightColor = System.Drawing.Color.Black
        Me.Label19.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.TopColor = System.Drawing.Color.Black
        Me.Label19.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Height = 0.25!
        Me.Label19.HyperLink = Nothing
        Me.Label19.Left = 4.5625!
        Me.Label19.Name = "Label19"
        Me.Label19.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label19.Text = "Reference No."
        Me.Label19.Top = 0.28125!
        Me.Label19.Width = 0.875!
        '
        'Label9
        '
        Me.Label9.Border.BottomColor = System.Drawing.Color.Black
        Me.Label9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.LeftColor = System.Drawing.Color.Black
        Me.Label9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.RightColor = System.Drawing.Color.Black
        Me.Label9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.TopColor = System.Drawing.Color.Black
        Me.Label9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Height = 0.3125!
        Me.Label9.HyperLink = Nothing
        Me.Label9.Left = 4.75!
        Me.Label9.Name = "Label9"
        Me.Label9.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 9.75pt; font-f" &
    "amily: Times New Roman; "
        Me.Label9.Text = "ASEAN -CHINA FREE TRADE AREA PREFERENTIAL TARIFF"
        Me.Label9.Top = 0.5625!
        Me.Label9.Width = 2.75!
        '
        'Label2
        '
        Me.Label2.Border.BottomColor = System.Drawing.Color.Black
        Me.Label2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.LeftColor = System.Drawing.Color.Black
        Me.Label2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.RightColor = System.Drawing.Color.Black
        Me.Label2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.TopColor = System.Drawing.Color.Black
        Me.Label2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Height = 0.3125!
        Me.Label2.HyperLink = Nothing
        Me.Label2.Left = 4.875!
        Me.Label2.Name = "Label2"
        Me.Label2.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 9.75pt; font-f" &
    "amily: Times New Roman; "
        Me.Label2.Text = "CERTIFICATE OF ORIGIN"
        Me.Label2.Top = 0.9375!
        Me.Label2.Width = 2.4375!
        '
        'Label20
        '
        Me.Label20.Border.BottomColor = System.Drawing.Color.Black
        Me.Label20.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label20.Border.LeftColor = System.Drawing.Color.Black
        Me.Label20.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label20.Border.RightColor = System.Drawing.Color.Black
        Me.Label20.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label20.Border.TopColor = System.Drawing.Color.Black
        Me.Label20.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label20.Height = 0.25!
        Me.Label20.HyperLink = Nothing
        Me.Label20.Left = 4.4375!
        Me.Label20.Name = "Label20"
        Me.Label20.Style = "ddo-char-set: 0; text-align: center; font-size: 11.25pt; font-family: Times New R" &
    "oman; "
        Me.Label20.Text = "(Combined Declaration and Certificate)"
        Me.Label20.Top = 1.1875!
        Me.Label20.Width = 3.4375!
        '
        'Label22
        '
        Me.Label22.Border.BottomColor = System.Drawing.Color.Black
        Me.Label22.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.LeftColor = System.Drawing.Color.Black
        Me.Label22.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.RightColor = System.Drawing.Color.Black
        Me.Label22.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.TopColor = System.Drawing.Color.Black
        Me.Label22.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Height = 0.25!
        Me.Label22.HyperLink = Nothing
        Me.Label22.Left = 5.625!
        Me.Label22.Name = "Label22"
        Me.Label22.Style = "color: #0000C0; ddo-char-set: 0; text-align: center; font-weight: bold; font-size" &
    ": 14.25pt; font-family: Times New Roman; "
        Me.Label22.Text = "FORM E"
        Me.Label22.Top = 1.4375!
        Me.Label22.Width = 1.125!
        '
        'TextBox2
        '
        Me.TextBox2.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Height = 0.5167325!
        Me.TextBox2.Left = 5.8125!
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Style = "ddo-char-set: 222; font-weight: bold; font-size: 15.75pt; font-family: BrowalliaU" &
    "PC; "
        Me.TextBox2.Text = "THAILAND"
        Me.TextBox2.Top = 1.625!
        Me.TextBox2.Width = 2.140748!
        '
        'Line19
        '
        Me.Line19.Border.BottomColor = System.Drawing.Color.Black
        Me.Line19.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.LeftColor = System.Drawing.Color.Black
        Me.Line19.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.RightColor = System.Drawing.Color.Black
        Me.Line19.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.TopColor = System.Drawing.Color.Black
        Me.Line19.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Height = 0!
        Me.Line19.Left = 5.25!
        Me.Line19.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line19.LineWeight = 1.0!
        Me.Line19.Name = "Line19"
        Me.Line19.Top = 1.875!
        Me.Line19.Width = 2.4375!
        Me.Line19.X1 = 5.25!
        Me.Line19.X2 = 7.6875!
        Me.Line19.Y1 = 1.875!
        Me.Line19.Y2 = 1.875!
        '
        'Label17
        '
        Me.Label17.Border.BottomColor = System.Drawing.Color.Black
        Me.Label17.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.LeftColor = System.Drawing.Color.Black
        Me.Label17.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.RightColor = System.Drawing.Color.Black
        Me.Label17.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.TopColor = System.Drawing.Color.Black
        Me.Label17.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Height = 0.1875!
        Me.Label17.HyperLink = Nothing
        Me.Label17.Left = 4.625!
        Me.Label17.Name = "Label17"
        Me.Label17.Style = "text-align: left; font-size: 9pt; font-family: Times New Roman; "
        Me.Label17.Text = "Issued in"
        Me.Label17.Top = 1.75!
        Me.Label17.Width = 0.5625!
        '
        'Label7
        '
        Me.Label7.Border.BottomColor = System.Drawing.Color.Black
        Me.Label7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.LeftColor = System.Drawing.Color.Black
        Me.Label7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.RightColor = System.Drawing.Color.Black
        Me.Label7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.TopColor = System.Drawing.Color.Black
        Me.Label7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Height = 0.1875!
        Me.Label7.HyperLink = Nothing
        Me.Label7.Left = 5.625!
        Me.Label7.Name = "Label7"
        Me.Label7.Style = "text-align: center; font-size: 9pt; font-family: Times New Roman; "
        Me.Label7.Text = "(Country)"
        Me.Label7.Top = 1.875!
        Me.Label7.Width = 1.125!
        '
        'Label31
        '
        Me.Label31.Border.BottomColor = System.Drawing.Color.Black
        Me.Label31.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.LeftColor = System.Drawing.Color.Black
        Me.Label31.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.RightColor = System.Drawing.Color.Black
        Me.Label31.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.TopColor = System.Drawing.Color.Black
        Me.Label31.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Height = 0.1875!
        Me.Label31.HyperLink = Nothing
        Me.Label31.Left = 4.4375!
        Me.Label31.Name = "Label31"
        Me.Label31.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label31.Text = "4. For Official Use"
        Me.Label31.Top = 2.3125!
        Me.Label31.Width = 2.5625!
        '
        'Shape3
        '
        Me.Shape3.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Border.RightColor = System.Drawing.Color.Black
        Me.Shape3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Border.TopColor = System.Drawing.Color.Black
        Me.Shape3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape3.Height = 0.3125!
        Me.Shape3.Left = 4.5625!
        Me.Shape3.Name = "Shape3"
        Me.Shape3.RoundingRadius = 9.999999!
        Me.Shape3.Top = 2.625!
        Me.Shape3.Width = 0.3125!
        '
        'Label32
        '
        Me.Label32.Border.BottomColor = System.Drawing.Color.Black
        Me.Label32.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label32.Border.LeftColor = System.Drawing.Color.Black
        Me.Label32.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label32.Border.RightColor = System.Drawing.Color.Black
        Me.Label32.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label32.Border.TopColor = System.Drawing.Color.Black
        Me.Label32.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label32.Height = 0.375!
        Me.Label32.HyperLink = Nothing
        Me.Label32.Left = 4.9375!
        Me.Label32.Name = "Label32"
        Me.Label32.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label32.Text = "Preferential Treatment Given Under ASEAN-CHINA Free Trade Area Preferential Tarif" &
    "f"
        Me.Label32.Top = 2.625!
        Me.Label32.Width = 2.875!
        '
        'Shape2
        '
        Me.Shape2.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Border.RightColor = System.Drawing.Color.Black
        Me.Shape2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Border.TopColor = System.Drawing.Color.Black
        Me.Shape2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape2.Height = 0.3125!
        Me.Shape2.Left = 4.5625!
        Me.Shape2.Name = "Shape2"
        Me.Shape2.RoundingRadius = 9.999999!
        Me.Shape2.Top = 3.125!
        Me.Shape2.Width = 0.3125!
        '
        'Line9
        '
        Me.Line9.Border.BottomColor = System.Drawing.Color.Black
        Me.Line9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.LeftColor = System.Drawing.Color.Black
        Me.Line9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.RightColor = System.Drawing.Color.Black
        Me.Line9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.TopColor = System.Drawing.Color.Black
        Me.Line9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Height = 0!
        Me.Line9.Left = 4.9375!
        Me.Line9.LineWeight = 1.0!
        Me.Line9.Name = "Line9"
        Me.Line9.Top = 3.0625!
        Me.Line9.Width = 3.25!
        Me.Line9.X1 = 4.9375!
        Me.Line9.X2 = 8.1875!
        Me.Line9.Y1 = 3.0625!
        Me.Line9.Y2 = 3.0625!
        '
        'Label10
        '
        Me.Label10.Border.BottomColor = System.Drawing.Color.Black
        Me.Label10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.LeftColor = System.Drawing.Color.Black
        Me.Label10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.RightColor = System.Drawing.Color.Black
        Me.Label10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.TopColor = System.Drawing.Color.Black
        Me.Label10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Height = 0.1875!
        Me.Label10.HyperLink = Nothing
        Me.Label10.Left = 4.9375!
        Me.Label10.Name = "Label10"
        Me.Label10.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label10.Text = "Preferential Treatment Not Given (Please state reason/s)"
        Me.Label10.Top = 3.1875!
        Me.Label10.Width = 2.875!
        '
        'Line21
        '
        Me.Line21.Border.BottomColor = System.Drawing.Color.Black
        Me.Line21.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line21.Border.LeftColor = System.Drawing.Color.Black
        Me.Line21.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line21.Border.RightColor = System.Drawing.Color.Black
        Me.Line21.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line21.Border.TopColor = System.Drawing.Color.Black
        Me.Line21.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line21.Height = 4.625!
        Me.Line21.Left = 8.1875!
        Me.Line21.LineWeight = 1.0!
        Me.Line21.Name = "Line21"
        Me.Line21.Top = 0.1875!
        Me.Line21.Width = 0!
        Me.Line21.X1 = 8.1875!
        Me.Line21.X2 = 8.1875!
        Me.Line21.Y1 = 0.1875!
        Me.Line21.Y2 = 4.8125!
        '
        'Line7
        '
        Me.Line7.Border.BottomColor = System.Drawing.Color.Black
        Me.Line7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.LeftColor = System.Drawing.Color.Black
        Me.Line7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.RightColor = System.Drawing.Color.Black
        Me.Line7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.TopColor = System.Drawing.Color.Black
        Me.Line7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Height = 0!
        Me.Line7.Left = 4.9375!
        Me.Line7.LineWeight = 1.0!
        Me.Line7.Name = "Line7"
        Me.Line7.Top = 3.5!
        Me.Line7.Width = 3.25!
        Me.Line7.X1 = 4.9375!
        Me.Line7.X2 = 8.1875!
        Me.Line7.Y1 = 3.5!
        Me.Line7.Y2 = 3.5!
        '
        'Label4
        '
        Me.Label4.Border.BottomColor = System.Drawing.Color.Black
        Me.Label4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.LeftColor = System.Drawing.Color.Black
        Me.Label4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.RightColor = System.Drawing.Color.Black
        Me.Label4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.TopColor = System.Drawing.Color.Black
        Me.Label4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Height = 0.3125!
        Me.Label4.HyperLink = Nothing
        Me.Label4.Left = 0.125!
        Me.Label4.Name = "Label4"
        Me.Label4.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label4.Text = "5. Item number"
        Me.Label4.Top = 3.9375!
        Me.Label4.Width = 0.5625!
        '
        'Line22
        '
        Me.Line22.Border.BottomColor = System.Drawing.Color.Black
        Me.Line22.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line22.Border.LeftColor = System.Drawing.Color.Black
        Me.Line22.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line22.Border.RightColor = System.Drawing.Color.Black
        Me.Line22.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line22.Border.TopColor = System.Drawing.Color.Black
        Me.Line22.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line22.Height = 0!
        Me.Line22.Left = 0.0625!
        Me.Line22.LineWeight = 1.0!
        Me.Line22.Name = "Line22"
        Me.Line22.Top = 3.9375!
        Me.Line22.Width = 8.125!
        Me.Line22.X1 = 0.0625!
        Me.Line22.X2 = 8.1875!
        Me.Line22.Y1 = 3.9375!
        Me.Line22.Y2 = 3.9375!
        '
        'Label14
        '
        Me.Label14.Border.BottomColor = System.Drawing.Color.Black
        Me.Label14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.LeftColor = System.Drawing.Color.Black
        Me.Label14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.RightColor = System.Drawing.Color.Black
        Me.Label14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.TopColor = System.Drawing.Color.Black
        Me.Label14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Height = 0.1875!
        Me.Label14.HyperLink = Nothing
        Me.Label14.Left = 0.3125!
        Me.Label14.Name = "Label14"
        Me.Label14.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label14.Text = "Port of Discharge"
        Me.Label14.Top = 3.5!
        Me.Label14.Width = 2.875!
        '
        'Label13
        '
        Me.Label13.Border.BottomColor = System.Drawing.Color.Black
        Me.Label13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.LeftColor = System.Drawing.Color.Black
        Me.Label13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.RightColor = System.Drawing.Color.Black
        Me.Label13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.TopColor = System.Drawing.Color.Black
        Me.Label13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Height = 0.1875!
        Me.Label13.HyperLink = Nothing
        Me.Label13.Left = 0.3125!
        Me.Label13.Name = "Label13"
        Me.Label13.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label13.Text = "Vessel's name / Aircraft etc."
        Me.Label13.Top = 3.125!
        Me.Label13.Width = 2.875!
        '
        'Label12
        '
        Me.Label12.Border.BottomColor = System.Drawing.Color.Black
        Me.Label12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.LeftColor = System.Drawing.Color.Black
        Me.Label12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.RightColor = System.Drawing.Color.Black
        Me.Label12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.TopColor = System.Drawing.Color.Black
        Me.Label12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Height = 0.1875!
        Me.Label12.HyperLink = Nothing
        Me.Label12.Left = 0.3125!
        Me.Label12.Name = "Label12"
        Me.Label12.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label12.Text = "Daparture Date"
        Me.Label12.Top = 2.6875!
        Me.Label12.Width = 2.875!
        '
        'Label6
        '
        Me.Label6.Border.BottomColor = System.Drawing.Color.Black
        Me.Label6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.LeftColor = System.Drawing.Color.Black
        Me.Label6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.RightColor = System.Drawing.Color.Black
        Me.Label6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.TopColor = System.Drawing.Color.Black
        Me.Label6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Height = 0.5625!
        Me.Label6.HyperLink = Nothing
        Me.Label6.Left = 2.0!
        Me.Label6.Name = "Label6"
        Me.Label6.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label6.Text = "7. Number and type of packages,description of goods (including quantity where app" &
    "ropriate and HS number of the importing country)"
        Me.Label6.Top = 3.9375!
        Me.Label6.Width = 2.8125!
        '
        'Label5
        '
        Me.Label5.Border.BottomColor = System.Drawing.Color.Black
        Me.Label5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.LeftColor = System.Drawing.Color.Black
        Me.Label5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.RightColor = System.Drawing.Color.Black
        Me.Label5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.TopColor = System.Drawing.Color.Black
        Me.Label5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Height = 0.4375!
        Me.Label5.HyperLink = Nothing
        Me.Label5.Left = 0.9375!
        Me.Label5.Name = "Label5"
        Me.Label5.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label5.Text = "6. Marks and    numbers of packages "
        Me.Label5.Top = 3.9375!
        Me.Label5.Width = 0.875!
        '
        'Label11
        '
        Me.Label11.Border.BottomColor = System.Drawing.Color.Black
        Me.Label11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.LeftColor = System.Drawing.Color.Black
        Me.Label11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.RightColor = System.Drawing.Color.Black
        Me.Label11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.TopColor = System.Drawing.Color.Black
        Me.Label11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Height = 0.3125!
        Me.Label11.HyperLink = Nothing
        Me.Label11.Left = 5.25!
        Me.Label11.Name = "Label11"
        Me.Label11.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label11.Text = "8. Origin criterion"
        Me.Label11.Top = 3.9375!
        Me.Label11.Width = 0.5625!
        '
        'Label15
        '
        Me.Label15.Border.BottomColor = System.Drawing.Color.Black
        Me.Label15.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.LeftColor = System.Drawing.Color.Black
        Me.Label15.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.RightColor = System.Drawing.Color.Black
        Me.Label15.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.TopColor = System.Drawing.Color.Black
        Me.Label15.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Height = 0.6875!
        Me.Label15.HyperLink = Nothing
        Me.Label15.Left = 6.0625!
        Me.Label15.Name = "Label15"
        Me.Label15.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label15.Text = "9. Gross weight or other quantity and value (FOB)"
        Me.Label15.Top = 3.9375!
        Me.Label15.Width = 0.8125!
        '
        'Label16
        '
        Me.Label16.Border.BottomColor = System.Drawing.Color.Black
        Me.Label16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.LeftColor = System.Drawing.Color.Black
        Me.Label16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.RightColor = System.Drawing.Color.Black
        Me.Label16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.TopColor = System.Drawing.Color.Black
        Me.Label16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Height = 0.5!
        Me.Label16.HyperLink = Nothing
        Me.Label16.Left = 7.125!
        Me.Label16.Name = "Label16"
        Me.Label16.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label16.Text = "10. Number and date of invoices"
        Me.Label16.Top = 3.9375!
        Me.Label16.Width = 0.875!
        '
        'Line5
        '
        Me.Line5.Border.BottomColor = System.Drawing.Color.Black
        Me.Line5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.LeftColor = System.Drawing.Color.Black
        Me.Line5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.RightColor = System.Drawing.Color.Black
        Me.Line5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.TopColor = System.Drawing.Color.Black
        Me.Line5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Height = 0!
        Me.Line5.Left = 0.0625!
        Me.Line5.LineWeight = 1.0!
        Me.Line5.Name = "Line5"
        Me.Line5.Top = 4.5625!
        Me.Line5.Width = 8.125!
        Me.Line5.X1 = 0.0625!
        Me.Line5.X2 = 8.1875!
        Me.Line5.Y1 = 4.5625!
        Me.Line5.Y2 = 4.5625!
        '
        'PageFooter1
        '
        Me.PageFooter1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtTHAILAND, Me.txtIMPORT_COUNTRY, Me.txtcompany_provincefoot1, Me.txtcompany_provincefoot, Me.txtshow_check, Me.txtback_country, Me.txtinvh_run_auto, Me.txttotalSum_fob_amt, Me.Pic_ch5_exhibi, Me.Pic_ch7_Issued, Me.Pic_ch3_back, Me.Pic_ch1_third, Me.Line4, Me.Line10, Me.Label28, Me.Label29, Me.Line11, Me.Label23, Me.Label34, Me.Line17, Me.Label26, Me.Line20, Me.Label35, Me.Line16, Me.Line1, Me.Label30, Me.Label21, Me.Line2, Me.Label18, Me.Shape4, Me.Shape5, Me.Label24, Me.Shape1, Me.Shape6, Me.Label33, Me.Label27, Me.Line3, Me.txtCheck_CaseRVCCount})
        Me.PageFooter1.Height = 4.133858!
        Me.PageFooter1.Name = "PageFooter1"
        '
        'txtTHAILAND
        '
        Me.txtTHAILAND.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTHAILAND.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTHAILAND.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTHAILAND.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTHAILAND.Border.RightColor = System.Drawing.Color.Black
        Me.txtTHAILAND.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTHAILAND.Border.TopColor = System.Drawing.Color.Black
        Me.txtTHAILAND.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTHAILAND.CanGrow = False
        Me.txtTHAILAND.Height = 0.3937007!
        Me.txtTHAILAND.Left = 0.5!
        Me.txtTHAILAND.Name = "txtTHAILAND"
        Me.txtTHAILAND.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-weight: bold; font-size: 1" &
    "4pt; font-family: BrowalliaUPC; "
        Me.txtTHAILAND.Text = Nothing
        Me.txtTHAILAND.Top = 0.59375!
        Me.txtTHAILAND.Width = 3.469488!
        '
        'txtIMPORT_COUNTRY
        '
        Me.txtIMPORT_COUNTRY.Border.BottomColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.LeftColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.RightColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.TopColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.CanGrow = False
        Me.txtIMPORT_COUNTRY.DataField = "IMPORT_COUNTRY"
        Me.txtIMPORT_COUNTRY.Height = 0.3937007!
        Me.txtIMPORT_COUNTRY.Left = 0.5!
        Me.txtIMPORT_COUNTRY.Name = "txtIMPORT_COUNTRY"
        Me.txtIMPORT_COUNTRY.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-weight: bold; font-size: 1" &
    "4pt; font-family: BrowalliaUPC; vertical-align: bottom; "
        Me.txtIMPORT_COUNTRY.Text = Nothing
        Me.txtIMPORT_COUNTRY.Top = 1.46875!
        Me.txtIMPORT_COUNTRY.Width = 3.469488!
        '
        'txtcompany_provincefoot1
        '
        Me.txtcompany_provincefoot1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.DataField = "company_province"
        Me.txtcompany_provincefoot1.Height = 0.1979167!
        Me.txtcompany_provincefoot1.Left = 6.668307!
        Me.txtcompany_provincefoot1.Name = "txtcompany_provincefoot1"
        Me.txtcompany_provincefoot1.Style = "color: Red; "
        Me.txtcompany_provincefoot1.Text = "company_province"
        Me.txtcompany_provincefoot1.Top = 0!
        Me.txtcompany_provincefoot1.Visible = False
        Me.txtcompany_provincefoot1.Width = 1.0!
        '
        'txtcompany_provincefoot
        '
        Me.txtcompany_provincefoot.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.CanGrow = False
        Me.txtcompany_provincefoot.Height = 0.3937007!
        Me.txtcompany_provincefoot.Left = 0.5!
        Me.txtcompany_provincefoot.Name = "txtcompany_provincefoot"
        Me.txtcompany_provincefoot.Style = "color: Blue; ddo-char-set: 1; text-align: center; font-weight: bold; font-size: 1" &
    "4pt; font-family: BrowalliaUPC; vertical-align: bottom; "
        Me.txtcompany_provincefoot.Text = Nothing
        Me.txtcompany_provincefoot.Top = 1.864583!
        Me.txtcompany_provincefoot.Width = 3.469488!
        '
        'txtshow_check
        '
        Me.txtshow_check.Border.BottomColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.LeftColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.RightColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.Border.TopColor = System.Drawing.Color.Black
        Me.txtshow_check.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtshow_check.DataField = "show_check"
        Me.txtshow_check.Height = 0.1979167!
        Me.txtshow_check.Left = 6.668307!
        Me.txtshow_check.Name = "txtshow_check"
        Me.txtshow_check.Style = "color: Red; "
        Me.txtshow_check.Text = "show_check"
        Me.txtshow_check.Top = 0.2604167!
        Me.txtshow_check.Visible = False
        Me.txtshow_check.Width = 1.0!
        '
        'txtback_country
        '
        Me.txtback_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtback_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtback_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtback_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtback_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.DataField = "back_country"
        Me.txtback_country.Height = 0.1979167!
        Me.txtback_country.Left = 6.668307!
        Me.txtback_country.Name = "txtback_country"
        Me.txtback_country.Style = "color: Red; "
        Me.txtback_country.Text = "back_country"
        Me.txtback_country.Top = 0.5208334!
        Me.txtback_country.Visible = False
        Me.txtback_country.Width = 1.0!
        '
        'txtinvh_run_auto
        '
        Me.txtinvh_run_auto.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.DataField = "invh_run_auto"
        Me.txtinvh_run_auto.Height = 0.1979167!
        Me.txtinvh_run_auto.Left = 5.375!
        Me.txtinvh_run_auto.Name = "txtinvh_run_auto"
        Me.txtinvh_run_auto.Style = "color: Red; "
        Me.txtinvh_run_auto.Text = "invh_run_auto"
        Me.txtinvh_run_auto.Top = 0.125!
        Me.txtinvh_run_auto.Visible = False
        Me.txtinvh_run_auto.Width = 1.0!
        '
        'txttotalSum_fob_amt
        '
        Me.txttotalSum_fob_amt.Border.BottomColor = System.Drawing.Color.Black
        Me.txttotalSum_fob_amt.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttotalSum_fob_amt.Border.LeftColor = System.Drawing.Color.Black
        Me.txttotalSum_fob_amt.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttotalSum_fob_amt.Border.RightColor = System.Drawing.Color.Black
        Me.txttotalSum_fob_amt.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttotalSum_fob_amt.Border.TopColor = System.Drawing.Color.Black
        Me.txttotalSum_fob_amt.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttotalSum_fob_amt.DataField = "totalSum_fob_amt"
        Me.txttotalSum_fob_amt.Height = 0.1979167!
        Me.txttotalSum_fob_amt.Left = 6.668307!
        Me.txttotalSum_fob_amt.Name = "txttotalSum_fob_amt"
        Me.txttotalSum_fob_amt.Style = "color: Red; "
        Me.txttotalSum_fob_amt.Text = "totalSum_fob_amt"
        Me.txttotalSum_fob_amt.Top = 0.7812501!
        Me.txttotalSum_fob_amt.Visible = False
        Me.txttotalSum_fob_amt.Width = 1.0!
        '
        'Pic_ch5_exhibi
        '
        Me.Pic_ch5_exhibi.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch5_exhibi.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch5_exhibi.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch5_exhibi.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch5_exhibi.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch5_exhibi.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch5_exhibi.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch5_exhibi.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch5_exhibi.Height = 0.3937008!
        Me.Pic_ch5_exhibi.Image = CType(resources.GetObject("Pic_ch5_exhibi.Image"), System.Drawing.Image)
        Me.Pic_ch5_exhibi.ImageData = CType(resources.GetObject("Pic_ch5_exhibi.ImageData"), System.IO.Stream)
        Me.Pic_ch5_exhibi.Left = 2.559055!
        Me.Pic_ch5_exhibi.LineWeight = 0!
        Me.Pic_ch5_exhibi.Name = "Pic_ch5_exhibi"
        Me.Pic_ch5_exhibi.Top = 2.678313!
        Me.Pic_ch5_exhibi.Visible = False
        Me.Pic_ch5_exhibi.Width = 0.3937007!
        '
        'Pic_ch7_Issued
        '
        Me.Pic_ch7_Issued.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch7_Issued.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch7_Issued.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch7_Issued.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch7_Issued.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch7_Issued.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch7_Issued.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch7_Issued.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch7_Issued.Height = 0.3937008!
        Me.Pic_ch7_Issued.Image = CType(resources.GetObject("Pic_ch7_Issued.Image"), System.Drawing.Image)
        Me.Pic_ch7_Issued.ImageData = CType(resources.GetObject("Pic_ch7_Issued.ImageData"), System.IO.Stream)
        Me.Pic_ch7_Issued.Left = 0.734416!
        Me.Pic_ch7_Issued.LineWeight = 0!
        Me.Pic_ch7_Issued.Name = "Pic_ch7_Issued"
        Me.Pic_ch7_Issued.Top = 2.678314!
        Me.Pic_ch7_Issued.Visible = False
        Me.Pic_ch7_Issued.Width = 0.3937008!
        '
        'Pic_ch3_back
        '
        Me.Pic_ch3_back.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch3_back.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch3_back.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch3_back.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch3_back.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch3_back.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch3_back.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch3_back.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch3_back.Height = 0.3937008!
        Me.Pic_ch3_back.Image = CType(resources.GetObject("Pic_ch3_back.Image"), System.Drawing.Image)
        Me.Pic_ch3_back.ImageData = CType(resources.GetObject("Pic_ch3_back.ImageData"), System.IO.Stream)
        Me.Pic_ch3_back.Left = 0.734416!
        Me.Pic_ch3_back.LineWeight = 0!
        Me.Pic_ch3_back.Name = "Pic_ch3_back"
        Me.Pic_ch3_back.Top = 2.976378!
        Me.Pic_ch3_back.Visible = False
        Me.Pic_ch3_back.Width = 0.3937008!
        '
        'Pic_ch1_third
        '
        Me.Pic_ch1_third.Border.BottomColor = System.Drawing.Color.Black
        Me.Pic_ch1_third.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch1_third.Border.LeftColor = System.Drawing.Color.Black
        Me.Pic_ch1_third.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch1_third.Border.RightColor = System.Drawing.Color.Black
        Me.Pic_ch1_third.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch1_third.Border.TopColor = System.Drawing.Color.Black
        Me.Pic_ch1_third.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Pic_ch1_third.Height = 0.3937008!
        Me.Pic_ch1_third.Image = CType(resources.GetObject("Pic_ch1_third.Image"), System.Drawing.Image)
        Me.Pic_ch1_third.ImageData = CType(resources.GetObject("Pic_ch1_third.ImageData"), System.IO.Stream)
        Me.Pic_ch1_third.Left = 2.559055!
        Me.Pic_ch1_third.LineWeight = 0!
        Me.Pic_ch1_third.Name = "Pic_ch1_third"
        Me.Pic_ch1_third.Top = 2.977362!
        Me.Pic_ch1_third.Visible = False
        Me.Pic_ch1_third.Width = 0.3937008!
        '
        'Line4
        '
        Me.Line4.Border.BottomColor = System.Drawing.Color.Black
        Me.Line4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.LeftColor = System.Drawing.Color.Black
        Me.Line4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.RightColor = System.Drawing.Color.Black
        Me.Line4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.TopColor = System.Drawing.Color.Black
        Me.Line4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Height = 0!
        Me.Line4.Left = 0.0625!
        Me.Line4.LineWeight = 1.0!
        Me.Line4.Name = "Line4"
        Me.Line4.Top = 0!
        Me.Line4.Width = 8.125!
        Me.Line4.X1 = 8.1875!
        Me.Line4.X2 = 0.0625!
        Me.Line4.Y1 = 0!
        Me.Line4.Y2 = 0!
        '
        'Line10
        '
        Me.Line10.Border.BottomColor = System.Drawing.Color.Black
        Me.Line10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.LeftColor = System.Drawing.Color.Black
        Me.Line10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.RightColor = System.Drawing.Color.Black
        Me.Line10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.TopColor = System.Drawing.Color.Black
        Me.Line10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Height = 3.625!
        Me.Line10.Left = 0.0625!
        Me.Line10.LineWeight = 1.0!
        Me.Line10.Name = "Line10"
        Me.Line10.Top = 0!
        Me.Line10.Width = 0!
        Me.Line10.X1 = 0.0625!
        Me.Line10.X2 = 0.0625!
        Me.Line10.Y1 = 3.625!
        Me.Line10.Y2 = 0!
        '
        'Label28
        '
        Me.Label28.Border.BottomColor = System.Drawing.Color.Black
        Me.Label28.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.LeftColor = System.Drawing.Color.Black
        Me.Label28.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.RightColor = System.Drawing.Color.Black
        Me.Label28.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.TopColor = System.Drawing.Color.Black
        Me.Label28.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Height = 0.1875!
        Me.Label28.HyperLink = Nothing
        Me.Label28.Left = 0.125!
        Me.Label28.Name = "Label28"
        Me.Label28.Style = "font-weight: normal; font-size: 9.75pt; "
        Me.Label28.Text = "11. Declaration by the exporter"
        Me.Label28.Top = 0.0625!
        Me.Label28.Width = 3.0!
        '
        'Label29
        '
        Me.Label29.Border.BottomColor = System.Drawing.Color.Black
        Me.Label29.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.LeftColor = System.Drawing.Color.Black
        Me.Label29.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.RightColor = System.Drawing.Color.Black
        Me.Label29.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.TopColor = System.Drawing.Color.Black
        Me.Label29.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Height = 0.375!
        Me.Label29.HyperLink = Nothing
        Me.Label29.Left = 0.3125!
        Me.Label29.Name = "Label29"
        Me.Label29.Style = "ddo-char-set: 1; font-size: 9pt; "
        Me.Label29.Text = "The undersigned hereby declares that the above details and statement are correct;" &
    " that all the goods were produced in"
        Me.Label29.Top = 0.25!
        Me.Label29.Width = 4.0!
        '
        'Line11
        '
        Me.Line11.Border.BottomColor = System.Drawing.Color.Black
        Me.Line11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.LeftColor = System.Drawing.Color.Black
        Me.Line11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.RightColor = System.Drawing.Color.Black
        Me.Line11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.TopColor = System.Drawing.Color.Black
        Me.Line11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Height = 0!
        Me.Line11.Left = 0.3125!
        Me.Line11.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line11.LineWeight = 1.0!
        Me.Line11.Name = "Line11"
        Me.Line11.Top = 0.8125!
        Me.Line11.Width = 3.6875!
        Me.Line11.X1 = 0.3125!
        Me.Line11.X2 = 4.0!
        Me.Line11.Y1 = 0.8125!
        Me.Line11.Y2 = 0.8125!
        '
        'Label23
        '
        Me.Label23.Border.BottomColor = System.Drawing.Color.Black
        Me.Label23.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.LeftColor = System.Drawing.Color.Black
        Me.Label23.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.RightColor = System.Drawing.Color.Black
        Me.Label23.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.TopColor = System.Drawing.Color.Black
        Me.Label23.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Height = 0.1875!
        Me.Label23.HyperLink = Nothing
        Me.Label23.Left = 1.9375!
        Me.Label23.Name = "Label23"
        Me.Label23.Style = "ddo-char-set: 0; font-size: 8.25pt; font-family: Times New Roman; "
        Me.Label23.Text = "(Country)"
        Me.Label23.Top = 0.8125!
        Me.Label23.Width = 0.625!
        '
        'Label34
        '
        Me.Label34.Border.BottomColor = System.Drawing.Color.Black
        Me.Label34.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label34.Border.LeftColor = System.Drawing.Color.Black
        Me.Label34.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label34.Border.RightColor = System.Drawing.Color.Black
        Me.Label34.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label34.Border.TopColor = System.Drawing.Color.Black
        Me.Label34.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label34.Height = 0.5!
        Me.Label34.HyperLink = Nothing
        Me.Label34.Left = 0.3125!
        Me.Label34.Name = "Label34"
        Me.Label34.Style = "ddo-char-set: 1; font-size: 9pt; "
        Me.Label34.Text = "and that they comply with the origin requirements specified for these goods in th" &
    "e ASEAN-CHINA Free Trade Area Preferenctial Tariff for the goods exported to"
        Me.Label34.Top = 1.0!
        Me.Label34.Width = 4.0!
        '
        'Line17
        '
        Me.Line17.Border.BottomColor = System.Drawing.Color.Black
        Me.Line17.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.LeftColor = System.Drawing.Color.Black
        Me.Line17.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.RightColor = System.Drawing.Color.Black
        Me.Line17.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.TopColor = System.Drawing.Color.Black
        Me.Line17.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Height = 0!
        Me.Line17.Left = 0.3125!
        Me.Line17.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line17.LineWeight = 1.0!
        Me.Line17.Name = "Line17"
        Me.Line17.Top = 1.8125!
        Me.Line17.Width = 3.6875!
        Me.Line17.X1 = 0.3125!
        Me.Line17.X2 = 4.0!
        Me.Line17.Y1 = 1.8125!
        Me.Line17.Y2 = 1.8125!
        '
        'Label26
        '
        Me.Label26.Border.BottomColor = System.Drawing.Color.Black
        Me.Label26.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.LeftColor = System.Drawing.Color.Black
        Me.Label26.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.RightColor = System.Drawing.Color.Black
        Me.Label26.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.TopColor = System.Drawing.Color.Black
        Me.Label26.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Height = 0.1875!
        Me.Label26.HyperLink = Nothing
        Me.Label26.Left = 1.6875!
        Me.Label26.Name = "Label26"
        Me.Label26.Style = "ddo-char-set: 0; font-size: 8.25pt; font-family: Times New Roman; "
        Me.Label26.Text = "(Importing Country)"
        Me.Label26.Top = 1.8125!
        Me.Label26.Width = 1.125!
        '
        'Line20
        '
        Me.Line20.Border.BottomColor = System.Drawing.Color.Black
        Me.Line20.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.LeftColor = System.Drawing.Color.Black
        Me.Line20.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.RightColor = System.Drawing.Color.Black
        Me.Line20.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.TopColor = System.Drawing.Color.Black
        Me.Line20.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Height = 0!
        Me.Line20.Left = 0.3125!
        Me.Line20.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line20.LineWeight = 1.0!
        Me.Line20.Name = "Line20"
        Me.Line20.Top = 2.3125!
        Me.Line20.Width = 3.6875!
        Me.Line20.X1 = 0.3125!
        Me.Line20.X2 = 4.0!
        Me.Line20.Y1 = 2.3125!
        Me.Line20.Y2 = 2.3125!
        '
        'Label35
        '
        Me.Label35.Border.BottomColor = System.Drawing.Color.Black
        Me.Label35.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label35.Border.LeftColor = System.Drawing.Color.Black
        Me.Label35.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label35.Border.RightColor = System.Drawing.Color.Black
        Me.Label35.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label35.Border.TopColor = System.Drawing.Color.Black
        Me.Label35.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label35.Height = 0.1875!
        Me.Label35.HyperLink = Nothing
        Me.Label35.Left = 0.6875!
        Me.Label35.Name = "Label35"
        Me.Label35.Style = "ddo-char-set: 0; text-align: center; font-size: 8.25pt; font-family: Times New Ro" &
    "man; "
        Me.Label35.Text = "Place and date, signature of authorised signatory"
        Me.Label35.Top = 2.3125!
        Me.Label35.Width = 3.125!
        '
        'Line16
        '
        Me.Line16.Border.BottomColor = System.Drawing.Color.Black
        Me.Line16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.LeftColor = System.Drawing.Color.Black
        Me.Line16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.RightColor = System.Drawing.Color.Black
        Me.Line16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.TopColor = System.Drawing.Color.Black
        Me.Line16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Height = 3.625!
        Me.Line16.Left = 4.3125!
        Me.Line16.LineWeight = 1.0!
        Me.Line16.Name = "Line16"
        Me.Line16.Top = 0!
        Me.Line16.Width = 0!
        Me.Line16.X1 = 4.3125!
        Me.Line16.X2 = 4.3125!
        Me.Line16.Y1 = 3.625!
        Me.Line16.Y2 = 0!
        '
        'Line1
        '
        Me.Line1.Border.BottomColor = System.Drawing.Color.Black
        Me.Line1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.LeftColor = System.Drawing.Color.Black
        Me.Line1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.RightColor = System.Drawing.Color.Black
        Me.Line1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.TopColor = System.Drawing.Color.Black
        Me.Line1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Height = 3.625!
        Me.Line1.Left = 8.1875!
        Me.Line1.LineWeight = 1.0!
        Me.Line1.Name = "Line1"
        Me.Line1.Top = 0!
        Me.Line1.Width = 0!
        Me.Line1.X1 = 8.1875!
        Me.Line1.X2 = 8.1875!
        Me.Line1.Y1 = 3.625!
        Me.Line1.Y2 = 0!
        '
        'Label30
        '
        Me.Label30.Border.BottomColor = System.Drawing.Color.Black
        Me.Label30.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.LeftColor = System.Drawing.Color.Black
        Me.Label30.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.RightColor = System.Drawing.Color.Black
        Me.Label30.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.TopColor = System.Drawing.Color.Black
        Me.Label30.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Height = 0.1875!
        Me.Label30.HyperLink = Nothing
        Me.Label30.Left = 4.375!
        Me.Label30.Name = "Label30"
        Me.Label30.Style = "font-weight: normal; font-size: 9.75pt; "
        Me.Label30.Text = "12. Certification"
        Me.Label30.Top = 0.0625!
        Me.Label30.Width = 1.625!
        '
        'Label21
        '
        Me.Label21.Border.BottomColor = System.Drawing.Color.Black
        Me.Label21.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.LeftColor = System.Drawing.Color.Black
        Me.Label21.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.RightColor = System.Drawing.Color.Black
        Me.Label21.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.TopColor = System.Drawing.Color.Black
        Me.Label21.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Height = 0.375!
        Me.Label21.HyperLink = Nothing
        Me.Label21.Left = 4.625!
        Me.Label21.Name = "Label21"
        Me.Label21.Style = "ddo-char-set: 1; font-size: 9pt; "
        Me.Label21.Text = "It is hereby certified, on the basis of control carried out, that the declaration" &
    " by the exporter is correct."
        Me.Label21.Top = 0.3125!
        Me.Label21.Width = 3.25!
        '
        'Line2
        '
        Me.Line2.Border.BottomColor = System.Drawing.Color.Black
        Me.Line2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.LeftColor = System.Drawing.Color.Black
        Me.Line2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.RightColor = System.Drawing.Color.Black
        Me.Line2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.TopColor = System.Drawing.Color.Black
        Me.Line2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Height = 0!
        Me.Line2.Left = 0.0625!
        Me.Line2.LineWeight = 1.0!
        Me.Line2.Name = "Line2"
        Me.Line2.Top = 3.625!
        Me.Line2.Width = 8.125!
        Me.Line2.X1 = 8.1875!
        Me.Line2.X2 = 0.0625!
        Me.Line2.Y1 = 3.625!
        Me.Line2.Y2 = 3.625!
        '
        'Label18
        '
        Me.Label18.Border.BottomColor = System.Drawing.Color.Black
        Me.Label18.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label18.Border.LeftColor = System.Drawing.Color.Black
        Me.Label18.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label18.Border.RightColor = System.Drawing.Color.Black
        Me.Label18.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label18.Border.TopColor = System.Drawing.Color.Black
        Me.Label18.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label18.Height = 0.1875!
        Me.Label18.HyperLink = Nothing
        Me.Label18.Left = 1.1875!
        Me.Label18.Name = "Label18"
        Me.Label18.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label18.Text = "Issued Retroactively"
        Me.Label18.Top = 2.75!
        Me.Label18.Width = 1.3125!
        '
        'Shape4
        '
        Me.Shape4.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape4.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape4.Border.RightColor = System.Drawing.Color.Black
        Me.Shape4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape4.Border.TopColor = System.Drawing.Color.Black
        Me.Shape4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape4.Height = 0.25!
        Me.Shape4.Left = 0.75!
        Me.Shape4.Name = "Shape4"
        Me.Shape4.RoundingRadius = 9.999999!
        Me.Shape4.Top = 2.6875!
        Me.Shape4.Width = 0.3125!
        '
        'Shape5
        '
        Me.Shape5.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape5.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape5.Border.RightColor = System.Drawing.Color.Black
        Me.Shape5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape5.Border.TopColor = System.Drawing.Color.Black
        Me.Shape5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape5.Height = 0.25!
        Me.Shape5.Left = 0.75!
        Me.Shape5.Name = "Shape5"
        Me.Shape5.RoundingRadius = 9.999999!
        Me.Shape5.Top = 3.0!
        Me.Shape5.Width = 0.3125!
        '
        'Label24
        '
        Me.Label24.Border.BottomColor = System.Drawing.Color.Black
        Me.Label24.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.LeftColor = System.Drawing.Color.Black
        Me.Label24.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.RightColor = System.Drawing.Color.Black
        Me.Label24.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.TopColor = System.Drawing.Color.Black
        Me.Label24.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Height = 0.1875!
        Me.Label24.HyperLink = Nothing
        Me.Label24.Left = 1.1875!
        Me.Label24.Name = "Label24"
        Me.Label24.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label24.Text = "Movement Certificate"
        Me.Label24.Top = 3.0625!
        Me.Label24.Width = 1.3125!
        '
        'Shape1
        '
        Me.Shape1.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.RightColor = System.Drawing.Color.Black
        Me.Shape1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Border.TopColor = System.Drawing.Color.Black
        Me.Shape1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape1.Height = 0.25!
        Me.Shape1.Left = 2.625!
        Me.Shape1.Name = "Shape1"
        Me.Shape1.RoundingRadius = 9.999999!
        Me.Shape1.Top = 2.6875!
        Me.Shape1.Width = 0.3125!
        '
        'Shape6
        '
        Me.Shape6.Border.BottomColor = System.Drawing.Color.Black
        Me.Shape6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape6.Border.LeftColor = System.Drawing.Color.Black
        Me.Shape6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape6.Border.RightColor = System.Drawing.Color.Black
        Me.Shape6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape6.Border.TopColor = System.Drawing.Color.Black
        Me.Shape6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Shape6.Height = 0.25!
        Me.Shape6.Left = 2.625!
        Me.Shape6.Name = "Shape6"
        Me.Shape6.RoundingRadius = 9.999999!
        Me.Shape6.Top = 3.0!
        Me.Shape6.Width = 0.3125!
        '
        'Label33
        '
        Me.Label33.Border.BottomColor = System.Drawing.Color.Black
        Me.Label33.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.LeftColor = System.Drawing.Color.Black
        Me.Label33.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.RightColor = System.Drawing.Color.Black
        Me.Label33.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.TopColor = System.Drawing.Color.Black
        Me.Label33.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Height = 0.1875!
        Me.Label33.HyperLink = Nothing
        Me.Label33.Left = 3.0!
        Me.Label33.Name = "Label33"
        Me.Label33.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label33.Text = "Third Party Invoicing"
        Me.Label33.Top = 3.0625!
        Me.Label33.Width = 1.25!
        '
        'Label27
        '
        Me.Label27.Border.BottomColor = System.Drawing.Color.Black
        Me.Label27.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label27.Border.LeftColor = System.Drawing.Color.Black
        Me.Label27.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label27.Border.RightColor = System.Drawing.Color.Black
        Me.Label27.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label27.Border.TopColor = System.Drawing.Color.Black
        Me.Label27.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label27.Height = 0.1875!
        Me.Label27.HyperLink = Nothing
        Me.Label27.Left = 3.0!
        Me.Label27.Name = "Label27"
        Me.Label27.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label27.Text = "Exhibition"
        Me.Label27.Top = 2.75!
        Me.Label27.Width = 1.25!
        '
        'Line3
        '
        Me.Line3.Border.BottomColor = System.Drawing.Color.Black
        Me.Line3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.LeftColor = System.Drawing.Color.Black
        Me.Line3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.RightColor = System.Drawing.Color.Black
        Me.Line3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.TopColor = System.Drawing.Color.Black
        Me.Line3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Height = 0!
        Me.Line3.Left = 0.0625!
        Me.Line3.LineWeight = 1.0!
        Me.Line3.Name = "Line3"
        Me.Line3.Top = 2.5625!
        Me.Line3.Width = 4.25!
        Me.Line3.X1 = 0.0625!
        Me.Line3.X2 = 4.3125!
        Me.Line3.Y1 = 2.5625!
        Me.Line3.Y2 = 2.5625!
        '
        'txtCheck_CaseRVCCount
        '
        Me.txtCheck_CaseRVCCount.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCheck_CaseRVCCount.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_CaseRVCCount.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCheck_CaseRVCCount.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_CaseRVCCount.Border.RightColor = System.Drawing.Color.Black
        Me.txtCheck_CaseRVCCount.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_CaseRVCCount.Border.TopColor = System.Drawing.Color.Black
        Me.txtCheck_CaseRVCCount.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCheck_CaseRVCCount.Height = 0.1979167!
        Me.txtCheck_CaseRVCCount.Left = 6.668307!
        Me.txtCheck_CaseRVCCount.Name = "txtCheck_CaseRVCCount"
        Me.txtCheck_CaseRVCCount.Style = "color: Red; "
        Me.txtCheck_CaseRVCCount.Text = "Check_CaseRVCCount"
        Me.txtCheck_CaseRVCCount.Top = 1.041667!
        Me.txtCheck_CaseRVCCount.Visible = False
        Me.txtCheck_CaseRVCCount.Width = 1.0!
        '
        'GroupHeader1
        '
        Me.GroupHeader1.Height = 0!
        Me.GroupHeader1.Name = "GroupHeader1"
        Me.GroupHeader1.Visible = False
        '
        'GroupFooter1
        '
        Me.GroupFooter1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtTotalAll})
        Me.GroupFooter1.Height = 0.2916667!
        Me.GroupFooter1.KeepTogether = True
        Me.GroupFooter1.Name = "GroupFooter1"
        Me.GroupFooter1.Visible = False
        '
        'txtTotalAll
        '
        Me.txtTotalAll.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTotalAll.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotalAll.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTotalAll.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotalAll.Border.RightColor = System.Drawing.Color.Black
        Me.txtTotalAll.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotalAll.Border.TopColor = System.Drawing.Color.Black
        Me.txtTotalAll.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotalAll.Height = 0.22!
        Me.txtTotalAll.Left = 1.88!
        Me.txtTotalAll.Name = "txtTotalAll"
        Me.txtTotalAll.Style = "color: Blue; ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtTotalAll.Text = Nothing
        Me.txtTotalAll.Top = 0!
        Me.txtTotalAll.Visible = False
        Me.txtTotalAll.Width = 3.25!
        '
        'Label51
        '
        Me.Label51.Border.BottomColor = System.Drawing.Color.Black
        Me.Label51.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.LeftColor = System.Drawing.Color.Black
        Me.Label51.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.RightColor = System.Drawing.Color.Black
        Me.Label51.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.TopColor = System.Drawing.Color.Black
        Me.Label51.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Height = 0.1875!
        Me.Label51.HyperLink = Nothing
        Me.Label51.Left = 5.25!
        Me.Label51.Name = "Label51"
        Me.Label51.Style = "color: Red; ddo-char-set: 0; text-align: right; font-weight: bold; font-size: 13." &
    "8pt; font-family: BrowalliaUPC; "
        Me.Label51.Text = "DUPLICATE"
        Me.Label51.Top = 0!
        Me.Label51.Width = 2.875!
        '
        'rpt3_ediFORM4_2_pr_New
        '
        Me.MasterReport = False
        Me.PageSettings.DefaultPaperSize = False
        Me.PageSettings.Margins.Bottom = 0!
        Me.PageSettings.Margins.Left = 0!
        Me.PageSettings.Margins.Right = 0!
        Me.PageSettings.Margins.Top = 0!
        Me.PageSettings.PaperHeight = 12.0!
        Me.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Custom
        Me.PageSettings.PaperName = "Fanfold 210 x 305 mm"
        Me.PageSettings.PaperWidth = 8.259843!
        Me.PrintWidth = 8.267715!
        Me.Script = "public bool ActiveReport_FetchData(bool eof)" & Global.Microsoft.VisualBasic.ChrW(10) & "{" & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(9) & "return eof;" & Global.Microsoft.VisualBasic.ChrW(10) & "}"
        Me.Sections.Add(Me.PageHeader1)
        Me.Sections.Add(Me.GroupHeader1)
        Me.Sections.Add(Me.Detail1)
        Me.Sections.Add(Me.GroupFooter1)
        Me.Sections.Add(Me.PageFooter1)
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Arial; font-style: normal; text-decoration: none; font-weight: norma" &
            "l; font-size: 10pt; color: Black; ddo-char-set: 204; ", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 16pt; font-weight: bold; ", "Heading1", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Times New Roman; font-size: 14pt; font-weight: bold; font-style: ita" &
            "lic; ", "Heading2", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 13pt; font-weight: bold; ", "Heading3", "Normal"))
        CType(Me.txtNumRowCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_marks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtT_product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_box8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTolInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrossTxt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGross_Weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtmarks1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_n1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_n2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtg_unit_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttariff_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtg_Unit_Desc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOB_AMT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_board, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtWeightDisplayHeader, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOBDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtnet_weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgross_weightH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtthird_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtplace_exibition, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtWeightDisplayHeaderH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtletter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtprofit_per_unit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtmarks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSINGLE_COUNTRY_CONTENT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNumInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUSDInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUSDInvoiceDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInvoiceDetailTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTitleMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCurrency_Code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgross_weightD, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDIGIT1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCheckGrossDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPriceOtherDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompany_Check_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtreference_code2_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_Check2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttransport_by, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtob_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_remark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_Receive_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtreference_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_email, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_email, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_taxid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_remark1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtob_dest_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdeparture_date, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtvasel_name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtport_discharge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTax_Status, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReportInfo1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCheck_StatusWeb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNewEmail_ch02, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNewEmail_ch01, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtReserve1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtsupplementary_details, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtRep_Doc_date2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTitleHead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTHAILAND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtIMPORT_COUNTRY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_provincefoot1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_provincefoot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtshow_check, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtback_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttotalSum_fob_amt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch5_exhibi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch7_Issued, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch3_back, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_ch1_third, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCheck_CaseRVCCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotalAll, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Friend WithEvents Detail1 As DataDynamics.ActiveReports.Detail
    Friend WithEvents txtNumRowCount As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_marks As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtT_product As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_box8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTolInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtGrossTxt As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtGross_Weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtmarks1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_n1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_n2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtg_unit_code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttariff_code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtg_Unit_Desc As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtFOB_AMT As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_board As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtWeightDisplayHeader As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtFOBDisplay As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtunit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtnet_weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtgross_weightH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtthird_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtplace_exibition As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtWeightDisplayHeaderH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbox8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtletter As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtprofit_per_unit As DataDynamics.ActiveReports.TextBox
    Friend WithEvents PageHeader1 As DataDynamics.ActiveReports.PageHeader
    Friend WithEvents txtCompany_Check_1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtreference_code2_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_Check2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttransport_by As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_taxno As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtob_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_remark As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_company As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_Receive_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtreference_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_email As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_email As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_taxid As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_remark1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtob_dest_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdeparture_date As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtvasel_name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtport_discharge As DataDynamics.ActiveReports.TextBox
    Friend WithEvents PageFooter1 As DataDynamics.ActiveReports.PageFooter
    Friend WithEvents txtTHAILAND As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtIMPORT_COUNTRY As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_provincefoot1 As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtcompany_provincefoot As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtshow_check As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtback_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTax_Status As DataDynamics.ActiveReports.TextBox
    Friend WithEvents ReportInfo1 As DataDynamics.ActiveReports.ReportInfo
    Friend WithEvents txtmarks As DataDynamics.ActiveReports.TextBox
    Public WithEvents C_TotalRowDe As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvh_run_auto As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttotalSum_fob_amt As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtSINGLE_COUNTRY_CONTENT As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtCheck_StatusWeb As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNewEmail_ch02 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNewEmail_ch01 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents GroupHeader1 As DataDynamics.ActiveReports.GroupHeader
    Friend WithEvents GroupFooter1 As DataDynamics.ActiveReports.GroupFooter
    Friend WithEvents txtTotalAll As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Pic_ch5_exhibi As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch7_Issued As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch3_back As DataDynamics.ActiveReports.Picture
    Friend WithEvents Pic_ch1_third As DataDynamics.ActiveReports.Picture
    Friend WithEvents txtNumInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtUSDInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtReserve1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtsupplementary_details As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtRep_Doc_date2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtUSDInvoiceDetail As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtInvoiceDetailTH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTitleMain As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTitleHead As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line14 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label8 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label1 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line13 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label3 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line23 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line25 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line26 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label19 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label9 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label2 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label20 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label22 As DataDynamics.ActiveReports.Label
    Friend WithEvents TextBox2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line19 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label17 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label7 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label31 As DataDynamics.ActiveReports.Label
    Friend WithEvents Shape3 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Label32 As DataDynamics.ActiveReports.Label
    Friend WithEvents Shape2 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Line9 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label10 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line21 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line7 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label4 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line22 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label14 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label13 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label12 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label6 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label5 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label11 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label15 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label16 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line5 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line4 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line10 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label28 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label29 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line11 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label23 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label34 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line17 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label26 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line20 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label35 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line16 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line1 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label30 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label21 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line2 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label18 As DataDynamics.ActiveReports.Label
    Friend WithEvents Shape4 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape5 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Label24 As DataDynamics.ActiveReports.Label
    Friend WithEvents Shape1 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Shape6 As DataDynamics.ActiveReports.Shape
    Friend WithEvents Label33 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label27 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line3 As DataDynamics.ActiveReports.Line
    Public WithEvents txtCurrency_Code As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtgross_weightD As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtDIGIT1 As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtCheckGrossDetail As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtCheck_CaseRVCCount As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtPriceOtherDetail As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Label51 As DataDynamics.ActiveReports.Label
End Class
