<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class rpt3_ediFORM1_2
    Inherits DataDynamics.ActiveReports.ActiveReport3

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
        End If
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the ActiveReports Designer
    'It can be modified using the ActiveReports Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(rpt3_ediFORM1_2))
        Me.Detail1 = New DataDynamics.ActiveReports.Detail()
        Me.txtNumRowCount = New DataDynamics.ActiveReports.TextBox()
        Me.txtTemp_marks = New DataDynamics.ActiveReports.TextBox()
        Me.txtT_product = New DataDynamics.ActiveReports.TextBox()
        Me.txtTemp_box8 = New DataDynamics.ActiveReports.TextBox()
        Me.txtgross_weight1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtTolInvoice = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_no5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtinvoice_date5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtgross_weight = New DataDynamics.ActiveReports.TextBox()
        Me.txtmarks = New DataDynamics.ActiveReports.TextBox()
        Me.txtproduct_n1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtproduct_n2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code3 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code4 = New DataDynamics.ActiveReports.TextBox()
        Me.txtquantity5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtq_unit_code5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtg_unit_code = New DataDynamics.ActiveReports.TextBox()
        Me.C_TotalRowDe = New DataDynamics.ActiveReports.TextBox()
        Me.txtTotal_net_weight = New DataDynamics.ActiveReports.TextBox()
        Me.txtbox8 = New DataDynamics.ActiveReports.TextBox()
        Me.txtSum_Gross_Weight = New DataDynamics.ActiveReports.TextBox()
        Me.txtSum_g_Unit_Desc = New DataDynamics.ActiveReports.TextBox()
        Me.txtGrossTxt = New DataDynamics.ActiveReports.TextBox()
        Me.txtWeightDisplayHeaderH = New DataDynamics.ActiveReports.TextBox()
        Me.txtnet_weight = New DataDynamics.ActiveReports.TextBox()
        Me.txtunit_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtNumInvoice = New DataDynamics.ActiveReports.TextBox()
        Me.txttariff_code = New DataDynamics.ActiveReports.TextBox()
        Me.txtFOBDisplay = New DataDynamics.ActiveReports.TextBox()
        Me.txtgross_weightH = New DataDynamics.ActiveReports.TextBox()
        Me.txtfob_amt = New DataDynamics.ActiveReports.TextBox()
        Me.txtproduct_description = New DataDynamics.ActiveReports.TextBox()
        Me.PageHeader1 = New DataDynamics.ActiveReports.PageHeader()
        Me.txtCompany_Check_1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtreference_code2_Temp = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_Check2 = New DataDynamics.ActiveReports.TextBox()
        Me.txttransport_by = New DataDynamics.ActiveReports.TextBox()
        Me.TextBox5 = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_taxno = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_province = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_name = New DataDynamics.ActiveReports.TextBox()
        Me.txtob_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_remark = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_fax = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_phone = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_company = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_fax = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_phone = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_province = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_Receive_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtreference_code2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtdigit1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtdigit2 = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_email = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_email = New DataDynamics.ActiveReports.TextBox()
        Me.txtdestination_taxid = New DataDynamics.ActiveReports.TextBox()
        Me.txtdest_remark1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtob_dest_address = New DataDynamics.ActiveReports.TextBox()
        Me.txtNewEmail_ch01 = New DataDynamics.ActiveReports.TextBox()
        Me.txtNewEmail_ch02 = New DataDynamics.ActiveReports.TextBox()
        Me.ReportInfo1 = New DataDynamics.ActiveReports.ReportInfo()
        Me.Line17 = New DataDynamics.ActiveReports.Line()
        Me.Line16 = New DataDynamics.ActiveReports.Line()
        Me.Line21 = New DataDynamics.ActiveReports.Line()
        Me.Line22 = New DataDynamics.ActiveReports.Line()
        Me.Line18 = New DataDynamics.ActiveReports.Line()
        Me.Line23 = New DataDynamics.ActiveReports.Line()
        Me.Line13 = New DataDynamics.ActiveReports.Line()
        Me.Label8 = New DataDynamics.ActiveReports.Label()
        Me.Label1 = New DataDynamics.ActiveReports.Label()
        Me.Label3 = New DataDynamics.ActiveReports.Label()
        Me.Label42 = New DataDynamics.ActiveReports.Label()
        Me.Label43 = New DataDynamics.ActiveReports.Label()
        Me.Label44 = New DataDynamics.ActiveReports.Label()
        Me.Label46 = New DataDynamics.ActiveReports.Label()
        Me.Label45 = New DataDynamics.ActiveReports.Label()
        Me.Label47 = New DataDynamics.ActiveReports.Label()
        Me.Label48 = New DataDynamics.ActiveReports.Label()
        Me.Label6 = New DataDynamics.ActiveReports.Label()
        Me.Label19 = New DataDynamics.ActiveReports.Label()
        Me.Line19 = New DataDynamics.ActiveReports.Line()
        Me.Label17 = New DataDynamics.ActiveReports.Label()
        Me.Label4 = New DataDynamics.ActiveReports.Label()
        Me.Label21 = New DataDynamics.ActiveReports.Label()
        Me.Label22 = New DataDynamics.ActiveReports.Label()
        Me.Label20 = New DataDynamics.ActiveReports.Label()
        Me.Label16 = New DataDynamics.ActiveReports.Label()
        Me.Label2 = New DataDynamics.ActiveReports.Label()
        Me.Label7 = New DataDynamics.ActiveReports.Label()
        Me.Line8 = New DataDynamics.ActiveReports.Line()
        Me.Line9 = New DataDynamics.ActiveReports.Line()
        Me.Line10 = New DataDynamics.ActiveReports.Line()
        Me.Line11 = New DataDynamics.ActiveReports.Line()
        Me.Line12 = New DataDynamics.ActiveReports.Line()
        Me.Line14 = New DataDynamics.ActiveReports.Line()
        Me.Line24 = New DataDynamics.ActiveReports.Line()
        Me.Line25 = New DataDynamics.ActiveReports.Line()
        Me.Label23 = New DataDynamics.ActiveReports.Label()
        Me.Line26 = New DataDynamics.ActiveReports.Line()
        Me.Line27 = New DataDynamics.ActiveReports.Line()
        Me.Line28 = New DataDynamics.ActiveReports.Line()
        Me.Line29 = New DataDynamics.ActiveReports.Line()
        Me.Line30 = New DataDynamics.ActiveReports.Line()
        Me.Label24 = New DataDynamics.ActiveReports.Label()
        Me.Line31 = New DataDynamics.ActiveReports.Line()
        Me.Line32 = New DataDynamics.ActiveReports.Line()
        Me.Line33 = New DataDynamics.ActiveReports.Line()
        Me.Line34 = New DataDynamics.ActiveReports.Line()
        Me.Line35 = New DataDynamics.ActiveReports.Line()
        Me.Label26 = New DataDynamics.ActiveReports.Label()
        Me.Label27 = New DataDynamics.ActiveReports.Label()
        Me.Label28 = New DataDynamics.ActiveReports.Label()
        Me.Line36 = New DataDynamics.ActiveReports.Line()
        Me.Line37 = New DataDynamics.ActiveReports.Line()
        Me.Line38 = New DataDynamics.ActiveReports.Line()
        Me.Line39 = New DataDynamics.ActiveReports.Line()
        Me.Line40 = New DataDynamics.ActiveReports.Line()
        Me.Label29 = New DataDynamics.ActiveReports.Label()
        Me.Label30 = New DataDynamics.ActiveReports.Label()
        Me.Label31 = New DataDynamics.ActiveReports.Label()
        Me.Label32 = New DataDynamics.ActiveReports.Label()
        Me.Label33 = New DataDynamics.ActiveReports.Label()
        Me.Label34 = New DataDynamics.ActiveReports.Label()
        Me.Label35 = New DataDynamics.ActiveReports.Label()
        Me.Line41 = New DataDynamics.ActiveReports.Line()
        Me.Label36 = New DataDynamics.ActiveReports.Label()
        Me.Label37 = New DataDynamics.ActiveReports.Label()
        Me.Line42 = New DataDynamics.ActiveReports.Line()
        Me.Label38 = New DataDynamics.ActiveReports.Label()
        Me.Label39 = New DataDynamics.ActiveReports.Label()
        Me.Label40 = New DataDynamics.ActiveReports.Label()
        Me.Line43 = New DataDynamics.ActiveReports.Line()
        Me.Line44 = New DataDynamics.ActiveReports.Line()
        Me.Line45 = New DataDynamics.ActiveReports.Line()
        Me.Line46 = New DataDynamics.ActiveReports.Line()
        Me.Line47 = New DataDynamics.ActiveReports.Line()
        Me.Label41 = New DataDynamics.ActiveReports.Label()
        Me.Label49 = New DataDynamics.ActiveReports.Label()
        Me.Label50 = New DataDynamics.ActiveReports.Label()
        Me.Label51 = New DataDynamics.ActiveReports.Label()
        Me.Label52 = New DataDynamics.ActiveReports.Label()
        Me.Label53 = New DataDynamics.ActiveReports.Label()
        Me.Label54 = New DataDynamics.ActiveReports.Label()
        Me.Line48 = New DataDynamics.ActiveReports.Line()
        Me.Label55 = New DataDynamics.ActiveReports.Label()
        Me.Label56 = New DataDynamics.ActiveReports.Label()
        Me.Line49 = New DataDynamics.ActiveReports.Line()
        Me.Label57 = New DataDynamics.ActiveReports.Label()
        Me.Label58 = New DataDynamics.ActiveReports.Label()
        Me.Label59 = New DataDynamics.ActiveReports.Label()
        Me.Label60 = New DataDynamics.ActiveReports.Label()
        Me.Line50 = New DataDynamics.ActiveReports.Line()
        Me.Line51 = New DataDynamics.ActiveReports.Line()
        Me.Line52 = New DataDynamics.ActiveReports.Line()
        Me.Line53 = New DataDynamics.ActiveReports.Line()
        Me.Line54 = New DataDynamics.ActiveReports.Line()
        Me.Label61 = New DataDynamics.ActiveReports.Label()
        Me.Label62 = New DataDynamics.ActiveReports.Label()
        Me.Label63 = New DataDynamics.ActiveReports.Label()
        Me.Label64 = New DataDynamics.ActiveReports.Label()
        Me.Label65 = New DataDynamics.ActiveReports.Label()
        Me.Label66 = New DataDynamics.ActiveReports.Label()
        Me.Label67 = New DataDynamics.ActiveReports.Label()
        Me.Line55 = New DataDynamics.ActiveReports.Line()
        Me.Label68 = New DataDynamics.ActiveReports.Label()
        Me.Label69 = New DataDynamics.ActiveReports.Label()
        Me.Line56 = New DataDynamics.ActiveReports.Line()
        Me.Label70 = New DataDynamics.ActiveReports.Label()
        Me.Label71 = New DataDynamics.ActiveReports.Label()
        Me.Label72 = New DataDynamics.ActiveReports.Label()
        Me.Label73 = New DataDynamics.ActiveReports.Label()
        Me.Label74 = New DataDynamics.ActiveReports.Label()
        Me.Label75 = New DataDynamics.ActiveReports.Label()
        Me.Label76 = New DataDynamics.ActiveReports.Label()
        Me.Line57 = New DataDynamics.ActiveReports.Line()
        Me.Line58 = New DataDynamics.ActiveReports.Line()
        Me.Line59 = New DataDynamics.ActiveReports.Line()
        Me.Line60 = New DataDynamics.ActiveReports.Line()
        Me.Line61 = New DataDynamics.ActiveReports.Line()
        Me.Label77 = New DataDynamics.ActiveReports.Label()
        Me.Label78 = New DataDynamics.ActiveReports.Label()
        Me.Label79 = New DataDynamics.ActiveReports.Label()
        Me.Label80 = New DataDynamics.ActiveReports.Label()
        Me.Label81 = New DataDynamics.ActiveReports.Label()
        Me.Label82 = New DataDynamics.ActiveReports.Label()
        Me.Label83 = New DataDynamics.ActiveReports.Label()
        Me.Line62 = New DataDynamics.ActiveReports.Line()
        Me.Label84 = New DataDynamics.ActiveReports.Label()
        Me.Label85 = New DataDynamics.ActiveReports.Label()
        Me.Line63 = New DataDynamics.ActiveReports.Line()
        Me.Label86 = New DataDynamics.ActiveReports.Label()
        Me.Label87 = New DataDynamics.ActiveReports.Label()
        Me.Label88 = New DataDynamics.ActiveReports.Label()
        Me.Label89 = New DataDynamics.ActiveReports.Label()
        Me.Label90 = New DataDynamics.ActiveReports.Label()
        Me.Label91 = New DataDynamics.ActiveReports.Label()
        Me.Label92 = New DataDynamics.ActiveReports.Label()
        Me.Label93 = New DataDynamics.ActiveReports.Label()
        Me.Label94 = New DataDynamics.ActiveReports.Label()
        Me.Line76 = New DataDynamics.ActiveReports.Line()
        Me.PageFooter1 = New DataDynamics.ActiveReports.PageFooter()
        Me.txtIMPORT_COUNTRY = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_provincefoot = New DataDynamics.ActiveReports.TextBox()
        Me.txtcompany_provincefoot1 = New DataDynamics.ActiveReports.TextBox()
        Me.txtplace_exibition = New DataDynamics.ActiveReports.TextBox()
        Me.txtthird_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtback_country = New DataDynamics.ActiveReports.TextBox()
        Me.txtThaiLand = New DataDynamics.ActiveReports.TextBox()
        Me.Line5 = New DataDynamics.ActiveReports.Line()
        Me.Line4 = New DataDynamics.ActiveReports.Line()
        Me.Line1 = New DataDynamics.ActiveReports.Line()
        Me.Line3 = New DataDynamics.ActiveReports.Line()
        Me.Line2 = New DataDynamics.ActiveReports.Line()
        Me.Label9 = New DataDynamics.ActiveReports.Label()
        Me.Label5 = New DataDynamics.ActiveReports.Label()
        Me.Label25 = New DataDynamics.ActiveReports.Label()
        Me.Line20 = New DataDynamics.ActiveReports.Line()
        Me.Line15 = New DataDynamics.ActiveReports.Line()
        Me.Label18 = New DataDynamics.ActiveReports.Label()
        Me.Label15 = New DataDynamics.ActiveReports.Label()
        Me.Line7 = New DataDynamics.ActiveReports.Line()
        Me.Label14 = New DataDynamics.ActiveReports.Label()
        Me.Label13 = New DataDynamics.ActiveReports.Label()
        Me.Line6 = New DataDynamics.ActiveReports.Line()
        Me.Label11 = New DataDynamics.ActiveReports.Label()
        Me.TextBox1 = New DataDynamics.ActiveReports.TextBox()
        Me.Label12 = New DataDynamics.ActiveReports.Label()
        Me.Label10 = New DataDynamics.ActiveReports.Label()
        Me.Line64 = New DataDynamics.ActiveReports.Line()
        Me.Line65 = New DataDynamics.ActiveReports.Line()
        Me.Line66 = New DataDynamics.ActiveReports.Line()
        Me.Line67 = New DataDynamics.ActiveReports.Line()
        Me.Line68 = New DataDynamics.ActiveReports.Line()
        Me.Line69 = New DataDynamics.ActiveReports.Line()
        Me.Line70 = New DataDynamics.ActiveReports.Line()
        Me.Line71 = New DataDynamics.ActiveReports.Line()
        Me.Label95 = New DataDynamics.ActiveReports.Label()
        Me.Label96 = New DataDynamics.ActiveReports.Label()
        Me.Label97 = New DataDynamics.ActiveReports.Label()
        Me.Label98 = New DataDynamics.ActiveReports.Label()
        Me.Line72 = New DataDynamics.ActiveReports.Line()
        Me.TextBox2 = New DataDynamics.ActiveReports.TextBox()
        Me.Label99 = New DataDynamics.ActiveReports.Label()
        Me.Label100 = New DataDynamics.ActiveReports.Label()
        Me.Line73 = New DataDynamics.ActiveReports.Line()
        Me.Label101 = New DataDynamics.ActiveReports.Label()
        Me.Line74 = New DataDynamics.ActiveReports.Line()
        Me.Line75 = New DataDynamics.ActiveReports.Line()
        Me.txtinvh_run_auto = New DataDynamics.ActiveReports.TextBox()
        CType(Me.txtNumRowCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_marks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtT_product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTemp_box8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgross_weight1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTolInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvoice_date5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgross_weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtmarks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_n1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_n2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtquantity5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtq_unit_code5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtg_unit_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotal_net_weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtbox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSum_Gross_Weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSum_g_Unit_Desc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrossTxt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtWeightDisplayHeaderH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtnet_weight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNumInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttariff_code, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFOBDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgross_weightH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtfob_amt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtproduct_description, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompany_Check_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtreference_code2_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_Check2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txttransport_by, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtob_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_remark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_Receive_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtreference_code2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdigit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdigit2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_email, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_email, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdestination_taxid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdest_remark1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtob_dest_address, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNewEmail_ch01, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNewEmail_ch02, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReportInfo1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label60, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label61, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label67, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label69, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label70, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label71, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label77, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label79, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label80, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label81, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label89, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label90, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label91, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtIMPORT_COUNTRY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_provincefoot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtcompany_provincefoot1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtplace_exibition, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtthird_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtback_country, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtThaiLand, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label98, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label101, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'Detail1
        '
        Me.Detail1.CanShrink = True
        Me.Detail1.ColumnSpacing = 0!
        Me.Detail1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtNumRowCount, Me.txtTemp_marks, Me.txtT_product, Me.txtTemp_box8, Me.txtgross_weight1, Me.txtTolInvoice, Me.txtinvoice_no1, Me.txtinvoice_no2, Me.txtinvoice_no3, Me.txtinvoice_no4, Me.txtinvoice_no5, Me.txtinvoice_date1, Me.txtinvoice_date2, Me.txtinvoice_date3, Me.txtinvoice_date4, Me.txtinvoice_date5, Me.txtgross_weight, Me.txtmarks, Me.txtproduct_n1, Me.txtproduct_n2, Me.txtquantity1, Me.txtq_unit_code1, Me.txtquantity2, Me.txtq_unit_code2, Me.txtquantity3, Me.txtq_unit_code3, Me.txtquantity4, Me.txtq_unit_code4, Me.txtquantity5, Me.txtq_unit_code5, Me.txtg_unit_code, Me.C_TotalRowDe, Me.txtTotal_net_weight, Me.txtbox8, Me.txtSum_Gross_Weight, Me.txtSum_g_Unit_Desc, Me.txtGrossTxt, Me.txtWeightDisplayHeaderH, Me.txtnet_weight, Me.txtunit_code2, Me.txtNumInvoice, Me.txttariff_code, Me.txtFOBDisplay, Me.txtgross_weightH, Me.txtfob_amt, Me.txtproduct_description})
        Me.Detail1.Height = 0.2204724!
        Me.Detail1.KeepTogether = True
        Me.Detail1.Name = "Detail1"
        '
        'txtNumRowCount
        '
        Me.txtNumRowCount.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.RightColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Border.TopColor = System.Drawing.Color.Black
        Me.txtNumRowCount.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumRowCount.Height = 0.2204724!
        Me.txtNumRowCount.Left = 0.5659449!
        Me.txtNumRowCount.Name = "txtNumRowCount"
        Me.txtNumRowCount.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" &
    "; "
        Me.txtNumRowCount.Text = Nothing
        Me.txtNumRowCount.Top = 0!
        Me.txtNumRowCount.Width = 0.3937007!
        '
        'txtTemp_marks
        '
        Me.txtTemp_marks.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_marks.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_marks.Height = 0.2214567!
        Me.txtTemp_marks.Left = 1.033465!
        Me.txtTemp_marks.Name = "txtTemp_marks"
        Me.txtTemp_marks.Style = "ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtTemp_marks.Text = Nothing
        Me.txtTemp_marks.Top = 0!
        Me.txtTemp_marks.Width = 0.9350396!
        '
        'txtT_product
        '
        Me.txtT_product.Border.BottomColor = System.Drawing.Color.Black
        Me.txtT_product.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.LeftColor = System.Drawing.Color.Black
        Me.txtT_product.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.RightColor = System.Drawing.Color.Black
        Me.txtT_product.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Border.TopColor = System.Drawing.Color.Black
        Me.txtT_product.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtT_product.Height = 0.2204724!
        Me.txtT_product.Left = 1.99311!
        Me.txtT_product.Name = "txtT_product"
        Me.txtT_product.Style = "ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.txtT_product.Text = Nothing
        Me.txtT_product.Top = 0!
        Me.txtT_product.Width = 3.183727!
        '
        'txtTemp_box8
        '
        Me.txtTemp_box8.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.RightColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.Border.TopColor = System.Drawing.Color.Black
        Me.txtTemp_box8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTemp_box8.DataField = "box8"
        Me.txtTemp_box8.Height = 0.2204724!
        Me.txtTemp_box8.Left = 5.209892!
        Me.txtTemp_box8.Name = "txtTemp_box8"
        Me.txtTemp_box8.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" &
    "; "
        Me.txtTemp_box8.Text = Nothing
        Me.txtTemp_box8.Top = 0!
        Me.txtTemp_box8.Width = 0.9055118!
        '
        'txtgross_weight1
        '
        Me.txtgross_weight1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtgross_weight1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weight1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtgross_weight1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weight1.Border.RightColor = System.Drawing.Color.Black
        Me.txtgross_weight1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weight1.Border.TopColor = System.Drawing.Color.Black
        Me.txtgross_weight1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weight1.Height = 0.3937007!
        Me.txtgross_weight1.Left = 3.075788!
        Me.txtgross_weight1.Name = "txtgross_weight1"
        Me.txtgross_weight1.Style = "color: Red; ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: " &
    "BrowalliaUPC; "
        Me.txtgross_weight1.Text = "gross_weight1"
        Me.txtgross_weight1.Top = 1.722441!
        Me.txtgross_weight1.Visible = False
        Me.txtgross_weight1.Width = 0.9055118!
        '
        'txtTolInvoice
        '
        Me.txtTolInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtTolInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTolInvoice.Height = 0.2214567!
        Me.txtTolInvoice.Left = 7.111222!
        Me.txtTolInvoice.Name = "txtTolInvoice"
        Me.txtTolInvoice.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" &
    "; "
        Me.txtTolInvoice.Text = Nothing
        Me.txtTolInvoice.Top = 0!
        Me.txtTolInvoice.Width = 0.9350396!
        '
        'txtinvoice_no1
        '
        Me.txtinvoice_no1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no1.DataField = "invoice_no1"
        Me.txtinvoice_no1.Height = 0.1979167!
        Me.txtinvoice_no1.Left = 0!
        Me.txtinvoice_no1.Name = "txtinvoice_no1"
        Me.txtinvoice_no1.Style = "color: Red; "
        Me.txtinvoice_no1.Text = "invoice_no1"
        Me.txtinvoice_no1.Top = 0.6889763!
        Me.txtinvoice_no1.Visible = False
        Me.txtinvoice_no1.Width = 1.0!
        '
        'txtinvoice_no2
        '
        Me.txtinvoice_no2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no2.DataField = "invoice_no2"
        Me.txtinvoice_no2.Height = 0.1979167!
        Me.txtinvoice_no2.Left = 1.008858!
        Me.txtinvoice_no2.Name = "txtinvoice_no2"
        Me.txtinvoice_no2.Style = "color: Red; "
        Me.txtinvoice_no2.Text = "invoice_no2"
        Me.txtinvoice_no2.Top = 0.6889763!
        Me.txtinvoice_no2.Visible = False
        Me.txtinvoice_no2.Width = 1.0!
        '
        'txtinvoice_no3
        '
        Me.txtinvoice_no3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no3.DataField = "invoice_no3"
        Me.txtinvoice_no3.Height = 0.1979167!
        Me.txtinvoice_no3.Left = 2.017717!
        Me.txtinvoice_no3.Name = "txtinvoice_no3"
        Me.txtinvoice_no3.Style = "color: Red; "
        Me.txtinvoice_no3.Text = "invoice_no3"
        Me.txtinvoice_no3.Top = 0.6889763!
        Me.txtinvoice_no3.Visible = False
        Me.txtinvoice_no3.Width = 1.0!
        '
        'txtinvoice_no4
        '
        Me.txtinvoice_no4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no4.DataField = "invoice_no4"
        Me.txtinvoice_no4.Height = 0.1979167!
        Me.txtinvoice_no4.Left = 3.026575!
        Me.txtinvoice_no4.Name = "txtinvoice_no4"
        Me.txtinvoice_no4.Style = "color: Red; "
        Me.txtinvoice_no4.Text = "invoice_no4"
        Me.txtinvoice_no4.Top = 0.6889763!
        Me.txtinvoice_no4.Visible = False
        Me.txtinvoice_no4.Width = 1.0!
        '
        'txtinvoice_no5
        '
        Me.txtinvoice_no5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_no5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_no5.DataField = "invoice_no5"
        Me.txtinvoice_no5.Height = 0.1979167!
        Me.txtinvoice_no5.Left = 4.035433!
        Me.txtinvoice_no5.Name = "txtinvoice_no5"
        Me.txtinvoice_no5.Style = "color: Red; "
        Me.txtinvoice_no5.Text = "invoice_no5"
        Me.txtinvoice_no5.Top = 0.6889763!
        Me.txtinvoice_no5.Visible = False
        Me.txtinvoice_no5.Width = 1.0!
        '
        'txtinvoice_date1
        '
        Me.txtinvoice_date1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date1.DataField = "invoice_date1"
        Me.txtinvoice_date1.Height = 0.1979167!
        Me.txtinvoice_date1.Left = 0!
        Me.txtinvoice_date1.Name = "txtinvoice_date1"
        Me.txtinvoice_date1.Style = "color: Red; "
        Me.txtinvoice_date1.Text = "invoice_date1"
        Me.txtinvoice_date1.Top = 0.949393!
        Me.txtinvoice_date1.Visible = False
        Me.txtinvoice_date1.Width = 1.0!
        '
        'txtinvoice_date2
        '
        Me.txtinvoice_date2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date2.DataField = "invoice_date2"
        Me.txtinvoice_date2.Height = 0.1979167!
        Me.txtinvoice_date2.Left = 1.008858!
        Me.txtinvoice_date2.Name = "txtinvoice_date2"
        Me.txtinvoice_date2.Style = "color: Red; "
        Me.txtinvoice_date2.Text = "invoice_date2"
        Me.txtinvoice_date2.Top = 0.949393!
        Me.txtinvoice_date2.Visible = False
        Me.txtinvoice_date2.Width = 1.0!
        '
        'txtinvoice_date3
        '
        Me.txtinvoice_date3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date3.DataField = "invoice_date3"
        Me.txtinvoice_date3.Height = 0.1979167!
        Me.txtinvoice_date3.Left = 2.017717!
        Me.txtinvoice_date3.Name = "txtinvoice_date3"
        Me.txtinvoice_date3.Style = "color: Red; "
        Me.txtinvoice_date3.Text = "invoice_date3"
        Me.txtinvoice_date3.Top = 0.949393!
        Me.txtinvoice_date3.Visible = False
        Me.txtinvoice_date3.Width = 1.0!
        '
        'txtinvoice_date4
        '
        Me.txtinvoice_date4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date4.DataField = "invoice_date4"
        Me.txtinvoice_date4.Height = 0.1979167!
        Me.txtinvoice_date4.Left = 3.026575!
        Me.txtinvoice_date4.Name = "txtinvoice_date4"
        Me.txtinvoice_date4.Style = "color: Red; "
        Me.txtinvoice_date4.Text = "invoice_date4"
        Me.txtinvoice_date4.Top = 0.949393!
        Me.txtinvoice_date4.Visible = False
        Me.txtinvoice_date4.Width = 1.0!
        '
        'txtinvoice_date5
        '
        Me.txtinvoice_date5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvoice_date5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvoice_date5.DataField = "invoice_date5"
        Me.txtinvoice_date5.Height = 0.1979167!
        Me.txtinvoice_date5.Left = 4.035433!
        Me.txtinvoice_date5.Name = "txtinvoice_date5"
        Me.txtinvoice_date5.Style = "color: Red; "
        Me.txtinvoice_date5.Text = "invoice_date5"
        Me.txtinvoice_date5.Top = 0.949393!
        Me.txtinvoice_date5.Visible = False
        Me.txtinvoice_date5.Width = 1.0!
        '
        'txtgross_weight
        '
        Me.txtgross_weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtgross_weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtgross_weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtgross_weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtgross_weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weight.DataField = "gross_weight"
        Me.txtgross_weight.Height = 0.1979167!
        Me.txtgross_weight.Left = 0!
        Me.txtgross_weight.Name = "txtgross_weight"
        Me.txtgross_weight.Style = "color: Red; "
        Me.txtgross_weight.Text = "gross_weight"
        Me.txtgross_weight.Top = 1.20981!
        Me.txtgross_weight.Visible = False
        Me.txtgross_weight.Width = 1.0!
        '
        'txtmarks
        '
        Me.txtmarks.Border.BottomColor = System.Drawing.Color.Black
        Me.txtmarks.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.LeftColor = System.Drawing.Color.Black
        Me.txtmarks.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.RightColor = System.Drawing.Color.Black
        Me.txtmarks.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.Border.TopColor = System.Drawing.Color.Black
        Me.txtmarks.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtmarks.DataField = "marks"
        Me.txtmarks.Height = 0.1979167!
        Me.txtmarks.Left = 1.008858!
        Me.txtmarks.Name = "txtmarks"
        Me.txtmarks.Style = "color: Red; "
        Me.txtmarks.Text = "marks"
        Me.txtmarks.Top = 1.20981!
        Me.txtmarks.Visible = False
        Me.txtmarks.Width = 1.0!
        '
        'txtproduct_n1
        '
        Me.txtproduct_n1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_n1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n1.DataField = "product_n1"
        Me.txtproduct_n1.Height = 0.1979167!
        Me.txtproduct_n1.Left = 2.017717!
        Me.txtproduct_n1.Name = "txtproduct_n1"
        Me.txtproduct_n1.Style = "color: Red; text-align: left; "
        Me.txtproduct_n1.Text = "product_n1"
        Me.txtproduct_n1.Top = 1.20981!
        Me.txtproduct_n1.Visible = False
        Me.txtproduct_n1.Width = 1.0!
        '
        'txtproduct_n2
        '
        Me.txtproduct_n2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_n2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_n2.DataField = "product_n2"
        Me.txtproduct_n2.Height = 0.1979167!
        Me.txtproduct_n2.Left = 3.026575!
        Me.txtproduct_n2.Name = "txtproduct_n2"
        Me.txtproduct_n2.Style = "color: Red; "
        Me.txtproduct_n2.Text = "product_n2"
        Me.txtproduct_n2.Top = 1.20981!
        Me.txtproduct_n2.Visible = False
        Me.txtproduct_n2.Width = 1.0!
        '
        'txtquantity1
        '
        Me.txtquantity1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity1.DataField = "quantity1"
        Me.txtquantity1.Height = 0.1979167!
        Me.txtquantity1.Left = 0!
        Me.txtquantity1.Name = "txtquantity1"
        Me.txtquantity1.Style = "color: Red; text-align: left; "
        Me.txtquantity1.Text = "quantity1"
        Me.txtquantity1.Top = 1.402559!
        Me.txtquantity1.Visible = False
        Me.txtquantity1.Width = 1.0!
        '
        'txtq_unit_code1
        '
        Me.txtq_unit_code1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code1.DataField = "q_unit_code1"
        Me.txtq_unit_code1.Height = 0.1979167!
        Me.txtq_unit_code1.Left = 1.008858!
        Me.txtq_unit_code1.Name = "txtq_unit_code1"
        Me.txtq_unit_code1.Style = "color: Red; "
        Me.txtq_unit_code1.Text = "q_unit_code1"
        Me.txtq_unit_code1.Top = 1.402559!
        Me.txtq_unit_code1.Visible = False
        Me.txtq_unit_code1.Width = 1.0!
        '
        'txtquantity2
        '
        Me.txtquantity2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity2.DataField = "quantity2"
        Me.txtquantity2.Height = 0.1979167!
        Me.txtquantity2.Left = 0!
        Me.txtquantity2.Name = "txtquantity2"
        Me.txtquantity2.Style = "color: Red; text-align: left; "
        Me.txtquantity2.Text = "quantity2"
        Me.txtquantity2.Top = 1.662976!
        Me.txtquantity2.Visible = False
        Me.txtquantity2.Width = 1.0!
        '
        'txtq_unit_code2
        '
        Me.txtq_unit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code2.DataField = "q_unit_code2"
        Me.txtq_unit_code2.Height = 0.1979167!
        Me.txtq_unit_code2.Left = 1.008858!
        Me.txtq_unit_code2.Name = "txtq_unit_code2"
        Me.txtq_unit_code2.Style = "color: Red; "
        Me.txtq_unit_code2.Text = "q_unit_code2"
        Me.txtq_unit_code2.Top = 1.662976!
        Me.txtq_unit_code2.Visible = False
        Me.txtq_unit_code2.Width = 1.0!
        '
        'txtquantity3
        '
        Me.txtquantity3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity3.DataField = "quantity3"
        Me.txtquantity3.Height = 0.1979167!
        Me.txtquantity3.Left = 0!
        Me.txtquantity3.Name = "txtquantity3"
        Me.txtquantity3.Style = "color: Red; text-align: left; "
        Me.txtquantity3.Text = "quantity3"
        Me.txtquantity3.Top = 1.923393!
        Me.txtquantity3.Visible = False
        Me.txtquantity3.Width = 1.0!
        '
        'txtq_unit_code3
        '
        Me.txtq_unit_code3.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code3.DataField = "q_unit_code3"
        Me.txtq_unit_code3.Height = 0.1979167!
        Me.txtq_unit_code3.Left = 1.008858!
        Me.txtq_unit_code3.Name = "txtq_unit_code3"
        Me.txtq_unit_code3.Style = "color: Red; "
        Me.txtq_unit_code3.Text = "q_unit_code3"
        Me.txtq_unit_code3.Top = 1.923393!
        Me.txtq_unit_code3.Visible = False
        Me.txtq_unit_code3.Width = 1.0!
        '
        'txtquantity4
        '
        Me.txtquantity4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity4.DataField = "quantity4"
        Me.txtquantity4.Height = 0.1979167!
        Me.txtquantity4.Left = 0!
        Me.txtquantity4.Name = "txtquantity4"
        Me.txtquantity4.Style = "color: Red; text-align: left; "
        Me.txtquantity4.Text = "quantity4"
        Me.txtquantity4.Top = 2.183809!
        Me.txtquantity4.Visible = False
        Me.txtquantity4.Width = 1.0!
        '
        'txtq_unit_code4
        '
        Me.txtq_unit_code4.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code4.DataField = "q_unit_code4"
        Me.txtq_unit_code4.Height = 0.1979167!
        Me.txtq_unit_code4.Left = 1.008858!
        Me.txtq_unit_code4.Name = "txtq_unit_code4"
        Me.txtq_unit_code4.Style = "color: Red; "
        Me.txtq_unit_code4.Text = "q_unit_code4"
        Me.txtq_unit_code4.Top = 2.183809!
        Me.txtq_unit_code4.Visible = False
        Me.txtq_unit_code4.Width = 1.0!
        '
        'txtquantity5
        '
        Me.txtquantity5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.RightColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.Border.TopColor = System.Drawing.Color.Black
        Me.txtquantity5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtquantity5.DataField = "quantity5"
        Me.txtquantity5.Height = 0.1979167!
        Me.txtquantity5.Left = 0!
        Me.txtquantity5.Name = "txtquantity5"
        Me.txtquantity5.Style = "color: Red; text-align: left; "
        Me.txtquantity5.Text = "quantity5"
        Me.txtquantity5.Top = 2.444227!
        Me.txtquantity5.Visible = False
        Me.txtquantity5.Width = 1.0!
        '
        'txtq_unit_code5
        '
        Me.txtq_unit_code5.Border.BottomColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.LeftColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.RightColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.Border.TopColor = System.Drawing.Color.Black
        Me.txtq_unit_code5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtq_unit_code5.DataField = "q_unit_code5"
        Me.txtq_unit_code5.Height = 0.1979167!
        Me.txtq_unit_code5.Left = 1.008858!
        Me.txtq_unit_code5.Name = "txtq_unit_code5"
        Me.txtq_unit_code5.Style = "color: Red; "
        Me.txtq_unit_code5.Text = "q_unit_code5"
        Me.txtq_unit_code5.Top = 2.444227!
        Me.txtq_unit_code5.Visible = False
        Me.txtq_unit_code5.Width = 1.0!
        '
        'txtg_unit_code
        '
        Me.txtg_unit_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.RightColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.Border.TopColor = System.Drawing.Color.Black
        Me.txtg_unit_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtg_unit_code.DataField = "g_unit_code"
        Me.txtg_unit_code.Height = 0.1979167!
        Me.txtg_unit_code.Left = 2.017717!
        Me.txtg_unit_code.Name = "txtg_unit_code"
        Me.txtg_unit_code.Style = "color: Red; "
        Me.txtg_unit_code.Text = "g_unit_code"
        Me.txtg_unit_code.Top = 1.470227!
        Me.txtg_unit_code.Visible = False
        Me.txtg_unit_code.Width = 1.0!
        '
        'C_TotalRowDe
        '
        Me.C_TotalRowDe.Border.BottomColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.LeftColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.RightColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Border.TopColor = System.Drawing.Color.Black
        Me.C_TotalRowDe.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.C_TotalRowDe.Height = 0.1979167!
        Me.C_TotalRowDe.Left = 2.017717!
        Me.C_TotalRowDe.Name = "C_TotalRowDe"
        Me.C_TotalRowDe.Style = "color: Lime; "
        Me.C_TotalRowDe.Text = "C_TotalRowDe"
        Me.C_TotalRowDe.Top = 1.730644!
        Me.C_TotalRowDe.Visible = False
        Me.C_TotalRowDe.Width = 1.0!
        '
        'txtTotal_net_weight
        '
        Me.txtTotal_net_weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtTotal_net_weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal_net_weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtTotal_net_weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal_net_weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtTotal_net_weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal_net_weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtTotal_net_weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtTotal_net_weight.DataField = "Total_net_weight"
        Me.txtTotal_net_weight.Height = 0.1979167!
        Me.txtTotal_net_weight.Left = 3.026575!
        Me.txtTotal_net_weight.Name = "txtTotal_net_weight"
        Me.txtTotal_net_weight.Style = "color: Red; "
        Me.txtTotal_net_weight.Text = "Total_net_weight"
        Me.txtTotal_net_weight.Top = 1.470227!
        Me.txtTotal_net_weight.Visible = False
        Me.txtTotal_net_weight.Width = 1.0!
        '
        'txtbox8
        '
        Me.txtbox8.Border.BottomColor = System.Drawing.Color.Black
        Me.txtbox8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.LeftColor = System.Drawing.Color.Black
        Me.txtbox8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.RightColor = System.Drawing.Color.Black
        Me.txtbox8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.Border.TopColor = System.Drawing.Color.Black
        Me.txtbox8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtbox8.DataField = "box8"
        Me.txtbox8.Height = 0.3937007!
        Me.txtbox8.Left = 4.109252!
        Me.txtbox8.Name = "txtbox8"
        Me.txtbox8.Style = "color: Red; ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: " &
    "BrowalliaUPC; "
        Me.txtbox8.Text = "box8"
        Me.txtbox8.Top = 1.205709!
        Me.txtbox8.Visible = False
        Me.txtbox8.Width = 0.9055118!
        '
        'txtSum_Gross_Weight
        '
        Me.txtSum_Gross_Weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtSum_Gross_Weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Gross_Weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtSum_Gross_Weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Gross_Weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtSum_Gross_Weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Gross_Weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtSum_Gross_Weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_Gross_Weight.Height = 0.1979167!
        Me.txtSum_Gross_Weight.Left = 2.017717!
        Me.txtSum_Gross_Weight.Name = "txtSum_Gross_Weight"
        Me.txtSum_Gross_Weight.Style = "color: Lime; "
        Me.txtSum_Gross_Weight.Text = "Sum_Gross_Weight"
        Me.txtSum_Gross_Weight.Top = 1.991061!
        Me.txtSum_Gross_Weight.Visible = False
        Me.txtSum_Gross_Weight.Width = 1.0!
        '
        'txtSum_g_Unit_Desc
        '
        Me.txtSum_g_Unit_Desc.Border.BottomColor = System.Drawing.Color.Black
        Me.txtSum_g_Unit_Desc.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_g_Unit_Desc.Border.LeftColor = System.Drawing.Color.Black
        Me.txtSum_g_Unit_Desc.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_g_Unit_Desc.Border.RightColor = System.Drawing.Color.Black
        Me.txtSum_g_Unit_Desc.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_g_Unit_Desc.Border.TopColor = System.Drawing.Color.Black
        Me.txtSum_g_Unit_Desc.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtSum_g_Unit_Desc.Height = 0.1979167!
        Me.txtSum_g_Unit_Desc.Left = 2.017717!
        Me.txtSum_g_Unit_Desc.Name = "txtSum_g_Unit_Desc"
        Me.txtSum_g_Unit_Desc.Style = "color: Lime; "
        Me.txtSum_g_Unit_Desc.Text = "Sum_g_Unit_Desc"
        Me.txtSum_g_Unit_Desc.Top = 2.251477!
        Me.txtSum_g_Unit_Desc.Visible = False
        Me.txtSum_g_Unit_Desc.Width = 1.0!
        '
        'txtGrossTxt
        '
        Me.txtGrossTxt.Border.BottomColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.LeftColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.RightColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Border.TopColor = System.Drawing.Color.Black
        Me.txtGrossTxt.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtGrossTxt.Height = 0.2204724!
        Me.txtGrossTxt.Left = 6.176181!
        Me.txtGrossTxt.Name = "txtGrossTxt"
        Me.txtGrossTxt.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" &
    "; "
        Me.txtGrossTxt.Text = Nothing
        Me.txtGrossTxt.Top = 0!
        Me.txtGrossTxt.Width = 0.9055118!
        '
        'txtWeightDisplayHeaderH
        '
        Me.txtWeightDisplayHeaderH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.RightColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.Border.TopColor = System.Drawing.Color.Black
        Me.txtWeightDisplayHeaderH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtWeightDisplayHeaderH.DataField = "WeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Height = 0.1979167!
        Me.txtWeightDisplayHeaderH.Left = 4.109252!
        Me.txtWeightDisplayHeaderH.Name = "txtWeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Style = "color: Red; "
        Me.txtWeightDisplayHeaderH.Text = "WeightDisplayHeaderH"
        Me.txtWeightDisplayHeaderH.Top = 1.66191!
        Me.txtWeightDisplayHeaderH.Visible = False
        Me.txtWeightDisplayHeaderH.Width = 1.0!
        '
        'txtnet_weight
        '
        Me.txtnet_weight.Border.BottomColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.LeftColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.RightColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.Border.TopColor = System.Drawing.Color.Black
        Me.txtnet_weight.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtnet_weight.DataField = "net_weight"
        Me.txtnet_weight.Height = 0.1979167!
        Me.txtnet_weight.Left = 4.109252!
        Me.txtnet_weight.Name = "txtnet_weight"
        Me.txtnet_weight.Style = "color: Red; "
        Me.txtnet_weight.Text = "net_weight"
        Me.txtnet_weight.Top = 1.922326!
        Me.txtnet_weight.Visible = False
        Me.txtnet_weight.Width = 1.0!
        '
        'txtunit_code2
        '
        Me.txtunit_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtunit_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtunit_code2.DataField = "unit_code2"
        Me.txtunit_code2.Height = 0.1979167!
        Me.txtunit_code2.Left = 4.109252!
        Me.txtunit_code2.Name = "txtunit_code2"
        Me.txtunit_code2.Style = "color: Red; "
        Me.txtunit_code2.Text = "unit_code2"
        Me.txtunit_code2.Top = 2.182743!
        Me.txtunit_code2.Visible = False
        Me.txtunit_code2.Width = 1.0!
        '
        'txtNumInvoice
        '
        Me.txtNumInvoice.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.RightColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.Border.TopColor = System.Drawing.Color.Black
        Me.txtNumInvoice.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNumInvoice.DataField = "NumInvoice"
        Me.txtNumInvoice.Height = 0.1979167!
        Me.txtNumInvoice.Left = 4.109252!
        Me.txtNumInvoice.Name = "txtNumInvoice"
        Me.txtNumInvoice.Style = "color: Red; "
        Me.txtNumInvoice.Text = "NumInvoice"
        Me.txtNumInvoice.Top = 2.44316!
        Me.txtNumInvoice.Visible = False
        Me.txtNumInvoice.Width = 1.0!
        '
        'txttariff_code
        '
        Me.txttariff_code.Border.BottomColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.LeftColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.RightColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.Border.TopColor = System.Drawing.Color.Black
        Me.txttariff_code.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttariff_code.DataField = "tariff_code"
        Me.txttariff_code.Height = 0.1979167!
        Me.txttariff_code.Left = 4.109252!
        Me.txttariff_code.Name = "txttariff_code"
        Me.txttariff_code.Style = "color: Red; "
        Me.txttariff_code.Text = "tariff_code"
        Me.txttariff_code.Top = 2.703577!
        Me.txttariff_code.Visible = False
        Me.txttariff_code.Width = 1.0!
        '
        'txtFOBDisplay
        '
        Me.txtFOBDisplay.Border.BottomColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.LeftColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.RightColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.Border.TopColor = System.Drawing.Color.Black
        Me.txtFOBDisplay.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtFOBDisplay.DataField = "FOBDisplay"
        Me.txtFOBDisplay.Height = 0.1979167!
        Me.txtFOBDisplay.Left = 4.109252!
        Me.txtFOBDisplay.Name = "txtFOBDisplay"
        Me.txtFOBDisplay.Style = "color: Red; "
        Me.txtFOBDisplay.Text = "FOBDisplay"
        Me.txtFOBDisplay.Top = 2.963993!
        Me.txtFOBDisplay.Visible = False
        Me.txtFOBDisplay.Width = 1.0!
        '
        'txtgross_weightH
        '
        Me.txtgross_weightH.Border.BottomColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.LeftColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.RightColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.Border.TopColor = System.Drawing.Color.Black
        Me.txtgross_weightH.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtgross_weightH.DataField = "gross_weightH"
        Me.txtgross_weightH.Height = 0.3937007!
        Me.txtgross_weightH.Left = 3.075788!
        Me.txtgross_weightH.Name = "txtgross_weightH"
        Me.txtgross_weightH.Style = "color: Red; ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: " &
    "BrowalliaUPC; "
        Me.txtgross_weightH.Text = "gross_weightH"
        Me.txtgross_weightH.Top = 2.178643!
        Me.txtgross_weightH.Visible = False
        Me.txtgross_weightH.Width = 0.9055118!
        '
        'txtfob_amt
        '
        Me.txtfob_amt.Border.BottomColor = System.Drawing.Color.Black
        Me.txtfob_amt.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfob_amt.Border.LeftColor = System.Drawing.Color.Black
        Me.txtfob_amt.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfob_amt.Border.RightColor = System.Drawing.Color.Black
        Me.txtfob_amt.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfob_amt.Border.TopColor = System.Drawing.Color.Black
        Me.txtfob_amt.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtfob_amt.DataField = "fob_amt"
        Me.txtfob_amt.Height = 0.1979167!
        Me.txtfob_amt.Left = 4.109252!
        Me.txtfob_amt.Name = "txtfob_amt"
        Me.txtfob_amt.Style = "color: Red; "
        Me.txtfob_amt.Text = "fob_amt"
        Me.txtfob_amt.Top = 3.22441!
        Me.txtfob_amt.Visible = False
        Me.txtfob_amt.Width = 1.0!
        '
        'txtproduct_description
        '
        Me.txtproduct_description.Border.BottomColor = System.Drawing.Color.Black
        Me.txtproduct_description.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_description.Border.LeftColor = System.Drawing.Color.Black
        Me.txtproduct_description.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_description.Border.RightColor = System.Drawing.Color.Black
        Me.txtproduct_description.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_description.Border.TopColor = System.Drawing.Color.Black
        Me.txtproduct_description.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtproduct_description.DataField = "product_description"
        Me.txtproduct_description.Height = 0.1979167!
        Me.txtproduct_description.Left = 1.008858!
        Me.txtproduct_description.Name = "txtproduct_description"
        Me.txtproduct_description.Style = "color: Red; "
        Me.txtproduct_description.Text = "product_description"
        Me.txtproduct_description.Top = 2.704644!
        Me.txtproduct_description.Visible = False
        Me.txtproduct_description.Width = 1.0!
        '
        'PageHeader1
        '
        Me.PageHeader1.CanGrow = False
        Me.PageHeader1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtCompany_Check_1, Me.txtreference_code2_Temp, Me.txtdestination_Check2, Me.txttransport_by, Me.TextBox5, Me.txtcompany_taxno, Me.txtcompany_country, Me.txtcompany_province, Me.txtcompany_address, Me.txtcompany_name, Me.txtob_address, Me.txtdest_remark, Me.txtcompany_fax, Me.txtcompany_phone, Me.txtdestination_company, Me.txtdestination_fax, Me.txtdestination_address, Me.txtdestination_phone, Me.txtdestination_province, Me.txtdest_Receive_country, Me.txtreference_code2, Me.txtdigit1, Me.txtdigit2, Me.txtcompany_email, Me.txtdestination_email, Me.txtdestination_taxid, Me.txtdest_remark1, Me.txtob_dest_address, Me.txtNewEmail_ch01, Me.txtNewEmail_ch02, Me.ReportInfo1, Me.Line17, Me.Line16, Me.Line21, Me.Line22, Me.Line18, Me.Line23, Me.Line13, Me.Label8, Me.Label1, Me.Label3, Me.Label42, Me.Label43, Me.Label44, Me.Label46, Me.Label45, Me.Label47, Me.Label48, Me.Label6, Me.Label19, Me.Line19, Me.Label17, Me.Label4, Me.Label21, Me.Label22, Me.Label20, Me.Label16, Me.Label2, Me.Label7, Me.Line8, Me.Line9, Me.Line10, Me.Line11, Me.Line12, Me.Line14, Me.Line24, Me.Line25, Me.Label23, Me.Line26, Me.Line27, Me.Line28, Me.Line29, Me.Line30, Me.Label24, Me.Line31, Me.Line32, Me.Line33, Me.Line34, Me.Line35, Me.Label26, Me.Label27, Me.Label28, Me.Line36, Me.Line37, Me.Line38, Me.Line39, Me.Line40, Me.Label29, Me.Label30, Me.Label31, Me.Label32, Me.Label33, Me.Label34, Me.Label35, Me.Line41, Me.Label36, Me.Label37, Me.Line42, Me.Label38, Me.Label39, Me.Label40, Me.Line43, Me.Line44, Me.Line45, Me.Line46, Me.Line47, Me.Label41, Me.Label49, Me.Label50, Me.Label51, Me.Label52, Me.Label53, Me.Label54, Me.Line48, Me.Label55, Me.Label56, Me.Line49, Me.Label57, Me.Label58, Me.Label59, Me.Label60, Me.Line50, Me.Line51, Me.Line52, Me.Line53, Me.Line54, Me.Label61, Me.Label62, Me.Label63, Me.Label64, Me.Label65, Me.Label66, Me.Label67, Me.Line55, Me.Label68, Me.Label69, Me.Line56, Me.Label70, Me.Label71, Me.Label72, Me.Label73, Me.Label74, Me.Label75, Me.Label76, Me.Line57, Me.Line58, Me.Line59, Me.Line60, Me.Line61, Me.Label77, Me.Label78, Me.Label79, Me.Label80, Me.Label81, Me.Label82, Me.Label83, Me.Line62, Me.Label84, Me.Label85, Me.Line63, Me.Label86, Me.Label87, Me.Label88, Me.Label89, Me.Label90, Me.Label91, Me.Label92, Me.Label93, Me.Label94, Me.Line76})
        Me.PageHeader1.Height = 5.006945!
        Me.PageHeader1.Name = "PageHeader1"
        '
        'txtCompany_Check_1
        '
        Me.txtCompany_Check_1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.RightColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.Border.TopColor = System.Drawing.Color.Black
        Me.txtCompany_Check_1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtCompany_Check_1.CanGrow = False
        Me.txtCompany_Check_1.Height = 0.7816604!
        Me.txtCompany_Check_1.Left = 0.6151575!
        Me.txtCompany_Check_1.Name = "txtCompany_Check_1"
        Me.txtCompany_Check_1.Style = "ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtCompany_Check_1.Text = Nothing
        Me.txtCompany_Check_1.Top = 0.492126!
        Me.txtCompany_Check_1.Width = 3.700787!
        '
        'txtreference_code2_Temp
        '
        Me.txtreference_code2_Temp.Border.BottomColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.LeftColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.RightColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.Border.TopColor = System.Drawing.Color.Black
        Me.txtreference_code2_Temp.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2_Temp.CanGrow = False
        Me.txtreference_code2_Temp.Height = 0.3937007!
        Me.txtreference_code2_Temp.Left = 5.905513!
        Me.txtreference_code2_Temp.Name = "txtreference_code2_Temp"
        Me.txtreference_code2_Temp.Style = "ddo-char-set: 222; font-weight: bold; font-size: 13pt; font-family: BrowalliaUPC;" &
    " "
        Me.txtreference_code2_Temp.Text = Nothing
        Me.txtreference_code2_Temp.Top = 0.2214567!
        Me.txtreference_code2_Temp.Width = 1.648622!
        '
        'txtdestination_Check2
        '
        Me.txtdestination_Check2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_Check2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_Check2.CanGrow = False
        Me.txtdestination_Check2.Height = 0.8125!
        Me.txtdestination_Check2.Left = 0.625!
        Me.txtdestination_Check2.Name = "txtdestination_Check2"
        Me.txtdestination_Check2.Style = "ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txtdestination_Check2.Text = Nothing
        Me.txtdestination_Check2.Top = 1.5!
        Me.txtdestination_Check2.Width = 3.6875!
        '
        'txttransport_by
        '
        Me.txttransport_by.Border.BottomColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.LeftColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.RightColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.Border.TopColor = System.Drawing.Color.Black
        Me.txttransport_by.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txttransport_by.CanGrow = False
        Me.txttransport_by.DataField = "transport_by"
        Me.txttransport_by.Height = 1.771653!
        Me.txttransport_by.Left = 0.6151575!
        Me.txttransport_by.Name = "txttransport_by"
        Me.txttransport_by.Style = "ddo-char-set: 1; font-size: 10pt; font-family: BrowalliaUPC; "
        Me.txttransport_by.Text = "transport_by"
        Me.txttransport_by.Top = 2.485236!
        Me.txttransport_by.Width = 3.690944!
        '
        'TextBox5
        '
        Me.TextBox5.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox5.CanGrow = False
        Me.TextBox5.Height = 1.578576!
        Me.TextBox5.Left = 4.375!
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Style = "ddo-char-set: 222; font-size: 12pt; font-family: BrowalliaUPC; "
        Me.TextBox5.Text = Nothing
        Me.TextBox5.Top = 2.6875!
        Me.TextBox5.Width = 3.688238!
        '
        'txtcompany_taxno
        '
        Me.txtcompany_taxno.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_taxno.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_taxno.DataField = "company_taxno"
        Me.txtcompany_taxno.Height = 0.1979167!
        Me.txtcompany_taxno.Left = 0.2214567!
        Me.txtcompany_taxno.Name = "txtcompany_taxno"
        Me.txtcompany_taxno.Style = "color: Red; "
        Me.txtcompany_taxno.Text = "company_taxno"
        Me.txtcompany_taxno.Top = 0.07381889!
        Me.txtcompany_taxno.Visible = False
        Me.txtcompany_taxno.Width = 1.0!
        '
        'txtcompany_country
        '
        Me.txtcompany_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_country.DataField = "company_country"
        Me.txtcompany_country.Height = 0.1979167!
        Me.txtcompany_country.Left = 1.254921!
        Me.txtcompany_country.Name = "txtcompany_country"
        Me.txtcompany_country.Style = "color: Red; "
        Me.txtcompany_country.Text = "company_country"
        Me.txtcompany_country.Top = 0.07381889!
        Me.txtcompany_country.Visible = False
        Me.txtcompany_country.Width = 1.0!
        '
        'txtcompany_province
        '
        Me.txtcompany_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_province.DataField = "company_province"
        Me.txtcompany_province.Height = 0.1979167!
        Me.txtcompany_province.Left = 2.288386!
        Me.txtcompany_province.Name = "txtcompany_province"
        Me.txtcompany_province.Style = "color: Red; "
        Me.txtcompany_province.Text = "company_province"
        Me.txtcompany_province.Top = 0.07381889!
        Me.txtcompany_province.Visible = False
        Me.txtcompany_province.Width = 1.0!
        '
        'txtcompany_address
        '
        Me.txtcompany_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_address.DataField = "company_address"
        Me.txtcompany_address.Height = 0.1979167!
        Me.txtcompany_address.Left = 2.288386!
        Me.txtcompany_address.Name = "txtcompany_address"
        Me.txtcompany_address.Style = "color: Red; "
        Me.txtcompany_address.Text = "company_address"
        Me.txtcompany_address.Top = 0.2952756!
        Me.txtcompany_address.Visible = False
        Me.txtcompany_address.Width = 1.0!
        '
        'txtcompany_name
        '
        Me.txtcompany_name.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_name.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_name.DataField = "company_name"
        Me.txtcompany_name.Height = 0.1979167!
        Me.txtcompany_name.Left = 3.297244!
        Me.txtcompany_name.Name = "txtcompany_name"
        Me.txtcompany_name.Style = "color: Red; "
        Me.txtcompany_name.Text = "company_name"
        Me.txtcompany_name.Top = 0.07381889!
        Me.txtcompany_name.Visible = False
        Me.txtcompany_name.Width = 1.0!
        '
        'txtob_address
        '
        Me.txtob_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtob_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtob_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtob_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtob_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_address.DataField = "ob_address"
        Me.txtob_address.Height = 0.1979167!
        Me.txtob_address.Left = 3.297244!
        Me.txtob_address.Name = "txtob_address"
        Me.txtob_address.Style = "color: Red; "
        Me.txtob_address.Text = "ob_address"
        Me.txtob_address.Top = 0.2952756!
        Me.txtob_address.Visible = False
        Me.txtob_address.Width = 1.0!
        '
        'txtdest_remark
        '
        Me.txtdest_remark.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_remark.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark.DataField = "dest_remark"
        Me.txtdest_remark.Height = 0.1979167!
        Me.txtdest_remark.Left = 4.330709!
        Me.txtdest_remark.Name = "txtdest_remark"
        Me.txtdest_remark.Style = "color: Red; "
        Me.txtdest_remark.Text = "dest_remark"
        Me.txtdest_remark.Top = 0.07381889!
        Me.txtdest_remark.Visible = False
        Me.txtdest_remark.Width = 1.0!
        '
        'txtcompany_fax
        '
        Me.txtcompany_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_fax.DataField = "company_fax"
        Me.txtcompany_fax.Height = 0.1979167!
        Me.txtcompany_fax.Left = 0.2214567!
        Me.txtcompany_fax.Name = "txtcompany_fax"
        Me.txtcompany_fax.Style = "color: Red; "
        Me.txtcompany_fax.Text = "company_fax"
        Me.txtcompany_fax.Top = 0.2952756!
        Me.txtcompany_fax.Visible = False
        Me.txtcompany_fax.Width = 1.0!
        '
        'txtcompany_phone
        '
        Me.txtcompany_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_phone.DataField = "company_phone"
        Me.txtcompany_phone.Height = 0.1979167!
        Me.txtcompany_phone.Left = 1.254921!
        Me.txtcompany_phone.Name = "txtcompany_phone"
        Me.txtcompany_phone.Style = "color: Red; "
        Me.txtcompany_phone.Text = "company_phone"
        Me.txtcompany_phone.Top = 0.2952756!
        Me.txtcompany_phone.Visible = False
        Me.txtcompany_phone.Width = 1.0!
        '
        'txtdestination_company
        '
        Me.txtdestination_company.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_company.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_company.DataField = "destination_company"
        Me.txtdestination_company.Height = 0.1979167!
        Me.txtdestination_company.Left = 0.1722441!
        Me.txtdestination_company.Name = "txtdestination_company"
        Me.txtdestination_company.Style = "color: Red; "
        Me.txtdestination_company.Text = "destination_company"
        Me.txtdestination_company.Top = 4.330709!
        Me.txtdestination_company.Visible = False
        Me.txtdestination_company.Width = 1.0!
        '
        'txtdestination_fax
        '
        Me.txtdestination_fax.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_fax.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_fax.DataField = "destination_fax"
        Me.txtdestination_fax.Height = 0.1979167!
        Me.txtdestination_fax.Left = 1.205709!
        Me.txtdestination_fax.Name = "txtdestination_fax"
        Me.txtdestination_fax.Style = "color: Red; "
        Me.txtdestination_fax.Text = "destination_fax"
        Me.txtdestination_fax.Top = 4.330709!
        Me.txtdestination_fax.Visible = False
        Me.txtdestination_fax.Width = 1.0!
        '
        'txtdestination_address
        '
        Me.txtdestination_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_address.DataField = "destination_address"
        Me.txtdestination_address.Height = 0.1979167!
        Me.txtdestination_address.Left = 1.205709!
        Me.txtdestination_address.Name = "txtdestination_address"
        Me.txtdestination_address.Style = "color: Red; "
        Me.txtdestination_address.Text = "destination_address"
        Me.txtdestination_address.Top = 4.625985!
        Me.txtdestination_address.Visible = False
        Me.txtdestination_address.Width = 1.0!
        '
        'txtdestination_phone
        '
        Me.txtdestination_phone.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_phone.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_phone.DataField = "destination_phone"
        Me.txtdestination_phone.Height = 0.1979167!
        Me.txtdestination_phone.Left = 0.1722441!
        Me.txtdestination_phone.Name = "txtdestination_phone"
        Me.txtdestination_phone.Style = "color: Red; "
        Me.txtdestination_phone.Text = "destination_phone"
        Me.txtdestination_phone.Top = 4.615732!
        Me.txtdestination_phone.Visible = False
        Me.txtdestination_phone.Width = 1.0!
        '
        'txtdestination_province
        '
        Me.txtdestination_province.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_province.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_province.DataField = "destination_province"
        Me.txtdestination_province.Height = 0.1979167!
        Me.txtdestination_province.Left = 2.239173!
        Me.txtdestination_province.Name = "txtdestination_province"
        Me.txtdestination_province.Style = "color: Red; "
        Me.txtdestination_province.Text = "destination_province"
        Me.txtdestination_province.Top = 4.330709!
        Me.txtdestination_province.Visible = False
        Me.txtdestination_province.Width = 1.0!
        '
        'txtdest_Receive_country
        '
        Me.txtdest_Receive_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_Receive_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_Receive_country.DataField = "dest_Receive_country"
        Me.txtdest_Receive_country.Height = 0.1979167!
        Me.txtdest_Receive_country.Left = 2.239173!
        Me.txtdest_Receive_country.Name = "txtdest_Receive_country"
        Me.txtdest_Receive_country.Style = "color: Red; "
        Me.txtdest_Receive_country.Text = "dest_Receive_country"
        Me.txtdest_Receive_country.Top = 4.591125!
        Me.txtdest_Receive_country.Visible = False
        Me.txtdest_Receive_country.Width = 1.0!
        '
        'txtreference_code2
        '
        Me.txtreference_code2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.RightColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.Border.TopColor = System.Drawing.Color.Black
        Me.txtreference_code2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtreference_code2.DataField = "reference_code2"
        Me.txtreference_code2.Height = 0.3937007!
        Me.txtreference_code2.Left = 5.905513!
        Me.txtreference_code2.Name = "txtreference_code2"
        Me.txtreference_code2.Style = "color: Lime; ddo-char-set: 222; font-weight: bold; font-size: 13pt; font-family: " &
    "BrowalliaUPC; "
        Me.txtreference_code2.Text = "reference_code2"
        Me.txtreference_code2.Top = 0.8991145!
        Me.txtreference_code2.Visible = False
        Me.txtreference_code2.Width = 1.648622!
        '
        'txtdigit1
        '
        Me.txtdigit1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdigit1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdigit1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdigit1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdigit1.Border.RightColor = System.Drawing.Color.Black
        Me.txtdigit1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdigit1.Border.TopColor = System.Drawing.Color.Black
        Me.txtdigit1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdigit1.DataField = "digit1"
        Me.txtdigit1.Height = 0.1979167!
        Me.txtdigit1.Left = 4.355315!
        Me.txtdigit1.Name = "txtdigit1"
        Me.txtdigit1.Style = "color: Red; "
        Me.txtdigit1.Text = "digit1"
        Me.txtdigit1.Top = 0.2952756!
        Me.txtdigit1.Visible = False
        Me.txtdigit1.Width = 1.0!
        '
        'txtdigit2
        '
        Me.txtdigit2.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdigit2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdigit2.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdigit2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdigit2.Border.RightColor = System.Drawing.Color.Black
        Me.txtdigit2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdigit2.Border.TopColor = System.Drawing.Color.Black
        Me.txtdigit2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdigit2.DataField = "digit2"
        Me.txtdigit2.Height = 0.1979167!
        Me.txtdigit2.Left = 4.355315!
        Me.txtdigit2.Name = "txtdigit2"
        Me.txtdigit2.Style = "color: Red; "
        Me.txtdigit2.Text = "digit2"
        Me.txtdigit2.Top = 0.5556924!
        Me.txtdigit2.Visible = False
        Me.txtdigit2.Width = 1.0!
        '
        'txtcompany_email
        '
        Me.txtcompany_email.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_email.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_email.DataField = "company_email"
        Me.txtcompany_email.Height = 0.1979167!
        Me.txtcompany_email.Left = 4.355315!
        Me.txtcompany_email.Name = "txtcompany_email"
        Me.txtcompany_email.Style = "color: Red; "
        Me.txtcompany_email.Text = "company_email"
        Me.txtcompany_email.Top = 0.8161091!
        Me.txtcompany_email.Visible = False
        Me.txtcompany_email.Width = 1.0!
        '
        'txtdestination_email
        '
        Me.txtdestination_email.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_email.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_email.DataField = "destination_email"
        Me.txtdestination_email.Height = 0.1979167!
        Me.txtdestination_email.Left = 4.355315!
        Me.txtdestination_email.Name = "txtdestination_email"
        Me.txtdestination_email.Style = "color: Red; "
        Me.txtdestination_email.Text = "destination_email"
        Me.txtdestination_email.Top = 1.076526!
        Me.txtdestination_email.Visible = False
        Me.txtdestination_email.Width = 1.0!
        '
        'txtdestination_taxid
        '
        Me.txtdestination_taxid.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.RightColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.Border.TopColor = System.Drawing.Color.Black
        Me.txtdestination_taxid.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdestination_taxid.DataField = "destination_taxid"
        Me.txtdestination_taxid.Height = 0.1979167!
        Me.txtdestination_taxid.Left = 4.355315!
        Me.txtdestination_taxid.Name = "txtdestination_taxid"
        Me.txtdestination_taxid.Style = "color: Red; "
        Me.txtdestination_taxid.Text = "destination_taxid"
        Me.txtdestination_taxid.Top = 1.336943!
        Me.txtdestination_taxid.Visible = False
        Me.txtdestination_taxid.Width = 1.0!
        '
        'txtdest_remark1
        '
        Me.txtdest_remark1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.RightColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.Border.TopColor = System.Drawing.Color.Black
        Me.txtdest_remark1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtdest_remark1.DataField = "dest_remark1"
        Me.txtdest_remark1.Height = 0.1979167!
        Me.txtdest_remark1.Left = 4.355315!
        Me.txtdest_remark1.Name = "txtdest_remark1"
        Me.txtdest_remark1.Style = "color: Red; "
        Me.txtdest_remark1.Text = "dest_remark1"
        Me.txtdest_remark1.Top = 1.59736!
        Me.txtdest_remark1.Visible = False
        Me.txtdest_remark1.Width = 1.0!
        '
        'txtob_dest_address
        '
        Me.txtob_dest_address.Border.BottomColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.LeftColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.RightColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.Border.TopColor = System.Drawing.Color.Black
        Me.txtob_dest_address.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtob_dest_address.DataField = "ob_dest_address"
        Me.txtob_dest_address.Height = 0.1979167!
        Me.txtob_dest_address.Left = 4.355315!
        Me.txtob_dest_address.Name = "txtob_dest_address"
        Me.txtob_dest_address.Style = "color: Red; "
        Me.txtob_dest_address.Text = "ob_dest_address"
        Me.txtob_dest_address.Top = 1.857777!
        Me.txtob_dest_address.Visible = False
        Me.txtob_dest_address.Width = 1.0!
        '
        'txtNewEmail_ch01
        '
        Me.txtNewEmail_ch01.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.RightColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.Border.TopColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch01.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch01.DataField = "NewEmail_ch01"
        Me.txtNewEmail_ch01.Height = 0.1979167!
        Me.txtNewEmail_ch01.Left = 4.355315!
        Me.txtNewEmail_ch01.Name = "txtNewEmail_ch01"
        Me.txtNewEmail_ch01.Style = "color: Red; "
        Me.txtNewEmail_ch01.Text = "NewEmail_ch01"
        Me.txtNewEmail_ch01.Top = 2.118194!
        Me.txtNewEmail_ch01.Visible = False
        Me.txtNewEmail_ch01.Width = 1.0!
        '
        'txtNewEmail_ch02
        '
        Me.txtNewEmail_ch02.Border.BottomColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.LeftColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.RightColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.Border.TopColor = System.Drawing.Color.Black
        Me.txtNewEmail_ch02.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtNewEmail_ch02.DataField = "NewEmail_ch02"
        Me.txtNewEmail_ch02.Height = 0.1979167!
        Me.txtNewEmail_ch02.Left = 4.355315!
        Me.txtNewEmail_ch02.Name = "txtNewEmail_ch02"
        Me.txtNewEmail_ch02.Style = "color: Red; "
        Me.txtNewEmail_ch02.Text = "NewEmail_ch02"
        Me.txtNewEmail_ch02.Top = 2.37861!
        Me.txtNewEmail_ch02.Visible = False
        Me.txtNewEmail_ch02.Width = 1.0!
        '
        'ReportInfo1
        '
        Me.ReportInfo1.Border.BottomColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.LeftColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.RightColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.Border.TopColor = System.Drawing.Color.Black
        Me.ReportInfo1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.ReportInfo1.FormatString = Nothing
        Me.ReportInfo1.Height = 0.3125!
        Me.ReportInfo1.Left = 3.494095!
        Me.ReportInfo1.Name = "ReportInfo1"
        Me.ReportInfo1.Style = "text-align: center; font-family: BrowalliaUPC; "
        Me.ReportInfo1.Top = 4.284367!
        Me.ReportInfo1.Width = 1.5!
        '
        'Line17
        '
        Me.Line17.Border.BottomColor = System.Drawing.Color.Black
        Me.Line17.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.LeftColor = System.Drawing.Color.Black
        Me.Line17.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.RightColor = System.Drawing.Color.Black
        Me.Line17.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Border.TopColor = System.Drawing.Color.Black
        Me.Line17.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line17.Height = 0!
        Me.Line17.Left = 0.0625!
        Me.Line17.LineWeight = 1.0!
        Me.Line17.Name = "Line17"
        Me.Line17.Top = 0.0625!
        Me.Line17.Width = 8.125!
        Me.Line17.X1 = 0.0625!
        Me.Line17.X2 = 8.1875!
        Me.Line17.Y1 = 0.0625!
        Me.Line17.Y2 = 0.0625!
        '
        'Line16
        '
        Me.Line16.Border.BottomColor = System.Drawing.Color.Black
        Me.Line16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.LeftColor = System.Drawing.Color.Black
        Me.Line16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.RightColor = System.Drawing.Color.Black
        Me.Line16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Border.TopColor = System.Drawing.Color.Black
        Me.Line16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line16.Height = 4.9375!
        Me.Line16.Left = 0.0625!
        Me.Line16.LineWeight = 1.0!
        Me.Line16.Name = "Line16"
        Me.Line16.Top = 0.0625!
        Me.Line16.Width = 0!
        Me.Line16.X1 = 0.0625!
        Me.Line16.X2 = 0.0625!
        Me.Line16.Y1 = 5.0!
        Me.Line16.Y2 = 0.0625!
        '
        'Line21
        '
        Me.Line21.Border.BottomColor = System.Drawing.Color.Black
        Me.Line21.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line21.Border.LeftColor = System.Drawing.Color.Black
        Me.Line21.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line21.Border.RightColor = System.Drawing.Color.Black
        Me.Line21.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line21.Border.TopColor = System.Drawing.Color.Black
        Me.Line21.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line21.Height = 4.9375!
        Me.Line21.Left = 8.1875!
        Me.Line21.LineWeight = 1.0!
        Me.Line21.Name = "Line21"
        Me.Line21.Top = 0.0625!
        Me.Line21.Width = 0!
        Me.Line21.X1 = 8.1875!
        Me.Line21.X2 = 8.1875!
        Me.Line21.Y1 = 0.0625!
        Me.Line21.Y2 = 5.0!
        '
        'Line22
        '
        Me.Line22.Border.BottomColor = System.Drawing.Color.Black
        Me.Line22.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line22.Border.LeftColor = System.Drawing.Color.Black
        Me.Line22.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line22.Border.RightColor = System.Drawing.Color.Black
        Me.Line22.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line22.Border.TopColor = System.Drawing.Color.Black
        Me.Line22.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line22.Height = 0!
        Me.Line22.Left = 0.0625!
        Me.Line22.LineWeight = 1.0!
        Me.Line22.Name = "Line22"
        Me.Line22.Top = 4.25!
        Me.Line22.Width = 8.125!
        Me.Line22.X1 = 0.0625!
        Me.Line22.X2 = 8.1875!
        Me.Line22.Y1 = 4.25!
        Me.Line22.Y2 = 4.25!
        '
        'Line18
        '
        Me.Line18.Border.BottomColor = System.Drawing.Color.Black
        Me.Line18.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line18.Border.LeftColor = System.Drawing.Color.Black
        Me.Line18.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line18.Border.RightColor = System.Drawing.Color.Black
        Me.Line18.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line18.Border.TopColor = System.Drawing.Color.Black
        Me.Line18.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line18.Height = 4.1875!
        Me.Line18.Left = 4.3125!
        Me.Line18.LineWeight = 1.0!
        Me.Line18.Name = "Line18"
        Me.Line18.Top = 0.0625!
        Me.Line18.Width = 0!
        Me.Line18.X1 = 4.3125!
        Me.Line18.X2 = 4.3125!
        Me.Line18.Y1 = 4.25!
        Me.Line18.Y2 = 0.0625!
        '
        'Line23
        '
        Me.Line23.Border.BottomColor = System.Drawing.Color.Black
        Me.Line23.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line23.Border.LeftColor = System.Drawing.Color.Black
        Me.Line23.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line23.Border.RightColor = System.Drawing.Color.Black
        Me.Line23.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line23.Border.TopColor = System.Drawing.Color.Black
        Me.Line23.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line23.Height = 0!
        Me.Line23.Left = 0.0625!
        Me.Line23.LineWeight = 1.0!
        Me.Line23.Name = "Line23"
        Me.Line23.Top = 2.25!
        Me.Line23.Width = 8.125!
        Me.Line23.X1 = 0.0625!
        Me.Line23.X2 = 8.1875!
        Me.Line23.Y1 = 2.25!
        Me.Line23.Y2 = 2.25!
        '
        'Line13
        '
        Me.Line13.Border.BottomColor = System.Drawing.Color.Black
        Me.Line13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.LeftColor = System.Drawing.Color.Black
        Me.Line13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.RightColor = System.Drawing.Color.Black
        Me.Line13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Border.TopColor = System.Drawing.Color.Black
        Me.Line13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line13.Height = 0!
        Me.Line13.Left = 0.0625!
        Me.Line13.LineWeight = 1.0!
        Me.Line13.Name = "Line13"
        Me.Line13.Top = 1.25!
        Me.Line13.Width = 4.25!
        Me.Line13.X1 = 0.0625!
        Me.Line13.X2 = 4.3125!
        Me.Line13.Y1 = 1.25!
        Me.Line13.Y2 = 1.25!
        '
        'Label8
        '
        Me.Label8.Border.BottomColor = System.Drawing.Color.Black
        Me.Label8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.LeftColor = System.Drawing.Color.Black
        Me.Label8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.RightColor = System.Drawing.Color.Black
        Me.Label8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Border.TopColor = System.Drawing.Color.Black
        Me.Label8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label8.Height = 0.1875!
        Me.Label8.HyperLink = Nothing
        Me.Label8.Left = 0.25!
        Me.Label8.Name = "Label8"
        Me.Label8.Style = "font-size: 9pt; font-family: Times New Roman; "
        Me.Label8.Text = "1. Goods consigned from (Exporter's business name, address, country)"
        Me.Label8.Top = 0.25!
        Me.Label8.Width = 4.0!
        '
        'Label1
        '
        Me.Label1.Border.BottomColor = System.Drawing.Color.Black
        Me.Label1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.LeftColor = System.Drawing.Color.Black
        Me.Label1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.RightColor = System.Drawing.Color.Black
        Me.Label1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Border.TopColor = System.Drawing.Color.Black
        Me.Label1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label1.Height = 0.1875!
        Me.Label1.HyperLink = Nothing
        Me.Label1.Left = 0.25!
        Me.Label1.Name = "Label1"
        Me.Label1.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label1.Text = "2. Goods consigned to (Consignee's name, address, country)"
        Me.Label1.Top = 1.3125!
        Me.Label1.Width = 4.0!
        '
        'Label3
        '
        Me.Label3.Border.BottomColor = System.Drawing.Color.Black
        Me.Label3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.LeftColor = System.Drawing.Color.Black
        Me.Label3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.RightColor = System.Drawing.Color.Black
        Me.Label3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Border.TopColor = System.Drawing.Color.Black
        Me.Label3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label3.Height = 0.1875!
        Me.Label3.HyperLink = Nothing
        Me.Label3.Left = 0.25!
        Me.Label3.Name = "Label3"
        Me.Label3.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label3.Text = "3. Means of transport and route (as far as known)"
        Me.Label3.Top = 2.3125!
        Me.Label3.Width = 3.875!
        '
        'Label42
        '
        Me.Label42.Border.BottomColor = System.Drawing.Color.Black
        Me.Label42.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label42.Border.LeftColor = System.Drawing.Color.Black
        Me.Label42.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label42.Border.RightColor = System.Drawing.Color.Black
        Me.Label42.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label42.Border.TopColor = System.Drawing.Color.Black
        Me.Label42.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label42.Height = 0.3125!
        Me.Label42.HyperLink = Nothing
        Me.Label42.Left = 0.1875!
        Me.Label42.Name = "Label42"
        Me.Label42.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label42.Text = "5. Item number"
        Me.Label42.Top = 4.375!
        Me.Label42.Width = 0.5625!
        '
        'Label43
        '
        Me.Label43.Border.BottomColor = System.Drawing.Color.Black
        Me.Label43.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label43.Border.LeftColor = System.Drawing.Color.Black
        Me.Label43.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label43.Border.RightColor = System.Drawing.Color.Black
        Me.Label43.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label43.Border.TopColor = System.Drawing.Color.Black
        Me.Label43.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label43.Height = 0.4375!
        Me.Label43.HyperLink = Nothing
        Me.Label43.Left = 1.0625!
        Me.Label43.Name = "Label43"
        Me.Label43.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label43.Text = "6. Marks and    numbers on packages "
        Me.Label43.Top = 4.375!
        Me.Label43.Width = 0.875!
        '
        'Label44
        '
        Me.Label44.Border.BottomColor = System.Drawing.Color.Black
        Me.Label44.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label44.Border.LeftColor = System.Drawing.Color.Black
        Me.Label44.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label44.Border.RightColor = System.Drawing.Color.Black
        Me.Label44.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label44.Border.TopColor = System.Drawing.Color.Black
        Me.Label44.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label44.Height = 0.1875!
        Me.Label44.HyperLink = Nothing
        Me.Label44.Left = 2.1875!
        Me.Label44.Name = "Label44"
        Me.Label44.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label44.Text = "7. Number and kind of packages; description of goods"
        Me.Label44.Top = 4.375!
        Me.Label44.Width = 2.8125!
        '
        'Label46
        '
        Me.Label46.Border.BottomColor = System.Drawing.Color.Black
        Me.Label46.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label46.Border.LeftColor = System.Drawing.Color.Black
        Me.Label46.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label46.Border.RightColor = System.Drawing.Color.Black
        Me.Label46.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label46.Border.TopColor = System.Drawing.Color.Black
        Me.Label46.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label46.Height = 0.3125!
        Me.Label46.HyperLink = Nothing
        Me.Label46.Left = 5.3125!
        Me.Label46.Name = "Label46"
        Me.Label46.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label46.Text = "8. Origin criterion"
        Me.Label46.Top = 4.375!
        Me.Label46.Width = 0.5625!
        '
        'Label45
        '
        Me.Label45.Border.BottomColor = System.Drawing.Color.Black
        Me.Label45.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label45.Border.LeftColor = System.Drawing.Color.Black
        Me.Label45.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label45.Border.RightColor = System.Drawing.Color.Black
        Me.Label45.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label45.Border.TopColor = System.Drawing.Color.Black
        Me.Label45.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label45.Height = 0.25!
        Me.Label45.HyperLink = Nothing
        Me.Label45.Left = 5.3125!
        Me.Label45.Name = "Label45"
        Me.Label45.Style = "ddo-char-set: 0; font-size: 6pt; font-family: Times New Roman; "
        Me.Label45.Text = "(see notes overleaf )"
        Me.Label45.Top = 4.6875!
        Me.Label45.Width = 0.5625!
        '
        'Label47
        '
        Me.Label47.Border.BottomColor = System.Drawing.Color.Black
        Me.Label47.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label47.Border.LeftColor = System.Drawing.Color.Black
        Me.Label47.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label47.Border.RightColor = System.Drawing.Color.Black
        Me.Label47.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label47.Border.TopColor = System.Drawing.Color.Black
        Me.Label47.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label47.Height = 0.4375!
        Me.Label47.HyperLink = Nothing
        Me.Label47.Left = 6.1875!
        Me.Label47.Name = "Label47"
        Me.Label47.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label47.Text = "9. Gross weight or other quantity"
        Me.Label47.Top = 4.375!
        Me.Label47.Width = 0.875!
        '
        'Label48
        '
        Me.Label48.Border.BottomColor = System.Drawing.Color.Black
        Me.Label48.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label48.Border.LeftColor = System.Drawing.Color.Black
        Me.Label48.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label48.Border.RightColor = System.Drawing.Color.Black
        Me.Label48.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label48.Border.TopColor = System.Drawing.Color.Black
        Me.Label48.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label48.Height = 0.4375!
        Me.Label48.HyperLink = Nothing
        Me.Label48.Left = 7.1875!
        Me.Label48.Name = "Label48"
        Me.Label48.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label48.Text = "10. Number and date of invoices"
        Me.Label48.Top = 4.375!
        Me.Label48.Width = 0.8125!
        '
        'Label6
        '
        Me.Label6.Border.BottomColor = System.Drawing.Color.Black
        Me.Label6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.LeftColor = System.Drawing.Color.Black
        Me.Label6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.RightColor = System.Drawing.Color.Black
        Me.Label6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Border.TopColor = System.Drawing.Color.Black
        Me.Label6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label6.Height = 0.1875!
        Me.Label6.HyperLink = Nothing
        Me.Label6.Left = 4.5!
        Me.Label6.Name = "Label6"
        Me.Label6.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label6.Text = "4. For Official Use"
        Me.Label6.Top = 2.3125!
        Me.Label6.Width = 2.5625!
        '
        'Label19
        '
        Me.Label19.Border.BottomColor = System.Drawing.Color.Black
        Me.Label19.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.LeftColor = System.Drawing.Color.Black
        Me.Label19.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.RightColor = System.Drawing.Color.Black
        Me.Label19.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Border.TopColor = System.Drawing.Color.Black
        Me.Label19.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label19.Height = 0.1875!
        Me.Label19.HyperLink = Nothing
        Me.Label19.Left = 6.1875!
        Me.Label19.Name = "Label19"
        Me.Label19.Style = "text-align: right; font-size: 9pt; font-family: Times New Roman; "
        Me.Label19.Text = "See notes overleaf"
        Me.Label19.Top = 1.9375!
        Me.Label19.Width = 1.625!
        '
        'Line19
        '
        Me.Line19.Border.BottomColor = System.Drawing.Color.Black
        Me.Line19.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.LeftColor = System.Drawing.Color.Black
        Me.Line19.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.RightColor = System.Drawing.Color.Black
        Me.Line19.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Border.TopColor = System.Drawing.Color.Black
        Me.Line19.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line19.Height = 0!
        Me.Line19.Left = 5.375!
        Me.Line19.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line19.LineWeight = 1.0!
        Me.Line19.Name = "Line19"
        Me.Line19.Top = 1.75!
        Me.Line19.Width = 2.4375!
        Me.Line19.X1 = 5.375!
        Me.Line19.X2 = 7.8125!
        Me.Line19.Y1 = 1.75!
        Me.Line19.Y2 = 1.75!
        '
        'Label17
        '
        Me.Label17.Border.BottomColor = System.Drawing.Color.Black
        Me.Label17.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.LeftColor = System.Drawing.Color.Black
        Me.Label17.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.RightColor = System.Drawing.Color.Black
        Me.Label17.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Border.TopColor = System.Drawing.Color.Black
        Me.Label17.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label17.Height = 0.1875!
        Me.Label17.HyperLink = Nothing
        Me.Label17.Left = 4.875!
        Me.Label17.Name = "Label17"
        Me.Label17.Style = "text-align: left; font-size: 9pt; font-family: Times New Roman; "
        Me.Label17.Text = "Issued in"
        Me.Label17.Top = 1.625!
        Me.Label17.Width = 0.5625!
        '
        'Label4
        '
        Me.Label4.Border.BottomColor = System.Drawing.Color.Black
        Me.Label4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.LeftColor = System.Drawing.Color.Black
        Me.Label4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.RightColor = System.Drawing.Color.Black
        Me.Label4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Border.TopColor = System.Drawing.Color.Black
        Me.Label4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label4.Height = 0.1875!
        Me.Label4.HyperLink = Nothing
        Me.Label4.Left = 5.8125!
        Me.Label4.Name = "Label4"
        Me.Label4.Style = "text-align: center; font-size: 9pt; font-family: Times New Roman; "
        Me.Label4.Text = "(country)"
        Me.Label4.Top = 1.75!
        Me.Label4.Width = 1.125!
        '
        'Label21
        '
        Me.Label21.Border.BottomColor = System.Drawing.Color.Black
        Me.Label21.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.LeftColor = System.Drawing.Color.Black
        Me.Label21.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.RightColor = System.Drawing.Color.Black
        Me.Label21.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Border.TopColor = System.Drawing.Color.Black
        Me.Label21.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label21.Height = 0.25!
        Me.Label21.HyperLink = Nothing
        Me.Label21.Left = 5.6875!
        Me.Label21.Name = "Label21"
        Me.Label21.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 12pt; font-fam" &
    "ily: Times New Roman; "
        Me.Label21.Text = "THAILAND"
        Me.Label21.Top = 1.5!
        Me.Label21.Width = 1.3125!
        '
        'Label22
        '
        Me.Label22.Border.BottomColor = System.Drawing.Color.Black
        Me.Label22.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.LeftColor = System.Drawing.Color.Black
        Me.Label22.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.RightColor = System.Drawing.Color.Black
        Me.Label22.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Border.TopColor = System.Drawing.Color.Black
        Me.Label22.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label22.Height = 0.25!
        Me.Label22.HyperLink = Nothing
        Me.Label22.Left = 5.6875!
        Me.Label22.Name = "Label22"
        Me.Label22.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 11.25pt; font-" &
    "family: Times New Roman; "
        Me.Label22.Text = "FORM A"
        Me.Label22.Top = 1.3125!
        Me.Label22.Width = 0.8125!
        '
        'Label20
        '
        Me.Label20.Border.BottomColor = System.Drawing.Color.Black
        Me.Label20.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label20.Border.LeftColor = System.Drawing.Color.Black
        Me.Label20.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label20.Border.RightColor = System.Drawing.Color.Black
        Me.Label20.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label20.Border.TopColor = System.Drawing.Color.Black
        Me.Label20.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label20.Height = 0.25!
        Me.Label20.HyperLink = Nothing
        Me.Label20.Left = 4.5!
        Me.Label20.Name = "Label20"
        Me.Label20.Style = "ddo-char-set: 0; text-align: center; font-size: 11.25pt; font-family: Times New R" &
    "oman; "
        Me.Label20.Text = "(Combined Declaration and Certificate)"
        Me.Label20.Top = 1.0625!
        Me.Label20.Width = 3.4375!
        '
        'Label16
        '
        Me.Label16.Border.BottomColor = System.Drawing.Color.Black
        Me.Label16.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.LeftColor = System.Drawing.Color.Black
        Me.Label16.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.RightColor = System.Drawing.Color.Black
        Me.Label16.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Border.TopColor = System.Drawing.Color.Black
        Me.Label16.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label16.Height = 0.1875!
        Me.Label16.HyperLink = Nothing
        Me.Label16.Left = 4.375!
        Me.Label16.Name = "Label16"
        Me.Label16.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 12pt; font-fam" &
    "ily: Times New Roman; "
        Me.Label16.Text = "CERTIFICATE OF ORIGIN"
        Me.Label16.Top = 0.8125!
        Me.Label16.Width = 3.6875!
        '
        'Label2
        '
        Me.Label2.Border.BottomColor = System.Drawing.Color.Black
        Me.Label2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.LeftColor = System.Drawing.Color.Black
        Me.Label2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.RightColor = System.Drawing.Color.Black
        Me.Label2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Border.TopColor = System.Drawing.Color.Black
        Me.Label2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label2.Height = 0.1875!
        Me.Label2.HyperLink = Nothing
        Me.Label2.Left = 4.375!
        Me.Label2.Name = "Label2"
        Me.Label2.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 9.75pt; font-f" &
    "amily: Times New Roman; "
        Me.Label2.Text = "GENERALIZED SYSTEM OF PREFERENCES"
        Me.Label2.Top = 0.5625!
        Me.Label2.Width = 3.6875!
        '
        'Label7
        '
        Me.Label7.Border.BottomColor = System.Drawing.Color.Black
        Me.Label7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.LeftColor = System.Drawing.Color.Black
        Me.Label7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.RightColor = System.Drawing.Color.Black
        Me.Label7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Border.TopColor = System.Drawing.Color.Black
        Me.Label7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label7.Height = 0.25!
        Me.Label7.HyperLink = Nothing
        Me.Label7.Left = 4.5!
        Me.Label7.Name = "Label7"
        Me.Label7.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label7.Text = "Reference No."
        Me.Label7.Top = 0.25!
        Me.Label7.Width = 0.875!
        '
        'Line8
        '
        Me.Line8.Border.BottomColor = System.Drawing.Color.Black
        Me.Line8.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.LeftColor = System.Drawing.Color.Black
        Me.Line8.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.RightColor = System.Drawing.Color.Black
        Me.Line8.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Border.TopColor = System.Drawing.Color.Black
        Me.Line8.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line8.Height = 4.9375!
        Me.Line8.Left = 0.0625!
        Me.Line8.LineWeight = 1.0!
        Me.Line8.Name = "Line8"
        Me.Line8.Top = 0.0625!
        Me.Line8.Width = 0!
        Me.Line8.X1 = 0.0625!
        Me.Line8.X2 = 0.0625!
        Me.Line8.Y1 = 5.0!
        Me.Line8.Y2 = 0.0625!
        '
        'Line9
        '
        Me.Line9.Border.BottomColor = System.Drawing.Color.Black
        Me.Line9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.LeftColor = System.Drawing.Color.Black
        Me.Line9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.RightColor = System.Drawing.Color.Black
        Me.Line9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Border.TopColor = System.Drawing.Color.Black
        Me.Line9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line9.Height = 0!
        Me.Line9.Left = 0.0625!
        Me.Line9.LineWeight = 1.0!
        Me.Line9.Name = "Line9"
        Me.Line9.Top = 0.0625!
        Me.Line9.Width = 8.125!
        Me.Line9.X1 = 0.0625!
        Me.Line9.X2 = 8.1875!
        Me.Line9.Y1 = 0.0625!
        Me.Line9.Y2 = 0.0625!
        '
        'Line10
        '
        Me.Line10.Border.BottomColor = System.Drawing.Color.Black
        Me.Line10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.LeftColor = System.Drawing.Color.Black
        Me.Line10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.RightColor = System.Drawing.Color.Black
        Me.Line10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Border.TopColor = System.Drawing.Color.Black
        Me.Line10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line10.Height = 0!
        Me.Line10.Left = 0.0625!
        Me.Line10.LineWeight = 1.0!
        Me.Line10.Name = "Line10"
        Me.Line10.Top = 1.25!
        Me.Line10.Width = 4.25!
        Me.Line10.X1 = 0.0625!
        Me.Line10.X2 = 4.3125!
        Me.Line10.Y1 = 1.25!
        Me.Line10.Y2 = 1.25!
        '
        'Line11
        '
        Me.Line11.Border.BottomColor = System.Drawing.Color.Black
        Me.Line11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.LeftColor = System.Drawing.Color.Black
        Me.Line11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.RightColor = System.Drawing.Color.Black
        Me.Line11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Border.TopColor = System.Drawing.Color.Black
        Me.Line11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line11.Height = 4.1875!
        Me.Line11.Left = 4.3125!
        Me.Line11.LineWeight = 1.0!
        Me.Line11.Name = "Line11"
        Me.Line11.Top = 0.0625!
        Me.Line11.Width = 0!
        Me.Line11.X1 = 4.3125!
        Me.Line11.X2 = 4.3125!
        Me.Line11.Y1 = 4.25!
        Me.Line11.Y2 = 0.0625!
        '
        'Line12
        '
        Me.Line12.Border.BottomColor = System.Drawing.Color.Black
        Me.Line12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.LeftColor = System.Drawing.Color.Black
        Me.Line12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.RightColor = System.Drawing.Color.Black
        Me.Line12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Border.TopColor = System.Drawing.Color.Black
        Me.Line12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line12.Height = 4.9375!
        Me.Line12.Left = 0.0625!
        Me.Line12.LineWeight = 1.0!
        Me.Line12.Name = "Line12"
        Me.Line12.Top = 0.0625!
        Me.Line12.Width = 0!
        Me.Line12.X1 = 0.0625!
        Me.Line12.X2 = 0.0625!
        Me.Line12.Y1 = 5.0!
        Me.Line12.Y2 = 0.0625!
        '
        'Line14
        '
        Me.Line14.Border.BottomColor = System.Drawing.Color.Black
        Me.Line14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.LeftColor = System.Drawing.Color.Black
        Me.Line14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.RightColor = System.Drawing.Color.Black
        Me.Line14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Border.TopColor = System.Drawing.Color.Black
        Me.Line14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line14.Height = 0!
        Me.Line14.Left = 0.0625!
        Me.Line14.LineWeight = 1.0!
        Me.Line14.Name = "Line14"
        Me.Line14.Top = 0.0625!
        Me.Line14.Width = 8.125!
        Me.Line14.X1 = 0.0625!
        Me.Line14.X2 = 8.1875!
        Me.Line14.Y1 = 0.0625!
        Me.Line14.Y2 = 0.0625!
        '
        'Line24
        '
        Me.Line24.Border.BottomColor = System.Drawing.Color.Black
        Me.Line24.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line24.Border.LeftColor = System.Drawing.Color.Black
        Me.Line24.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line24.Border.RightColor = System.Drawing.Color.Black
        Me.Line24.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line24.Border.TopColor = System.Drawing.Color.Black
        Me.Line24.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line24.Height = 0!
        Me.Line24.Left = 0.0625!
        Me.Line24.LineWeight = 1.0!
        Me.Line24.Name = "Line24"
        Me.Line24.Top = 1.25!
        Me.Line24.Width = 4.25!
        Me.Line24.X1 = 0.0625!
        Me.Line24.X2 = 4.3125!
        Me.Line24.Y1 = 1.25!
        Me.Line24.Y2 = 1.25!
        '
        'Line25
        '
        Me.Line25.Border.BottomColor = System.Drawing.Color.Black
        Me.Line25.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.LeftColor = System.Drawing.Color.Black
        Me.Line25.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.RightColor = System.Drawing.Color.Black
        Me.Line25.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Border.TopColor = System.Drawing.Color.Black
        Me.Line25.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line25.Height = 4.1875!
        Me.Line25.Left = 4.3125!
        Me.Line25.LineWeight = 1.0!
        Me.Line25.Name = "Line25"
        Me.Line25.Top = 0.0625!
        Me.Line25.Width = 0!
        Me.Line25.X1 = 4.3125!
        Me.Line25.X2 = 4.3125!
        Me.Line25.Y1 = 4.25!
        Me.Line25.Y2 = 0.0625!
        '
        'Label23
        '
        Me.Label23.Border.BottomColor = System.Drawing.Color.Black
        Me.Label23.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.LeftColor = System.Drawing.Color.Black
        Me.Label23.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.RightColor = System.Drawing.Color.Black
        Me.Label23.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Border.TopColor = System.Drawing.Color.Black
        Me.Label23.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label23.Height = 0.1875!
        Me.Label23.HyperLink = Nothing
        Me.Label23.Left = 4.5!
        Me.Label23.Name = "Label23"
        Me.Label23.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label23.Text = "4. For Official Use"
        Me.Label23.Top = 2.3125!
        Me.Label23.Width = 2.5625!
        '
        'Line26
        '
        Me.Line26.Border.BottomColor = System.Drawing.Color.Black
        Me.Line26.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.LeftColor = System.Drawing.Color.Black
        Me.Line26.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.RightColor = System.Drawing.Color.Black
        Me.Line26.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Border.TopColor = System.Drawing.Color.Black
        Me.Line26.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line26.Height = 4.9375!
        Me.Line26.Left = 8.1875!
        Me.Line26.LineWeight = 1.0!
        Me.Line26.Name = "Line26"
        Me.Line26.Top = 0.0625!
        Me.Line26.Width = 0!
        Me.Line26.X1 = 8.1875!
        Me.Line26.X2 = 8.1875!
        Me.Line26.Y1 = 0.0625!
        Me.Line26.Y2 = 5.0!
        '
        'Line27
        '
        Me.Line27.Border.BottomColor = System.Drawing.Color.Black
        Me.Line27.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line27.Border.LeftColor = System.Drawing.Color.Black
        Me.Line27.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line27.Border.RightColor = System.Drawing.Color.Black
        Me.Line27.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line27.Border.TopColor = System.Drawing.Color.Black
        Me.Line27.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line27.Height = 0!
        Me.Line27.Left = 0.0625!
        Me.Line27.LineWeight = 1.0!
        Me.Line27.Name = "Line27"
        Me.Line27.Top = 0.0625!
        Me.Line27.Width = 8.125!
        Me.Line27.X1 = 0.0625!
        Me.Line27.X2 = 8.1875!
        Me.Line27.Y1 = 0.0625!
        Me.Line27.Y2 = 0.0625!
        '
        'Line28
        '
        Me.Line28.Border.BottomColor = System.Drawing.Color.Black
        Me.Line28.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line28.Border.LeftColor = System.Drawing.Color.Black
        Me.Line28.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line28.Border.RightColor = System.Drawing.Color.Black
        Me.Line28.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line28.Border.TopColor = System.Drawing.Color.Black
        Me.Line28.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line28.Height = 4.1875!
        Me.Line28.Left = 4.3125!
        Me.Line28.LineWeight = 1.0!
        Me.Line28.Name = "Line28"
        Me.Line28.Top = 0.0625!
        Me.Line28.Width = 0!
        Me.Line28.X1 = 4.3125!
        Me.Line28.X2 = 4.3125!
        Me.Line28.Y1 = 4.25!
        Me.Line28.Y2 = 0.0625!
        '
        'Line29
        '
        Me.Line29.Border.BottomColor = System.Drawing.Color.Black
        Me.Line29.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line29.Border.LeftColor = System.Drawing.Color.Black
        Me.Line29.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line29.Border.RightColor = System.Drawing.Color.Black
        Me.Line29.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line29.Border.TopColor = System.Drawing.Color.Black
        Me.Line29.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line29.Height = 0!
        Me.Line29.Left = 0.0625!
        Me.Line29.LineWeight = 1.0!
        Me.Line29.Name = "Line29"
        Me.Line29.Top = 2.25!
        Me.Line29.Width = 8.125!
        Me.Line29.X1 = 0.0625!
        Me.Line29.X2 = 8.1875!
        Me.Line29.Y1 = 2.25!
        Me.Line29.Y2 = 2.25!
        '
        'Line30
        '
        Me.Line30.Border.BottomColor = System.Drawing.Color.Black
        Me.Line30.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line30.Border.LeftColor = System.Drawing.Color.Black
        Me.Line30.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line30.Border.RightColor = System.Drawing.Color.Black
        Me.Line30.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line30.Border.TopColor = System.Drawing.Color.Black
        Me.Line30.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line30.Height = 0!
        Me.Line30.Left = 0.0625!
        Me.Line30.LineWeight = 1.0!
        Me.Line30.Name = "Line30"
        Me.Line30.Top = 4.25!
        Me.Line30.Width = 8.125!
        Me.Line30.X1 = 0.0625!
        Me.Line30.X2 = 8.1875!
        Me.Line30.Y1 = 4.25!
        Me.Line30.Y2 = 4.25!
        '
        'Label24
        '
        Me.Label24.Border.BottomColor = System.Drawing.Color.Black
        Me.Label24.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.LeftColor = System.Drawing.Color.Black
        Me.Label24.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.RightColor = System.Drawing.Color.Black
        Me.Label24.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Border.TopColor = System.Drawing.Color.Black
        Me.Label24.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label24.Height = 0.4375!
        Me.Label24.HyperLink = Nothing
        Me.Label24.Left = 7.1875!
        Me.Label24.Name = "Label24"
        Me.Label24.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label24.Text = "10. Number and date of invoices"
        Me.Label24.Top = 4.375!
        Me.Label24.Width = 0.8125!
        '
        'Line31
        '
        Me.Line31.Border.BottomColor = System.Drawing.Color.Black
        Me.Line31.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line31.Border.LeftColor = System.Drawing.Color.Black
        Me.Line31.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line31.Border.RightColor = System.Drawing.Color.Black
        Me.Line31.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line31.Border.TopColor = System.Drawing.Color.Black
        Me.Line31.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line31.Height = 4.9375!
        Me.Line31.Left = 8.1875!
        Me.Line31.LineWeight = 1.0!
        Me.Line31.Name = "Line31"
        Me.Line31.Top = 0.0625!
        Me.Line31.Width = 0!
        Me.Line31.X1 = 8.1875!
        Me.Line31.X2 = 8.1875!
        Me.Line31.Y1 = 0.0625!
        Me.Line31.Y2 = 5.0!
        '
        'Line32
        '
        Me.Line32.Border.BottomColor = System.Drawing.Color.Black
        Me.Line32.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line32.Border.LeftColor = System.Drawing.Color.Black
        Me.Line32.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line32.Border.RightColor = System.Drawing.Color.Black
        Me.Line32.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line32.Border.TopColor = System.Drawing.Color.Black
        Me.Line32.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line32.Height = 0!
        Me.Line32.Left = 0.0625!
        Me.Line32.LineWeight = 1.0!
        Me.Line32.Name = "Line32"
        Me.Line32.Top = 0.0625!
        Me.Line32.Width = 8.125!
        Me.Line32.X1 = 0.0625!
        Me.Line32.X2 = 8.1875!
        Me.Line32.Y1 = 0.0625!
        Me.Line32.Y2 = 0.0625!
        '
        'Line33
        '
        Me.Line33.Border.BottomColor = System.Drawing.Color.Black
        Me.Line33.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line33.Border.LeftColor = System.Drawing.Color.Black
        Me.Line33.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line33.Border.RightColor = System.Drawing.Color.Black
        Me.Line33.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line33.Border.TopColor = System.Drawing.Color.Black
        Me.Line33.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line33.Height = 4.1875!
        Me.Line33.Left = 4.3125!
        Me.Line33.LineWeight = 1.0!
        Me.Line33.Name = "Line33"
        Me.Line33.Top = 0.0625!
        Me.Line33.Width = 0!
        Me.Line33.X1 = 4.3125!
        Me.Line33.X2 = 4.3125!
        Me.Line33.Y1 = 4.25!
        Me.Line33.Y2 = 0.0625!
        '
        'Line34
        '
        Me.Line34.Border.BottomColor = System.Drawing.Color.Black
        Me.Line34.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line34.Border.LeftColor = System.Drawing.Color.Black
        Me.Line34.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line34.Border.RightColor = System.Drawing.Color.Black
        Me.Line34.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line34.Border.TopColor = System.Drawing.Color.Black
        Me.Line34.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line34.Height = 0!
        Me.Line34.Left = 0.0625!
        Me.Line34.LineWeight = 1.0!
        Me.Line34.Name = "Line34"
        Me.Line34.Top = 2.25!
        Me.Line34.Width = 8.125!
        Me.Line34.X1 = 0.0625!
        Me.Line34.X2 = 8.1875!
        Me.Line34.Y1 = 2.25!
        Me.Line34.Y2 = 2.25!
        '
        'Line35
        '
        Me.Line35.Border.BottomColor = System.Drawing.Color.Black
        Me.Line35.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line35.Border.LeftColor = System.Drawing.Color.Black
        Me.Line35.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line35.Border.RightColor = System.Drawing.Color.Black
        Me.Line35.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line35.Border.TopColor = System.Drawing.Color.Black
        Me.Line35.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line35.Height = 0!
        Me.Line35.Left = 0.0625!
        Me.Line35.LineWeight = 1.0!
        Me.Line35.Name = "Line35"
        Me.Line35.Top = 4.25!
        Me.Line35.Width = 8.125!
        Me.Line35.X1 = 0.0625!
        Me.Line35.X2 = 8.1875!
        Me.Line35.Y1 = 4.25!
        Me.Line35.Y2 = 4.25!
        '
        'Label26
        '
        Me.Label26.Border.BottomColor = System.Drawing.Color.Black
        Me.Label26.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.LeftColor = System.Drawing.Color.Black
        Me.Label26.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.RightColor = System.Drawing.Color.Black
        Me.Label26.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Border.TopColor = System.Drawing.Color.Black
        Me.Label26.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label26.Height = 0.4375!
        Me.Label26.HyperLink = Nothing
        Me.Label26.Left = 7.1875!
        Me.Label26.Name = "Label26"
        Me.Label26.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label26.Text = "10. Number and date of invoices"
        Me.Label26.Top = 4.375!
        Me.Label26.Width = 0.8125!
        '
        'Label27
        '
        Me.Label27.Border.BottomColor = System.Drawing.Color.Black
        Me.Label27.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label27.Border.LeftColor = System.Drawing.Color.Black
        Me.Label27.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label27.Border.RightColor = System.Drawing.Color.Black
        Me.Label27.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label27.Border.TopColor = System.Drawing.Color.Black
        Me.Label27.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label27.Height = 0.4375!
        Me.Label27.HyperLink = Nothing
        Me.Label27.Left = 6.1875!
        Me.Label27.Name = "Label27"
        Me.Label27.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label27.Text = "9. Gross weight or other quantity"
        Me.Label27.Top = 4.375!
        Me.Label27.Width = 0.875!
        '
        'Label28
        '
        Me.Label28.Border.BottomColor = System.Drawing.Color.Black
        Me.Label28.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.LeftColor = System.Drawing.Color.Black
        Me.Label28.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.RightColor = System.Drawing.Color.Black
        Me.Label28.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Border.TopColor = System.Drawing.Color.Black
        Me.Label28.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label28.Height = 0.3125!
        Me.Label28.HyperLink = Nothing
        Me.Label28.Left = 5.3125!
        Me.Label28.Name = "Label28"
        Me.Label28.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label28.Text = "8. Origin criterion"
        Me.Label28.Top = 4.375!
        Me.Label28.Width = 0.5625!
        '
        'Line36
        '
        Me.Line36.Border.BottomColor = System.Drawing.Color.Black
        Me.Line36.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line36.Border.LeftColor = System.Drawing.Color.Black
        Me.Line36.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line36.Border.RightColor = System.Drawing.Color.Black
        Me.Line36.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line36.Border.TopColor = System.Drawing.Color.Black
        Me.Line36.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line36.Height = 4.9375!
        Me.Line36.Left = 8.1875!
        Me.Line36.LineWeight = 1.0!
        Me.Line36.Name = "Line36"
        Me.Line36.Top = 0.0625!
        Me.Line36.Width = 0!
        Me.Line36.X1 = 8.1875!
        Me.Line36.X2 = 8.1875!
        Me.Line36.Y1 = 0.0625!
        Me.Line36.Y2 = 5.0!
        '
        'Line37
        '
        Me.Line37.Border.BottomColor = System.Drawing.Color.Black
        Me.Line37.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line37.Border.LeftColor = System.Drawing.Color.Black
        Me.Line37.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line37.Border.RightColor = System.Drawing.Color.Black
        Me.Line37.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line37.Border.TopColor = System.Drawing.Color.Black
        Me.Line37.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line37.Height = 0!
        Me.Line37.Left = 0.0625!
        Me.Line37.LineWeight = 1.0!
        Me.Line37.Name = "Line37"
        Me.Line37.Top = 0.0625!
        Me.Line37.Width = 8.125!
        Me.Line37.X1 = 0.0625!
        Me.Line37.X2 = 8.1875!
        Me.Line37.Y1 = 0.0625!
        Me.Line37.Y2 = 0.0625!
        '
        'Line38
        '
        Me.Line38.Border.BottomColor = System.Drawing.Color.Black
        Me.Line38.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line38.Border.LeftColor = System.Drawing.Color.Black
        Me.Line38.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line38.Border.RightColor = System.Drawing.Color.Black
        Me.Line38.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line38.Border.TopColor = System.Drawing.Color.Black
        Me.Line38.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line38.Height = 4.1875!
        Me.Line38.Left = 4.3125!
        Me.Line38.LineWeight = 1.0!
        Me.Line38.Name = "Line38"
        Me.Line38.Top = 0.0625!
        Me.Line38.Width = 0!
        Me.Line38.X1 = 4.3125!
        Me.Line38.X2 = 4.3125!
        Me.Line38.Y1 = 4.25!
        Me.Line38.Y2 = 0.0625!
        '
        'Line39
        '
        Me.Line39.Border.BottomColor = System.Drawing.Color.Black
        Me.Line39.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line39.Border.LeftColor = System.Drawing.Color.Black
        Me.Line39.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line39.Border.RightColor = System.Drawing.Color.Black
        Me.Line39.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line39.Border.TopColor = System.Drawing.Color.Black
        Me.Line39.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line39.Height = 0!
        Me.Line39.Left = 0.0625!
        Me.Line39.LineWeight = 1.0!
        Me.Line39.Name = "Line39"
        Me.Line39.Top = 2.25!
        Me.Line39.Width = 8.125!
        Me.Line39.X1 = 0.0625!
        Me.Line39.X2 = 8.1875!
        Me.Line39.Y1 = 2.25!
        Me.Line39.Y2 = 2.25!
        '
        'Line40
        '
        Me.Line40.Border.BottomColor = System.Drawing.Color.Black
        Me.Line40.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line40.Border.LeftColor = System.Drawing.Color.Black
        Me.Line40.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line40.Border.RightColor = System.Drawing.Color.Black
        Me.Line40.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line40.Border.TopColor = System.Drawing.Color.Black
        Me.Line40.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line40.Height = 0!
        Me.Line40.Left = 0.0625!
        Me.Line40.LineWeight = 1.0!
        Me.Line40.Name = "Line40"
        Me.Line40.Top = 4.25!
        Me.Line40.Width = 8.125!
        Me.Line40.X1 = 0.0625!
        Me.Line40.X2 = 8.1875!
        Me.Line40.Y1 = 4.25!
        Me.Line40.Y2 = 4.25!
        '
        'Label29
        '
        Me.Label29.Border.BottomColor = System.Drawing.Color.Black
        Me.Label29.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.LeftColor = System.Drawing.Color.Black
        Me.Label29.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.RightColor = System.Drawing.Color.Black
        Me.Label29.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Border.TopColor = System.Drawing.Color.Black
        Me.Label29.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label29.Height = 0.4375!
        Me.Label29.HyperLink = Nothing
        Me.Label29.Left = 7.1875!
        Me.Label29.Name = "Label29"
        Me.Label29.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label29.Text = "10. Number and date of invoices"
        Me.Label29.Top = 4.375!
        Me.Label29.Width = 0.8125!
        '
        'Label30
        '
        Me.Label30.Border.BottomColor = System.Drawing.Color.Black
        Me.Label30.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.LeftColor = System.Drawing.Color.Black
        Me.Label30.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.RightColor = System.Drawing.Color.Black
        Me.Label30.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Border.TopColor = System.Drawing.Color.Black
        Me.Label30.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label30.Height = 0.4375!
        Me.Label30.HyperLink = Nothing
        Me.Label30.Left = 6.1875!
        Me.Label30.Name = "Label30"
        Me.Label30.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label30.Text = "9. Gross weight or other quantity"
        Me.Label30.Top = 4.375!
        Me.Label30.Width = 0.875!
        '
        'Label31
        '
        Me.Label31.Border.BottomColor = System.Drawing.Color.Black
        Me.Label31.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.LeftColor = System.Drawing.Color.Black
        Me.Label31.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.RightColor = System.Drawing.Color.Black
        Me.Label31.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Border.TopColor = System.Drawing.Color.Black
        Me.Label31.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label31.Height = 0.3125!
        Me.Label31.HyperLink = Nothing
        Me.Label31.Left = 5.3125!
        Me.Label31.Name = "Label31"
        Me.Label31.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label31.Text = "8. Origin criterion"
        Me.Label31.Top = 4.375!
        Me.Label31.Width = 0.5625!
        '
        'Label32
        '
        Me.Label32.Border.BottomColor = System.Drawing.Color.Black
        Me.Label32.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label32.Border.LeftColor = System.Drawing.Color.Black
        Me.Label32.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label32.Border.RightColor = System.Drawing.Color.Black
        Me.Label32.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label32.Border.TopColor = System.Drawing.Color.Black
        Me.Label32.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label32.Height = 0.25!
        Me.Label32.HyperLink = Nothing
        Me.Label32.Left = 5.3125!
        Me.Label32.Name = "Label32"
        Me.Label32.Style = "ddo-char-set: 0; font-size: 6pt; font-family: Times New Roman; "
        Me.Label32.Text = "(see notes overleaf )"
        Me.Label32.Top = 4.6875!
        Me.Label32.Width = 0.5625!
        '
        'Label33
        '
        Me.Label33.Border.BottomColor = System.Drawing.Color.Black
        Me.Label33.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.LeftColor = System.Drawing.Color.Black
        Me.Label33.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.RightColor = System.Drawing.Color.Black
        Me.Label33.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Border.TopColor = System.Drawing.Color.Black
        Me.Label33.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label33.Height = 0.1875!
        Me.Label33.HyperLink = Nothing
        Me.Label33.Left = 2.1875!
        Me.Label33.Name = "Label33"
        Me.Label33.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label33.Text = "7. Number and kind of packages; description of goods"
        Me.Label33.Top = 4.375!
        Me.Label33.Width = 2.8125!
        '
        'Label34
        '
        Me.Label34.Border.BottomColor = System.Drawing.Color.Black
        Me.Label34.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label34.Border.LeftColor = System.Drawing.Color.Black
        Me.Label34.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label34.Border.RightColor = System.Drawing.Color.Black
        Me.Label34.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label34.Border.TopColor = System.Drawing.Color.Black
        Me.Label34.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label34.Height = 0.4375!
        Me.Label34.HyperLink = Nothing
        Me.Label34.Left = 1.0625!
        Me.Label34.Name = "Label34"
        Me.Label34.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label34.Text = "6. Marks and    numbers on packages "
        Me.Label34.Top = 4.375!
        Me.Label34.Width = 0.875!
        '
        'Label35
        '
        Me.Label35.Border.BottomColor = System.Drawing.Color.Black
        Me.Label35.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label35.Border.LeftColor = System.Drawing.Color.Black
        Me.Label35.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label35.Border.RightColor = System.Drawing.Color.Black
        Me.Label35.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label35.Border.TopColor = System.Drawing.Color.Black
        Me.Label35.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label35.Height = 0.3125!
        Me.Label35.HyperLink = Nothing
        Me.Label35.Left = 0.1875!
        Me.Label35.Name = "Label35"
        Me.Label35.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label35.Text = "5. Item number"
        Me.Label35.Top = 4.375!
        Me.Label35.Width = 0.5625!
        '
        'Line41
        '
        Me.Line41.Border.BottomColor = System.Drawing.Color.Black
        Me.Line41.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line41.Border.LeftColor = System.Drawing.Color.Black
        Me.Line41.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line41.Border.RightColor = System.Drawing.Color.Black
        Me.Line41.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line41.Border.TopColor = System.Drawing.Color.Black
        Me.Line41.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line41.Height = 4.9375!
        Me.Line41.Left = 0.0625!
        Me.Line41.LineWeight = 1.0!
        Me.Line41.Name = "Line41"
        Me.Line41.Top = 0.0625!
        Me.Line41.Width = 0!
        Me.Line41.X1 = 0.0625!
        Me.Line41.X2 = 0.0625!
        Me.Line41.Y1 = 5.0!
        Me.Line41.Y2 = 0.0625!
        '
        'Label36
        '
        Me.Label36.Border.BottomColor = System.Drawing.Color.Black
        Me.Label36.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label36.Border.LeftColor = System.Drawing.Color.Black
        Me.Label36.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label36.Border.RightColor = System.Drawing.Color.Black
        Me.Label36.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label36.Border.TopColor = System.Drawing.Color.Black
        Me.Label36.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label36.Height = 0.1875!
        Me.Label36.HyperLink = Nothing
        Me.Label36.Left = 0.25!
        Me.Label36.Name = "Label36"
        Me.Label36.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label36.Text = "3. Means of transport and route (as far as known)"
        Me.Label36.Top = 2.3125!
        Me.Label36.Width = 3.875!
        '
        'Label37
        '
        Me.Label37.Border.BottomColor = System.Drawing.Color.Black
        Me.Label37.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label37.Border.LeftColor = System.Drawing.Color.Black
        Me.Label37.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label37.Border.RightColor = System.Drawing.Color.Black
        Me.Label37.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label37.Border.TopColor = System.Drawing.Color.Black
        Me.Label37.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label37.Height = 0.1875!
        Me.Label37.HyperLink = Nothing
        Me.Label37.Left = 0.25!
        Me.Label37.Name = "Label37"
        Me.Label37.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label37.Text = "2. Goods consigned to (Consignee's name, address, country)"
        Me.Label37.Top = 1.3125!
        Me.Label37.Width = 4.0!
        '
        'Line42
        '
        Me.Line42.Border.BottomColor = System.Drawing.Color.Black
        Me.Line42.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line42.Border.LeftColor = System.Drawing.Color.Black
        Me.Line42.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line42.Border.RightColor = System.Drawing.Color.Black
        Me.Line42.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line42.Border.TopColor = System.Drawing.Color.Black
        Me.Line42.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line42.Height = 0!
        Me.Line42.Left = 0.0625!
        Me.Line42.LineWeight = 1.0!
        Me.Line42.Name = "Line42"
        Me.Line42.Top = 1.25!
        Me.Line42.Width = 4.25!
        Me.Line42.X1 = 0.0625!
        Me.Line42.X2 = 4.3125!
        Me.Line42.Y1 = 1.25!
        Me.Line42.Y2 = 1.25!
        '
        'Label38
        '
        Me.Label38.Border.BottomColor = System.Drawing.Color.Black
        Me.Label38.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label38.Border.LeftColor = System.Drawing.Color.Black
        Me.Label38.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label38.Border.RightColor = System.Drawing.Color.Black
        Me.Label38.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label38.Border.TopColor = System.Drawing.Color.Black
        Me.Label38.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label38.Height = 0.1875!
        Me.Label38.HyperLink = Nothing
        Me.Label38.Left = 0.25!
        Me.Label38.Name = "Label38"
        Me.Label38.Style = "font-size: 9pt; font-family: Times New Roman; "
        Me.Label38.Text = "1. Goods consigned from (Exporter's business name, address, country)"
        Me.Label38.Top = 0.25!
        Me.Label38.Width = 4.0!
        '
        'Label39
        '
        Me.Label39.Border.BottomColor = System.Drawing.Color.Black
        Me.Label39.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label39.Border.LeftColor = System.Drawing.Color.Black
        Me.Label39.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label39.Border.RightColor = System.Drawing.Color.Black
        Me.Label39.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label39.Border.TopColor = System.Drawing.Color.Black
        Me.Label39.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label39.Height = 0.25!
        Me.Label39.HyperLink = Nothing
        Me.Label39.Left = 4.5!
        Me.Label39.Name = "Label39"
        Me.Label39.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label39.Text = "Reference No."
        Me.Label39.Top = 0.25!
        Me.Label39.Width = 0.875!
        '
        'Label40
        '
        Me.Label40.Border.BottomColor = System.Drawing.Color.Black
        Me.Label40.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label40.Border.LeftColor = System.Drawing.Color.Black
        Me.Label40.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label40.Border.RightColor = System.Drawing.Color.Black
        Me.Label40.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label40.Border.TopColor = System.Drawing.Color.Black
        Me.Label40.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label40.Height = 0.1875!
        Me.Label40.HyperLink = Nothing
        Me.Label40.Left = 4.375!
        Me.Label40.Name = "Label40"
        Me.Label40.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 9.75pt; font-f" &
    "amily: Times New Roman; "
        Me.Label40.Text = "GENERALIZED SYSTEM OF PREFERENCES"
        Me.Label40.Top = 0.5625!
        Me.Label40.Width = 3.6875!
        '
        'Line43
        '
        Me.Line43.Border.BottomColor = System.Drawing.Color.Black
        Me.Line43.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line43.Border.LeftColor = System.Drawing.Color.Black
        Me.Line43.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line43.Border.RightColor = System.Drawing.Color.Black
        Me.Line43.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line43.Border.TopColor = System.Drawing.Color.Black
        Me.Line43.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line43.Height = 4.9375!
        Me.Line43.Left = 8.1875!
        Me.Line43.LineWeight = 1.0!
        Me.Line43.Name = "Line43"
        Me.Line43.Top = 0.0625!
        Me.Line43.Width = 0!
        Me.Line43.X1 = 8.1875!
        Me.Line43.X2 = 8.1875!
        Me.Line43.Y1 = 0.0625!
        Me.Line43.Y2 = 5.0!
        '
        'Line44
        '
        Me.Line44.Border.BottomColor = System.Drawing.Color.Black
        Me.Line44.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line44.Border.LeftColor = System.Drawing.Color.Black
        Me.Line44.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line44.Border.RightColor = System.Drawing.Color.Black
        Me.Line44.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line44.Border.TopColor = System.Drawing.Color.Black
        Me.Line44.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line44.Height = 0!
        Me.Line44.Left = 0.0625!
        Me.Line44.LineWeight = 1.0!
        Me.Line44.Name = "Line44"
        Me.Line44.Top = 0.0625!
        Me.Line44.Width = 8.125!
        Me.Line44.X1 = 0.0625!
        Me.Line44.X2 = 8.1875!
        Me.Line44.Y1 = 0.0625!
        Me.Line44.Y2 = 0.0625!
        '
        'Line45
        '
        Me.Line45.Border.BottomColor = System.Drawing.Color.Black
        Me.Line45.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line45.Border.LeftColor = System.Drawing.Color.Black
        Me.Line45.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line45.Border.RightColor = System.Drawing.Color.Black
        Me.Line45.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line45.Border.TopColor = System.Drawing.Color.Black
        Me.Line45.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line45.Height = 4.1875!
        Me.Line45.Left = 4.3125!
        Me.Line45.LineWeight = 1.0!
        Me.Line45.Name = "Line45"
        Me.Line45.Top = 0.0625!
        Me.Line45.Width = 0!
        Me.Line45.X1 = 4.3125!
        Me.Line45.X2 = 4.3125!
        Me.Line45.Y1 = 4.25!
        Me.Line45.Y2 = 0.0625!
        '
        'Line46
        '
        Me.Line46.Border.BottomColor = System.Drawing.Color.Black
        Me.Line46.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line46.Border.LeftColor = System.Drawing.Color.Black
        Me.Line46.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line46.Border.RightColor = System.Drawing.Color.Black
        Me.Line46.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line46.Border.TopColor = System.Drawing.Color.Black
        Me.Line46.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line46.Height = 0!
        Me.Line46.Left = 0.0625!
        Me.Line46.LineWeight = 1.0!
        Me.Line46.Name = "Line46"
        Me.Line46.Top = 2.25!
        Me.Line46.Width = 8.125!
        Me.Line46.X1 = 0.0625!
        Me.Line46.X2 = 8.1875!
        Me.Line46.Y1 = 2.25!
        Me.Line46.Y2 = 2.25!
        '
        'Line47
        '
        Me.Line47.Border.BottomColor = System.Drawing.Color.Black
        Me.Line47.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line47.Border.LeftColor = System.Drawing.Color.Black
        Me.Line47.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line47.Border.RightColor = System.Drawing.Color.Black
        Me.Line47.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line47.Border.TopColor = System.Drawing.Color.Black
        Me.Line47.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line47.Height = 0!
        Me.Line47.Left = 0.0625!
        Me.Line47.LineWeight = 1.0!
        Me.Line47.Name = "Line47"
        Me.Line47.Top = 4.25!
        Me.Line47.Width = 8.125!
        Me.Line47.X1 = 0.0625!
        Me.Line47.X2 = 8.1875!
        Me.Line47.Y1 = 4.25!
        Me.Line47.Y2 = 4.25!
        '
        'Label41
        '
        Me.Label41.Border.BottomColor = System.Drawing.Color.Black
        Me.Label41.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label41.Border.LeftColor = System.Drawing.Color.Black
        Me.Label41.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label41.Border.RightColor = System.Drawing.Color.Black
        Me.Label41.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label41.Border.TopColor = System.Drawing.Color.Black
        Me.Label41.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label41.Height = 0.4375!
        Me.Label41.HyperLink = Nothing
        Me.Label41.Left = 7.1875!
        Me.Label41.Name = "Label41"
        Me.Label41.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label41.Text = "10. Number and date of invoices"
        Me.Label41.Top = 4.375!
        Me.Label41.Width = 0.8125!
        '
        'Label49
        '
        Me.Label49.Border.BottomColor = System.Drawing.Color.Black
        Me.Label49.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label49.Border.LeftColor = System.Drawing.Color.Black
        Me.Label49.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label49.Border.RightColor = System.Drawing.Color.Black
        Me.Label49.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label49.Border.TopColor = System.Drawing.Color.Black
        Me.Label49.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label49.Height = 0.4375!
        Me.Label49.HyperLink = Nothing
        Me.Label49.Left = 6.1875!
        Me.Label49.Name = "Label49"
        Me.Label49.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label49.Text = "9. Gross weight or other quantity"
        Me.Label49.Top = 4.375!
        Me.Label49.Width = 0.875!
        '
        'Label50
        '
        Me.Label50.Border.BottomColor = System.Drawing.Color.Black
        Me.Label50.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label50.Border.LeftColor = System.Drawing.Color.Black
        Me.Label50.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label50.Border.RightColor = System.Drawing.Color.Black
        Me.Label50.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label50.Border.TopColor = System.Drawing.Color.Black
        Me.Label50.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label50.Height = 0.3125!
        Me.Label50.HyperLink = Nothing
        Me.Label50.Left = 5.3125!
        Me.Label50.Name = "Label50"
        Me.Label50.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label50.Text = "8. Origin criterion"
        Me.Label50.Top = 4.375!
        Me.Label50.Width = 0.5625!
        '
        'Label51
        '
        Me.Label51.Border.BottomColor = System.Drawing.Color.Black
        Me.Label51.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.LeftColor = System.Drawing.Color.Black
        Me.Label51.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.RightColor = System.Drawing.Color.Black
        Me.Label51.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Border.TopColor = System.Drawing.Color.Black
        Me.Label51.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label51.Height = 0.25!
        Me.Label51.HyperLink = Nothing
        Me.Label51.Left = 5.3125!
        Me.Label51.Name = "Label51"
        Me.Label51.Style = "ddo-char-set: 0; font-size: 6pt; font-family: Times New Roman; "
        Me.Label51.Text = "(see notes overleaf )"
        Me.Label51.Top = 4.6875!
        Me.Label51.Width = 0.5625!
        '
        'Label52
        '
        Me.Label52.Border.BottomColor = System.Drawing.Color.Black
        Me.Label52.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label52.Border.LeftColor = System.Drawing.Color.Black
        Me.Label52.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label52.Border.RightColor = System.Drawing.Color.Black
        Me.Label52.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label52.Border.TopColor = System.Drawing.Color.Black
        Me.Label52.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label52.Height = 0.1875!
        Me.Label52.HyperLink = Nothing
        Me.Label52.Left = 2.1875!
        Me.Label52.Name = "Label52"
        Me.Label52.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label52.Text = "7. Number and kind of packages; description of goods"
        Me.Label52.Top = 4.375!
        Me.Label52.Width = 2.8125!
        '
        'Label53
        '
        Me.Label53.Border.BottomColor = System.Drawing.Color.Black
        Me.Label53.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label53.Border.LeftColor = System.Drawing.Color.Black
        Me.Label53.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label53.Border.RightColor = System.Drawing.Color.Black
        Me.Label53.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label53.Border.TopColor = System.Drawing.Color.Black
        Me.Label53.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label53.Height = 0.4375!
        Me.Label53.HyperLink = Nothing
        Me.Label53.Left = 1.0625!
        Me.Label53.Name = "Label53"
        Me.Label53.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label53.Text = "6. Marks and    numbers on packages "
        Me.Label53.Top = 4.375!
        Me.Label53.Width = 0.875!
        '
        'Label54
        '
        Me.Label54.Border.BottomColor = System.Drawing.Color.Black
        Me.Label54.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label54.Border.LeftColor = System.Drawing.Color.Black
        Me.Label54.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label54.Border.RightColor = System.Drawing.Color.Black
        Me.Label54.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label54.Border.TopColor = System.Drawing.Color.Black
        Me.Label54.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label54.Height = 0.3125!
        Me.Label54.HyperLink = Nothing
        Me.Label54.Left = 0.1875!
        Me.Label54.Name = "Label54"
        Me.Label54.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label54.Text = "5. Item number"
        Me.Label54.Top = 4.375!
        Me.Label54.Width = 0.5625!
        '
        'Line48
        '
        Me.Line48.Border.BottomColor = System.Drawing.Color.Black
        Me.Line48.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line48.Border.LeftColor = System.Drawing.Color.Black
        Me.Line48.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line48.Border.RightColor = System.Drawing.Color.Black
        Me.Line48.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line48.Border.TopColor = System.Drawing.Color.Black
        Me.Line48.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line48.Height = 4.9375!
        Me.Line48.Left = 0.0625!
        Me.Line48.LineWeight = 1.0!
        Me.Line48.Name = "Line48"
        Me.Line48.Top = 0.0625!
        Me.Line48.Width = 0!
        Me.Line48.X1 = 0.0625!
        Me.Line48.X2 = 0.0625!
        Me.Line48.Y1 = 5.0!
        Me.Line48.Y2 = 0.0625!
        '
        'Label55
        '
        Me.Label55.Border.BottomColor = System.Drawing.Color.Black
        Me.Label55.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label55.Border.LeftColor = System.Drawing.Color.Black
        Me.Label55.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label55.Border.RightColor = System.Drawing.Color.Black
        Me.Label55.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label55.Border.TopColor = System.Drawing.Color.Black
        Me.Label55.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label55.Height = 0.1875!
        Me.Label55.HyperLink = Nothing
        Me.Label55.Left = 0.25!
        Me.Label55.Name = "Label55"
        Me.Label55.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label55.Text = "3. Means of transport and route (as far as known)"
        Me.Label55.Top = 2.3125!
        Me.Label55.Width = 3.875!
        '
        'Label56
        '
        Me.Label56.Border.BottomColor = System.Drawing.Color.Black
        Me.Label56.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label56.Border.LeftColor = System.Drawing.Color.Black
        Me.Label56.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label56.Border.RightColor = System.Drawing.Color.Black
        Me.Label56.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label56.Border.TopColor = System.Drawing.Color.Black
        Me.Label56.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label56.Height = 0.1875!
        Me.Label56.HyperLink = Nothing
        Me.Label56.Left = 0.25!
        Me.Label56.Name = "Label56"
        Me.Label56.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label56.Text = "2. Goods consigned to (Consignee's name, address, country)"
        Me.Label56.Top = 1.3125!
        Me.Label56.Width = 4.0!
        '
        'Line49
        '
        Me.Line49.Border.BottomColor = System.Drawing.Color.Black
        Me.Line49.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line49.Border.LeftColor = System.Drawing.Color.Black
        Me.Line49.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line49.Border.RightColor = System.Drawing.Color.Black
        Me.Line49.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line49.Border.TopColor = System.Drawing.Color.Black
        Me.Line49.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line49.Height = 0!
        Me.Line49.Left = 0.0625!
        Me.Line49.LineWeight = 1.0!
        Me.Line49.Name = "Line49"
        Me.Line49.Top = 1.25!
        Me.Line49.Width = 4.25!
        Me.Line49.X1 = 0.0625!
        Me.Line49.X2 = 4.3125!
        Me.Line49.Y1 = 1.25!
        Me.Line49.Y2 = 1.25!
        '
        'Label57
        '
        Me.Label57.Border.BottomColor = System.Drawing.Color.Black
        Me.Label57.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label57.Border.LeftColor = System.Drawing.Color.Black
        Me.Label57.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label57.Border.RightColor = System.Drawing.Color.Black
        Me.Label57.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label57.Border.TopColor = System.Drawing.Color.Black
        Me.Label57.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label57.Height = 0.1875!
        Me.Label57.HyperLink = Nothing
        Me.Label57.Left = 0.25!
        Me.Label57.Name = "Label57"
        Me.Label57.Style = "font-size: 9pt; font-family: Times New Roman; "
        Me.Label57.Text = "1. Goods consigned from (Exporter's business name, address, country)"
        Me.Label57.Top = 0.25!
        Me.Label57.Width = 4.0!
        '
        'Label58
        '
        Me.Label58.Border.BottomColor = System.Drawing.Color.Black
        Me.Label58.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label58.Border.LeftColor = System.Drawing.Color.Black
        Me.Label58.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label58.Border.RightColor = System.Drawing.Color.Black
        Me.Label58.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label58.Border.TopColor = System.Drawing.Color.Black
        Me.Label58.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label58.Height = 0.25!
        Me.Label58.HyperLink = Nothing
        Me.Label58.Left = 4.5!
        Me.Label58.Name = "Label58"
        Me.Label58.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label58.Text = "Reference No."
        Me.Label58.Top = 0.25!
        Me.Label58.Width = 0.875!
        '
        'Label59
        '
        Me.Label59.Border.BottomColor = System.Drawing.Color.Black
        Me.Label59.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label59.Border.LeftColor = System.Drawing.Color.Black
        Me.Label59.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label59.Border.RightColor = System.Drawing.Color.Black
        Me.Label59.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label59.Border.TopColor = System.Drawing.Color.Black
        Me.Label59.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label59.Height = 0.1875!
        Me.Label59.HyperLink = Nothing
        Me.Label59.Left = 4.375!
        Me.Label59.Name = "Label59"
        Me.Label59.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 9.75pt; font-f" &
    "amily: Times New Roman; "
        Me.Label59.Text = "GENERALIZED SYSTEM OF PREFERENCES"
        Me.Label59.Top = 0.5625!
        Me.Label59.Width = 3.6875!
        '
        'Label60
        '
        Me.Label60.Border.BottomColor = System.Drawing.Color.Black
        Me.Label60.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label60.Border.LeftColor = System.Drawing.Color.Black
        Me.Label60.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label60.Border.RightColor = System.Drawing.Color.Black
        Me.Label60.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label60.Border.TopColor = System.Drawing.Color.Black
        Me.Label60.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label60.Height = 0.1875!
        Me.Label60.HyperLink = Nothing
        Me.Label60.Left = 4.375!
        Me.Label60.Name = "Label60"
        Me.Label60.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 12pt; font-fam" &
    "ily: Times New Roman; "
        Me.Label60.Text = "CERTIFICATE OF ORIGIN"
        Me.Label60.Top = 0.8125!
        Me.Label60.Width = 3.6875!
        '
        'Line50
        '
        Me.Line50.Border.BottomColor = System.Drawing.Color.Black
        Me.Line50.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line50.Border.LeftColor = System.Drawing.Color.Black
        Me.Line50.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line50.Border.RightColor = System.Drawing.Color.Black
        Me.Line50.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line50.Border.TopColor = System.Drawing.Color.Black
        Me.Line50.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line50.Height = 4.9375!
        Me.Line50.Left = 8.1875!
        Me.Line50.LineWeight = 1.0!
        Me.Line50.Name = "Line50"
        Me.Line50.Top = 0.0625!
        Me.Line50.Width = 0!
        Me.Line50.X1 = 8.1875!
        Me.Line50.X2 = 8.1875!
        Me.Line50.Y1 = 0.0625!
        Me.Line50.Y2 = 5.0!
        '
        'Line51
        '
        Me.Line51.Border.BottomColor = System.Drawing.Color.Black
        Me.Line51.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line51.Border.LeftColor = System.Drawing.Color.Black
        Me.Line51.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line51.Border.RightColor = System.Drawing.Color.Black
        Me.Line51.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line51.Border.TopColor = System.Drawing.Color.Black
        Me.Line51.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line51.Height = 0!
        Me.Line51.Left = 0.0625!
        Me.Line51.LineWeight = 1.0!
        Me.Line51.Name = "Line51"
        Me.Line51.Top = 0.0625!
        Me.Line51.Width = 8.125!
        Me.Line51.X1 = 0.0625!
        Me.Line51.X2 = 8.1875!
        Me.Line51.Y1 = 0.0625!
        Me.Line51.Y2 = 0.0625!
        '
        'Line52
        '
        Me.Line52.Border.BottomColor = System.Drawing.Color.Black
        Me.Line52.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line52.Border.LeftColor = System.Drawing.Color.Black
        Me.Line52.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line52.Border.RightColor = System.Drawing.Color.Black
        Me.Line52.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line52.Border.TopColor = System.Drawing.Color.Black
        Me.Line52.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line52.Height = 4.1875!
        Me.Line52.Left = 4.3125!
        Me.Line52.LineWeight = 1.0!
        Me.Line52.Name = "Line52"
        Me.Line52.Top = 0.0625!
        Me.Line52.Width = 0!
        Me.Line52.X1 = 4.3125!
        Me.Line52.X2 = 4.3125!
        Me.Line52.Y1 = 4.25!
        Me.Line52.Y2 = 0.0625!
        '
        'Line53
        '
        Me.Line53.Border.BottomColor = System.Drawing.Color.Black
        Me.Line53.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line53.Border.LeftColor = System.Drawing.Color.Black
        Me.Line53.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line53.Border.RightColor = System.Drawing.Color.Black
        Me.Line53.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line53.Border.TopColor = System.Drawing.Color.Black
        Me.Line53.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line53.Height = 0!
        Me.Line53.Left = 0.0625!
        Me.Line53.LineWeight = 1.0!
        Me.Line53.Name = "Line53"
        Me.Line53.Top = 2.25!
        Me.Line53.Width = 8.125!
        Me.Line53.X1 = 0.0625!
        Me.Line53.X2 = 8.1875!
        Me.Line53.Y1 = 2.25!
        Me.Line53.Y2 = 2.25!
        '
        'Line54
        '
        Me.Line54.Border.BottomColor = System.Drawing.Color.Black
        Me.Line54.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line54.Border.LeftColor = System.Drawing.Color.Black
        Me.Line54.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line54.Border.RightColor = System.Drawing.Color.Black
        Me.Line54.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line54.Border.TopColor = System.Drawing.Color.Black
        Me.Line54.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line54.Height = 0!
        Me.Line54.Left = 0.0625!
        Me.Line54.LineWeight = 1.0!
        Me.Line54.Name = "Line54"
        Me.Line54.Top = 4.25!
        Me.Line54.Width = 8.125!
        Me.Line54.X1 = 0.0625!
        Me.Line54.X2 = 8.1875!
        Me.Line54.Y1 = 4.25!
        Me.Line54.Y2 = 4.25!
        '
        'Label61
        '
        Me.Label61.Border.BottomColor = System.Drawing.Color.Black
        Me.Label61.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label61.Border.LeftColor = System.Drawing.Color.Black
        Me.Label61.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label61.Border.RightColor = System.Drawing.Color.Black
        Me.Label61.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label61.Border.TopColor = System.Drawing.Color.Black
        Me.Label61.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label61.Height = 0.4375!
        Me.Label61.HyperLink = Nothing
        Me.Label61.Left = 7.1875!
        Me.Label61.Name = "Label61"
        Me.Label61.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label61.Text = "10. Number and date of invoices"
        Me.Label61.Top = 4.375!
        Me.Label61.Width = 0.8125!
        '
        'Label62
        '
        Me.Label62.Border.BottomColor = System.Drawing.Color.Black
        Me.Label62.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label62.Border.LeftColor = System.Drawing.Color.Black
        Me.Label62.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label62.Border.RightColor = System.Drawing.Color.Black
        Me.Label62.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label62.Border.TopColor = System.Drawing.Color.Black
        Me.Label62.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label62.Height = 0.4375!
        Me.Label62.HyperLink = Nothing
        Me.Label62.Left = 6.1875!
        Me.Label62.Name = "Label62"
        Me.Label62.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label62.Text = "9. Gross weight or other quantity"
        Me.Label62.Top = 4.375!
        Me.Label62.Width = 0.875!
        '
        'Label63
        '
        Me.Label63.Border.BottomColor = System.Drawing.Color.Black
        Me.Label63.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label63.Border.LeftColor = System.Drawing.Color.Black
        Me.Label63.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label63.Border.RightColor = System.Drawing.Color.Black
        Me.Label63.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label63.Border.TopColor = System.Drawing.Color.Black
        Me.Label63.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label63.Height = 0.3125!
        Me.Label63.HyperLink = Nothing
        Me.Label63.Left = 5.3125!
        Me.Label63.Name = "Label63"
        Me.Label63.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label63.Text = "8. Origin criterion"
        Me.Label63.Top = 4.375!
        Me.Label63.Width = 0.5625!
        '
        'Label64
        '
        Me.Label64.Border.BottomColor = System.Drawing.Color.Black
        Me.Label64.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label64.Border.LeftColor = System.Drawing.Color.Black
        Me.Label64.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label64.Border.RightColor = System.Drawing.Color.Black
        Me.Label64.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label64.Border.TopColor = System.Drawing.Color.Black
        Me.Label64.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label64.Height = 0.25!
        Me.Label64.HyperLink = Nothing
        Me.Label64.Left = 5.3125!
        Me.Label64.Name = "Label64"
        Me.Label64.Style = "ddo-char-set: 0; font-size: 6pt; font-family: Times New Roman; "
        Me.Label64.Text = "(see notes overleaf )"
        Me.Label64.Top = 4.6875!
        Me.Label64.Width = 0.5625!
        '
        'Label65
        '
        Me.Label65.Border.BottomColor = System.Drawing.Color.Black
        Me.Label65.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label65.Border.LeftColor = System.Drawing.Color.Black
        Me.Label65.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label65.Border.RightColor = System.Drawing.Color.Black
        Me.Label65.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label65.Border.TopColor = System.Drawing.Color.Black
        Me.Label65.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label65.Height = 0.1875!
        Me.Label65.HyperLink = Nothing
        Me.Label65.Left = 2.1875!
        Me.Label65.Name = "Label65"
        Me.Label65.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label65.Text = "7. Number and kind of packages; description of goods"
        Me.Label65.Top = 4.375!
        Me.Label65.Width = 2.8125!
        '
        'Label66
        '
        Me.Label66.Border.BottomColor = System.Drawing.Color.Black
        Me.Label66.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label66.Border.LeftColor = System.Drawing.Color.Black
        Me.Label66.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label66.Border.RightColor = System.Drawing.Color.Black
        Me.Label66.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label66.Border.TopColor = System.Drawing.Color.Black
        Me.Label66.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label66.Height = 0.4375!
        Me.Label66.HyperLink = Nothing
        Me.Label66.Left = 1.0625!
        Me.Label66.Name = "Label66"
        Me.Label66.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label66.Text = "6. Marks and    numbers on packages "
        Me.Label66.Top = 4.375!
        Me.Label66.Width = 0.875!
        '
        'Label67
        '
        Me.Label67.Border.BottomColor = System.Drawing.Color.Black
        Me.Label67.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label67.Border.LeftColor = System.Drawing.Color.Black
        Me.Label67.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label67.Border.RightColor = System.Drawing.Color.Black
        Me.Label67.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label67.Border.TopColor = System.Drawing.Color.Black
        Me.Label67.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label67.Height = 0.3125!
        Me.Label67.HyperLink = Nothing
        Me.Label67.Left = 0.1875!
        Me.Label67.Name = "Label67"
        Me.Label67.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label67.Text = "5. Item number"
        Me.Label67.Top = 4.375!
        Me.Label67.Width = 0.5625!
        '
        'Line55
        '
        Me.Line55.Border.BottomColor = System.Drawing.Color.Black
        Me.Line55.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line55.Border.LeftColor = System.Drawing.Color.Black
        Me.Line55.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line55.Border.RightColor = System.Drawing.Color.Black
        Me.Line55.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line55.Border.TopColor = System.Drawing.Color.Black
        Me.Line55.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line55.Height = 4.9375!
        Me.Line55.Left = 0.0625!
        Me.Line55.LineWeight = 1.0!
        Me.Line55.Name = "Line55"
        Me.Line55.Top = 0.0625!
        Me.Line55.Width = 0!
        Me.Line55.X1 = 0.0625!
        Me.Line55.X2 = 0.0625!
        Me.Line55.Y1 = 5.0!
        Me.Line55.Y2 = 0.0625!
        '
        'Label68
        '
        Me.Label68.Border.BottomColor = System.Drawing.Color.Black
        Me.Label68.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label68.Border.LeftColor = System.Drawing.Color.Black
        Me.Label68.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label68.Border.RightColor = System.Drawing.Color.Black
        Me.Label68.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label68.Border.TopColor = System.Drawing.Color.Black
        Me.Label68.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label68.Height = 0.1875!
        Me.Label68.HyperLink = Nothing
        Me.Label68.Left = 0.25!
        Me.Label68.Name = "Label68"
        Me.Label68.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label68.Text = "3. Means of transport and route (as far as known)"
        Me.Label68.Top = 2.3125!
        Me.Label68.Width = 3.875!
        '
        'Label69
        '
        Me.Label69.Border.BottomColor = System.Drawing.Color.Black
        Me.Label69.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label69.Border.LeftColor = System.Drawing.Color.Black
        Me.Label69.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label69.Border.RightColor = System.Drawing.Color.Black
        Me.Label69.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label69.Border.TopColor = System.Drawing.Color.Black
        Me.Label69.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label69.Height = 0.1875!
        Me.Label69.HyperLink = Nothing
        Me.Label69.Left = 0.25!
        Me.Label69.Name = "Label69"
        Me.Label69.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label69.Text = "2. Goods consigned to (Consignee's name, address, country)"
        Me.Label69.Top = 1.3125!
        Me.Label69.Width = 4.0!
        '
        'Line56
        '
        Me.Line56.Border.BottomColor = System.Drawing.Color.Black
        Me.Line56.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line56.Border.LeftColor = System.Drawing.Color.Black
        Me.Line56.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line56.Border.RightColor = System.Drawing.Color.Black
        Me.Line56.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line56.Border.TopColor = System.Drawing.Color.Black
        Me.Line56.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line56.Height = 0!
        Me.Line56.Left = 0.0625!
        Me.Line56.LineWeight = 1.0!
        Me.Line56.Name = "Line56"
        Me.Line56.Top = 1.25!
        Me.Line56.Width = 4.25!
        Me.Line56.X1 = 0.0625!
        Me.Line56.X2 = 4.3125!
        Me.Line56.Y1 = 1.25!
        Me.Line56.Y2 = 1.25!
        '
        'Label70
        '
        Me.Label70.Border.BottomColor = System.Drawing.Color.Black
        Me.Label70.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label70.Border.LeftColor = System.Drawing.Color.Black
        Me.Label70.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label70.Border.RightColor = System.Drawing.Color.Black
        Me.Label70.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label70.Border.TopColor = System.Drawing.Color.Black
        Me.Label70.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label70.Height = 0.1875!
        Me.Label70.HyperLink = Nothing
        Me.Label70.Left = 0.25!
        Me.Label70.Name = "Label70"
        Me.Label70.Style = "font-size: 9pt; font-family: Times New Roman; "
        Me.Label70.Text = "1. Goods consigned from (Exporter's business name, address, country)"
        Me.Label70.Top = 0.25!
        Me.Label70.Width = 4.0!
        '
        'Label71
        '
        Me.Label71.Border.BottomColor = System.Drawing.Color.Black
        Me.Label71.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label71.Border.LeftColor = System.Drawing.Color.Black
        Me.Label71.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label71.Border.RightColor = System.Drawing.Color.Black
        Me.Label71.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label71.Border.TopColor = System.Drawing.Color.Black
        Me.Label71.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label71.Height = 0.25!
        Me.Label71.HyperLink = Nothing
        Me.Label71.Left = 4.5!
        Me.Label71.Name = "Label71"
        Me.Label71.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label71.Text = "Reference No."
        Me.Label71.Top = 0.25!
        Me.Label71.Width = 0.875!
        '
        'Label72
        '
        Me.Label72.Border.BottomColor = System.Drawing.Color.Black
        Me.Label72.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label72.Border.LeftColor = System.Drawing.Color.Black
        Me.Label72.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label72.Border.RightColor = System.Drawing.Color.Black
        Me.Label72.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label72.Border.TopColor = System.Drawing.Color.Black
        Me.Label72.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label72.Height = 0.1875!
        Me.Label72.HyperLink = Nothing
        Me.Label72.Left = 4.375!
        Me.Label72.Name = "Label72"
        Me.Label72.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 9.75pt; font-f" &
    "amily: Times New Roman; "
        Me.Label72.Text = "GENERALIZED SYSTEM OF PREFERENCES"
        Me.Label72.Top = 0.5625!
        Me.Label72.Width = 3.6875!
        '
        'Label73
        '
        Me.Label73.Border.BottomColor = System.Drawing.Color.Black
        Me.Label73.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label73.Border.LeftColor = System.Drawing.Color.Black
        Me.Label73.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label73.Border.RightColor = System.Drawing.Color.Black
        Me.Label73.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label73.Border.TopColor = System.Drawing.Color.Black
        Me.Label73.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label73.Height = 0.1875!
        Me.Label73.HyperLink = Nothing
        Me.Label73.Left = 4.375!
        Me.Label73.Name = "Label73"
        Me.Label73.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 12pt; font-fam" &
    "ily: Times New Roman; "
        Me.Label73.Text = "CERTIFICATE OF ORIGIN"
        Me.Label73.Top = 0.8125!
        Me.Label73.Width = 3.6875!
        '
        'Label74
        '
        Me.Label74.Border.BottomColor = System.Drawing.Color.Black
        Me.Label74.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label74.Border.LeftColor = System.Drawing.Color.Black
        Me.Label74.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label74.Border.RightColor = System.Drawing.Color.Black
        Me.Label74.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label74.Border.TopColor = System.Drawing.Color.Black
        Me.Label74.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label74.Height = 0.25!
        Me.Label74.HyperLink = Nothing
        Me.Label74.Left = 4.5!
        Me.Label74.Name = "Label74"
        Me.Label74.Style = "ddo-char-set: 0; text-align: center; font-size: 11.25pt; font-family: Times New R" &
    "oman; "
        Me.Label74.Text = "(Combined Declaration and Certificate)"
        Me.Label74.Top = 1.0625!
        Me.Label74.Width = 3.4375!
        '
        'Label75
        '
        Me.Label75.Border.BottomColor = System.Drawing.Color.Black
        Me.Label75.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label75.Border.LeftColor = System.Drawing.Color.Black
        Me.Label75.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label75.Border.RightColor = System.Drawing.Color.Black
        Me.Label75.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label75.Border.TopColor = System.Drawing.Color.Black
        Me.Label75.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label75.Height = 0.25!
        Me.Label75.HyperLink = Nothing
        Me.Label75.Left = 5.6875!
        Me.Label75.Name = "Label75"
        Me.Label75.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 11.25pt; font-" &
    "family: Times New Roman; "
        Me.Label75.Text = "FORM A"
        Me.Label75.Top = 1.3125!
        Me.Label75.Width = 0.8125!
        '
        'Label76
        '
        Me.Label76.Border.BottomColor = System.Drawing.Color.Black
        Me.Label76.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label76.Border.LeftColor = System.Drawing.Color.Black
        Me.Label76.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label76.Border.RightColor = System.Drawing.Color.Black
        Me.Label76.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label76.Border.TopColor = System.Drawing.Color.Black
        Me.Label76.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label76.Height = 0.25!
        Me.Label76.HyperLink = Nothing
        Me.Label76.Left = 5.6875!
        Me.Label76.Name = "Label76"
        Me.Label76.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 12pt; font-fam" &
    "ily: Times New Roman; "
        Me.Label76.Text = "THAILAND"
        Me.Label76.Top = 1.5!
        Me.Label76.Width = 1.3125!
        '
        'Line57
        '
        Me.Line57.Border.BottomColor = System.Drawing.Color.Black
        Me.Line57.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line57.Border.LeftColor = System.Drawing.Color.Black
        Me.Line57.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line57.Border.RightColor = System.Drawing.Color.Black
        Me.Line57.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line57.Border.TopColor = System.Drawing.Color.Black
        Me.Line57.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line57.Height = 4.9375!
        Me.Line57.Left = 8.1875!
        Me.Line57.LineWeight = 1.0!
        Me.Line57.Name = "Line57"
        Me.Line57.Top = 0.0625!
        Me.Line57.Width = 0!
        Me.Line57.X1 = 8.1875!
        Me.Line57.X2 = 8.1875!
        Me.Line57.Y1 = 0.0625!
        Me.Line57.Y2 = 5.0!
        '
        'Line58
        '
        Me.Line58.Border.BottomColor = System.Drawing.Color.Black
        Me.Line58.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line58.Border.LeftColor = System.Drawing.Color.Black
        Me.Line58.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line58.Border.RightColor = System.Drawing.Color.Black
        Me.Line58.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line58.Border.TopColor = System.Drawing.Color.Black
        Me.Line58.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line58.Height = 0!
        Me.Line58.Left = 0.0625!
        Me.Line58.LineWeight = 1.0!
        Me.Line58.Name = "Line58"
        Me.Line58.Top = 0.0625!
        Me.Line58.Width = 8.125!
        Me.Line58.X1 = 0.0625!
        Me.Line58.X2 = 8.1875!
        Me.Line58.Y1 = 0.0625!
        Me.Line58.Y2 = 0.0625!
        '
        'Line59
        '
        Me.Line59.Border.BottomColor = System.Drawing.Color.Black
        Me.Line59.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line59.Border.LeftColor = System.Drawing.Color.Black
        Me.Line59.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line59.Border.RightColor = System.Drawing.Color.Black
        Me.Line59.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line59.Border.TopColor = System.Drawing.Color.Black
        Me.Line59.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line59.Height = 4.1875!
        Me.Line59.Left = 4.3125!
        Me.Line59.LineWeight = 1.0!
        Me.Line59.Name = "Line59"
        Me.Line59.Top = 0.0625!
        Me.Line59.Width = 0!
        Me.Line59.X1 = 4.3125!
        Me.Line59.X2 = 4.3125!
        Me.Line59.Y1 = 4.25!
        Me.Line59.Y2 = 0.0625!
        '
        'Line60
        '
        Me.Line60.Border.BottomColor = System.Drawing.Color.Black
        Me.Line60.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line60.Border.LeftColor = System.Drawing.Color.Black
        Me.Line60.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line60.Border.RightColor = System.Drawing.Color.Black
        Me.Line60.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line60.Border.TopColor = System.Drawing.Color.Black
        Me.Line60.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line60.Height = 0!
        Me.Line60.Left = 0.0625!
        Me.Line60.LineWeight = 1.0!
        Me.Line60.Name = "Line60"
        Me.Line60.Top = 2.25!
        Me.Line60.Width = 8.125!
        Me.Line60.X1 = 0.0625!
        Me.Line60.X2 = 8.1875!
        Me.Line60.Y1 = 2.25!
        Me.Line60.Y2 = 2.25!
        '
        'Line61
        '
        Me.Line61.Border.BottomColor = System.Drawing.Color.Black
        Me.Line61.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line61.Border.LeftColor = System.Drawing.Color.Black
        Me.Line61.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line61.Border.RightColor = System.Drawing.Color.Black
        Me.Line61.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line61.Border.TopColor = System.Drawing.Color.Black
        Me.Line61.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line61.Height = 0!
        Me.Line61.Left = 0.0625!
        Me.Line61.LineWeight = 1.0!
        Me.Line61.Name = "Line61"
        Me.Line61.Top = 4.25!
        Me.Line61.Width = 8.125!
        Me.Line61.X1 = 0.0625!
        Me.Line61.X2 = 8.1875!
        Me.Line61.Y1 = 4.25!
        Me.Line61.Y2 = 4.25!
        '
        'Label77
        '
        Me.Label77.Border.BottomColor = System.Drawing.Color.Black
        Me.Label77.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label77.Border.LeftColor = System.Drawing.Color.Black
        Me.Label77.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label77.Border.RightColor = System.Drawing.Color.Black
        Me.Label77.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label77.Border.TopColor = System.Drawing.Color.Black
        Me.Label77.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label77.Height = 0.4375!
        Me.Label77.HyperLink = Nothing
        Me.Label77.Left = 7.1875!
        Me.Label77.Name = "Label77"
        Me.Label77.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label77.Text = "10. Number and date of invoices"
        Me.Label77.Top = 4.375!
        Me.Label77.Width = 0.8125!
        '
        'Label78
        '
        Me.Label78.Border.BottomColor = System.Drawing.Color.Black
        Me.Label78.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label78.Border.LeftColor = System.Drawing.Color.Black
        Me.Label78.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label78.Border.RightColor = System.Drawing.Color.Black
        Me.Label78.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label78.Border.TopColor = System.Drawing.Color.Black
        Me.Label78.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label78.Height = 0.4375!
        Me.Label78.HyperLink = Nothing
        Me.Label78.Left = 6.1875!
        Me.Label78.Name = "Label78"
        Me.Label78.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label78.Text = "9. Gross weight or other quantity"
        Me.Label78.Top = 4.375!
        Me.Label78.Width = 0.875!
        '
        'Label79
        '
        Me.Label79.Border.BottomColor = System.Drawing.Color.Black
        Me.Label79.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label79.Border.LeftColor = System.Drawing.Color.Black
        Me.Label79.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label79.Border.RightColor = System.Drawing.Color.Black
        Me.Label79.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label79.Border.TopColor = System.Drawing.Color.Black
        Me.Label79.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label79.Height = 0.3125!
        Me.Label79.HyperLink = Nothing
        Me.Label79.Left = 5.3125!
        Me.Label79.Name = "Label79"
        Me.Label79.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label79.Text = "8. Origin criterion"
        Me.Label79.Top = 4.375!
        Me.Label79.Width = 0.5625!
        '
        'Label80
        '
        Me.Label80.Border.BottomColor = System.Drawing.Color.Black
        Me.Label80.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label80.Border.LeftColor = System.Drawing.Color.Black
        Me.Label80.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label80.Border.RightColor = System.Drawing.Color.Black
        Me.Label80.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label80.Border.TopColor = System.Drawing.Color.Black
        Me.Label80.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label80.Height = 0.25!
        Me.Label80.HyperLink = Nothing
        Me.Label80.Left = 5.3125!
        Me.Label80.Name = "Label80"
        Me.Label80.Style = "ddo-char-set: 0; font-size: 6pt; font-family: Times New Roman; "
        Me.Label80.Text = "(see notes overleaf )"
        Me.Label80.Top = 4.6875!
        Me.Label80.Width = 0.5625!
        '
        'Label81
        '
        Me.Label81.Border.BottomColor = System.Drawing.Color.Black
        Me.Label81.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label81.Border.LeftColor = System.Drawing.Color.Black
        Me.Label81.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label81.Border.RightColor = System.Drawing.Color.Black
        Me.Label81.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label81.Border.TopColor = System.Drawing.Color.Black
        Me.Label81.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label81.Height = 0.1875!
        Me.Label81.HyperLink = Nothing
        Me.Label81.Left = 2.1875!
        Me.Label81.Name = "Label81"
        Me.Label81.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label81.Text = "7. Number and kind of packages; description of goods"
        Me.Label81.Top = 4.375!
        Me.Label81.Width = 2.8125!
        '
        'Label82
        '
        Me.Label82.Border.BottomColor = System.Drawing.Color.Black
        Me.Label82.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label82.Border.LeftColor = System.Drawing.Color.Black
        Me.Label82.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label82.Border.RightColor = System.Drawing.Color.Black
        Me.Label82.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label82.Border.TopColor = System.Drawing.Color.Black
        Me.Label82.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label82.Height = 0.4375!
        Me.Label82.HyperLink = Nothing
        Me.Label82.Left = 1.0625!
        Me.Label82.Name = "Label82"
        Me.Label82.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label82.Text = "6. Marks and    numbers on packages "
        Me.Label82.Top = 4.375!
        Me.Label82.Width = 0.875!
        '
        'Label83
        '
        Me.Label83.Border.BottomColor = System.Drawing.Color.Black
        Me.Label83.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label83.Border.LeftColor = System.Drawing.Color.Black
        Me.Label83.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label83.Border.RightColor = System.Drawing.Color.Black
        Me.Label83.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label83.Border.TopColor = System.Drawing.Color.Black
        Me.Label83.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label83.Height = 0.3125!
        Me.Label83.HyperLink = Nothing
        Me.Label83.Left = 0.1875!
        Me.Label83.Name = "Label83"
        Me.Label83.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label83.Text = "5. Item number"
        Me.Label83.Top = 4.375!
        Me.Label83.Width = 0.5625!
        '
        'Line62
        '
        Me.Line62.Border.BottomColor = System.Drawing.Color.Black
        Me.Line62.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line62.Border.LeftColor = System.Drawing.Color.Black
        Me.Line62.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line62.Border.RightColor = System.Drawing.Color.Black
        Me.Line62.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line62.Border.TopColor = System.Drawing.Color.Black
        Me.Line62.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line62.Height = 4.9375!
        Me.Line62.Left = 0.0625!
        Me.Line62.LineWeight = 1.0!
        Me.Line62.Name = "Line62"
        Me.Line62.Top = 0.0625!
        Me.Line62.Width = 0!
        Me.Line62.X1 = 0.0625!
        Me.Line62.X2 = 0.0625!
        Me.Line62.Y1 = 5.0!
        Me.Line62.Y2 = 0.0625!
        '
        'Label84
        '
        Me.Label84.Border.BottomColor = System.Drawing.Color.Black
        Me.Label84.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label84.Border.LeftColor = System.Drawing.Color.Black
        Me.Label84.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label84.Border.RightColor = System.Drawing.Color.Black
        Me.Label84.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label84.Border.TopColor = System.Drawing.Color.Black
        Me.Label84.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label84.Height = 0.1875!
        Me.Label84.HyperLink = Nothing
        Me.Label84.Left = 0.25!
        Me.Label84.Name = "Label84"
        Me.Label84.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label84.Text = "3. Means of transport and route (as far as known)"
        Me.Label84.Top = 2.3125!
        Me.Label84.Width = 3.875!
        '
        'Label85
        '
        Me.Label85.Border.BottomColor = System.Drawing.Color.Black
        Me.Label85.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label85.Border.LeftColor = System.Drawing.Color.Black
        Me.Label85.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label85.Border.RightColor = System.Drawing.Color.Black
        Me.Label85.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label85.Border.TopColor = System.Drawing.Color.Black
        Me.Label85.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label85.Height = 0.1875!
        Me.Label85.HyperLink = Nothing
        Me.Label85.Left = 0.25!
        Me.Label85.Name = "Label85"
        Me.Label85.Style = "ddo-char-set: 0; font-size: 9pt; font-family: Times New Roman; "
        Me.Label85.Text = "2. Goods consigned to (Consignee's name, address, country)"
        Me.Label85.Top = 1.3125!
        Me.Label85.Width = 4.0!
        '
        'Line63
        '
        Me.Line63.Border.BottomColor = System.Drawing.Color.Black
        Me.Line63.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line63.Border.LeftColor = System.Drawing.Color.Black
        Me.Line63.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line63.Border.RightColor = System.Drawing.Color.Black
        Me.Line63.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line63.Border.TopColor = System.Drawing.Color.Black
        Me.Line63.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line63.Height = 0!
        Me.Line63.Left = 0.0625!
        Me.Line63.LineWeight = 1.0!
        Me.Line63.Name = "Line63"
        Me.Line63.Top = 1.25!
        Me.Line63.Width = 4.25!
        Me.Line63.X1 = 0.0625!
        Me.Line63.X2 = 4.3125!
        Me.Line63.Y1 = 1.25!
        Me.Line63.Y2 = 1.25!
        '
        'Label86
        '
        Me.Label86.Border.BottomColor = System.Drawing.Color.Black
        Me.Label86.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label86.Border.LeftColor = System.Drawing.Color.Black
        Me.Label86.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label86.Border.RightColor = System.Drawing.Color.Black
        Me.Label86.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label86.Border.TopColor = System.Drawing.Color.Black
        Me.Label86.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label86.Height = 0.1875!
        Me.Label86.HyperLink = Nothing
        Me.Label86.Left = 0.25!
        Me.Label86.Name = "Label86"
        Me.Label86.Style = "font-size: 9pt; font-family: Times New Roman; "
        Me.Label86.Text = "1. Goods consigned from (Exporter's business name, address, country)"
        Me.Label86.Top = 0.25!
        Me.Label86.Width = 4.0!
        '
        'Label87
        '
        Me.Label87.Border.BottomColor = System.Drawing.Color.Black
        Me.Label87.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label87.Border.LeftColor = System.Drawing.Color.Black
        Me.Label87.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label87.Border.RightColor = System.Drawing.Color.Black
        Me.Label87.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label87.Border.TopColor = System.Drawing.Color.Black
        Me.Label87.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label87.Height = 0.25!
        Me.Label87.HyperLink = Nothing
        Me.Label87.Left = 4.5!
        Me.Label87.Name = "Label87"
        Me.Label87.Style = "ddo-char-set: 0; font-size: 9.75pt; font-family: Times New Roman; "
        Me.Label87.Text = "Reference No."
        Me.Label87.Top = 0.25!
        Me.Label87.Width = 0.875!
        '
        'Label88
        '
        Me.Label88.Border.BottomColor = System.Drawing.Color.Black
        Me.Label88.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label88.Border.LeftColor = System.Drawing.Color.Black
        Me.Label88.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label88.Border.RightColor = System.Drawing.Color.Black
        Me.Label88.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label88.Border.TopColor = System.Drawing.Color.Black
        Me.Label88.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label88.Height = 0.1875!
        Me.Label88.HyperLink = Nothing
        Me.Label88.Left = 4.375!
        Me.Label88.Name = "Label88"
        Me.Label88.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 9.75pt; font-f" &
    "amily: Times New Roman; "
        Me.Label88.Text = "GENERALIZED SYSTEM OF PREFERENCES"
        Me.Label88.Top = 0.5625!
        Me.Label88.Width = 3.6875!
        '
        'Label89
        '
        Me.Label89.Border.BottomColor = System.Drawing.Color.Black
        Me.Label89.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label89.Border.LeftColor = System.Drawing.Color.Black
        Me.Label89.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label89.Border.RightColor = System.Drawing.Color.Black
        Me.Label89.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label89.Border.TopColor = System.Drawing.Color.Black
        Me.Label89.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label89.Height = 0.1875!
        Me.Label89.HyperLink = Nothing
        Me.Label89.Left = 4.375!
        Me.Label89.Name = "Label89"
        Me.Label89.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 12pt; font-fam" &
    "ily: Times New Roman; "
        Me.Label89.Text = "CERTIFICATE OF ORIGIN"
        Me.Label89.Top = 0.8125!
        Me.Label89.Width = 3.6875!
        '
        'Label90
        '
        Me.Label90.Border.BottomColor = System.Drawing.Color.Black
        Me.Label90.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label90.Border.LeftColor = System.Drawing.Color.Black
        Me.Label90.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label90.Border.RightColor = System.Drawing.Color.Black
        Me.Label90.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label90.Border.TopColor = System.Drawing.Color.Black
        Me.Label90.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label90.Height = 0.25!
        Me.Label90.HyperLink = Nothing
        Me.Label90.Left = 4.5!
        Me.Label90.Name = "Label90"
        Me.Label90.Style = "ddo-char-set: 0; text-align: center; font-size: 11.25pt; font-family: Times New R" &
    "oman; "
        Me.Label90.Text = "(Combined Declaration and Certificate)"
        Me.Label90.Top = 1.0625!
        Me.Label90.Width = 3.4375!
        '
        'Label91
        '
        Me.Label91.Border.BottomColor = System.Drawing.Color.Black
        Me.Label91.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label91.Border.LeftColor = System.Drawing.Color.Black
        Me.Label91.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label91.Border.RightColor = System.Drawing.Color.Black
        Me.Label91.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label91.Border.TopColor = System.Drawing.Color.Black
        Me.Label91.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label91.Height = 0.25!
        Me.Label91.HyperLink = Nothing
        Me.Label91.Left = 5.6875!
        Me.Label91.Name = "Label91"
        Me.Label91.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 11.25pt; font-" &
    "family: Times New Roman; "
        Me.Label91.Text = "FORM A"
        Me.Label91.Top = 1.3125!
        Me.Label91.Width = 0.8125!
        '
        'Label92
        '
        Me.Label92.Border.BottomColor = System.Drawing.Color.Black
        Me.Label92.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label92.Border.LeftColor = System.Drawing.Color.Black
        Me.Label92.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label92.Border.RightColor = System.Drawing.Color.Black
        Me.Label92.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label92.Border.TopColor = System.Drawing.Color.Black
        Me.Label92.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label92.Height = 0.25!
        Me.Label92.HyperLink = Nothing
        Me.Label92.Left = 5.6875!
        Me.Label92.Name = "Label92"
        Me.Label92.Style = "ddo-char-set: 0; text-align: center; font-weight: bold; font-size: 12pt; font-fam" &
    "ily: Times New Roman; "
        Me.Label92.Text = "THAILAND"
        Me.Label92.Top = 1.5!
        Me.Label92.Width = 1.3125!
        '
        'Label93
        '
        Me.Label93.Border.BottomColor = System.Drawing.Color.Black
        Me.Label93.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label93.Border.LeftColor = System.Drawing.Color.Black
        Me.Label93.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label93.Border.RightColor = System.Drawing.Color.Black
        Me.Label93.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label93.Border.TopColor = System.Drawing.Color.Black
        Me.Label93.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label93.Height = 0.1875!
        Me.Label93.HyperLink = Nothing
        Me.Label93.Left = 5.8125!
        Me.Label93.Name = "Label93"
        Me.Label93.Style = "text-align: center; font-size: 9pt; font-family: Times New Roman; "
        Me.Label93.Text = "(country)"
        Me.Label93.Top = 1.75!
        Me.Label93.Width = 1.125!
        '
        'Label94
        '
        Me.Label94.Border.BottomColor = System.Drawing.Color.Black
        Me.Label94.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label94.Border.LeftColor = System.Drawing.Color.Black
        Me.Label94.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label94.Border.RightColor = System.Drawing.Color.Black
        Me.Label94.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label94.Border.TopColor = System.Drawing.Color.Black
        Me.Label94.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label94.Height = 0.1875!
        Me.Label94.HyperLink = Nothing
        Me.Label94.Left = 6.1875!
        Me.Label94.Name = "Label94"
        Me.Label94.Style = "text-align: right; font-size: 9pt; font-family: Times New Roman; "
        Me.Label94.Text = "See notes overleaf"
        Me.Label94.Top = 1.9375!
        Me.Label94.Width = 1.625!
        '
        'Line76
        '
        Me.Line76.Border.BottomColor = System.Drawing.Color.Black
        Me.Line76.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line76.Border.LeftColor = System.Drawing.Color.Black
        Me.Line76.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line76.Border.RightColor = System.Drawing.Color.Black
        Me.Line76.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line76.Border.TopColor = System.Drawing.Color.Black
        Me.Line76.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line76.Height = 0!
        Me.Line76.Left = 0.0625!
        Me.Line76.LineWeight = 1.0!
        Me.Line76.Name = "Line76"
        Me.Line76.Top = 0.0625!
        Me.Line76.Width = 8.125!
        Me.Line76.X1 = 0.0625!
        Me.Line76.X2 = 8.1875!
        Me.Line76.Y1 = 0.0625!
        Me.Line76.Y2 = 0.0625!
        '
        'PageFooter1
        '
        Me.PageFooter1.Controls.AddRange(New DataDynamics.ActiveReports.ARControl() {Me.txtIMPORT_COUNTRY, Me.txtcompany_provincefoot, Me.txtcompany_provincefoot1, Me.txtplace_exibition, Me.txtthird_country, Me.txtback_country, Me.txtThaiLand, Me.Line5, Me.Line4, Me.Line1, Me.Line3, Me.Line2, Me.Label9, Me.Label5, Me.Label25, Me.Line20, Me.Line15, Me.Label18, Me.Label15, Me.Line7, Me.Label14, Me.Label13, Me.Line6, Me.Label11, Me.TextBox1, Me.Label12, Me.Label10, Me.Line64, Me.Line65, Me.Line66, Me.Line67, Me.Line68, Me.Line69, Me.Line70, Me.Line71, Me.Label95, Me.Label96, Me.Label97, Me.Label98, Me.Line72, Me.TextBox2, Me.Label99, Me.Label100, Me.Line73, Me.Label101, Me.Line74, Me.Line75, Me.txtinvh_run_auto})
        Me.PageFooter1.Height = 3.381944!
        Me.PageFooter1.Name = "PageFooter1"
        '
        'txtIMPORT_COUNTRY
        '
        Me.txtIMPORT_COUNTRY.Border.BottomColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.LeftColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.RightColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.Border.TopColor = System.Drawing.Color.Black
        Me.txtIMPORT_COUNTRY.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtIMPORT_COUNTRY.CanGrow = False
        Me.txtIMPORT_COUNTRY.DataField = "IMPORT_COUNTRY"
        Me.txtIMPORT_COUNTRY.Height = 0.3937007!
        Me.txtIMPORT_COUNTRY.Left = 4.527559!
        Me.txtIMPORT_COUNTRY.Name = "txtIMPORT_COUNTRY"
        Me.txtIMPORT_COUNTRY.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" &
    "; "
        Me.txtIMPORT_COUNTRY.Text = "IMPORT_COUNTRY"
        Me.txtIMPORT_COUNTRY.Top = 1.968504!
        Me.txtIMPORT_COUNTRY.Width = 3.469488!
        '
        'txtcompany_provincefoot
        '
        Me.txtcompany_provincefoot.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot.CanGrow = False
        Me.txtcompany_provincefoot.Height = 0.3312007!
        Me.txtcompany_provincefoot.Left = 4.5!
        Me.txtcompany_provincefoot.Name = "txtcompany_provincefoot"
        Me.txtcompany_provincefoot.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" &
    "; vertical-align: bottom; "
        Me.txtcompany_provincefoot.Text = Nothing
        Me.txtcompany_provincefoot.Top = 2.5625!
        Me.txtcompany_provincefoot.Width = 3.469488!
        '
        'txtcompany_provincefoot1
        '
        Me.txtcompany_provincefoot1.Border.BottomColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.LeftColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.RightColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.Border.TopColor = System.Drawing.Color.Black
        Me.txtcompany_provincefoot1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtcompany_provincefoot1.DataField = "company_province"
        Me.txtcompany_provincefoot1.Height = 0.1979167!
        Me.txtcompany_provincefoot1.Left = 6.668307!
        Me.txtcompany_provincefoot1.Name = "txtcompany_provincefoot1"
        Me.txtcompany_provincefoot1.Style = "color: Red; "
        Me.txtcompany_provincefoot1.Text = "company_province"
        Me.txtcompany_provincefoot1.Top = 0!
        Me.txtcompany_provincefoot1.Visible = False
        Me.txtcompany_provincefoot1.Width = 1.0!
        '
        'txtplace_exibition
        '
        Me.txtplace_exibition.Border.BottomColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.LeftColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.RightColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.Border.TopColor = System.Drawing.Color.Black
        Me.txtplace_exibition.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtplace_exibition.DataField = "place_exibition"
        Me.txtplace_exibition.Height = 0.1979167!
        Me.txtplace_exibition.Left = 6.668307!
        Me.txtplace_exibition.Name = "txtplace_exibition"
        Me.txtplace_exibition.Style = "color: Red; "
        Me.txtplace_exibition.Text = "place_exibition"
        Me.txtplace_exibition.Top = 0.2604167!
        Me.txtplace_exibition.Visible = False
        Me.txtplace_exibition.Width = 1.0!
        '
        'txtthird_country
        '
        Me.txtthird_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtthird_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtthird_country.DataField = "third_country"
        Me.txtthird_country.Height = 0.1979167!
        Me.txtthird_country.Left = 5.462599!
        Me.txtthird_country.Name = "txtthird_country"
        Me.txtthird_country.Style = "color: Red; "
        Me.txtthird_country.Text = "third_country"
        Me.txtthird_country.Top = 0.0246063!
        Me.txtthird_country.Visible = False
        Me.txtthird_country.Width = 1.0!
        '
        'txtback_country
        '
        Me.txtback_country.Border.BottomColor = System.Drawing.Color.Black
        Me.txtback_country.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.LeftColor = System.Drawing.Color.Black
        Me.txtback_country.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.RightColor = System.Drawing.Color.Black
        Me.txtback_country.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.Border.TopColor = System.Drawing.Color.Black
        Me.txtback_country.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtback_country.DataField = "back_country"
        Me.txtback_country.Height = 0.1979167!
        Me.txtback_country.Left = 5.462599!
        Me.txtback_country.Name = "txtback_country"
        Me.txtback_country.Style = "color: Red; "
        Me.txtback_country.Text = "back_country"
        Me.txtback_country.Top = 0.2952756!
        Me.txtback_country.Visible = False
        Me.txtback_country.Width = 1.0!
        '
        'txtThaiLand
        '
        Me.txtThaiLand.Border.BottomColor = System.Drawing.Color.Black
        Me.txtThaiLand.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtThaiLand.Border.LeftColor = System.Drawing.Color.Black
        Me.txtThaiLand.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtThaiLand.Border.RightColor = System.Drawing.Color.Black
        Me.txtThaiLand.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtThaiLand.Border.TopColor = System.Drawing.Color.Black
        Me.txtThaiLand.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtThaiLand.CanGrow = False
        Me.txtThaiLand.Height = 0.3198819!
        Me.txtThaiLand.Left = 4.995079!
        Me.txtThaiLand.Name = "txtThaiLand"
        Me.txtThaiLand.Style = "ddo-char-set: 222; text-align: center; font-size: 12pt; font-family: BrowalliaUPC" &
    "; vertical-align: bottom; "
        Me.txtThaiLand.Text = "THAILAND"
        Me.txtThaiLand.Top = 1.008858!
        Me.txtThaiLand.Visible = False
        Me.txtThaiLand.Width = 3.001969!
        '
        'Line5
        '
        Me.Line5.Border.BottomColor = System.Drawing.Color.Black
        Me.Line5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.LeftColor = System.Drawing.Color.Black
        Me.Line5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.RightColor = System.Drawing.Color.Black
        Me.Line5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Border.TopColor = System.Drawing.Color.Black
        Me.Line5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line5.Height = 3.3125!
        Me.Line5.Left = 0.0625!
        Me.Line5.LineWeight = 1.0!
        Me.Line5.Name = "Line5"
        Me.Line5.Top = 0!
        Me.Line5.Width = 0!
        Me.Line5.X1 = 0.0625!
        Me.Line5.X2 = 0.0625!
        Me.Line5.Y1 = 0!
        Me.Line5.Y2 = 3.3125!
        '
        'Line4
        '
        Me.Line4.Border.BottomColor = System.Drawing.Color.Black
        Me.Line4.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.LeftColor = System.Drawing.Color.Black
        Me.Line4.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.RightColor = System.Drawing.Color.Black
        Me.Line4.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Border.TopColor = System.Drawing.Color.Black
        Me.Line4.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line4.Height = 0!
        Me.Line4.Left = 0.0625!
        Me.Line4.LineWeight = 1.0!
        Me.Line4.Name = "Line4"
        Me.Line4.Top = 0!
        Me.Line4.Width = 8.125!
        Me.Line4.X1 = 0.0625!
        Me.Line4.X2 = 8.1875!
        Me.Line4.Y1 = 0!
        Me.Line4.Y2 = 0!
        '
        'Line1
        '
        Me.Line1.Border.BottomColor = System.Drawing.Color.Black
        Me.Line1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.LeftColor = System.Drawing.Color.Black
        Me.Line1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.RightColor = System.Drawing.Color.Black
        Me.Line1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Border.TopColor = System.Drawing.Color.Black
        Me.Line1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line1.Height = 3.3125!
        Me.Line1.Left = 4.3125!
        Me.Line1.LineWeight = 1.0!
        Me.Line1.Name = "Line1"
        Me.Line1.Top = 0!
        Me.Line1.Width = 0!
        Me.Line1.X1 = 4.3125!
        Me.Line1.X2 = 4.3125!
        Me.Line1.Y1 = 0!
        Me.Line1.Y2 = 3.3125!
        '
        'Line3
        '
        Me.Line3.Border.BottomColor = System.Drawing.Color.Black
        Me.Line3.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.LeftColor = System.Drawing.Color.Black
        Me.Line3.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.RightColor = System.Drawing.Color.Black
        Me.Line3.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Border.TopColor = System.Drawing.Color.Black
        Me.Line3.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line3.Height = 3.3125!
        Me.Line3.Left = 8.1875!
        Me.Line3.LineWeight = 1.0!
        Me.Line3.Name = "Line3"
        Me.Line3.Top = 0!
        Me.Line3.Width = 0!
        Me.Line3.X1 = 8.1875!
        Me.Line3.X2 = 8.1875!
        Me.Line3.Y1 = 3.3125!
        Me.Line3.Y2 = 0!
        '
        'Line2
        '
        Me.Line2.Border.BottomColor = System.Drawing.Color.Black
        Me.Line2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.LeftColor = System.Drawing.Color.Black
        Me.Line2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.RightColor = System.Drawing.Color.Black
        Me.Line2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Border.TopColor = System.Drawing.Color.Black
        Me.Line2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line2.Height = 0!
        Me.Line2.Left = 0.0625!
        Me.Line2.LineWeight = 1.0!
        Me.Line2.Name = "Line2"
        Me.Line2.Top = 3.3125!
        Me.Line2.Width = 8.125!
        Me.Line2.X1 = 0.0625!
        Me.Line2.X2 = 8.1875!
        Me.Line2.Y1 = 3.3125!
        Me.Line2.Y2 = 3.3125!
        '
        'Label9
        '
        Me.Label9.Border.BottomColor = System.Drawing.Color.Black
        Me.Label9.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.LeftColor = System.Drawing.Color.Black
        Me.Label9.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.RightColor = System.Drawing.Color.Black
        Me.Label9.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Border.TopColor = System.Drawing.Color.Black
        Me.Label9.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label9.Height = 0.375!
        Me.Label9.HyperLink = Nothing
        Me.Label9.Left = 0.5!
        Me.Label9.Name = "Label9"
        Me.Label9.Style = "ddo-char-set: 1; font-size: 9pt; "
        Me.Label9.Text = "It is hereby certified, on the basis of control carried out, that the declaration" &
    " by the exporter is correct."
        Me.Label9.Top = 0.3125!
        Me.Label9.Width = 3.6875!
        '
        'Label5
        '
        Me.Label5.Border.BottomColor = System.Drawing.Color.Black
        Me.Label5.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.LeftColor = System.Drawing.Color.Black
        Me.Label5.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.RightColor = System.Drawing.Color.Black
        Me.Label5.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Border.TopColor = System.Drawing.Color.Black
        Me.Label5.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label5.Height = 0.1875!
        Me.Label5.HyperLink = Nothing
        Me.Label5.Left = 0.25!
        Me.Label5.Name = "Label5"
        Me.Label5.Style = "font-weight: bold; font-size: 9.75pt; "
        Me.Label5.Text = "11. Certification"
        Me.Label5.Top = 0.0625!
        Me.Label5.Width = 1.625!
        '
        'Label25
        '
        Me.Label25.Border.BottomColor = System.Drawing.Color.Black
        Me.Label25.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label25.Border.LeftColor = System.Drawing.Color.Black
        Me.Label25.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label25.Border.RightColor = System.Drawing.Color.Black
        Me.Label25.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label25.Border.TopColor = System.Drawing.Color.Black
        Me.Label25.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label25.Height = 0.1875!
        Me.Label25.HyperLink = Nothing
        Me.Label25.Left = 0.375!
        Me.Label25.Name = "Label25"
        Me.Label25.Style = "ddo-char-set: 0; font-size: 8.25pt; font-family: Times New Roman; "
        Me.Label25.Text = "Place and date, signature and stamp of certifying authority"
        Me.Label25.Top = 2.9375!
        Me.Label25.Width = 3.125!
        '
        'Line20
        '
        Me.Line20.Border.BottomColor = System.Drawing.Color.Black
        Me.Line20.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.LeftColor = System.Drawing.Color.Black
        Me.Line20.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.RightColor = System.Drawing.Color.Black
        Me.Line20.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Border.TopColor = System.Drawing.Color.Black
        Me.Line20.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line20.Height = 0!
        Me.Line20.Left = 0.375!
        Me.Line20.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line20.LineWeight = 1.0!
        Me.Line20.Name = "Line20"
        Me.Line20.Top = 2.875!
        Me.Line20.Width = 3.75!
        Me.Line20.X1 = 0.375!
        Me.Line20.X2 = 4.125!
        Me.Line20.Y1 = 2.875!
        Me.Line20.Y2 = 2.875!
        '
        'Line15
        '
        Me.Line15.Border.BottomColor = System.Drawing.Color.Black
        Me.Line15.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line15.Border.LeftColor = System.Drawing.Color.Black
        Me.Line15.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line15.Border.RightColor = System.Drawing.Color.Black
        Me.Line15.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line15.Border.TopColor = System.Drawing.Color.Black
        Me.Line15.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line15.Height = 0!
        Me.Line15.Left = 4.5!
        Me.Line15.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line15.LineWeight = 1.0!
        Me.Line15.Name = "Line15"
        Me.Line15.Top = 2.875!
        Me.Line15.Width = 3.5625!
        Me.Line15.X1 = 4.5!
        Me.Line15.X2 = 8.0625!
        Me.Line15.Y1 = 2.875!
        Me.Line15.Y2 = 2.875!
        '
        'Label18
        '
        Me.Label18.Border.BottomColor = System.Drawing.Color.Black
        Me.Label18.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label18.Border.LeftColor = System.Drawing.Color.Black
        Me.Label18.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label18.Border.RightColor = System.Drawing.Color.Black
        Me.Label18.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label18.Border.TopColor = System.Drawing.Color.Black
        Me.Label18.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label18.Height = 0.1875!
        Me.Label18.HyperLink = Nothing
        Me.Label18.Left = 4.5!
        Me.Label18.Name = "Label18"
        Me.Label18.Style = "ddo-char-set: 0; font-size: 8.25pt; font-family: Times New Roman; "
        Me.Label18.Text = "Place and date, signature and stamp of certifying authority"
        Me.Label18.Top = 2.875!
        Me.Label18.Width = 3.125!
        '
        'Label15
        '
        Me.Label15.Border.BottomColor = System.Drawing.Color.Black
        Me.Label15.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.LeftColor = System.Drawing.Color.Black
        Me.Label15.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.RightColor = System.Drawing.Color.Black
        Me.Label15.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Border.TopColor = System.Drawing.Color.Black
        Me.Label15.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label15.Height = 0.1875!
        Me.Label15.HyperLink = Nothing
        Me.Label15.Left = 5.5625!
        Me.Label15.Name = "Label15"
        Me.Label15.Style = "text-align: center; font-size: 8.25pt; "
        Me.Label15.Text = "(importing country)"
        Me.Label15.Top = 2.166667!
        Me.Label15.Width = 1.4375!
        '
        'Line7
        '
        Me.Line7.Border.BottomColor = System.Drawing.Color.Black
        Me.Line7.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.LeftColor = System.Drawing.Color.Black
        Me.Line7.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.RightColor = System.Drawing.Color.Black
        Me.Line7.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Border.TopColor = System.Drawing.Color.Black
        Me.Line7.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line7.Height = 0!
        Me.Line7.Left = 4.6875!
        Me.Line7.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line7.LineWeight = 1.0!
        Me.Line7.Name = "Line7"
        Me.Line7.Top = 2.166667!
        Me.Line7.Width = 3.375!
        Me.Line7.X1 = 4.6875!
        Me.Line7.X2 = 8.0625!
        Me.Line7.Y1 = 2.166667!
        Me.Line7.Y2 = 2.166667!
        '
        'Label14
        '
        Me.Label14.Border.BottomColor = System.Drawing.Color.Black
        Me.Label14.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.LeftColor = System.Drawing.Color.Black
        Me.Label14.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.RightColor = System.Drawing.Color.Black
        Me.Label14.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Border.TopColor = System.Drawing.Color.Black
        Me.Label14.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label14.Height = 0.5!
        Me.Label14.HyperLink = Nothing
        Me.Label14.Left = 4.6875!
        Me.Label14.Name = "Label14"
        Me.Label14.Style = "font-size: 9pt; "
        Me.Label14.Text = "and that they comply with the origin requirements specified for those goods in th" &
    "e generalized system of preferences for goods exported to"
        Me.Label14.Top = 1.375!
        Me.Label14.Width = 3.5!
        '
        'Label13
        '
        Me.Label13.Border.BottomColor = System.Drawing.Color.Black
        Me.Label13.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.LeftColor = System.Drawing.Color.Black
        Me.Label13.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.RightColor = System.Drawing.Color.Black
        Me.Label13.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Border.TopColor = System.Drawing.Color.Black
        Me.Label13.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label13.Height = 0.1875!
        Me.Label13.HyperLink = Nothing
        Me.Label13.Left = 6.125!
        Me.Label13.Name = "Label13"
        Me.Label13.Style = "text-align: center; font-size: 8.25pt; "
        Me.Label13.Text = "(country)"
        Me.Label13.Top = 1.125!
        Me.Label13.Width = 0.75!
        '
        'Line6
        '
        Me.Line6.Border.BottomColor = System.Drawing.Color.Black
        Me.Line6.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.LeftColor = System.Drawing.Color.Black
        Me.Line6.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.RightColor = System.Drawing.Color.Black
        Me.Line6.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Border.TopColor = System.Drawing.Color.Black
        Me.Line6.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line6.Height = 0!
        Me.Line6.Left = 5.375!
        Me.Line6.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line6.LineWeight = 1.0!
        Me.Line6.Name = "Line6"
        Me.Line6.Top = 1.125!
        Me.Line6.Width = 2.6875!
        Me.Line6.X1 = 5.375!
        Me.Line6.X2 = 8.0625!
        Me.Line6.Y1 = 1.125!
        Me.Line6.Y2 = 1.125!
        '
        'Label11
        '
        Me.Label11.Border.BottomColor = System.Drawing.Color.Black
        Me.Label11.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.LeftColor = System.Drawing.Color.Black
        Me.Label11.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.RightColor = System.Drawing.Color.Black
        Me.Label11.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Border.TopColor = System.Drawing.Color.Black
        Me.Label11.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label11.Height = 0.1875!
        Me.Label11.HyperLink = Nothing
        Me.Label11.Left = 4.6875!
        Me.Label11.Name = "Label11"
        Me.Label11.Style = "font-size: 9pt; "
        Me.Label11.Text = "Produced in"
        Me.Label11.Top = 1.0!
        Me.Label11.Width = 0.75!
        '
        'TextBox1
        '
        Me.TextBox1.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox1.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox1.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox1.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox1.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox1.CanGrow = False
        Me.TextBox1.Height = 0.3198819!
        Me.TextBox1.Left = 5.0!
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 18pt; font-f" &
    "amily: BrowalliaUPC; vertical-align: bottom; "
        Me.TextBox1.Text = "THAILAND"
        Me.TextBox1.Top = 0.875!
        Me.TextBox1.Width = 3.001969!
        '
        'Label12
        '
        Me.Label12.Border.BottomColor = System.Drawing.Color.Black
        Me.Label12.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.LeftColor = System.Drawing.Color.Black
        Me.Label12.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.RightColor = System.Drawing.Color.Black
        Me.Label12.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Border.TopColor = System.Drawing.Color.Black
        Me.Label12.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label12.Height = 0.375!
        Me.Label12.HyperLink = Nothing
        Me.Label12.Left = 4.6875!
        Me.Label12.Name = "Label12"
        Me.Label12.Style = "font-size: 9pt; "
        Me.Label12.Text = "The undersigned hereby declares that the above details and statements are correct" &
    "; that all the goods were"
        Me.Label12.Top = 0.3125!
        Me.Label12.Width = 3.5!
        '
        'Label10
        '
        Me.Label10.Border.BottomColor = System.Drawing.Color.Black
        Me.Label10.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.LeftColor = System.Drawing.Color.Black
        Me.Label10.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.RightColor = System.Drawing.Color.Black
        Me.Label10.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Border.TopColor = System.Drawing.Color.Black
        Me.Label10.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label10.Height = 0.1875!
        Me.Label10.HyperLink = Nothing
        Me.Label10.Left = 4.4375!
        Me.Label10.Name = "Label10"
        Me.Label10.Style = "font-weight: bold; font-size: 9.75pt; "
        Me.Label10.Text = "12. Declaration by the exporter"
        Me.Label10.Top = 0.0625!
        Me.Label10.Width = 3.375!
        '
        'Line64
        '
        Me.Line64.Border.BottomColor = System.Drawing.Color.Black
        Me.Line64.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line64.Border.LeftColor = System.Drawing.Color.Black
        Me.Line64.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line64.Border.RightColor = System.Drawing.Color.Black
        Me.Line64.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line64.Border.TopColor = System.Drawing.Color.Black
        Me.Line64.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line64.Height = 0!
        Me.Line64.Left = 0.0625!
        Me.Line64.LineWeight = 1.0!
        Me.Line64.Name = "Line64"
        Me.Line64.Top = 0!
        Me.Line64.Width = 8.125!
        Me.Line64.X1 = 0.0625!
        Me.Line64.X2 = 8.1875!
        Me.Line64.Y1 = 0!
        Me.Line64.Y2 = 0!
        '
        'Line65
        '
        Me.Line65.Border.BottomColor = System.Drawing.Color.Black
        Me.Line65.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line65.Border.LeftColor = System.Drawing.Color.Black
        Me.Line65.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line65.Border.RightColor = System.Drawing.Color.Black
        Me.Line65.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line65.Border.TopColor = System.Drawing.Color.Black
        Me.Line65.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line65.Height = 3.3125!
        Me.Line65.Left = 0.0625!
        Me.Line65.LineWeight = 1.0!
        Me.Line65.Name = "Line65"
        Me.Line65.Top = 0!
        Me.Line65.Width = 0!
        Me.Line65.X1 = 0.0625!
        Me.Line65.X2 = 0.0625!
        Me.Line65.Y1 = 0!
        Me.Line65.Y2 = 3.3125!
        '
        'Line66
        '
        Me.Line66.Border.BottomColor = System.Drawing.Color.Black
        Me.Line66.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line66.Border.LeftColor = System.Drawing.Color.Black
        Me.Line66.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line66.Border.RightColor = System.Drawing.Color.Black
        Me.Line66.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line66.Border.TopColor = System.Drawing.Color.Black
        Me.Line66.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line66.Height = 0!
        Me.Line66.Left = 0.0625!
        Me.Line66.LineWeight = 1.0!
        Me.Line66.Name = "Line66"
        Me.Line66.Top = 3.3125!
        Me.Line66.Width = 8.125!
        Me.Line66.X1 = 0.0625!
        Me.Line66.X2 = 8.1875!
        Me.Line66.Y1 = 3.3125!
        Me.Line66.Y2 = 3.3125!
        '
        'Line67
        '
        Me.Line67.Border.BottomColor = System.Drawing.Color.Black
        Me.Line67.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line67.Border.LeftColor = System.Drawing.Color.Black
        Me.Line67.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line67.Border.RightColor = System.Drawing.Color.Black
        Me.Line67.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line67.Border.TopColor = System.Drawing.Color.Black
        Me.Line67.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line67.Height = 0!
        Me.Line67.Left = 0.0625!
        Me.Line67.LineWeight = 1.0!
        Me.Line67.Name = "Line67"
        Me.Line67.Top = 0!
        Me.Line67.Width = 8.125!
        Me.Line67.X1 = 0.0625!
        Me.Line67.X2 = 8.1875!
        Me.Line67.Y1 = 0!
        Me.Line67.Y2 = 0!
        '
        'Line68
        '
        Me.Line68.Border.BottomColor = System.Drawing.Color.Black
        Me.Line68.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line68.Border.LeftColor = System.Drawing.Color.Black
        Me.Line68.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line68.Border.RightColor = System.Drawing.Color.Black
        Me.Line68.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line68.Border.TopColor = System.Drawing.Color.Black
        Me.Line68.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line68.Height = 3.3125!
        Me.Line68.Left = 0.0625!
        Me.Line68.LineWeight = 1.0!
        Me.Line68.Name = "Line68"
        Me.Line68.Top = 0!
        Me.Line68.Width = 0!
        Me.Line68.X1 = 0.0625!
        Me.Line68.X2 = 0.0625!
        Me.Line68.Y1 = 0!
        Me.Line68.Y2 = 3.3125!
        '
        'Line69
        '
        Me.Line69.Border.BottomColor = System.Drawing.Color.Black
        Me.Line69.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line69.Border.LeftColor = System.Drawing.Color.Black
        Me.Line69.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line69.Border.RightColor = System.Drawing.Color.Black
        Me.Line69.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line69.Border.TopColor = System.Drawing.Color.Black
        Me.Line69.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line69.Height = 0!
        Me.Line69.Left = 0.0625!
        Me.Line69.LineWeight = 1.0!
        Me.Line69.Name = "Line69"
        Me.Line69.Top = 3.3125!
        Me.Line69.Width = 8.125!
        Me.Line69.X1 = 0.0625!
        Me.Line69.X2 = 8.1875!
        Me.Line69.Y1 = 3.3125!
        Me.Line69.Y2 = 3.3125!
        '
        'Line70
        '
        Me.Line70.Border.BottomColor = System.Drawing.Color.Black
        Me.Line70.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line70.Border.LeftColor = System.Drawing.Color.Black
        Me.Line70.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line70.Border.RightColor = System.Drawing.Color.Black
        Me.Line70.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line70.Border.TopColor = System.Drawing.Color.Black
        Me.Line70.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line70.Height = 3.3125!
        Me.Line70.Left = 4.3125!
        Me.Line70.LineWeight = 1.0!
        Me.Line70.Name = "Line70"
        Me.Line70.Top = 0!
        Me.Line70.Width = 0!
        Me.Line70.X1 = 4.3125!
        Me.Line70.X2 = 4.3125!
        Me.Line70.Y1 = 0!
        Me.Line70.Y2 = 3.3125!
        '
        'Line71
        '
        Me.Line71.Border.BottomColor = System.Drawing.Color.Black
        Me.Line71.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line71.Border.LeftColor = System.Drawing.Color.Black
        Me.Line71.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line71.Border.RightColor = System.Drawing.Color.Black
        Me.Line71.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line71.Border.TopColor = System.Drawing.Color.Black
        Me.Line71.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line71.Height = 3.3125!
        Me.Line71.Left = 8.1875!
        Me.Line71.LineWeight = 1.0!
        Me.Line71.Name = "Line71"
        Me.Line71.Top = 0!
        Me.Line71.Width = 0!
        Me.Line71.X1 = 8.1875!
        Me.Line71.X2 = 8.1875!
        Me.Line71.Y1 = 3.3125!
        Me.Line71.Y2 = 0!
        '
        'Label95
        '
        Me.Label95.Border.BottomColor = System.Drawing.Color.Black
        Me.Label95.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label95.Border.LeftColor = System.Drawing.Color.Black
        Me.Label95.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label95.Border.RightColor = System.Drawing.Color.Black
        Me.Label95.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label95.Border.TopColor = System.Drawing.Color.Black
        Me.Label95.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label95.Height = 0.1875!
        Me.Label95.HyperLink = Nothing
        Me.Label95.Left = 4.4375!
        Me.Label95.Name = "Label95"
        Me.Label95.Style = "font-weight: bold; font-size: 9.75pt; "
        Me.Label95.Text = "12. Declaration by the exporter"
        Me.Label95.Top = 0.0625!
        Me.Label95.Width = 3.375!
        '
        'Label96
        '
        Me.Label96.Border.BottomColor = System.Drawing.Color.Black
        Me.Label96.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label96.Border.LeftColor = System.Drawing.Color.Black
        Me.Label96.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label96.Border.RightColor = System.Drawing.Color.Black
        Me.Label96.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label96.Border.TopColor = System.Drawing.Color.Black
        Me.Label96.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label96.Height = 0.375!
        Me.Label96.HyperLink = Nothing
        Me.Label96.Left = 4.6875!
        Me.Label96.Name = "Label96"
        Me.Label96.Style = "font-size: 9pt; "
        Me.Label96.Text = "The undersigned hereby declares that the above details and statements are correct" &
    "; that all the goods were"
        Me.Label96.Top = 0.3125!
        Me.Label96.Width = 3.5!
        '
        'Label97
        '
        Me.Label97.Border.BottomColor = System.Drawing.Color.Black
        Me.Label97.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label97.Border.LeftColor = System.Drawing.Color.Black
        Me.Label97.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label97.Border.RightColor = System.Drawing.Color.Black
        Me.Label97.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label97.Border.TopColor = System.Drawing.Color.Black
        Me.Label97.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label97.Height = 0.1875!
        Me.Label97.HyperLink = Nothing
        Me.Label97.Left = 6.125!
        Me.Label97.Name = "Label97"
        Me.Label97.Style = "text-align: center; font-size: 8.25pt; "
        Me.Label97.Text = "(country)"
        Me.Label97.Top = 1.125!
        Me.Label97.Width = 0.75!
        '
        'Label98
        '
        Me.Label98.Border.BottomColor = System.Drawing.Color.Black
        Me.Label98.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label98.Border.LeftColor = System.Drawing.Color.Black
        Me.Label98.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label98.Border.RightColor = System.Drawing.Color.Black
        Me.Label98.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label98.Border.TopColor = System.Drawing.Color.Black
        Me.Label98.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label98.Height = 0.1875!
        Me.Label98.HyperLink = Nothing
        Me.Label98.Left = 4.6875!
        Me.Label98.Name = "Label98"
        Me.Label98.Style = "font-size: 9pt; "
        Me.Label98.Text = "Produced in"
        Me.Label98.Top = 1.0!
        Me.Label98.Width = 0.75!
        '
        'Line72
        '
        Me.Line72.Border.BottomColor = System.Drawing.Color.Black
        Me.Line72.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line72.Border.LeftColor = System.Drawing.Color.Black
        Me.Line72.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line72.Border.RightColor = System.Drawing.Color.Black
        Me.Line72.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line72.Border.TopColor = System.Drawing.Color.Black
        Me.Line72.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line72.Height = 0!
        Me.Line72.Left = 5.375!
        Me.Line72.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line72.LineWeight = 1.0!
        Me.Line72.Name = "Line72"
        Me.Line72.Top = 1.125!
        Me.Line72.Width = 2.6875!
        Me.Line72.X1 = 5.375!
        Me.Line72.X2 = 8.0625!
        Me.Line72.Y1 = 1.125!
        Me.Line72.Y2 = 1.125!
        '
        'TextBox2
        '
        Me.TextBox2.Border.BottomColor = System.Drawing.Color.Black
        Me.TextBox2.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.LeftColor = System.Drawing.Color.Black
        Me.TextBox2.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.RightColor = System.Drawing.Color.Black
        Me.TextBox2.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.Border.TopColor = System.Drawing.Color.Black
        Me.TextBox2.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.TextBox2.CanGrow = False
        Me.TextBox2.Height = 0.3198819!
        Me.TextBox2.Left = 5.0!
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Style = "ddo-char-set: 222; text-align: center; font-weight: bold; font-size: 18pt; font-f" &
    "amily: BrowalliaUPC; vertical-align: bottom; "
        Me.TextBox2.Text = "THAILAND"
        Me.TextBox2.Top = 0.875!
        Me.TextBox2.Width = 3.001969!
        '
        'Label99
        '
        Me.Label99.Border.BottomColor = System.Drawing.Color.Black
        Me.Label99.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label99.Border.LeftColor = System.Drawing.Color.Black
        Me.Label99.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label99.Border.RightColor = System.Drawing.Color.Black
        Me.Label99.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label99.Border.TopColor = System.Drawing.Color.Black
        Me.Label99.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label99.Height = 0.5!
        Me.Label99.HyperLink = Nothing
        Me.Label99.Left = 4.6875!
        Me.Label99.Name = "Label99"
        Me.Label99.Style = "font-size: 9pt; "
        Me.Label99.Text = "and that they comply with the origin requirements specified for those goods in th" &
    "e generalized system of preferences for goods exported to"
        Me.Label99.Top = 1.375!
        Me.Label99.Width = 3.5!
        '
        'Label100
        '
        Me.Label100.Border.BottomColor = System.Drawing.Color.Black
        Me.Label100.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label100.Border.LeftColor = System.Drawing.Color.Black
        Me.Label100.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label100.Border.RightColor = System.Drawing.Color.Black
        Me.Label100.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label100.Border.TopColor = System.Drawing.Color.Black
        Me.Label100.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label100.Height = 0.1875!
        Me.Label100.HyperLink = Nothing
        Me.Label100.Left = 5.5625!
        Me.Label100.Name = "Label100"
        Me.Label100.Style = "text-align: center; font-size: 8.25pt; "
        Me.Label100.Text = "(importing country)"
        Me.Label100.Top = 2.1875!
        Me.Label100.Width = 1.4375!
        '
        'Line73
        '
        Me.Line73.Border.BottomColor = System.Drawing.Color.Black
        Me.Line73.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line73.Border.LeftColor = System.Drawing.Color.Black
        Me.Line73.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line73.Border.RightColor = System.Drawing.Color.Black
        Me.Line73.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line73.Border.TopColor = System.Drawing.Color.Black
        Me.Line73.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line73.Height = 0!
        Me.Line73.Left = 4.6875!
        Me.Line73.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line73.LineWeight = 1.0!
        Me.Line73.Name = "Line73"
        Me.Line73.Top = 2.1875!
        Me.Line73.Width = 3.375!
        Me.Line73.X1 = 4.6875!
        Me.Line73.X2 = 8.0625!
        Me.Line73.Y1 = 2.1875!
        Me.Line73.Y2 = 2.1875!
        '
        'Label101
        '
        Me.Label101.Border.BottomColor = System.Drawing.Color.Black
        Me.Label101.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label101.Border.LeftColor = System.Drawing.Color.Black
        Me.Label101.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label101.Border.RightColor = System.Drawing.Color.Black
        Me.Label101.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label101.Border.TopColor = System.Drawing.Color.Black
        Me.Label101.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Label101.Height = 0.1875!
        Me.Label101.HyperLink = Nothing
        Me.Label101.Left = 4.5!
        Me.Label101.Name = "Label101"
        Me.Label101.Style = "ddo-char-set: 0; font-size: 8.25pt; font-family: Times New Roman; "
        Me.Label101.Text = "Place and date, signature and stamp of certifying authority"
        Me.Label101.Top = 2.875!
        Me.Label101.Width = 3.125!
        '
        'Line74
        '
        Me.Line74.Border.BottomColor = System.Drawing.Color.Black
        Me.Line74.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line74.Border.LeftColor = System.Drawing.Color.Black
        Me.Line74.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line74.Border.RightColor = System.Drawing.Color.Black
        Me.Line74.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line74.Border.TopColor = System.Drawing.Color.Black
        Me.Line74.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line74.Height = 0!
        Me.Line74.Left = 4.5!
        Me.Line74.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line74.LineWeight = 1.0!
        Me.Line74.Name = "Line74"
        Me.Line74.Top = 2.875!
        Me.Line74.Width = 3.5625!
        Me.Line74.X1 = 4.5!
        Me.Line74.X2 = 8.0625!
        Me.Line74.Y1 = 2.875!
        Me.Line74.Y2 = 2.875!
        '
        'Line75
        '
        Me.Line75.Border.BottomColor = System.Drawing.Color.Black
        Me.Line75.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line75.Border.LeftColor = System.Drawing.Color.Black
        Me.Line75.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line75.Border.RightColor = System.Drawing.Color.Black
        Me.Line75.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line75.Border.TopColor = System.Drawing.Color.Black
        Me.Line75.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.Line75.Height = 0!
        Me.Line75.Left = 0.375!
        Me.Line75.LineStyle = DataDynamics.ActiveReports.LineStyle.Dot
        Me.Line75.LineWeight = 1.0!
        Me.Line75.Name = "Line75"
        Me.Line75.Top = 2.875!
        Me.Line75.Width = 3.75!
        Me.Line75.X1 = 0.375!
        Me.Line75.X2 = 4.125!
        Me.Line75.Y1 = 2.875!
        Me.Line75.Y2 = 2.875!
        '
        'txtinvh_run_auto
        '
        Me.txtinvh_run_auto.Border.BottomColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.BottomStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.LeftColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.LeftStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.RightColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.RightStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.Border.TopColor = System.Drawing.Color.Black
        Me.txtinvh_run_auto.Border.TopStyle = DataDynamics.ActiveReports.BorderLineStyle.None
        Me.txtinvh_run_auto.DataField = "invh_run_auto"
        Me.txtinvh_run_auto.Height = 0.1979167!
        Me.txtinvh_run_auto.Left = 0.5!
        Me.txtinvh_run_auto.Name = "txtinvh_run_auto"
        Me.txtinvh_run_auto.Style = "color: Red; "
        Me.txtinvh_run_auto.Text = "invh_run_auto"
        Me.txtinvh_run_auto.Top = 0.75!
        Me.txtinvh_run_auto.Visible = False
        Me.txtinvh_run_auto.Width = 1.0!
        '
        'rpt3_ediFORM1_2
        '
        Me.MasterReport = False
        Me.PageSettings.DefaultPaperSource = False
        Me.PageSettings.Margins.Bottom = 0!
        Me.PageSettings.Margins.Left = 0!
        Me.PageSettings.Margins.Right = 0!
        Me.PageSettings.Margins.Top = 0!
        Me.PageSettings.PaperHeight = 11.69!
        Me.PageSettings.PaperSource = System.Drawing.Printing.PaperSourceKind.FormSource
        Me.PageSettings.PaperWidth = 8.27!
        Me.PrintWidth = 8.382298!
        Me.Script = "public bool ActiveReport_FetchData(bool eof)" & Global.Microsoft.VisualBasic.ChrW(10) & "{" & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(9) & "return eof;" & Global.Microsoft.VisualBasic.ChrW(10) & "}"
        Me.Sections.Add(Me.PageHeader1)
        Me.Sections.Add(Me.Detail1)
        Me.Sections.Add(Me.PageFooter1)
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Arial; font-style: normal; text-decoration: none; font-weight: norma" &
            "l; font-size: 10pt; color: Black; ddo-char-set: 204; ", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 16pt; font-weight: bold; ", "Heading1", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-family: Times New Roman; font-size: 14pt; font-weight: bold; font-style: ita" &
            "lic; ", "Heading2", "Normal"))
        Me.StyleSheet.Add(New DDCssLib.StyleSheetRule("font-size: 13pt; font-weight: bold; ", "Heading3", "Normal"))
        CType(Me.txtNumRowCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_marks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtT_product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTemp_box8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgross_weight1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTolInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_no5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvoice_date5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgross_weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtmarks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_n1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_n2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtquantity5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtq_unit_code5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtg_unit_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C_TotalRowDe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotal_net_weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtbox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSum_Gross_Weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSum_g_Unit_Desc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrossTxt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtWeightDisplayHeaderH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtnet_weight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtunit_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNumInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttariff_code, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFOBDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgross_weightH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtfob_amt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtproduct_description, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompany_Check_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtreference_code2_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_Check2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txttransport_by, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_taxno, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_name, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtob_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_remark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_company, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_fax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_phone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_province, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_Receive_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtreference_code2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdigit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdigit2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_email, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_email, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdestination_taxid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdest_remark1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtob_dest_address, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNewEmail_ch01, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNewEmail_ch02, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReportInfo1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label60, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label61, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label67, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label69, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label70, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label71, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label77, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label79, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label80, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label81, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label89, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label90, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label91, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtIMPORT_COUNTRY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_provincefoot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtcompany_provincefoot1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtplace_exibition, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtthird_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtback_country, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtThaiLand, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label98, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label101, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtinvh_run_auto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Friend WithEvents Detail1 As DataDynamics.ActiveReports.Detail
    Friend WithEvents txtNumRowCount As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_marks As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtT_product As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTemp_box8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtgross_weight1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTolInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_no5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtinvoice_date5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtgross_weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtmarks As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_n1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_n2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code3 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code4 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtquantity5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtq_unit_code5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtg_unit_code As DataDynamics.ActiveReports.TextBox
    Public WithEvents C_TotalRowDe As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtTotal_net_weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtbox8 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtSum_Gross_Weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtSum_g_Unit_Desc As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtGrossTxt As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtWeightDisplayHeaderH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtnet_weight As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtunit_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNumInvoice As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttariff_code As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtFOBDisplay As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtgross_weightH As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtfob_amt As DataDynamics.ActiveReports.TextBox
    Friend WithEvents PageHeader1 As DataDynamics.ActiveReports.PageHeader
    Friend WithEvents txtCompany_Check_1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtreference_code2_Temp As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_Check2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txttransport_by As DataDynamics.ActiveReports.TextBox
    Friend WithEvents TextBox5 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_taxno As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_name As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtob_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_remark As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_company As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_fax As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_phone As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_province As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_Receive_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtreference_code2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdigit1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdigit2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_email As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_email As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdestination_taxid As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtdest_remark1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtob_dest_address As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNewEmail_ch01 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtNewEmail_ch02 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents ReportInfo1 As DataDynamics.ActiveReports.ReportInfo
    Friend WithEvents PageFooter1 As DataDynamics.ActiveReports.PageFooter
    Friend WithEvents txtIMPORT_COUNTRY As DataDynamics.ActiveReports.TextBox
    Public WithEvents txtcompany_provincefoot As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtcompany_provincefoot1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtplace_exibition As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtthird_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtback_country As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtThaiLand As DataDynamics.ActiveReports.TextBox
    Friend WithEvents txtproduct_description As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Line17 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line16 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line21 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line22 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line18 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line23 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line13 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line5 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line4 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line1 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line3 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line2 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label9 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label5 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label25 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line20 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line15 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label18 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label15 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line7 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label14 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label13 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line6 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label11 As DataDynamics.ActiveReports.Label
    Friend WithEvents TextBox1 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Label12 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label10 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label8 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label1 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label3 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label42 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label43 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label44 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label46 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label45 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label47 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label48 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label6 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label19 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line19 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label17 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label4 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label21 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label22 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label20 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label16 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label2 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label7 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line8 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line9 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line10 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line11 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line12 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line14 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line24 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line25 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label23 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line26 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line27 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line28 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line29 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line30 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label24 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line31 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line32 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line33 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line34 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line35 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label26 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label27 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label28 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line36 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line37 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line38 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line39 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line40 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label29 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label30 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label31 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label32 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label33 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label34 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label35 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line41 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label36 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label37 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line42 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label38 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label39 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label40 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line43 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line44 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line45 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line46 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line47 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label41 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label49 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label50 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label51 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label52 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label53 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label54 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line48 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label55 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label56 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line49 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label57 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label58 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label59 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label60 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line50 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line51 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line52 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line53 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line54 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label61 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label62 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label63 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label64 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label65 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label66 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label67 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line55 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label68 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label69 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line56 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label70 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label71 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label72 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label73 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label74 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label75 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label76 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line57 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line58 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line59 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line60 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line61 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label77 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label78 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label79 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label80 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label81 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label82 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label83 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line62 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label84 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label85 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line63 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label86 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label87 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label88 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label89 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label90 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label91 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label92 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label93 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label94 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line64 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line65 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line66 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line67 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line68 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line69 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line70 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line71 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label95 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label96 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label97 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label98 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line72 As DataDynamics.ActiveReports.Line
    Friend WithEvents TextBox2 As DataDynamics.ActiveReports.TextBox
    Friend WithEvents Label99 As DataDynamics.ActiveReports.Label
    Friend WithEvents Label100 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line73 As DataDynamics.ActiveReports.Line
    Friend WithEvents Label101 As DataDynamics.ActiveReports.Label
    Friend WithEvents Line74 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line75 As DataDynamics.ActiveReports.Line
    Friend WithEvents Line76 As DataDynamics.ActiveReports.Line
    Friend WithEvents txtinvh_run_auto As DataDynamics.ActiveReports.TextBox
End Class
